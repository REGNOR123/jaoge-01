using Microsoft.Extensions.Caching.Memory;

namespace Text_To_Speeches_Dotnet_BE.Middleware;

public sealed class BotDetectionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IMemoryCache _cache;
    private readonly ILogger<BotDetectionMiddleware> _logger;

    private static readonly HashSet<string> BlockedUserAgentPatterns = new(StringComparer.OrdinalIgnoreCase)
    {
        "bot", "crawler", "spider", "scraper", "seeker", "curl", "wget", "python",
        "java(?!script)", "perl", "ruby", "php", "go-http-client", "httpclient",
        "axios", "scrapy", "selenium", "puppeteer", "playwright", "headlesschrome",
        "apachebench", "wrk", "loadrunner", "jmeter", "nessus", "masscan",
        "nmap", "sqlmap", "metasploit", "nikto", "openvas", "burp", "zap"
    };

    private static readonly HashSet<string> AllowedBots = new(StringComparer.OrdinalIgnoreCase)
    {
        "googlebot", "bingbot", "slurp", "duckduckbot", "baiduspider", "yandexbot",
        "facebookexternalhit", "linkedinbot", "twitterbot", "whatsapp", "telegrambot"
    };

    public BotDetectionMiddleware(
        RequestDelegate next,
        IMemoryCache cache,
        ILogger<BotDetectionMiddleware> logger)
    {
        _next = next;
        _cache = cache;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var ip = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var userAgent = context.Request.Headers.UserAgent.ToString() ?? "";
        var path = context.Request.Path.ToString();

        // Check if IP is flagged as bot
        if (IsKnownBot(ip))
        {
            _logger.LogWarning("Blocked bot request from IP {Ip} to {Path}", ip, path);
            await RespondWithChallengeAsync(context, "bot_detection");
            return;
        }

        // Analyze User-Agent
        var botDetectionResult = AnalyzeUserAgent(userAgent);
        if (botDetectionResult.IsBot && !botDetectionResult.IsWhitelisted)
        {
            _logger.LogWarning(
                "Detected bot User-Agent from IP {Ip}: {UserAgent} (confidence: {Confidence}%)",
                ip, userAgent, botDetectionResult.Confidence);

            // Track bot attempts
            var botAttemptKey = $"bot_attempts:{ip}";
            var attempts = _cache.GetOrCreate(botAttemptKey, entry =>
            {
                entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(1);
                return 1;
            });

            if (attempts >= 3)
            {
                _cache.Set($"blocked_bot:{ip}", true, TimeSpan.FromHours(1));
                _logger.LogWarning("Bot IP {Ip} blocked for 1 hour after {Attempts} attempts", ip, attempts);
            }
            else
            {
                _cache.Set(botAttemptKey, attempts + 1, TimeSpan.FromMinutes(1));
            }

            await RespondWithChallengeAsync(context, "suspicious_agent");
            return;
        }

        // Check for suspicious request patterns
        if (IsSuspiciousRequest(context))
        {
            _logger.LogWarning("Suspicious request pattern from IP {Ip} to {Path}", ip, path);
            var suspiciousKey = $"suspicious:{ip}";
            var suspiciousCount = _cache.GetOrCreate(suspiciousKey, entry =>
            {
                entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5);
                return 1;
            });

            if (suspiciousCount >= 5)
            {
                _cache.Set($"blocked_bot:{ip}", true, TimeSpan.FromHours(2));
            }
            else
            {
                _cache.Set(suspiciousKey, suspiciousCount + 1, TimeSpan.FromMinutes(5));
            }
        }

        await _next(context);
    }

    private BotDetectionResult AnalyzeUserAgent(string userAgent)
    {
        if (string.IsNullOrEmpty(userAgent))
            return new BotDetectionResult { IsBot = true, Confidence = 90 };

        var ua = userAgent.ToLowerInvariant();

        // Check whitelist first
        foreach (var allowed in AllowedBots)
        {
            if (ua.Contains(allowed))
                return new BotDetectionResult { IsBot = true, IsWhitelisted = true, Confidence = 100 };
        }

        // Check blocked patterns
        var matchedPatterns = 0;
        foreach (var pattern in BlockedUserAgentPatterns)
        {
            if (ua.Contains(pattern))
                matchedPatterns++;
        }

        if (matchedPatterns >= 2)
            return new BotDetectionResult { IsBot = true, Confidence = 100 };

        if (matchedPatterns == 1)
            return new BotDetectionResult { IsBot = true, Confidence = 75 };

        // Additional heuristics
        if (ua.Length < 20 && ua.Length > 0)
            return new BotDetectionResult { IsBot = true, Confidence = 60 };

        if (ua.Contains("like gecko") && !ua.Contains("mozilla"))
            return new BotDetectionResult { IsBot = true, Confidence = 70 };

        return new BotDetectionResult { IsBot = false, Confidence = 0 };
    }

    private bool IsSuspiciousRequest(HttpContext context)
    {
        var queryString = context.Request.QueryString.ToString();
        var headers = context.Request.Headers;

        // Missing common headers
        var acceptHeader = headers.Accept.ToString();
        var acceptLanguageHeader = headers.AcceptLanguage.ToString();
        var acceptEncodingHeader = headers.AcceptEncoding.ToString();

        if (string.IsNullOrEmpty(acceptHeader) && string.IsNullOrEmpty(acceptLanguageHeader))
            return true;

        // Suspicious query patterns
        if (queryString.Contains("union") || queryString.Contains("select") ||
            queryString.Contains("drop") || queryString.Contains("script"))
            return true;

        // Multiple encoding or obfuscation attempts
        if (queryString.Contains("%") && queryString.Length > queryString.Replace("%", "").Length * 2)
            return true;

        return false;
    }

    private bool IsKnownBot(string ip)
    {
        var cacheKey = $"blocked_bot:{ip}";
        if (_cache.TryGetValue(cacheKey, out bool blocked))
            return blocked;

        return false;
    }

    private async Task RespondWithChallengeAsync(HttpContext context, string reason)
    {
        context.Response.StatusCode = StatusCodes.Status429TooManyRequests;
        context.Response.ContentType = "application/json";
        context.Response.Headers["Retry-After"] = "3600";

        var response = new
        {
            success = false,
            error = "Too many requests. Please try again later.",
            reason
        };

        await context.Response.WriteAsJsonAsync(response);
    }

    private class BotDetectionResult
    {
        public bool IsBot { get; set; }
        public bool IsWhitelisted { get; set; }
        public int Confidence { get; set; }
    }
}
