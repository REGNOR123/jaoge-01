using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Credits;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Authorize]
[Route("api/credits")]
public sealed class CreditController : BaseApiController
{
    private readonly ICreditService _creditService;
    private readonly ILogger<CreditController> _logger;

    public CreditController(ICreditService creditService, ILogger<CreditController> logger)
    {
        _creditService = creditService;
        _logger = logger;
    }

    [HttpGet("balance")]
    public async Task<ActionResult<ApiResponse<object>>> GetBalance(CancellationToken cancellationToken)
    {
        try
        {
            var userId = GetRequiredUserId();
            var balance = await _creditService.GetBalanceAsync(userId, cancellationToken);
            return Ok(ApiResponse<object>.Ok(new { balance }));
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(ApiResponse<object>.Fail("Authentication required."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching credit balance");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Failed to fetch credit balance."));
        }
    }

    [HttpPost("deduct-voice-preview")]
    public async Task<ActionResult<ApiResponse<object>>> DeductVoicePreview(CancellationToken cancellationToken)
    {
        try
        {
            var userId = GetRequiredUserId();
            var (success, newBalance) = await _creditService.DeductCreditsAsync(
                userId, "voice-preview", 1, "Voice preview (per 2 previews)", cancellationToken);

            if (!success)
                return StatusCode(StatusCodes.Status402PaymentRequired,
                    ApiResponse<object>.Fail("Insufficient credits.", new { currentBalance = newBalance, requiredCredits = 1 } as object));

            return Ok(ApiResponse<object>.Ok(new { balance = newBalance }));
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(ApiResponse<object>.Fail("Authentication required."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deducting voice preview credit");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Failed to deduct credit."));
        }
    }

    [AllowAnonymous]
    [HttpGet("feature-costs")]
    public async Task<ActionResult<ApiResponse<object>>> GetFeatureCosts(CancellationToken cancellationToken)
    {
        try
        {
            var costs = await _creditService.GetDisplayFeatureCostsAsync(cancellationToken);
            return Ok(ApiResponse<object>.Ok(costs));
        }
        catch (SqlException ex)
        {
            _logger.LogWarning(ex, "Feature-costs lookup failed due to SQL issue. Returning empty feature-cost list.");
            return Ok(ApiResponse<object>.Ok(Array.Empty<FeatureCostDto>()));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching feature costs");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Failed to fetch feature costs."));
        }
    }
}
