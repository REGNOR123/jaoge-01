-- ============================================================
-- TextToSpeeches.in — Complete Database Migration Script
-- Target: SQL Server (Azure SQL or on-prem)
-- Run this against a fresh, empty database.
-- All statements are idempotent (safe to re-run).
-- ============================================================

-- ============================================================
-- 1. dbo.users
--    Core user accounts (email + Google OAuth)
-- ============================================================
IF OBJECT_ID('dbo.users', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.users (
        id                           INT IDENTITY(1,1)  NOT NULL PRIMARY KEY,
        google_id                    NVARCHAR(255)      NULL UNIQUE,
        full_name                    NVARCHAR(255)      NOT NULL,
        email                        NVARCHAR(255)      NOT NULL UNIQUE,
        password_hash                NVARCHAR(255)      NULL,
        email_verified               BIT                NOT NULL DEFAULT 0,
        email_verification_token     NVARCHAR(64)       NULL,
        email_verification_expires_at DATETIME2         NULL,
        profile_picture              NVARCHAR(MAX)      NULL,
        created_at                   DATETIME2          NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_at                   DATETIME2          NOT NULL DEFAULT SYSUTCDATETIME(),
        credits                      BIGINT             NOT NULL DEFAULT 0,
        voice_cloning_key            NVARCHAR(MAX)      NULL,
        current_plan                 NVARCHAR(50)       NOT NULL DEFAULT 'free',
        is_banned                    BIT                NOT NULL DEFAULT 0,
        credits_frozen               BIT                NOT NULL DEFAULT 0
    );
END

-- Backfill: Google accounts are always verified
UPDATE dbo.users SET email_verified = 1
WHERE google_id IS NOT NULL AND email_verified = 0;

-- ============================================================
-- 2. dbo.pending_signups
--    Staged registrations awaiting email verification
-- ============================================================
IF OBJECT_ID('dbo.pending_signups', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.pending_signups (
        id                           INT IDENTITY(1,1)  NOT NULL PRIMARY KEY,
        full_name                    NVARCHAR(255)      NOT NULL,
        email                        NVARCHAR(255)      NOT NULL UNIQUE,
        password_hash                NVARCHAR(255)      NOT NULL,
        email_verification_token     NVARCHAR(64)       NOT NULL UNIQUE,
        email_verification_expires_at DATETIME2         NOT NULL,
        created_at                   DATETIME2          NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_at                   DATETIME2          NOT NULL DEFAULT SYSUTCDATETIME()
    );
END

-- ============================================================
-- 3. dbo.file_artifacts
--    Tracks generated/uploaded files stored in Azure File Share
-- ============================================================
IF OBJECT_ID('dbo.file_artifacts', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.file_artifacts (
        id             UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
        user_id        INT              NULL,
        user_folder    NVARCHAR(64)     NOT NULL,
        job_id         NVARCHAR(64)     NOT NULL,
        feature        NVARCHAR(50)     NOT NULL,
        file_name      NVARCHAR(255)    NOT NULL,
        relative_path  NVARCHAR(600)    NOT NULL UNIQUE,
        content_type   NVARCHAR(200)    NULL,
        size_bytes     BIGINT           NOT NULL,
        duration_minutes FLOAT          NULL,
        is_output      BIT              NOT NULL DEFAULT 0,
        created_at     DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        expires_at     DATETIME2        NOT NULL
    );

    CREATE INDEX IX_file_artifacts_expires      ON dbo.file_artifacts(expires_at);
    CREATE INDEX IX_file_artifacts_user_created ON dbo.file_artifacts(user_id, created_at);
END

-- ============================================================
-- 4. dbo.credit_ledger
--    Immutable log of every credit debit/credit per user
-- ============================================================
IF OBJECT_ID('dbo.credit_ledger', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.credit_ledger (
        id            UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
        user_id       INT              NOT NULL,
        credit_delta  BIGINT           NOT NULL,
        balance_after BIGINT           NOT NULL,
        source        NVARCHAR(50)     NOT NULL,
        feature       NVARCHAR(50)     NULL,
        description   NVARCHAR(200)    NULL,
        created_at    DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),

        CONSTRAINT FK_credit_ledger_users
            FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE CASCADE
    );

    CREATE INDEX IX_credit_ledger_user ON dbo.credit_ledger(user_id, created_at);
END

-- ============================================================
-- 5. dbo.feature_costs
--    Credit cost configuration per feature (source of truth for billing)
-- ============================================================
IF OBJECT_ID('dbo.feature_costs', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.feature_costs (
        feature          NVARCHAR(50)  NOT NULL PRIMARY KEY,
        credit_cost      BIGINT        NOT NULL,
        cost_per_n_chars INT           NULL,
        min_cost         BIGINT        NOT NULL DEFAULT 1,
        display_name     NVARCHAR(100) NOT NULL DEFAULT '',
        display_unit     NVARCHAR(100) NOT NULL DEFAULT ''
    );
END

-- Seed / upsert feature costs
MERGE dbo.feature_costs AS t
USING (VALUES
    ('create-voice',           1,   100,  1,  'Create AI Voice',              'per 1,000 characters'),
    ('create-voice-regional',  2,   100,  1,  'Create AI Voice (Regional)',   'per 1,000 characters'),
    ('create-voice-hd',        3,   100,  1,  'Create AI Voice (Neural HD)',  'per 1,000 characters'),
    ('transcribe',             10,  NULL, 10, 'Transcribe Audio',             'per audio file'),
    ('translate-text',         15,  NULL, 15, 'Speech Translate',             'per file'),
    ('translate-dub',          1,   125,  1,  'Translate & Dub',              'per 1,000 characters'),
    ('speech-translate',       20,  NULL, 20, 'Speech Translate',             'per min × language'),
    ('text-translate',         3,   1000, 1,  'Text Translation',             'per 1,000 characters'),
    ('text-translate-regional',6,   1000, 1,  'Regional Text Translation',    'per 1,000 characters'),
    ('detect-language',        1,   NULL, 1,  'Language Detection',           'per request'),
    ('script-generate',        4,   NULL, 4,  'AI Script Studio',             'per script'),
    ('auto-generate',          2,   NULL, 2,  'AI Field Generate',            'per field'),
    ('script-transform',       3,   NULL, 3,  'Script Transform',             'per transform'),
    ('ai-enhance',             2,   NULL, 2,  'AI Text Enhance',              'per request'),
    ('voice-preview',          1,   NULL, 1,  'Voice Preview',                'per 2 previews'),
    ('voice-clone-generate',   50,  NULL, 50, 'Voice Clone Setup',            'per clone'),
    ('voice-clone-synthesize', 10,  NULL, 10, 'Voice Clone Synthesis',        'per synthesis')
) AS s (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
ON t.feature = s.feature
WHEN MATCHED THEN UPDATE SET
    credit_cost      = s.credit_cost,
    cost_per_n_chars = s.cost_per_n_chars,
    min_cost         = s.min_cost,
    display_name     = s.display_name,
    display_unit     = s.display_unit
WHEN NOT MATCHED THEN INSERT
    (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
    VALUES (s.feature, s.credit_cost, s.cost_per_n_chars, s.min_cost, s.display_name, s.display_unit);

-- ============================================================
-- 6. dbo.app_config
--    Key-value runtime configuration (kill switch, credit grants, etc.)
-- ============================================================
IF OBJECT_ID('dbo.app_config', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.app_config (
        config_key   NVARCHAR(100) NOT NULL PRIMARY KEY,
        config_value NVARCHAR(500) NOT NULL,
        description  NVARCHAR(300) NULL
    );
END

-- Seed config keys
MERGE dbo.app_config AS t
USING (VALUES
    ('signup_credit_grant', '200',  'Free credits awarded to every new verified user'),
    ('service_enabled',     'true', 'Set to false to activate maintenance mode on all API routes')
) AS s (config_key, config_value, description)
ON t.config_key = s.config_key
WHEN NOT MATCHED THEN INSERT (config_key, config_value, description)
    VALUES (s.config_key, s.config_value, s.description);

-- ============================================================
-- 7. dbo.plans
--    Subscription/credit-pack plan definitions (INR + USD pricing)
-- ============================================================
IF OBJECT_ID('dbo.plans', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.plans (
        id                INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        name              NVARCHAR(50)      NOT NULL UNIQUE,
        display_name      NVARCHAR(100)     NOT NULL DEFAULT '',
        monthly_price     DECIMAL(10,2)     NOT NULL DEFAULT 0,   -- USD monthly
        annual_price      DECIMAL(10,2)     NOT NULL DEFAULT 0,   -- USD annual (per month)
        inr_monthly_price DECIMAL(10,2)     NOT NULL DEFAULT 0,   -- INR monthly
        inr_annual_price  DECIMAL(10,2)     NOT NULL DEFAULT 0,   -- INR annual (per month)
        credits_per_month BIGINT            NOT NULL DEFAULT 0,
        is_one_time_grant BIT               NOT NULL DEFAULT 0,
        is_active         BIT               NOT NULL DEFAULT 1,
        is_popular        BIT               NOT NULL DEFAULT 0,
        badge             NVARCHAR(50)      NULL,
        cta_label         NVARCHAR(100)     NULL,
        features_json     NVARCHAR(MAX)     NULL,
        sort_order        INT               NOT NULL DEFAULT 0
    );
END

-- Upsert all 6 plans
MERGE dbo.plans AS t
USING (VALUES
    ('free',     'Free',     0.00,  0.00,     0.00,    0.00,    200,   1, 1, 0, NULL,         'Get Started Free', 1),
    ('starter',  'Starter',  0.00,  0.00,   199.00,  159.00,    500,   0, 1, 0, NULL,         'Get Starter',      2),
    ('basic',    'Basic',    0.00,  0.00,   399.00,  319.00,   1200,   0, 1, 0, NULL,         'Get Basic',        3),
    ('standard', 'Standard', 0.00,  0.00,   699.00,  559.00,   3000,   0, 1, 1, NULL,         'Get Standard',     4),
    ('pro',      'Pro',      9.00,  7.00,   999.00,  799.00,   6000,   0, 1, 0, NULL,         'Get Pro',          5),
    ('ultra',    'Ultra',   29.00, 23.00,  1999.00, 1599.00,  15000,   0, 1, 0, 'Best Value', 'Get Ultra',        6)
) AS s (name, display_name, monthly_price, annual_price, inr_monthly_price, inr_annual_price,
        credits_per_month, is_one_time_grant, is_active, is_popular, badge, cta_label, sort_order)
ON t.name = s.name
WHEN MATCHED THEN UPDATE SET
    display_name      = s.display_name,
    monthly_price     = s.monthly_price,
    annual_price      = s.annual_price,
    inr_monthly_price = s.inr_monthly_price,
    inr_annual_price  = s.inr_annual_price,
    credits_per_month = s.credits_per_month,
    is_one_time_grant = s.is_one_time_grant,
    is_active         = s.is_active,
    is_popular        = s.is_popular,
    badge             = s.badge,
    cta_label         = s.cta_label,
    sort_order        = s.sort_order
WHEN NOT MATCHED THEN INSERT
    (name, display_name, monthly_price, annual_price, inr_monthly_price, inr_annual_price,
     credits_per_month, is_one_time_grant, is_active, is_popular, badge, cta_label, sort_order)
    VALUES (s.name, s.display_name, s.monthly_price, s.annual_price, s.inr_monthly_price, s.inr_annual_price,
            s.credits_per_month, s.is_one_time_grant, s.is_active, s.is_popular, s.badge, s.cta_label, s.sort_order);

-- Populate features_json for each plan
UPDATE dbo.plans SET features_json =
    '["Create AI Voice","Transcribe Audio","Speech Translate","Translate & Dub","Regional Language Support","AI Text Enhance"]'
WHERE name = 'free';

UPDATE dbo.plans SET features_json =
    '["Create AI Voice","Transcribe Audio","Regional Language Support","AI Text Enhance"]'
WHERE name = 'starter';

UPDATE dbo.plans SET features_json =
    '["Create AI Voice","Transcribe Audio","Speech Translate","Regional Language Support","AI Script Studio","AI Text Enhance","Projects & Storage"]'
WHERE name = 'basic';

UPDATE dbo.plans SET features_json =
    '["Create AI Voice","Transcribe Audio","Speech Translate","Translate & Dub","Regional Language Support","AI Script Studio","AI Text Enhance","Projects & Storage"]'
WHERE name = 'standard';

UPDATE dbo.plans SET features_json =
    '["Create AI Voice","Transcribe Audio","Speech Translate","Translate & Dub","Regional Language Support","AI Script Studio","AI Text Enhance","Projects & Storage","Priority Processing"]'
WHERE name = 'pro';

UPDATE dbo.plans SET features_json =
    '["Create AI Voice","Transcribe Audio","Speech Translate","Translate & Dub","Regional Language Support","AI Script Studio","AI Text Enhance","Projects & Storage","Priority Processing","Priority Support"]'
WHERE name = 'ultra';

-- ============================================================
-- 8. dbo.payment_orders
--    Razorpay payment records; links user to plan purchase
-- ============================================================
IF OBJECT_ID('dbo.payment_orders', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.payment_orders (
        id                  UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
        user_id             INT              NOT NULL,
        razorpay_order_id   NVARCHAR(100)    NOT NULL UNIQUE,
        razorpay_payment_id NVARCHAR(100)    NULL,
        plan_name           NVARCHAR(50)     NOT NULL,
        plan_display_name   NVARCHAR(100)    NOT NULL,
        amount_inr          DECIMAL(10,2)    NOT NULL,
        credits_granted     BIGINT           NOT NULL DEFAULT 0,
        status              NVARCHAR(20)     NOT NULL DEFAULT 'created',  -- created | paid | failed
        currency            NVARCHAR(10)     NOT NULL DEFAULT 'INR',
        created_at          DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        paid_at             DATETIME2        NULL,

        CONSTRAINT FK_payment_orders_users
            FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE CASCADE
    );
END

-- ============================================================
-- 9. dbo.blocked_ips
--    IP-level access blocklist (checked by middleware on every request)
-- ============================================================
IF OBJECT_ID('dbo.blocked_ips', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.blocked_ips (
        id            INT IDENTITY(1,1)  NOT NULL PRIMARY KEY,
        ip_address    NVARCHAR(45)       NOT NULL UNIQUE,
        reason        NVARCHAR(200)      NULL,
        blocked_until DATETIME2          NULL,          -- NULL = permanent
        created_at    DATETIME2          NOT NULL DEFAULT SYSUTCDATETIME()
    );
END

-- ============================================================
-- 10. dbo.security_events
--     Audit log for suspicious activity, bans, and rate-limit breaches
-- ============================================================
IF OBJECT_ID('dbo.security_events', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.security_events (
        id         UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
        user_id    INT              NULL,
        ip_address NVARCHAR(45)     NULL,
        event_type NVARCHAR(50)     NOT NULL,
        details    NVARCHAR(500)    NULL,
        created_at DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME()
    );

    CREATE INDEX IX_security_events_user ON dbo.security_events(user_id, created_at);
    CREATE INDEX IX_security_events_type ON dbo.security_events(event_type, created_at);
END

-- ============================================================
-- Done.
-- After running this script, update your .env / appsettings with
-- the new database connection string and restart the application.
-- ============================================================
