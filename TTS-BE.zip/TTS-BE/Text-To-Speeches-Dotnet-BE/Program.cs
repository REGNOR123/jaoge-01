using System.Threading.RateLimiting;
using System.Text;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Text_To_Speeches_Dotnet_BE.Configuration;
using Text_To_Speeches_Dotnet_BE.Services.Database;
using Text_To_Speeches_Dotnet_BE.Services.Email;
using Text_To_Speeches_Dotnet_BE.Services.Security;
using Text_To_Speeches_Dotnet_BE.Services.Translator;
using Text_To_Speeches_Dotnet_BE.Services.Users;
using Text_To_Speeches_Dotnet_BE.Services.Chat;
using Text_To_Speeches_Dotnet_BE.Services.ScriptGeneration;
using Text_To_Speeches_Dotnet_BE.Services.Storage;
using Text_To_Speeches_Dotnet_BE.Services.Speech;
using Text_To_Speeches_Dotnet_BE.Services.Credits;
using Text_To_Speeches_Dotnet_BE.Services.VoiceClone;

var builder = WebApplication.CreateBuilder(args);

builder.WebHost.ConfigureKestrel(options =>
{
    options.Limits.MaxRequestBodySize = 25 * 1024 * 1024; // 25 MB (audio uploads)
});

builder.Services.AddControllers();
builder.Services.AddMemoryCache();
builder.Services.AddHttpClient();
builder.Services.AddAuthorization();
builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    options.InvalidModelStateResponseFactory = context =>
    {
        var errors = context.ModelState
            .Where(x => x.Value?.Errors.Count > 0)
            .SelectMany(x => x.Value!.Errors.Select(err => new
            {
                field = x.Key,
                message = string.IsNullOrWhiteSpace(err.ErrorMessage) ? "Invalid value." : err.ErrorMessage
            }))
            .ToArray();

        return new UnprocessableEntityObjectResult(new
        {
            success = false,
            error = "Validation failed.",
            message = "Validation failed.",
            errors
        });
    };
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.Configure<ServerOptions>(builder.Configuration.GetSection("Server"));
builder.Services.Configure<DatabaseOptions>(builder.Configuration.GetSection("Db"));
builder.Services.Configure<JwtOptions>(builder.Configuration.GetSection("Jwt"));
builder.Services.Configure<GoogleOptions>(builder.Configuration.GetSection("Google"));
builder.Services.Configure<FrontendOptions>(builder.Configuration.GetSection("Frontend"));
builder.Services.Configure<EmailVerificationOptions>(builder.Configuration.GetSection("EmailVerification"));
builder.Services.Configure<BrevoOptions>(builder.Configuration.GetSection("Brevo"));
builder.Services.Configure<SpeechOptions>(builder.Configuration.GetSection("Speech"));
builder.Services.Configure<TranslatorOptions>(builder.Configuration.GetSection("Translator"));
builder.Services.Configure<AzureOpenAIOptions>(builder.Configuration.GetSection("AzureOpenAI"));
builder.Services.Configure<AzureStorageOptions>(builder.Configuration.GetSection("AzureStorage"));
builder.Services.Configure<GoogleTtsOptions>(builder.Configuration.GetSection("GoogleTts"));
builder.Services.Configure<RazorpayOptions>(builder.Configuration.GetSection("Razorpay"));
builder.Services.AddHttpClient("razorpay", client =>
{
    client.BaseAddress = new Uri("https://api.razorpay.com/v1/");
    client.Timeout = TimeSpan.FromSeconds(30);
});
builder.Services.AddScoped<ISqlConnectionFactory, SqlConnectionFactory>();
builder.Services.AddScoped<IDatabaseInitializer, DatabaseInitializer>();
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IPasswordService, PasswordService>();
builder.Services.AddHttpClient<IEmailService, EmailService>(client =>
{
    client.BaseAddress = new Uri("https://api.brevo.com");
});
builder.Services.AddHttpClient<IAzureTranslatorService, AzureTranslatorService>();
builder.Services.AddHttpClient<IAzureOpenAiChatService, AzureOpenAiChatService>();
builder.Services.AddScoped<IScriptGenerationService, ScriptGenerationService>();
builder.Services.AddSingleton<IAzureFileStorageService, AzureFileStorageService>();
builder.Services.AddScoped<IFileArtifactRepository, FileArtifactRepository>();
builder.Services.AddScoped<IProjectService, ProjectService>();
builder.Services.AddMemoryCache();
builder.Services.AddScoped<ICreditService, CreditService>();
builder.Services.AddScoped<ISpeechSynthesisService, SpeechSynthesisService>();
builder.Services.AddHttpClient<IGoogleTtsService, GoogleTtsService>();
builder.Services.AddHostedService<FileCleanupWorker>();

var jwtSecret = builder.Configuration["JWT_SECRET"] ?? builder.Configuration["Jwt:Secret"];

if (string.IsNullOrWhiteSpace(jwtSecret))
    throw new InvalidOperationException("JWT_SECRET must be configured. Set the JWT_SECRET environment variable or Jwt:Secret in appsettings.");

const string JwtIssuer = "texttospeeches.in";
const string JwtAudience = "texttospeeches-api";

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = JwtIssuer,
            ValidateAudience = true,
            ValidAudience = JwtAudience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.Zero
        };

        options.Events = new JwtBearerEvents
        {
            OnChallenge = async context =>
            {
                context.HandleResponse();
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                context.Response.ContentType = "application/json";

                var authHeader = context.Request.Headers.Authorization.ToString();
                if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                {
                    await context.Response.WriteAsJsonAsync(new { success = false, error = "Access denied. No token provided.", message = "Access denied. No token provided." });
                    return;
                }

                await context.Response.WriteAsJsonAsync(new { success = false, error = "Invalid or expired token.", message = "Invalid or expired token." });
            }
        };
    });

var configuredOriginsRaw = builder.Configuration["CLIENT_URL"]
    ?? builder.Configuration["Frontend:ClientUrl"]
    ?? builder.Configuration["ClientUrl"];

var allowedOrigins = (configuredOriginsRaw ?? string.Empty)
    .Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
    .ToList();

if (builder.Environment.IsDevelopment())
{
    if (!allowedOrigins.Contains("http://localhost:3000", StringComparer.OrdinalIgnoreCase))
    {
        allowedOrigins.Add("http://localhost:3000");
    }

    if (!allowedOrigins.Contains("http://127.0.0.1:3000", StringComparer.OrdinalIgnoreCase))
    {
        allowedOrigins.Add("http://127.0.0.1:3000");
    }
}

builder.Services.AddCors(options =>
{
    options.AddPolicy("ClientPolicy", policy =>
    {
        if (allowedOrigins.Count > 0)
        {
            policy.WithOrigins(allowedOrigins.ToArray())
                .WithMethods("GET", "POST", "PUT", "DELETE")
                .AllowAnyHeader()
                .AllowCredentials();
        }
        else if (builder.Environment.IsDevelopment())
        {
            policy.AllowAnyOrigin()
                .WithMethods("GET", "POST", "PUT", "DELETE")
                .AllowAnyHeader();
        }
        else
        {
            throw new InvalidOperationException("CLIENT_URL must be configured in production. Set the CLIENT_URL environment variable.");
        }
    });
});

builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    // Auth endpoints: 5 req/min per IP (brute-force protection)
    options.AddPolicy("AuthLimiter", context =>
        RateLimitPartition.GetSlidingWindowLimiter(
            partitionKey: context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            factory: _ => new SlidingWindowRateLimiterOptions
            {
                PermitLimit = 5,
                Window = TimeSpan.FromMinutes(1),
                SegmentsPerWindow = 4,
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                QueueLimit = 0
            }));

    // AI/credit endpoints: 30 req/min per authenticated user, 5/min per IP for anonymous
    options.AddPolicy("AiLimiter", context =>
    {
        var userId = context.User?.FindFirst("id")?.Value
            ?? context.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var key = userId is not null ? $"ai_user:{userId}" : $"ai_ip:{context.Connection.RemoteIpAddress}";
        return RateLimitPartition.GetFixedWindowLimiter(key, _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = userId is not null ? 30 : 5,
            Window = TimeSpan.FromMinutes(1),
            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
            QueueLimit = 0
        });
    });

    // Payment endpoints: 10 req/hour per user
    options.AddPolicy("PaymentLimiter", context =>
    {
        var userId = context.User?.FindFirst("id")?.Value
            ?? context.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value
            ?? context.Connection.RemoteIpAddress?.ToString()
            ?? "unknown";
        return RateLimitPartition.GetFixedWindowLimiter($"pay:{userId}", _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 10,
            Window = TimeSpan.FromHours(1),
            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
            QueueLimit = 0
        });
    });

    // General read endpoints: 120 req/min per IP
    options.AddPolicy("ReadLimiter", context =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 120,
                Window = TimeSpan.FromMinutes(1),
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                QueueLimit = 0
            }));

    // Fallback for any untagged API route: 200 req/min per IP
    options.AddPolicy("ApiLimiter", context =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 200,
                Window = TimeSpan.FromMinutes(1),
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                QueueLimit = 0
            }));

    options.OnRejected = async (rejectionContext, token) =>
    {
        rejectionContext.HttpContext.Response.Headers["Retry-After"] = "60";
        rejectionContext.HttpContext.Response.ContentType = "application/json";
        await rejectionContext.HttpContext.Response.WriteAsJsonAsync(
            new { success = false, error = "Too many requests. Please slow down and try again.", message = "Too many requests. Please slow down and try again." },
            cancellationToken: token);
    };
});

var app = builder.Build();

app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async context =>
    {
        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        context.Response.ContentType = "application/json";
        await context.Response.WriteAsJsonAsync(new { success = false, error = "Internal server error.", message = "Internal server error." });
    });
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Avoid "Failed to determine the https port for redirect." when running HTTP-only locally.
var aspnetcoreUrls = app.Configuration["ASPNETCORE_URLS"] ?? Environment.GetEnvironmentVariable("ASPNETCORE_URLS") ?? string.Empty;
if (aspnetcoreUrls.Contains("https://", StringComparison.OrdinalIgnoreCase))
{
    app.UseHttpsRedirection();
}
app.UseCors("ClientPolicy");

app.UseMiddleware<Text_To_Speeches_Dotnet_BE.Middleware.SecurityHeadersMiddleware>();
app.UseMiddleware<Text_To_Speeches_Dotnet_BE.Middleware.MaintenanceMiddleware>();
app.UseMiddleware<Text_To_Speeches_Dotnet_BE.Middleware.IpBlocklistMiddleware>();

app.UseAuthentication();
app.UseAuthorization();

app.UseMiddleware<Text_To_Speeches_Dotnet_BE.Middleware.UserBanMiddleware>();

// Apply rate limiter only to API routes (not static files)
app.UseWhen(
    context => context.Request.Path.StartsWithSegments("/api"),
    branch => branch.UseRateLimiter());

app.MapControllers();
app.MapGet("/", () => "Hello! Text to Speech Backend API is running");
app.MapGet("/api/hello", () => Results.Json(new { message = "Hello from backend" }));
app.MapGet("/api/health", () => Results.Json(new
{
    success = true,
    message = "Server is running.",
    timestamp = DateTime.UtcNow.ToString("O")
}));

app.MapFallback(() => Results.NotFound(new { success = false, error = "Route not found.", message = "Route not found." }));

using (var scope = app.Services.CreateScope())
{
    var initializer = scope.ServiceProvider.GetRequiredService<IDatabaseInitializer>();
    await initializer.InitializeAsync();
}

app.Run();
