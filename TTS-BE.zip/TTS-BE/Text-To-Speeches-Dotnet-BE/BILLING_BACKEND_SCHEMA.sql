-- Plans
IF OBJECT_ID('dbo.plans', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.plans (
    id NVARCHAR(100) NOT NULL PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    price DECIMAL(18,2) NOT NULL,
    billing_cycle NVARCHAR(20) NOT NULL,
    is_active BIT NOT NULL DEFAULT 1,
    created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
  );
END
GO

-- User subscriptions
IF OBJECT_ID('dbo.user_subscriptions', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.user_subscriptions (
    id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    plan_id NVARCHAR(100) NOT NULL,
    status NVARCHAR(20) NOT NULL DEFAULT 'active',
    starts_at DATETIME2 NOT NULL,
    ends_at DATETIME2 NOT NULL,
    razorpay_order_id NVARCHAR(100) NOT NULL,
    razorpay_payment_id NVARCHAR(100) NOT NULL,
    start_date DATETIME2 NOT NULL,
    end_date DATETIME2 NOT NULL,
    next_billing_date DATETIME2 NULL,
    auto_renew BIT NOT NULL DEFAULT 1,
    created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    updated_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_user_subscriptions_users FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE CASCADE
  );
END
GO

-- Billing transactions
IF OBJECT_ID('dbo.billing_transactions', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.billing_transactions (
    id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    subscription_id INT NOT NULL,
    amount DECIMAL(18,2) NOT NULL,
    status NVARCHAR(20) NOT NULL,
    payment_method NVARCHAR(50) NULL,
    transaction_ref NVARCHAR(100) NULL,
    created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_billing_transactions_users FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE CASCADE,
    CONSTRAINT FK_billing_transactions_user_subscriptions FOREIGN KEY (subscription_id) REFERENCES dbo.user_subscriptions(id) ON DELETE NO ACTION
  );
END
GO

-- Invoices
IF OBJECT_ID('dbo.invoices', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.invoices (
    id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    subscription_id INT NOT NULL,
    invoice_number NVARCHAR(50) NOT NULL UNIQUE,
    amount DECIMAL(18,2) NOT NULL,
    status NVARCHAR(20) NOT NULL,
    invoice_url NVARCHAR(1000) NULL,
    issued_date DATETIME2 NOT NULL,
    CONSTRAINT FK_invoices_users FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE CASCADE,
    CONSTRAINT FK_invoices_user_subscriptions FOREIGN KEY (subscription_id) REFERENCES dbo.user_subscriptions(id) ON DELETE NO ACTION
  );
END
GO

-- Payment methods
IF OBJECT_ID('dbo.payment_methods', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.payment_methods (
    id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    brand NVARCHAR(50) NOT NULL,
    last4_digits NVARCHAR(4) NOT NULL,
    expiry_month INT NOT NULL,
    expiry_year INT NOT NULL,
    is_default BIT NOT NULL DEFAULT 1,
    created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_payment_methods_users FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE CASCADE
  );
END
GO

-- Seed plans
MERGE dbo.plans AS target
USING (VALUES
  ('free-starter', 'Free Starter', CAST(0.00 AS DECIMAL(18,2)), 'monthly', CAST(1 AS BIT)),
  ('creator', 'Creator', CAST(199.00 AS DECIMAL(18,2)), 'monthly', CAST(1 AS BIT)),
  ('pro', 'Pro', CAST(499.00 AS DECIMAL(18,2)), 'monthly', CAST(1 AS BIT)),
  ('business', 'Business', CAST(1299.00 AS DECIMAL(18,2)), 'monthly', CAST(1 AS BIT)),
  ('enterprise', 'Enterprise', CAST(0.00 AS DECIMAL(18,2)), 'monthly', CAST(1 AS BIT))
) AS src(id, name, price, billing_cycle, is_active)
ON target.id = src.id
WHEN MATCHED THEN
  UPDATE SET
    name = src.name,
    price = src.price,
    billing_cycle = src.billing_cycle,
    is_active = src.is_active
WHEN NOT MATCHED THEN
  INSERT (id, name, price, billing_cycle, is_active, created_at)
  VALUES (src.id, src.name, src.price, src.billing_cycle, src.is_active, SYSUTCDATETIME());
GO
