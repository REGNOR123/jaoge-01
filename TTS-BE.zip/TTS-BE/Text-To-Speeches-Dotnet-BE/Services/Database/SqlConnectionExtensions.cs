using Microsoft.Data.SqlClient;

namespace Text_To_Speeches_Dotnet_BE.Services.Database;

internal static class SqlConnectionExtensions
{
    // Azure SQL transient error codes: 40613 = database paused/resuming, 40501 = service busy,
    // 49918/49919/49920 = resource limits, -2 = timeout, 10928/10929 = resource limits
    private static readonly HashSet<int> TransientErrorNumbers = [40613, 40501, 40143, 49918, 49919, 49920, -2, 10928, 10929];

    private const int MaxRetries = 15;
    private static readonly TimeSpan RetryDelay = TimeSpan.FromSeconds(6);

    internal static async Task OpenWithRetryAsync(this SqlConnection connection, CancellationToken cancellationToken = default)
    {
        for (var attempt = 1; attempt < MaxRetries; attempt++)
        {
            try
            {
                await connection.OpenAsync(cancellationToken);
                return;
            }
            catch (SqlException ex) when (TransientErrorNumbers.Contains(ex.Number))
            {
                await Task.Delay(RetryDelay, cancellationToken);
            }
        }

        await connection.OpenAsync(cancellationToken);
    }
}
