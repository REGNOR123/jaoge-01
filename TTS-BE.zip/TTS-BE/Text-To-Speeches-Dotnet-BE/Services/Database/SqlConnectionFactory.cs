using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;

namespace Text_To_Speeches_Dotnet_BE.Services.Database;

public interface ISqlConnectionFactory
{
    SqlConnection CreateConnection();
}

public sealed class SqlConnectionFactory : ISqlConnectionFactory
{
    private readonly IConfiguration _configuration;
    private readonly IOptions<DatabaseOptions> _databaseOptions;

    public SqlConnectionFactory(IConfiguration configuration, IOptions<DatabaseOptions> databaseOptions)
    {
        _configuration = configuration;
        _databaseOptions = databaseOptions;
    }

    public SqlConnection CreateConnection() => new(GetConnectionString());

    private string GetConnectionString()
    {
        var fromConnectionString = _configuration.GetConnectionString("DefaultConnection")
            ?? _configuration["DB_CONNECTION_STRING"]
            ?? _configuration["DATABASE_URL"];

        if (!string.IsNullOrWhiteSpace(fromConnectionString))
        {
            return fromConnectionString;
        }

        var db = ResolveDatabaseSettings();
        var missingFields = new List<string>();
        if (string.IsNullOrWhiteSpace(db.Server))
        {
            missingFields.Add("DB_SERVER");
        }

        if (string.IsNullOrWhiteSpace(db.Database))
        {
            missingFields.Add("DB_NAME");
        }

        if (string.IsNullOrWhiteSpace(db.User))
        {
            missingFields.Add("DB_USER");
        }

        if (string.IsNullOrWhiteSpace(db.Password))
        {
            missingFields.Add("DB_PASSWORD");
        }

        if (missingFields.Count > 0)
        {
            throw new InvalidOperationException($"Database configuration is missing required values: {string.Join(", ", missingFields)}");
        }

        var builder = new SqlConnectionStringBuilder
        {
            DataSource = db.Port > 0 ? $"{db.Server},{db.Port}" : db.Server,
            InitialCatalog = db.Database,
            UserID = db.User,
            Password = db.Password,
            Encrypt = db.Encrypt,
            TrustServerCertificate = db.TrustServerCertificate
        };

        return builder.ConnectionString;
    }

    private DatabaseOptions ResolveDatabaseSettings()
    {
        var db = _databaseOptions.Value;

        return new DatabaseOptions
        {
            Server = FirstNonEmpty(_configuration["DB_SERVER"], db.Server),
            Port = ResolveInt(_configuration["DB_PORT"], db.Port, 1433),
            User = FirstNonEmpty(_configuration["DB_USER"], db.User),
            Password = FirstNonEmpty(_configuration["DB_PASSWORD"], db.Password),
            Database = FirstNonEmpty(_configuration["DB_NAME"], db.Database),
            Encrypt = ResolveBool(_configuration["DB_ENCRYPT"], db.Encrypt, true),
            TrustServerCertificate = ResolveBool(_configuration["DB_TRUST_SERVER_CERTIFICATE"], db.TrustServerCertificate, false)
        };
    }

    private static string? FirstNonEmpty(params string?[] values)
    {
        return values.FirstOrDefault(v => !string.IsNullOrWhiteSpace(v));
    }

    private static int ResolveInt(string? raw, int preferred, int fallback)
    {
        if (!string.IsNullOrWhiteSpace(raw) && int.TryParse(raw, out var parsed))
        {
            return parsed;
        }

        return preferred > 0 ? preferred : fallback;
    }

    private static bool ResolveBool(string? raw, bool preferred, bool fallback)
    {
        if (!string.IsNullOrWhiteSpace(raw) && bool.TryParse(raw, out var parsed))
        {
            return parsed;
        }

        return preferred != fallback ? preferred : fallback;
    }
}
