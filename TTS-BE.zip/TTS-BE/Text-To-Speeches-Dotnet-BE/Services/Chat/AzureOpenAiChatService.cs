using System.Text;
using System.Text.Json;
using System.Net;
using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;

namespace Text_To_Speeches_Dotnet_BE.Services.Chat;

public interface IAzureOpenAiChatService
{
    Task<string> CompleteAsync(string message, string? systemPromptOverride = null, CancellationToken cancellationToken = default);
}

public sealed class AzureOpenAiChatService : IAzureOpenAiChatService
{
    private static readonly string[] AzureCognitiveScopes = ["https://cognitiveservices.azure.com/.default"];

    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;
    private readonly AzureOpenAIOptions _options;

    public AzureOpenAiChatService(
        HttpClient httpClient,
        IConfiguration configuration,
        IOptions<AzureOpenAIOptions> options)
    {
        _httpClient = httpClient;
        _configuration = configuration;
        _options = options.Value;
    }

    public async Task<string> CompleteAsync(string message, string? systemPromptOverride = null, CancellationToken cancellationToken = default)
    {
        var (endpoint, deployment, apiVersion, apiKey, systemPrompt, maxTokens, temperature) = GetConfig();

        var v1Endpoint = NormalizeAzureOpenAiEndpointForV1(endpoint);
        var apiVersionCandidates = BuildApiVersionCandidates(apiVersion);
        var shouldSendTemperature = ShouldSendTemperature(temperature);

        var includeTemperature = shouldSendTemperature;
        var tokenParam = "max_completion_tokens";

        HttpStatusCode statusCode = 0;
        string responseBody = string.Empty;

        // Priority order for gpt-5-mini and newer models:
        // 1. Responses endpoint on original endpoint (uses /openai/responses without /v1)
        // 2. Legacy chat/completions endpoint
        // 3. v1 chat/completions endpoint  
        // 4. v1 responses endpoint

        // Try responses endpoint first (required for gpt-5-mini and newer models)
        foreach (var candidateVersion in apiVersionCandidates)
        {
            var responsesUri = new Uri($"{endpoint.TrimEnd('/')}/openai/responses?api-version={Uri.EscapeDataString(candidateVersion)}");
            (statusCode, responseBody) = await SendResponsesAsync(responsesUri, includeTemperature);

            if (!IsSuccessStatusCode(statusCode) && IsUnsupportedApiVersion(statusCode, responseBody))
            {
                continue;
            }

            if (!IsSuccessStatusCode(statusCode))
            {
                // Try next approach
                break;
            }

            try
            {
                return ExtractResponsesOutputText(responseBody);
            }
            catch (InvalidOperationException)
            {
                // Try next approach
                break;
            }
        }

        // Fallback: Try legacy chat/completions endpoint
        foreach (var candidateVersion in apiVersionCandidates)
        {
            var legacyChatUri = new Uri($"{endpoint.TrimEnd('/')}/openai/deployments/{Uri.EscapeDataString(deployment)}/chat/completions?api-version={Uri.EscapeDataString(candidateVersion)}");
            (statusCode, responseBody) = await SendChatCompletionsWithAdaptiveRetriesAsync(legacyChatUri, includeModelInBody: false);

            if (!IsSuccessStatusCode(statusCode) && IsUnsupportedApiVersion(statusCode, responseBody))
            {
                continue;
            }

            if (!IsSuccessStatusCode(statusCode))
            {
                break;
            }

            try
            {
                return ExtractChatCompletionsAssistantText(responseBody);
            }
            catch (InvalidOperationException)
            {
                break;
            }
        }

        // Fallback: Try v1 chat/completions endpoint
        foreach (var candidateVersion in apiVersionCandidates)
        {
            var v1ChatUri = new Uri($"{v1Endpoint}/openai/v1/chat/completions?api-version={Uri.EscapeDataString(candidateVersion)}");
            (statusCode, responseBody) = await SendChatCompletionsWithAdaptiveRetriesAsync(v1ChatUri, includeModelInBody: true);

            if (!IsSuccessStatusCode(statusCode) && IsUnsupportedApiVersion(statusCode, responseBody))
            {
                continue;
            }

            if (!IsSuccessStatusCode(statusCode))
            {
                break;
            }

            try
            {
                return ExtractChatCompletionsAssistantText(responseBody);
            }
            catch (InvalidOperationException)
            {
                break;
            }
        }

        // Final fallback: Try v1 responses endpoint
        foreach (var candidateVersion in apiVersionCandidates)
        {
            var v1ResponsesUri = new Uri($"{v1Endpoint}/openai/v1/responses?api-version={Uri.EscapeDataString(candidateVersion)}");
            (statusCode, responseBody) = await SendResponsesAsync(v1ResponsesUri, includeTemperature);

            if (!IsSuccessStatusCode(statusCode) && IsUnsupportedApiVersion(statusCode, responseBody))
            {
                continue;
            }

            if (!IsSuccessStatusCode(statusCode))
            {
                break;
            }

            try
            {
                return ExtractResponsesOutputText(responseBody);
            }
            catch (InvalidOperationException)
            {
                break;
            }
        }

        throw new InvalidOperationException($"Azure OpenAI API version not supported. Tried: {string.Join(", ", apiVersionCandidates)}");

        async Task<(HttpStatusCode statusCode, string responseBody)> SendChatCompletionsWithAdaptiveRetriesAsync(Uri requestUri, bool includeModelInBody)
        {
            // Up to 3 attempts with small adaptive tweaks:
            // - Some models only support default temperature (1.0) and reject explicitly setting it.
            // - Some models expect max_tokens; others expect max_completion_tokens.
            var includeTemperatureLocal = includeTemperature;
            var tokenParamLocal = tokenParam;

            (statusCode, responseBody) = await SendChatCompletionsAsync(requestUri, includeTemperatureLocal, tokenParamLocal, includeModelInBody);
            if (!IsSuccessStatusCode(statusCode))
            {
                if (includeTemperatureLocal && IsUnsupportedTemperature(statusCode, responseBody))
                {
                    includeTemperatureLocal = false;
                    (statusCode, responseBody) = await SendChatCompletionsAsync(requestUri, includeTemperatureLocal, tokenParamLocal, includeModelInBody);
                }

                if (!IsSuccessStatusCode(statusCode) && IsUnsupportedTokenParam(statusCode, responseBody, out var alternateTokenParam))
                {
                    tokenParamLocal = alternateTokenParam;
                    (statusCode, responseBody) = await SendChatCompletionsAsync(requestUri, includeTemperatureLocal, tokenParamLocal, includeModelInBody);
                }
            }

            return (statusCode, responseBody);
        }

        async Task<(HttpStatusCode statusCode, string responseBody)> SendChatCompletionsAsync(Uri requestUri, bool includeTemperatureLocal, string tokenParamLocal, bool includeModelInBody)
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, requestUri);
            await ApplyAuthAsync(request, apiKey, cancellationToken);

            var payload = new Dictionary<string, object?>
            {
                ["messages"] = new object[]
                {
                    new { role = "system", content = systemPromptOverride ?? systemPrompt },
                    new { role = "user", content = message }
                },
            };

            if (includeModelInBody)
            {
                payload["model"] = deployment;
            }

            payload[tokenParamLocal] = maxTokens;

            if (includeTemperatureLocal)
            {
                payload["temperature"] = temperature;
            }

            request.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

            using var response = await _httpClient.SendAsync(request, cancellationToken);
            var body = await response.Content.ReadAsStringAsync(cancellationToken);
            return (response.StatusCode, body);
        }

        async Task<(HttpStatusCode statusCode, string responseBody)> SendResponsesAsync(Uri requestUri, bool includeTemperatureLocal)
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, requestUri);
            await ApplyAuthAsync(request, apiKey, cancellationToken);

            var payload = new Dictionary<string, object?>
            {
                ["model"] = deployment,
                ["input"] = new object[]
                {
                    new { role = "system", content = systemPromptOverride ?? systemPrompt },
                    new { role = "user", content = message }
                },
                ["max_output_tokens"] = maxTokens,
            };

            if (includeTemperatureLocal)
            {
                payload["temperature"] = temperature;
            }

            request.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

            using var response = await _httpClient.SendAsync(request, cancellationToken);
            var body = await response.Content.ReadAsStringAsync(cancellationToken);
            return (response.StatusCode, body);
        }
    }

    private (string endpoint, string deployment, string apiVersion, string? apiKey, string systemPrompt, int maxTokens, float temperature) GetConfig()
    {
        var endpoint = _configuration["AZURE_OPENAI_ENDPOINT"] ?? _options.Endpoint;
        var deployment = _configuration["AZURE_OPENAI_DEPLOYMENT"] ?? _options.Deployment;
        var apiVersion = _configuration["AZURE_OPENAI_API_VERSION"] ?? _options.ApiVersion;
        var apiKey = _configuration["AZURE_OPENAI_API_KEY"] ?? _options.ApiKey;
        var systemPrompt = _configuration["AZURE_OPENAI_SYSTEM_PROMPT"] ?? _options.SystemPrompt;

        var maxTokensRaw = _configuration["AZURE_OPENAI_MAX_TOKENS"];
        var temperatureRaw = _configuration["AZURE_OPENAI_TEMPERATURE"];

        var maxTokens = _options.MaxTokens;
        if (int.TryParse(maxTokensRaw, out var parsedMaxTokens) && parsedMaxTokens > 0)
        {
            maxTokens = parsedMaxTokens;
        }

        var temperature = _options.Temperature;
        if (float.TryParse(temperatureRaw, out var parsedTemperature) && parsedTemperature is >= 0 and <= 2)
        {
            temperature = parsedTemperature;
        }

        if (string.IsNullOrWhiteSpace(endpoint))
        {
            throw new InvalidOperationException("Missing AZURE_OPENAI_ENDPOINT configuration.");
        }

        if (string.IsNullOrWhiteSpace(deployment))
        {
            throw new InvalidOperationException("Missing AZURE_OPENAI_DEPLOYMENT configuration.");
        }

        if (string.IsNullOrWhiteSpace(apiVersion))
        {
            throw new InvalidOperationException("Missing AZURE_OPENAI_API_VERSION configuration.");
        }

        if (string.IsNullOrWhiteSpace(systemPrompt))
        {
            systemPrompt = "You are a helpful assistant.";
        }

        return (endpoint, deployment, apiVersion, string.IsNullOrWhiteSpace(apiKey) ? null : apiKey, systemPrompt, maxTokens, temperature);
    }

    private static string ExtractChatCompletionsAssistantText(string responseBody)
    {
        using var doc = JsonDocument.Parse(responseBody);

        // If the service returned an error payload with a 2xx status code, surface it.
        if (doc.RootElement.TryGetProperty("error", out var errorEl) && errorEl.ValueKind == JsonValueKind.Object)
        {
            var code = errorEl.TryGetProperty("code", out var codeEl) ? codeEl.GetString() : null;
            var message = errorEl.TryGetProperty("message", out var msgEl) ? msgEl.GetString() : null;
            throw new InvalidOperationException($"Azure OpenAI error payload returned: {code ?? "unknown_code"} - {message ?? "unknown_error"}");
        }

        if (!doc.RootElement.TryGetProperty("choices", out var choices) ||
            choices.ValueKind != JsonValueKind.Array ||
            choices.GetArrayLength() == 0)
        {
            throw new InvalidOperationException("Azure OpenAI returned no choices.");
        }

        var first = choices[0];
        var finishReason = first.TryGetProperty("finish_reason", out var finishEl) ? finishEl.GetString() : null;
        if (!first.TryGetProperty("message", out var msg) || msg.ValueKind != JsonValueKind.Object)
        {
            throw new InvalidOperationException("Azure OpenAI returned unexpected message payload.");
        }

        var content = msg.TryGetProperty("content", out var contentEl) ? contentEl.GetString() : null;
        if (string.IsNullOrWhiteSpace(content))
        {
            if (string.Equals(finishReason, "content_filter", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException("Azure OpenAI content was filtered (finish_reason=content_filter).");
            }

            if (msg.TryGetProperty("tool_calls", out var toolCallsEl) && toolCallsEl.ValueKind == JsonValueKind.Array && toolCallsEl.GetArrayLength() > 0)
            {
                throw new InvalidOperationException("Azure OpenAI returned tool calls with no assistant text content.");
            }

            throw new InvalidOperationException("Azure OpenAI returned empty content.");
        }

        return content;
    }

    private static string ExtractResponsesOutputText(string responseBody)
    {
        using var doc = JsonDocument.Parse(responseBody);

        if (doc.RootElement.TryGetProperty("error", out var errorEl) && errorEl.ValueKind == JsonValueKind.Object)
        {
            var code = errorEl.TryGetProperty("code", out var codeEl) ? codeEl.GetString() : null;
            var message = errorEl.TryGetProperty("message", out var msgEl) ? msgEl.GetString() : null;
            throw new InvalidOperationException($"Azure OpenAI responses error: {code ?? "unknown_code"} - {message ?? "unknown_error"}");
        }

        var outputText = doc.RootElement.TryGetProperty("output_text", out var outputTextEl) ? outputTextEl.GetString() : null;
        if (!string.IsNullOrWhiteSpace(outputText))
        {
            return outputText;
        }

        if (!doc.RootElement.TryGetProperty("output", out var outputEl) || outputEl.ValueKind != JsonValueKind.Array)
        {
            throw new InvalidOperationException("Azure OpenAI responses returned no output.");
        }

        foreach (var item in outputEl.EnumerateArray())
        {
            var type = item.TryGetProperty("type", out var typeEl) ? typeEl.GetString() : null;
            var role = item.TryGetProperty("role", out var roleEl) ? roleEl.GetString() : null;
            if (!string.Equals(type, "message", StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(role, "assistant", StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            if (!item.TryGetProperty("content", out var contentEl) || contentEl.ValueKind != JsonValueKind.Array)
            {
                continue;
            }

            var sb = new StringBuilder();
            foreach (var part in contentEl.EnumerateArray())
            {
                var text = part.TryGetProperty("text", out var textEl) ? textEl.GetString() : null;
                if (!string.IsNullOrWhiteSpace(text))
                {
                    sb.Append(text);
                }
            }

            var combined = sb.ToString();
            if (!string.IsNullOrWhiteSpace(combined))
            {
                return combined;
            }
        }

        throw new InvalidOperationException("Azure OpenAI responses returned empty content.");
    }

    private static string NormalizeAzureOpenAiEndpointForV1(string endpoint)
    {
        if (!Uri.TryCreate(endpoint, UriKind.Absolute, out var endpointUri))
        {
            return endpoint.TrimEnd('/');
        }

        var host = endpointUri.Host;
        const string cognitiveSuffix = ".cognitiveservices.azure.com";
        const string openAiSuffix = ".openai.azure.com";

        if (host.EndsWith(cognitiveSuffix, StringComparison.OrdinalIgnoreCase))
        {
            host = host[..^cognitiveSuffix.Length] + openAiSuffix;
        }

        var builder = new UriBuilder(endpointUri)
        {
            Host = host,
            Path = string.Empty,
            Query = string.Empty,
            Fragment = string.Empty
        };

        return builder.Uri.ToString().TrimEnd('/');
    }

    private static bool ShouldSendTemperature(float temperature)
    {
        return Math.Abs(temperature - 1.0f) > 0.0001f;
    }

    private static bool IsSuccessStatusCode(HttpStatusCode statusCode)
    {
        var code = (int)statusCode;
        return code is >= 200 and <= 299;
    }

    private static bool IsUnsupportedTemperature(HttpStatusCode statusCode, string responseBody)
    {
        if (statusCode != HttpStatusCode.BadRequest)
        {
            return false;
        }

        try
        {
            using var doc = JsonDocument.Parse(responseBody);
            if (!doc.RootElement.TryGetProperty("error", out var errorEl) || errorEl.ValueKind != JsonValueKind.Object)
            {
                return false;
            }

            var param = errorEl.TryGetProperty("param", out var paramEl) ? paramEl.GetString() : null;
            if (string.Equals(param, "temperature", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            var message = errorEl.TryGetProperty("message", out var msgEl) ? msgEl.GetString() : null;
            return message?.Contains("temperature", StringComparison.OrdinalIgnoreCase) == true
                   && message.Contains("Only the default", StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    private static bool IsUnsupportedTokenParam(HttpStatusCode statusCode, string responseBody, out string alternateTokenParam)
    {
        alternateTokenParam = "max_completion_tokens";

        if (statusCode != HttpStatusCode.BadRequest)
        {
            return false;
        }

        try
        {
            using var doc = JsonDocument.Parse(responseBody);
            if (!doc.RootElement.TryGetProperty("error", out var errorEl) || errorEl.ValueKind != JsonValueKind.Object)
            {
                return false;
            }

            var param = errorEl.TryGetProperty("param", out var paramEl) ? paramEl.GetString() : null;
            if (string.Equals(param, "max_tokens", StringComparison.OrdinalIgnoreCase))
            {
                alternateTokenParam = "max_completion_tokens";
                return true;
            }

            if (string.Equals(param, "max_completion_tokens", StringComparison.OrdinalIgnoreCase))
            {
                alternateTokenParam = "max_tokens";
                return true;
            }

            return false;
        }
        catch
        {
            return false;
        }
    }

    private static bool IsUnsupportedApiVersion(HttpStatusCode statusCode, string responseBody)
    {
        if (statusCode != HttpStatusCode.BadRequest)
        {
            return false;
        }

        try
        {
            using var doc = JsonDocument.Parse(responseBody);
            if (!doc.RootElement.TryGetProperty("error", out var errorEl) || errorEl.ValueKind != JsonValueKind.Object)
            {
                return false;
            }

            var message = errorEl.TryGetProperty("message", out var msgEl) ? msgEl.GetString() : null;
            return message?.Contains("API version not supported", StringComparison.OrdinalIgnoreCase) == true;
        }
        catch
        {
            return responseBody.Contains("API version not supported", StringComparison.OrdinalIgnoreCase);
        }
    }

    private static IReadOnlyList<string> BuildApiVersionCandidates(string configured)
    {
        // Prefer configured version first, then minimal fallbacks
        // gpt-5-mini requires 2025-04-01-preview or newer
        var candidates = new List<string>(capacity: 3);

        Add(configured);
        Add("2025-04-01-preview");   // Required for gpt-5-mini and newer models
        Add("2025-05-01-preview");   // Fallback for future versions

        return candidates;

        void Add(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            var trimmed = value.Trim();
            if (!candidates.Contains(trimmed, StringComparer.OrdinalIgnoreCase))
            {
                candidates.Add(trimmed);
            }
        }
    }

    private static async Task ApplyAuthAsync(HttpRequestMessage request, string? apiKey, CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(apiKey))
        {
            request.Headers.Add("api-key", apiKey);
            return;
        }

        var credential = new DefaultAzureCredential();
        var token = await credential.GetTokenAsync(new TokenRequestContext(AzureCognitiveScopes), cancellationToken);
        request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token.Token);
    }
}
