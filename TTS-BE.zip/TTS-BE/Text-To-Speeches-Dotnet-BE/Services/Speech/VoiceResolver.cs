using System.Text.Json;
using System.Text.RegularExpressions;

namespace Text_To_Speeches_Dotnet_BE.Services.Speech;

public static class VoiceResolver
{
    // Matches BCP-47 language tags: "en", "hi", "en-US", "zh-CN", "zh-Hans", "fil-PH"
    private static readonly Regex LanguageCodePattern =
        new(@"^[a-zA-Z]{2,3}(-[a-zA-Z]{2,8})?$", RegexOptions.Compiled, TimeSpan.FromMilliseconds(50));

    public static bool IsValidLanguageCode(string? code)
    {
        if (string.IsNullOrWhiteSpace(code) || code.Length > 20)
            return false;
        return LanguageCodePattern.IsMatch(code.Trim());
    }

    // Matches Azure Neural voice format: en-US-JennyNeural, hi-IN-SwaraNeural, etc.
    private static readonly Regex VoiceNamePattern =
        new(@"^[a-zA-Z]{2,3}-[a-zA-Z]{2,3}-[a-zA-Z0-9]+Neural$", RegexOptions.Compiled, TimeSpan.FromMilliseconds(100));
    private static readonly HashSet<string> RegionalLocales = new(StringComparer.OrdinalIgnoreCase)
    {
        // Indian regional
        "hi-IN", "ta-IN", "te-IN", "ml-IN", "bn-IN", "mr-IN",
        "gu-IN", "kn-IN", "pa-IN", "ur-IN", "or-IN", "as-IN",
        // Southeast Asian
        "ms-MY", "fil-PH", "id-ID", "jv-ID", "my-MM", "km-KH", "lo-LA",
        // South Asian neighbors
        "bn-BD", "ur-PK", "ta-LK", "ta-MY", "ta-SG",
    };

    // Standalone language codes (ISO 639-1/2) that map to regional locales
    private static readonly HashSet<string> RegionalLangCodes = new(StringComparer.OrdinalIgnoreCase)
    {
        "hi","ta","te","ml","bn","mr","gu","kn","pa","ur","or","as",   // Indian
        "ms","id","fil","jv","my","km","lo",                           // SE Asian
    };

    public static string ResolveFeatureKey(string? voiceName)
    {
        if (string.IsNullOrWhiteSpace(voiceName))
            return "create-voice";

        if (voiceName.EndsWith("DragonHDLatestNeural", StringComparison.OrdinalIgnoreCase))
            return "create-voice-hd";

        var parts = voiceName.Split('-');
        if (parts.Length >= 2 && RegionalLocales.Contains($"{parts[0]}-{parts[1]}"))
            return "create-voice-regional";

        return "create-voice";
    }

    public static bool IsKnownVoice(string voiceName)
    {
        if (string.IsNullOrWhiteSpace(voiceName) || voiceName.Length > 100)
            return false;
        // Accept DragonHD voices too
        if (voiceName.EndsWith("DragonHDLatestNeural", StringComparison.OrdinalIgnoreCase))
            return voiceName.Length < 100;
        return VoiceNamePattern.IsMatch(voiceName);
    }

    // Returns feature key for text translation — regional if EITHER source or target is regional.
    public static string ResolveTranslateFeatureKey(string? targetLanguage, string? sourceLanguage = null)
    {
        var targetCode = NormalizeTranslatorLanguage(targetLanguage);
        var sourceCode = NormalizeTranslatorLanguage(sourceLanguage);
        return (RegionalLangCodes.Contains(targetCode) || RegionalLangCodes.Contains(sourceCode))
            ? "text-translate-regional"
            : "text-translate";
    }

    public static bool TryParseVoicesJson(string json, out Dictionary<string, string> voicesByTarget)
    {
        voicesByTarget = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        try
        {
            var parsed = JsonSerializer.Deserialize<Dictionary<string, string>>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

            if (parsed is null)
            {
                return false;
            }

            foreach (var kv in parsed)
            {
                if (string.IsNullOrWhiteSpace(kv.Key) || string.IsNullOrWhiteSpace(kv.Value))
                {
                    continue;
                }

                voicesByTarget[kv.Key.Trim()] = kv.Value.Trim();
            }

            return true;
        }
        catch
        {
            return false;
        }
    }

    public static string ResolveVoiceForTarget(string target, Dictionary<string, string> voicesByTarget, string? defaultVoice)
    {
        if (voicesByTarget.TryGetValue(target, out var configuredVoice) && !string.IsNullOrWhiteSpace(configuredVoice))
        {
            return configuredVoice.Trim();
        }

        if (!string.IsNullOrWhiteSpace(defaultVoice))
        {
            return defaultVoice.Trim();
        }

        return GetDefaultVoiceForLanguage(target);
    }

    public static string GetDefaultVoiceForLanguage(string language)
    {
        var key = NormalizeTranslatorLanguage(language);
        return key.ToLowerInvariant() switch
        {
            "en"  => "en-US-JennyNeural",
            // Indian
            "hi"  => "hi-IN-SwaraNeural",
            "ta"  => "ta-IN-PallaviNeural",
            "te"  => "te-IN-ShrutiNeural",
            "ml"  => "ml-IN-SobhanaNeural",
            "bn"  => "bn-IN-TanishaaNeural",
            "mr"  => "mr-IN-AarohiNeural",
            "gu"  => "gu-IN-DhwaniNeural",
            "kn"  => "kn-IN-SapnaNeural",
            "pa"  => "pa-IN-VaaniNeural",
            "ur"  => "ur-IN-GulNeural",
            "or"  => "or-IN-SubhasiniNeural",
            "as"  => "as-IN-YashicaNeural",
            // European
            "de"  => "de-DE-KatjaNeural",
            "fr"  => "fr-FR-DeniseNeural",
            "es"  => "es-ES-ElviraNeural",
            "it"  => "it-IT-ElsaNeural",
            "pt"  => "pt-BR-FranciscaNeural",
            "ru"  => "ru-RU-SvetlanaNeural",
            // East Asian
            "ja"  => "ja-JP-NanamiNeural",
            "ko"  => "ko-KR-SunHiNeural",
            "zh"  => "zh-CN-XiaoxiaoNeural",
            // Middle East
            "ar"  => "ar-SA-ZariyahNeural",
            // Southeast Asian
            "ms"  => "ms-MY-YasminNeural",
            "fil" => "fil-PH-BlessicaNeural",
            "id"  => "id-ID-GadisNeural",
            "vi"  => "vi-VN-HoaiMyNeural",
            "th"  => "th-TH-PremwadeeNeural",
            _     => string.Empty
        };
    }

    public static string NormalizeTranslatorLanguage(string? code)
    {
        var trimmed = (code ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(trimmed))
        {
            return "en";
        }

        var dash = trimmed.IndexOf('-', StringComparison.Ordinal);
        if (dash > 0)
        {
            return trimmed[..dash];
        }

        var underscore = trimmed.IndexOf('_', StringComparison.Ordinal);
        if (underscore > 0)
        {
            return trimmed[..underscore];
        }

        return trimmed;
    }
}
