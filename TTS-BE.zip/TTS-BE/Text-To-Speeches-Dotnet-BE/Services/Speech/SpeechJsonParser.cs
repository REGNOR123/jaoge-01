using System.Text.Json;
using Text_To_Speeches_Dotnet_BE.Models;

namespace Text_To_Speeches_Dotnet_BE.Services.Speech;

public static class SpeechJsonParser
{
    public static bool TryParseDetailedSpeechJson(string json, out TranscribedSegment segment, out List<TranscribedWord> words)
    {
        segment = new TranscribedSegment(0, 0, string.Empty);
        words = new List<TranscribedWord>();

        if (string.IsNullOrWhiteSpace(json))
        {
            return false;
        }

        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            var displayText = root.TryGetProperty("DisplayText", out var displayEl) ? displayEl.GetString() : null;
            var offset = TryGetInt64(root, "Offset");
            var duration = TryGetInt64(root, "Duration");

            if (root.TryGetProperty("NBest", out var nbestEl) && nbestEl.ValueKind == JsonValueKind.Array && nbestEl.GetArrayLength() > 0)
            {
                var best = nbestEl[0];
                displayText ??= best.TryGetProperty("Display", out var displayBestEl) ? displayBestEl.GetString() : null;

                if (best.TryGetProperty("Words", out var wordsEl) && wordsEl.ValueKind == JsonValueKind.Array)
                {
                    foreach (var w in wordsEl.EnumerateArray())
                    {
                        var word = w.TryGetProperty("Word", out var wordEl) ? wordEl.GetString() : null;
                        var wOffset = TryGetInt64(w, "Offset");
                        var wDuration = TryGetInt64(w, "Duration");
                        if (!string.IsNullOrWhiteSpace(word) && wOffset.HasValue && wDuration.HasValue)
                        {
                            var startMs = ToMs(wOffset.Value);
                            var endMs = ToMs(wOffset.Value + wDuration.Value);
                            words.Add(new TranscribedWord(startMs, endMs, word));
                        }
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(displayText) || !offset.HasValue || !duration.HasValue)
            {
                return false;
            }

            var start = ToMs(offset.Value);
            var end = ToMs(offset.Value + duration.Value);
            segment = new TranscribedSegment(start, end, displayText);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static long ToMs(long ticks100ns) => (long)TimeSpan.FromTicks(ticks100ns).TotalMilliseconds;

    private static long? TryGetInt64(JsonElement obj, string propertyName)
    {
        if (!obj.TryGetProperty(propertyName, out var el))
        {
            return null;
        }

        return el.ValueKind switch
        {
            JsonValueKind.Number when el.TryGetInt64(out var value) => value,
            JsonValueKind.Number when el.TryGetDouble(out var dbl) => (long)dbl,
            _ => null
        };
    }
}
