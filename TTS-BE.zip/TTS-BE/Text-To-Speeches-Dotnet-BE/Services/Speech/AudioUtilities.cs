using NAudio.Wave;

namespace Text_To_Speeches_Dotnet_BE.Services.Speech;

public static class AudioUtilities
{
    public static bool LooksLikeWavFile(string path)
    {
        try
        {
            using var stream = File.OpenRead(path);
            Span<byte> header = stackalloc byte[12];
            var read = stream.Read(header);
            if (read < 12)
            {
                return false;
            }

            return header[0] == (byte)'R' &&
                   header[1] == (byte)'I' &&
                   header[2] == (byte)'F' &&
                   header[3] == (byte)'F' &&
                   header[8] == (byte)'W' &&
                   header[9] == (byte)'A' &&
                   header[10] == (byte)'V' &&
                   header[11] == (byte)'E';
        }
        catch
        {
            return false;
        }
    }

    public static bool LooksLikeMp3File(string path)
    {
        try
        {
            using var stream = File.OpenRead(path);
            Span<byte> header = stackalloc byte[3];
            var read = stream.Read(header);
            if (read < 3)
            {
                return false;
            }

            if (header[0] == (byte)'I' && header[1] == (byte)'D' && header[2] == (byte)'3')
            {
                return true;
            }

            if (header[0] == 0xFF && (header[1] & 0xE0) == 0xE0)
            {
                return true;
            }

            return false;
        }
        catch
        {
            return false;
        }
    }

    public static void ConvertAudioTo16kMonoWav(string inputPath, string outputWavPath)
    {
        using var reader = new MediaFoundationReader(inputPath);
        var outFormat = new WaveFormat(16000, 16, 1);
        using var resampler = new MediaFoundationResampler(reader, outFormat)
        {
            ResamplerQuality = 60
        };

        WaveFileWriter.CreateWaveFile(outputWavPath, resampler);
    }

    public static double TryGetAudioDurationMinutes(string path)
    {
        try
        {
            using var reader = new AudioFileReader(path);
            return Math.Round(reader.TotalTime.TotalMinutes, 4);
        }
        catch
        {
            return 0;
        }
    }
}
