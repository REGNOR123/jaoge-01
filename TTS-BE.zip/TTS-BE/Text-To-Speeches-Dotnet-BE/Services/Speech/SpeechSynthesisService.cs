using System.Net.Http.Headers;
using System.Text;

namespace Text_To_Speeches_Dotnet_BE.Services.Speech;

public interface ISpeechSynthesisService
{
    Task<(byte[] Bytes, string ContentType)> SynthesizeSpeechBytesAsync(
        string speechKey,
        string speechRegion,
        string voice,
        string text,
        string outputFormatHeader,
        string fallbackContentType,
        CancellationToken cancellationToken);
}

public sealed class SpeechSynthesisService : ISpeechSynthesisService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<SpeechSynthesisService> _logger;

    public SpeechSynthesisService(IHttpClientFactory httpClientFactory, ILogger<SpeechSynthesisService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }

    public async Task<(byte[] Bytes, string ContentType)> SynthesizeSpeechBytesAsync(
        string speechKey,
        string speechRegion,
        string voice,
        string text,
        string outputFormatHeader,
        string fallbackContentType,
        CancellationToken cancellationToken)
    {
        var ttsEndpoint = $"https://{speechRegion}.tts.speech.microsoft.com/cognitiveservices/v1";
        var ssml = SsmlBuilder.BuildSimpleSsml(voice, text);

        using var httpRequest = new HttpRequestMessage(HttpMethod.Post, ttsEndpoint);
        httpRequest.Headers.Add("Ocp-Apim-Subscription-Key", speechKey);
        httpRequest.Headers.Add("X-Microsoft-OutputFormat", outputFormatHeader);
        httpRequest.Headers.UserAgent.ParseAdd("TextToSpeechesBackend/1.0");
        httpRequest.Content = new StringContent(ssml, Encoding.UTF8, "application/ssml+xml");
        httpRequest.Content.Headers.ContentType = new MediaTypeHeaderValue("application/ssml+xml") { CharSet = "utf-8" };

        var client = _httpClientFactory.CreateClient();
        using var response = await client.SendAsync(httpRequest, cancellationToken);
        var bytes = await response.Content.ReadAsByteArrayAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            var responseBody = TryDecode(bytes);
            _logger.LogWarning("TTS failed ({Status}): {Body}", (int)response.StatusCode, responseBody);
            throw new InvalidOperationException("Azure TTS request failed.");
        }

        var contentType = response.Content.Headers.ContentType?.MediaType ?? fallbackContentType;
        return (bytes, contentType);
    }

    private static string TryDecode(byte[] bytes)
    {
        try
        {
            return Encoding.UTF8.GetString(bytes);
        }
        catch
        {
            return "<binary>";
        }
    }
}
