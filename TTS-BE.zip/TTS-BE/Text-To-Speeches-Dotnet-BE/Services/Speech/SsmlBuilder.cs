using Text_To_Speeches_Dotnet_BE.Models;

namespace Text_To_Speeches_Dotnet_BE.Services.Speech;

public static class SsmlBuilder
{
    public static string BuildSsml(SpeechTtsRequest request)
    {
        var voice = request.Voice.Trim();
        var escapedText = EscapeXml(request.Text);

        var rate = ToPercentOrRelative(request.Rate);
        var pitch = ToPercentOrRelative(request.Pitch);
        var volume = ToPercentOrRelative(request.Volume);

        var hasStyle = !string.IsNullOrWhiteSpace(request.Style);
        var style = hasStyle ? request.Style!.Trim() : string.Empty;
        var styleDegree = request.Degree;

        var prosodyOpen = $"<prosody rate=\"{rate}\" pitch=\"{pitch}\" volume=\"{volume}\">";
        var prosodyClose = "</prosody>";

        if (hasStyle)
        {
            var degreeAttr = styleDegree.HasValue ? $" styledegree=\"{Clamp(styleDegree.Value, 0.0, 2.0):0.##}\"" : string.Empty;
            return $"""
                    <speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xmlns:mstts="http://www.w3.org/2001/mstts" xml:lang="en-US">
                      <voice name="{EscapeXml(voice)}">
                        <mstts:express-as style="{EscapeXml(style)}"{degreeAttr}>
                          {prosodyOpen}{escapedText}{prosodyClose}
                        </mstts:express-as>
                      </voice>
                    </speak>
                    """;
        }

        return $"""
                <speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">
                  <voice name="{EscapeXml(voice)}">
                    {prosodyOpen}{escapedText}{prosodyClose}
                  </voice>
                </speak>
                """;
    }

    public static string BuildSimpleSsml(string voice, string text)
    {
        var trimmedVoice = (voice ?? string.Empty).Trim();
        var escapedText = EscapeXml(text ?? string.Empty);
        var lang = GetLocaleFromVoiceName(trimmedVoice) ?? "en-US";

        return $"""
                <speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="{EscapeXml(lang)}">
                  <voice name="{EscapeXml(trimmedVoice)}">{escapedText}</voice>
                </speak>
                """;
    }

    public static string ToPercentOrRelative(double? raw)
    {
        if (!raw.HasValue)
        {
            return "0%";
        }

        var value = raw.Value;

        if (value >= -100 && value <= 100)
        {
            var signed = value >= 0 ? $"+{value:0.##}%" : $"{value:0.##}%";
            return signed;
        }

        if (value >= 0.25 && value <= 4.0)
        {
            var pct = (value - 1.0) * 100.0;
            var signed = pct >= 0 ? $"+{pct:0.##}%" : $"{pct:0.##}%";
            return signed;
        }

        return "0%";
    }

    public static string EscapeXml(string input)
    {
        if (string.IsNullOrEmpty(input))
        {
            return string.Empty;
        }

        return input
            .Replace("&", "&amp;", StringComparison.Ordinal)
            .Replace("<", "&lt;", StringComparison.Ordinal)
            .Replace(">", "&gt;", StringComparison.Ordinal)
            .Replace("\"", "&quot;", StringComparison.Ordinal)
            .Replace("'", "&apos;", StringComparison.Ordinal);
    }

    public static double Clamp(double value, double min, double max)
        => value < min ? min : value > max ? max : value;

    public static string? GetLocaleFromVoiceName(string voice)
    {
        var parts = (voice ?? string.Empty).Split('-', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (parts.Length >= 2)
        {
            return $"{parts[0]}-{parts[1]}";
        }

        return null;
    }
}
