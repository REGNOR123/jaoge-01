namespace Text_To_Speeches_Dotnet_BE.Services.VoiceClone;

public interface IGoogleTtsService
{
    Task<string?> GenerateVoiceCloningKeyAsync(
        string refAudioBase64,
        string consentAudioBase64,
        string languageCode,
        string audioEncoding,
        CancellationToken cancellationToken = default);

    Task<string?> SynthesizeWithClonedVoiceAsync(
        string text,
        string voiceCloningKey,
        string languageCode,
        CancellationToken cancellationToken = default);
}
