using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;

namespace Text_To_Speeches_Dotnet_BE.Services.VoiceClone;

public sealed class GoogleTtsService : IGoogleTtsService
{
    private const string BaseUrl = "https://texttospeech.googleapis.com/v1beta1";
    private const string ConsentScript = "I am the owner of this voice and I consent to Google using this voice to create a synthetic voice model.";

    private readonly HttpClient _httpClient;
    private readonly GoogleTtsOptions _options;
    private readonly ILogger<GoogleTtsService> _logger;

    public GoogleTtsService(HttpClient httpClient, IOptions<GoogleTtsOptions> options, ILogger<GoogleTtsService> logger)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<string?> GenerateVoiceCloningKeyAsync(
        string refAudioBase64,
        string consentAudioBase64,
        string languageCode,
        string audioEncoding,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var url = $"{BaseUrl}/voices:generateVoiceCloningKey?key={_options.ApiKey}";

            var body = new
            {
                reference_audio = new
                {
                    audio_config = new { audio_encoding = audioEncoding },
                    content = refAudioBase64
                },
                voice_talent_consent = new
                {
                    audio_config = new { audio_encoding = audioEncoding },
                    content = consentAudioBase64
                },
                consent_script = ConsentScript,
                language_code = languageCode
            };

            using var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Add("x-goog-user-project", _options.ProjectId);
            request.Content = JsonContent.Create(body);

            using var response = await _httpClient.SendAsync(request, cancellationToken);
            var json = await response.Content.ReadAsStringAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError("Google TTS generate-key failed {Status}: {Body}", (int)response.StatusCode, json);
                return null;
            }

            using var doc = JsonDocument.Parse(json);
            return doc.RootElement.TryGetProperty("voiceCloningKey", out var keyProp) ? keyProp.GetString() : null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "GenerateVoiceCloningKeyAsync error");
            return null;
        }
    }

    public async Task<string?> SynthesizeWithClonedVoiceAsync(
        string text,
        string voiceCloningKey,
        string languageCode,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var url = $"{BaseUrl}/text:synthesize?key={_options.ApiKey}";

            var body = new
            {
                input = new { text },
                voice = new
                {
                    language_code = languageCode,
                    voice_clone = new { voice_cloning_key = voiceCloningKey }
                },
                audioConfig = new { audioEncoding = "MP3" }
            };

            using var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Add("x-goog-user-project", _options.ProjectId);
            request.Content = JsonContent.Create(body);

            using var response = await _httpClient.SendAsync(request, cancellationToken);
            var json = await response.Content.ReadAsStringAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError("Google TTS synthesize failed {Status}: {Body}", (int)response.StatusCode, json);
                return null;
            }

            using var doc = JsonDocument.Parse(json);
            return doc.RootElement.TryGetProperty("audioContent", out var audioProp) ? audioProp.GetString() : null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "SynthesizeWithClonedVoiceAsync error");
            return null;
        }
    }
}
