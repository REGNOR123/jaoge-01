namespace Text_To_Speeches_Dotnet_BE.Services.Credits;

public sealed record FeatureCostDto(
    string Feature,
    string DisplayName,
    long CreditCost,
    int? CostPerNChars,
    long MinCost,
    string DisplayUnit);

public interface ICreditService
{
    Task<long> GetBalanceAsync(int userId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Atomically deducts credits. Returns (false, currentBalance) when insufficient.
    /// </summary>
    Task<(bool Success, long NewBalance)> DeductCreditsAsync(
        int userId,
        string feature,
        long amount,
        string? description = null,
        CancellationToken cancellationToken = default);

    Task AllocateCreditsAsync(
        int userId,
        long amount,
        string source,
        string? description = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Reads signup grant amount from app_config and allocates credits. No-op if already granted.
    /// </summary>
    Task AllocateSignupGrantAsync(int userId, CancellationToken cancellationToken = default);

    /// <summary>
    /// Reads cost from dbo.feature_costs (cached). Returns 0 for unknown features.
    /// </summary>
    Task<long> CalculateCreditCostAsync(string feature, int characters = 0, CancellationToken cancellationToken = default);

    /// <summary>
    /// Returns all feature cost rows for public display (e.g. pricing page).
    /// </summary>
    Task<IReadOnlyList<FeatureCostDto>> GetDisplayFeatureCostsAsync(CancellationToken cancellationToken = default);
}
