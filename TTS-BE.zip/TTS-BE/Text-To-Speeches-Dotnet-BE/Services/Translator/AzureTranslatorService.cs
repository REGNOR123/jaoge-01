using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;

namespace Text_To_Speeches_Dotnet_BE.Services.Translator;

public interface IAzureTranslatorService
{
    Task<string> DetectLanguageAsync(string text, CancellationToken cancellationToken = default);
    Task<string> TranslateAsync(string text, string to, CancellationToken cancellationToken = default);
}

public sealed class AzureTranslatorService : IAzureTranslatorService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;
    private readonly TranslatorOptions _options;

    public AzureTranslatorService(
        HttpClient httpClient,
        IConfiguration configuration,
        IOptions<TranslatorOptions> options)
    {
        _httpClient = httpClient;
        _configuration = configuration;
        _options = options.Value;
    }

    public async Task<string> DetectLanguageAsync(string text, CancellationToken cancellationToken = default)
    {
        var (endpoint, key, region) = GetConfig();
        var uri = new Uri($"{endpoint.TrimEnd('/')}/detect?api-version=3.0");

        using var request = new HttpRequestMessage(HttpMethod.Post, uri);
        ApplyHeaders(request, key, region);
        request.Content = new StringContent(JsonSerializer.Serialize(new[] { new { Text = text } }), Encoding.UTF8, "application/json");

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var payload = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException($"Translator detect failed ({(int)response.StatusCode}): {payload}");
        }

        using var doc = JsonDocument.Parse(payload);
        var first = doc.RootElement.ValueKind == JsonValueKind.Array && doc.RootElement.GetArrayLength() > 0
            ? doc.RootElement[0]
            : default;

        var language = first.ValueKind == JsonValueKind.Object && first.TryGetProperty("language", out var langEl)
            ? langEl.GetString()
            : null;

        if (string.IsNullOrWhiteSpace(language))
        {
            throw new InvalidOperationException("Translator detect returned no language.");
        }

        // Azure sometimes returns a romanized variant (e.g. "hi-Latn") when the text contains
        // names or loanwords from a non-Latin language written in Latin script.
        // If the primary detection is a -Latn script variant and English appears in the
        // alternatives list, prefer English — the user is typing in Latin characters.
        if (language.EndsWith("-Latn", StringComparison.OrdinalIgnoreCase) &&
            first.TryGetProperty("alternatives", out var alts) &&
            alts.ValueKind == JsonValueKind.Array)
        {
            foreach (var alt in alts.EnumerateArray())
            {
                if (alt.TryGetProperty("language", out var altLang) &&
                    string.Equals(altLang.GetString(), "en", StringComparison.OrdinalIgnoreCase))
                {
                    language = "en";
                    break;
                }
            }
        }

        return language;
    }

    public async Task<string> TranslateAsync(string text, string to, CancellationToken cancellationToken = default)
    {
        var (endpoint, key, region) = GetConfig();
        var uri = new Uri($"{endpoint.TrimEnd('/')}/translate?api-version=3.0&to={Uri.EscapeDataString(to)}");

        using var request = new HttpRequestMessage(HttpMethod.Post, uri);
        ApplyHeaders(request, key, region);
        request.Content = new StringContent(JsonSerializer.Serialize(new[] { new { Text = text } }), Encoding.UTF8, "application/json");

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var payload = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException($"Translator translate failed ({(int)response.StatusCode}): {payload}");
        }

        using var doc = JsonDocument.Parse(payload);
        if (doc.RootElement.ValueKind != JsonValueKind.Array || doc.RootElement.GetArrayLength() == 0)
        {
            throw new InvalidOperationException("Translator translate returned unexpected response.");
        }

        var root = doc.RootElement[0];
        if (!root.TryGetProperty("translations", out var translations) || translations.ValueKind != JsonValueKind.Array || translations.GetArrayLength() == 0)
        {
            throw new InvalidOperationException("Translator translate returned no translations.");
        }

        var translated = translations[0].TryGetProperty("text", out var textEl) ? textEl.GetString() : null;
        if (string.IsNullOrWhiteSpace(translated))
        {
            throw new InvalidOperationException("Translator translate returned empty text.");
        }

        return translated;
    }

    private (string endpoint, string key, string? region) GetConfig()
    {
        var key = _configuration["TRANSLATOR_KEY"] ?? _options.Key;
        var region = _configuration["TRANSLATOR_REGION"] ?? _options.Region;
        var endpoint = _configuration["TRANSLATOR_ENDPOINT"] ?? _options.Endpoint ?? "https://api.cognitive.microsofttranslator.com";

        if (string.IsNullOrWhiteSpace(key))
        {
            throw new InvalidOperationException("Missing TRANSLATOR_KEY configuration.");
        }

        // For many Azure Translator resources, region is required via Ocp-Apim-Subscription-Region.
        // Leaving it empty will typically cause 401/403 from the API.
        if (string.IsNullOrWhiteSpace(region))
        {
            throw new InvalidOperationException("Missing TRANSLATOR_REGION configuration.");
        }

        return (endpoint, key, string.IsNullOrWhiteSpace(region) ? null : region);
    }

    private static void ApplyHeaders(HttpRequestMessage request, string key, string? region)
    {
        request.Headers.Add("Ocp-Apim-Subscription-Key", key);
        if (!string.IsNullOrWhiteSpace(region))
        {
            request.Headers.Add("Ocp-Apim-Subscription-Region", region);
        }
    }
}
