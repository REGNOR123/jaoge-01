using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;

namespace Text_To_Speeches_Dotnet_BE.Services.Email;

public interface IEmailService
{
    string BuildVerificationUrl(string token);
    Task<(string verificationUrl, string verificationCode)> SendVerificationEmailAsync(string email, string code, CancellationToken cancellationToken = default);
}

public sealed class EmailService : IEmailService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;
    private readonly IOptions<FrontendOptions> _frontendOptions;
    private readonly IOptions<BrevoOptions> _brevoOptions;

    public EmailService(
        HttpClient httpClient,
        IConfiguration configuration,
        IOptions<FrontendOptions> frontendOptions,
        IOptions<BrevoOptions> brevoOptions)
    {
        _httpClient = httpClient;
        _configuration = configuration;
        _frontendOptions = frontendOptions;
        _brevoOptions = brevoOptions;
    }

    public string BuildVerificationUrl(string token)
    {
        var clientUrl = _configuration["CLIENT_URL"] ?? _frontendOptions.Value.ClientUrl ?? string.Empty;
        var normalizedBase = clientUrl.TrimEnd('/');
        return $"{normalizedBase}/verify-email?token={Uri.EscapeDataString(token)}";
    }

    public async Task<(string verificationUrl, string verificationCode)> SendVerificationEmailAsync(string email, string code, CancellationToken cancellationToken = default)
    {
        var verificationUrl = BuildVerificationUrl(code);

        var apiKey = _configuration["BREVO_API_KEY"] ?? _brevoOptions.Value.ApiKey;
        var senderEmail = _configuration["BREVO_SENDER_EMAIL"] ?? _brevoOptions.Value.SenderEmail;
        var senderName = _configuration["BREVO_SENDER_NAME"] ?? _brevoOptions.Value.SenderName;

        if (string.IsNullOrWhiteSpace(apiKey) || string.IsNullOrWhiteSpace(senderEmail))
        {
            throw new InvalidOperationException("BREVO_API_KEY and BREVO_SENDER_EMAIL are required for email sending.");
        }

        var payload = new
        {
            sender = new
            {
                name = senderName,
                email = senderEmail
            },
            to = new[] { new { email } },
            subject = "Your verification code",
            htmlContent = $"""
                           <div style="margin:0;padding:0;background:linear-gradient(135deg,#f8fafc 0%,#ffffff 45%,#eef2ff 100%);font-family:Inter,Segoe UI,Arial,sans-serif;">
                             <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:32px 16px;">
                               <tr>
                                 <td align="center">
                                   <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;background:rgba(255,255,255,0.92);border:1px solid #e2e8f0;border-radius:20px;padding:32px;box-shadow:0 10px 30px rgba(79,70,229,0.12);">
                                     <tr>
                                       <td style="text-align:center;padding-bottom:20px;">
                                         <div style="display:inline-block;background:#4f46e5;color:#fff;border-radius:14px;padding:10px 12px;font-weight:800;font-size:14px;letter-spacing:.08em;text-transform:uppercase;">
                                           TextToSpeeches
                                         </div>
                                       </td>
                                     </tr>
                                     <tr>
                                       <td style="color:#0f172a;font-size:24px;line-height:1.2;font-weight:900;padding-bottom:10px;">
                                         Your Verification Code
                                       </td>
                                     </tr>
                                     <tr>
                                       <td style="color:#475569;font-size:15px;line-height:1.7;padding-bottom:22px;">
                                         Hello,<br />
                                         Enter the code below to verify your email and complete your signup.
                                       </td>
                                     </tr>
                                     <tr>
                                       <td style="padding-bottom:22px;text-align:center;">
                                         <div style="display:inline-block;background:#eef2ff;border:2px dashed #818cf8;border-radius:16px;padding:20px 36px;">
                                           <span style="font-size:40px;font-weight:900;letter-spacing:0.25em;color:#4f46e5;font-family:monospace;">{code}</span>
                                         </div>
                                       </td>
                                     </tr>
                                     <tr>
                                       <td style="color:#64748b;font-size:13px;line-height:1.6;padding-bottom:16px;text-align:center;">
                                         This code expires in <strong>15 minutes</strong>.
                                       </td>
                                     </tr>
                                     <tr>
                                       <td style="color:#64748b;font-size:13px;line-height:1.6;border-top:1px solid #e2e8f0;padding-top:16px;">
                                         If you did not request this, you can ignore this email.
                                       </td>
                                     </tr>
                                   </table>
                                 </td>
                               </tr>
                             </table>
                           </div>
                           """
        };

        using var request = new HttpRequestMessage(HttpMethod.Post, "/v3/smtp/email");
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        request.Headers.Add("api-key", apiKey);
        request.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException($"Brevo send failed ({(int)response.StatusCode}): {responseBody}");
        }

        return (verificationUrl, code);
    }
}
