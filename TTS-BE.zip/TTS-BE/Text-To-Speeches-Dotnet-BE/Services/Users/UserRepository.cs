using System.Data;
using Microsoft.Data.SqlClient;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Database;

namespace Text_To_Speeches_Dotnet_BE.Services.Users;

public interface IUserRepository
{
    Task<int> CreateGoogleUserAsync(string googleId, string fullName, string email, string? profilePicture, CancellationToken cancellationToken = default);
    Task<int> CreatePendingManualUserAsync(string fullName, string email, string passwordHash, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default);
    Task CreateOrUpdatePendingSignupAsync(string fullName, string email, string passwordHash, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default);
    Task UpdatePendingManualUserAsync(int userId, string fullName, string passwordHash, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default);
    Task<UserRecord?> FindByEmailAsync(string email, CancellationToken cancellationToken = default);
    Task<UserRecord?> FindByGoogleIdAsync(string googleId, CancellationToken cancellationToken = default);
    Task<UserRecord?> FindByVerificationTokenAsync(string token, CancellationToken cancellationToken = default);
    Task<PendingSignupRecord?> FindPendingByVerificationTokenAsync(string token, CancellationToken cancellationToken = default);
    Task<PendingSignupRecord?> FindPendingByEmailAsync(string email, CancellationToken cancellationToken = default);
    Task VerifyEmailAsync(int userId, CancellationToken cancellationToken = default);
    Task UpdateVerificationTokenAsync(int userId, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default);
    Task UpdatePendingVerificationTokenByEmailAsync(string email, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default);
    Task<int?> CreateVerifiedManualUserFromPendingIdAsync(int pendingId, CancellationToken cancellationToken = default);
    Task<UserProfileRecord?> FindByIdAsync(int id, CancellationToken cancellationToken = default);
    Task UpdateProfileAsync(int userId, string fullName, string? profilePicture, CancellationToken cancellationToken = default);
    Task LinkGoogleAccountAsync(int userId, string googleId, string fullName, string? profilePicture, CancellationToken cancellationToken = default);
    Task<bool> DeleteByIdAsync(int userId, CancellationToken cancellationToken = default);
    Task<string?> GetVoiceCloningKeyAsync(int userId, CancellationToken cancellationToken = default);
    Task SaveVoiceCloningKeyAsync(int userId, string key, CancellationToken cancellationToken = default);
}

public sealed class UserRepository : IUserRepository
{
    private readonly ISqlConnectionFactory _connectionFactory;

    public UserRepository(ISqlConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<int> CreateGoogleUserAsync(string googleId, string fullName, string email, string? profilePicture, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           INSERT INTO dbo.users (google_id, full_name, email, profile_picture, email_verified)
                           VALUES (@googleId, @fullName, @email, @profilePicture, 1);
                           SELECT CAST(SCOPE_IDENTITY() AS INT) AS id;
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@googleId", googleId);
        command.Parameters.AddWithValue("@fullName", fullName);
        command.Parameters.AddWithValue("@email", email);
        command.Parameters.AddWithValue("@profilePicture", (object?)profilePicture ?? DBNull.Value);

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return Convert.ToInt32(result);
    }

    public async Task<int> CreatePendingManualUserAsync(string fullName, string email, string passwordHash, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           INSERT INTO dbo.users (
                             full_name,
                             email,
                             password_hash,
                             email_verified,
                             email_verification_token,
                             email_verification_expires_at
                           ) VALUES (@fullName, @email, @passwordHash, 0, @verificationToken, @verificationExpiresAt);
                           SELECT CAST(SCOPE_IDENTITY() AS INT) AS id;
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@fullName", fullName);
        command.Parameters.AddWithValue("@email", email);
        command.Parameters.AddWithValue("@passwordHash", passwordHash);
        command.Parameters.AddWithValue("@verificationToken", verificationToken);
        command.Parameters.AddWithValue("@verificationExpiresAt", verificationExpiresAt);

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return Convert.ToInt32(result);
    }

    public async Task CreateOrUpdatePendingSignupAsync(string fullName, string email, string passwordHash, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           IF EXISTS (SELECT 1 FROM dbo.pending_signups WHERE email = @email)
                           BEGIN
                             UPDATE dbo.pending_signups
                             SET full_name = @fullName,
                                 password_hash = @passwordHash,
                                 email_verification_token = @verificationToken,
                                 email_verification_expires_at = @verificationExpiresAt,
                                 updated_at = SYSUTCDATETIME()
                             WHERE email = @email;
                           END
                           ELSE
                           BEGIN
                             INSERT INTO dbo.pending_signups (
                               full_name,
                               email,
                               password_hash,
                               email_verification_token,
                               email_verification_expires_at
                             ) VALUES (@fullName, @email, @passwordHash, @verificationToken, @verificationExpiresAt);
                           END
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@fullName", fullName);
        command.Parameters.AddWithValue("@email", email);
        command.Parameters.AddWithValue("@passwordHash", passwordHash);
        command.Parameters.AddWithValue("@verificationToken", verificationToken);
        command.Parameters.AddWithValue("@verificationExpiresAt", verificationExpiresAt);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task UpdatePendingManualUserAsync(int userId, string fullName, string passwordHash, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           UPDATE dbo.users
                           SET full_name = @fullName,
                               password_hash = @passwordHash,
                               email_verified = 0,
                               email_verification_token = @verificationToken,
                               email_verification_expires_at = @verificationExpiresAt,
                               updated_at = SYSUTCDATETIME()
                           WHERE id = @userId
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@userId", userId);
        command.Parameters.AddWithValue("@fullName", fullName);
        command.Parameters.AddWithValue("@passwordHash", passwordHash);
        command.Parameters.AddWithValue("@verificationToken", verificationToken);
        command.Parameters.AddWithValue("@verificationExpiresAt", verificationExpiresAt);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public Task<UserRecord?> FindByEmailAsync(string email, CancellationToken cancellationToken = default)
    {
        const string sql = "SELECT TOP 1 * FROM dbo.users WHERE email = @email";
        return QuerySingleUserAsync(sql, ("@email", email), cancellationToken);
    }

    public Task<UserRecord?> FindByGoogleIdAsync(string googleId, CancellationToken cancellationToken = default)
    {
        const string sql = "SELECT TOP 1 * FROM dbo.users WHERE google_id = @googleId";
        return QuerySingleUserAsync(sql, ("@googleId", googleId), cancellationToken);
    }

    public Task<UserRecord?> FindByVerificationTokenAsync(string token, CancellationToken cancellationToken = default)
    {
        const string sql = "SELECT TOP 1 * FROM dbo.users WHERE email_verification_token = @token";
        return QuerySingleUserAsync(sql, ("@token", token), cancellationToken);
    }

    public async Task<PendingSignupRecord?> FindPendingByVerificationTokenAsync(string token, CancellationToken cancellationToken = default)
    {
        const string sql = "SELECT TOP 1 * FROM dbo.pending_signups WHERE email_verification_token = @token";
        return await QuerySinglePendingAsync(sql, ("@token", token), cancellationToken);
    }

    public async Task<PendingSignupRecord?> FindPendingByEmailAsync(string email, CancellationToken cancellationToken = default)
    {
        const string sql = "SELECT TOP 1 * FROM dbo.pending_signups WHERE email = @email";
        return await QuerySinglePendingAsync(sql, ("@email", email), cancellationToken);
    }

    public async Task VerifyEmailAsync(int userId, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           UPDATE dbo.users
                           SET email_verified = 1,
                               email_verification_token = NULL,
                               email_verification_expires_at = NULL,
                               updated_at = SYSUTCDATETIME()
                           WHERE id = @userId
                           """;

        await ExecuteNonQueryAsync(sql, ("@userId", userId), cancellationToken);
    }

    public async Task UpdateVerificationTokenAsync(int userId, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           UPDATE dbo.users
                           SET email_verification_token = @verificationToken,
                               email_verification_expires_at = @verificationExpiresAt,
                               updated_at = SYSUTCDATETIME()
                           WHERE id = @userId
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@userId", userId);
        command.Parameters.AddWithValue("@verificationToken", verificationToken);
        command.Parameters.AddWithValue("@verificationExpiresAt", verificationExpiresAt);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task UpdatePendingVerificationTokenByEmailAsync(string email, string verificationToken, DateTime verificationExpiresAt, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           UPDATE dbo.pending_signups
                           SET email_verification_token = @verificationToken,
                               email_verification_expires_at = @verificationExpiresAt,
                               updated_at = SYSUTCDATETIME()
                           WHERE email = @email
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@email", email);
        command.Parameters.AddWithValue("@verificationToken", verificationToken);
        command.Parameters.AddWithValue("@verificationExpiresAt", verificationExpiresAt);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<int?> CreateVerifiedManualUserFromPendingIdAsync(int pendingId, CancellationToken cancellationToken = default)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);
        await using var transaction = await connection.BeginTransactionAsync(IsolationLevel.Serializable, cancellationToken);

        try
        {
            const string selectSql = """
                                     SELECT TOP 1 id, full_name, email, password_hash
                                     FROM dbo.pending_signups WITH (UPDLOCK, ROWLOCK, HOLDLOCK)
                                     WHERE id = @pendingId
                                     """;

            await using var selectCommand = new SqlCommand(selectSql, connection, (SqlTransaction)transaction);
            selectCommand.Parameters.AddWithValue("@pendingId", pendingId);
            await using var reader = await selectCommand.ExecuteReaderAsync(cancellationToken);

            if (!await reader.ReadAsync(cancellationToken))
            {
                await reader.CloseAsync();
                await transaction.RollbackAsync(cancellationToken);
                return null;
            }

            var existingPendingId = reader.GetInt32(0);
            var fullName = reader.GetString(1);
            var email = reader.GetString(2);
            var passwordHash = reader.GetString(3);
            await reader.CloseAsync();

            const string insertSql = """
                                     INSERT INTO dbo.users (
                                       full_name,
                                       email,
                                       password_hash,
                                       email_verified,
                                       email_verification_token,
                                       email_verification_expires_at
                                     ) VALUES (@fullName, @email, @passwordHash, 1, NULL, NULL);
                                     SELECT CAST(SCOPE_IDENTITY() AS INT) AS id;
                                     """;

            await using var insertCommand = new SqlCommand(insertSql, connection, (SqlTransaction)transaction);
            insertCommand.Parameters.AddWithValue("@fullName", fullName);
            insertCommand.Parameters.AddWithValue("@email", email);
            insertCommand.Parameters.AddWithValue("@passwordHash", passwordHash);
            var newUserId = Convert.ToInt32(await insertCommand.ExecuteScalarAsync(cancellationToken));

            const string deleteSql = "DELETE FROM dbo.pending_signups WHERE id = @pendingId";
            await using var deleteCommand = new SqlCommand(deleteSql, connection, (SqlTransaction)transaction);
            deleteCommand.Parameters.AddWithValue("@pendingId", existingPendingId);
            await deleteCommand.ExecuteNonQueryAsync(cancellationToken);

            await transaction.CommitAsync(cancellationToken);
            return newUserId;
        }
        catch
        {
            await transaction.RollbackAsync(cancellationToken);
            throw;
        }
    }

    public async Task<UserProfileRecord?> FindByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           SELECT
                             id,
                             google_id,
                             full_name,
                             email,
                             email_verified,
                             profile_picture,
                             created_at,
                             current_plan,
                             credits
                           FROM dbo.users
                           WHERE id = @id
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", id);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);

        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        return new UserProfileRecord
        {
            Id = reader.GetInt32(0),
            GoogleId = reader.IsDBNull(1) ? null : reader.GetString(1),
            FullName = reader.GetString(2),
            Email = reader.GetString(3),
            EmailVerified = reader.GetBoolean(4),
            ProfilePicture = reader.IsDBNull(5) ? null : reader.GetString(5),
            CreatedAt = reader.GetDateTime(6),
            CurrentPlan = reader.IsDBNull(7) ? null : reader.GetString(7),
            Credits = reader.IsDBNull(8) ? 0L : Convert.ToInt64(reader.GetValue(8)),
        };
    }

    public async Task UpdateProfileAsync(int userId, string fullName, string? profilePicture, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           UPDATE dbo.users
                           SET full_name = @fullName,
                               profile_picture = @profilePicture,
                               updated_at = SYSUTCDATETIME()
                           WHERE id = @userId
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@userId", userId);
        command.Parameters.AddWithValue("@fullName", fullName);
        command.Parameters.AddWithValue("@profilePicture", (object?)profilePicture ?? DBNull.Value);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task LinkGoogleAccountAsync(int userId, string googleId, string fullName, string? profilePicture, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           UPDATE dbo.users
                           SET google_id = @googleId,
                               full_name = @fullName,
                               profile_picture = @profilePicture,
                               email_verified = 1,
                               updated_at = SYSUTCDATETIME()
                           WHERE id = @userId
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@userId", userId);
        command.Parameters.AddWithValue("@googleId", googleId);
        command.Parameters.AddWithValue("@fullName", fullName);
        command.Parameters.AddWithValue("@profilePicture", (object?)profilePicture ?? DBNull.Value);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<bool> DeleteByIdAsync(int userId, CancellationToken cancellationToken = default)
    {
        const string sql = "DELETE FROM dbo.users WHERE id = @userId";

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@userId", userId);
        var rows = await command.ExecuteNonQueryAsync(cancellationToken);
        return rows > 0;
    }

    private async Task<UserRecord?> QuerySingleUserAsync(string sql, (string Key, object Value) parameter, CancellationToken cancellationToken)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue(parameter.Key, parameter.Value);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);

        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        return new UserRecord
        {
            Id = reader.GetInt32(reader.GetOrdinal("id")),
            GoogleId = ReadNullableString(reader, "google_id"),
            FullName = reader.GetString(reader.GetOrdinal("full_name")),
            Email = reader.GetString(reader.GetOrdinal("email")),
            PasswordHash = ReadNullableString(reader, "password_hash"),
            EmailVerified = reader.GetBoolean(reader.GetOrdinal("email_verified")),
            EmailVerificationToken = ReadNullableString(reader, "email_verification_token"),
            EmailVerificationExpiresAt = ReadNullableDateTime(reader, "email_verification_expires_at"),
            ProfilePicture = ReadNullableString(reader, "profile_picture"),
            CreatedAt = reader.GetDateTime(reader.GetOrdinal("created_at")),
            UpdatedAt = reader.GetDateTime(reader.GetOrdinal("updated_at"))
        };
    }

    private async Task<PendingSignupRecord?> QuerySinglePendingAsync(string sql, (string Key, object Value) parameter, CancellationToken cancellationToken)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue(parameter.Key, parameter.Value);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);

        if (!await reader.ReadAsync(cancellationToken))
        {
            return null;
        }

        return new PendingSignupRecord
        {
            Id = reader.GetInt32(reader.GetOrdinal("id")),
            FullName = reader.GetString(reader.GetOrdinal("full_name")),
            Email = reader.GetString(reader.GetOrdinal("email")),
            PasswordHash = reader.GetString(reader.GetOrdinal("password_hash")),
            EmailVerificationToken = reader.GetString(reader.GetOrdinal("email_verification_token")),
            EmailVerificationExpiresAt = reader.GetDateTime(reader.GetOrdinal("email_verification_expires_at")),
            CreatedAt = reader.GetDateTime(reader.GetOrdinal("created_at")),
            UpdatedAt = reader.GetDateTime(reader.GetOrdinal("updated_at"))
        };
    }

    private async Task ExecuteNonQueryAsync(string sql, (string Key, object Value) parameter, CancellationToken cancellationToken)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue(parameter.Key, parameter.Value);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static string? ReadNullableString(SqlDataReader reader, string columnName)    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
    }

    private static DateTime? ReadNullableDateTime(SqlDataReader reader, string columnName)
    {
        var ordinal = reader.GetOrdinal(columnName);
        return reader.IsDBNull(ordinal) ? null : reader.GetDateTime(ordinal);
    }

    public async Task<string?> GetVoiceCloningKeyAsync(int userId, CancellationToken cancellationToken = default)
    {
        const string sql = "SELECT voice_cloning_key FROM dbo.users WHERE id = @userId";

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@userId", userId);

        var result = await command.ExecuteScalarAsync(cancellationToken);
        return result is DBNull or null ? null : result.ToString();
    }

    public async Task SaveVoiceCloningKeyAsync(int userId, string key, CancellationToken cancellationToken = default)
    {
        const string sql = "UPDATE dbo.users SET voice_cloning_key = @key, updated_at = SYSUTCDATETIME() WHERE id = @userId";

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@key", key);
        command.Parameters.AddWithValue("@userId", userId);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }
}
