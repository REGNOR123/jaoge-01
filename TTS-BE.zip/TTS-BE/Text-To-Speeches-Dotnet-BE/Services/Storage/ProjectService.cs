using System.Text.Json;
using Text_To_Speeches_Dotnet_BE.Models;

namespace Text_To_Speeches_Dotnet_BE.Services.Storage;

public interface IProjectService
{
    Task<List<ProjectListItem>> ListProjectsAsync(int userId, CancellationToken cancellationToken = default);
    Task<UserProject?> GetProjectAsync(int userId, string projectId, CancellationToken cancellationToken = default);
    Task<UserProject> CreateProjectAsync(int userId, CreateProjectRequest request, CancellationToken cancellationToken = default);
    Task<UserProject?> UpdateProjectAsync(int userId, string projectId, UpdateProjectRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteProjectAsync(int userId, string projectId, CancellationToken cancellationToken = default);
}

public sealed class ProjectService : IProjectService
{
    private const string ProjectsFolder = "projects";
    private const string IndexFileName = "index.json";
    private const int MaxProjects = 100;

    private readonly IAzureFileStorageService _storageService;
    private readonly ILogger<ProjectService> _logger;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false
    };

    public ProjectService(IAzureFileStorageService storageService, ILogger<ProjectService> logger)
    {
        _storageService = storageService;
        _logger = logger;
    }

    /// <summary>
    /// List all projects for a user (lightweight, from index)
    /// </summary>
    public async Task<List<ProjectListItem>> ListProjectsAsync(int userId, CancellationToken cancellationToken = default)
    {
        try
        {
            var index = await LoadIndexAsync(userId, cancellationToken);
            return index
                .OrderByDescending(p => p.LastModifiedAt)
                .ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to list projects for user {UserId}", userId);
            return new List<ProjectListItem>();
        }
    }

    /// <summary>
    /// Get a single project with full data
    /// </summary>
    public async Task<UserProject?> GetProjectAsync(int userId, string projectId, CancellationToken cancellationToken = default)
    {
        try
        {
            var relativePath = GetProjectFilePath(userId, projectId);
            await using var stream = await _storageService.DownloadFileAsync(relativePath, cancellationToken);
            return await JsonSerializer.DeserializeAsync<UserProject>(stream, JsonOptions, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Project {ProjectId} not found for user {UserId}", projectId, userId);
            return null;
        }
    }

    /// <summary>
    /// Create a new project
    /// </summary>
    public async Task<UserProject> CreateProjectAsync(int userId, CreateProjectRequest request, CancellationToken cancellationToken = default)
    {
        var now = DateTime.UtcNow;
        var project = new UserProject
        {
            Id = Guid.NewGuid().ToString("N"),
            UserId = userId,
            Name = string.IsNullOrWhiteSpace(request.Name) ? "Untitled Project" : request.Name.Trim(),
            Type = request.Type,
            Status = request.Status,
            CreatedAt = now,
            LastModifiedAt = now,
            Data = request.Data
        };

        // Save project file
        await SaveProjectAsync(project, cancellationToken);

        // Update index
        var index = await LoadIndexAsync(userId, cancellationToken);
        
        // Enforce max projects limit
        if (index.Count >= MaxProjects)
        {
            // Remove oldest projects
            var toRemove = index
                .OrderBy(p => p.LastModifiedAt)
                .Take(index.Count - MaxProjects + 1)
                .ToList();

            foreach (var old in toRemove)
            {
                await DeleteProjectFileAsync(userId, old.Id, cancellationToken);
                index.RemoveAll(p => p.Id == old.Id);
            }
        }

        index.Add(new ProjectListItem
        {
            Id = project.Id,
            Name = project.Name,
            Type = project.Type,
            Status = project.Status,
            CreatedAt = project.CreatedAt,
            LastModifiedAt = project.LastModifiedAt
        });

        await SaveIndexAsync(userId, index, cancellationToken);

        return project;
    }

    /// <summary>
    /// Update an existing project
    /// </summary>
    public async Task<UserProject?> UpdateProjectAsync(int userId, string projectId, UpdateProjectRequest request, CancellationToken cancellationToken = default)
    {
        var existing = await GetProjectAsync(userId, projectId, cancellationToken);
        if (existing == null)
        {
            return null;
        }

        // Apply updates
        if (request.Name != null)
        {
            existing.Name = request.Name.Trim();
        }
        if (request.Type.HasValue)
        {
            existing.Type = request.Type.Value;
        }
        if (request.Status.HasValue)
        {
            existing.Status = request.Status.Value;
        }
        if (request.Data != null)
        {
            existing.Data = request.Data;
        }
        existing.LastModifiedAt = DateTime.UtcNow;

        // Save updated project
        await SaveProjectAsync(existing, cancellationToken);

        // Update index
        var index = await LoadIndexAsync(userId, cancellationToken);
        var indexItem = index.FirstOrDefault(p => p.Id == projectId);
        if (indexItem != null)
        {
            indexItem.Name = existing.Name;
            indexItem.Type = existing.Type;
            indexItem.Status = existing.Status;
            indexItem.LastModifiedAt = existing.LastModifiedAt;
            await SaveIndexAsync(userId, index, cancellationToken);
        }

        return existing;
    }

    /// <summary>
    /// Delete a project
    /// </summary>
    public async Task<bool> DeleteProjectAsync(int userId, string projectId, CancellationToken cancellationToken = default)
    {
        try
        {
            // Delete project file
            await DeleteProjectFileAsync(userId, projectId, cancellationToken);

            // Update index
            var index = await LoadIndexAsync(userId, cancellationToken);
            var removed = index.RemoveAll(p => p.Id == projectId);
            if (removed > 0)
            {
                await SaveIndexAsync(userId, index, cancellationToken);
            }

            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to delete project {ProjectId} for user {UserId}", projectId, userId);
            return false;
        }
    }

    // Helper methods

    private async Task<List<ProjectListItem>> LoadIndexAsync(int userId, CancellationToken cancellationToken)
    {
        try
        {
            var relativePath = GetIndexFilePath(userId);
            await using var stream = await _storageService.DownloadFileAsync(relativePath, cancellationToken);
            return await JsonSerializer.DeserializeAsync<List<ProjectListItem>>(stream, JsonOptions, cancellationToken) 
                   ?? new List<ProjectListItem>();
        }
        catch
        {
            // Index doesn't exist yet
            return new List<ProjectListItem>();
        }
    }

    private async Task SaveIndexAsync(int userId, List<ProjectListItem> index, CancellationToken cancellationToken)
    {
        var json = JsonSerializer.Serialize(index, JsonOptions);
        await _storageService.UploadTextAsync(json, IndexFileName, ProjectsFolder, userId.ToString(), cancellationToken);
    }

    private async Task SaveProjectAsync(UserProject project, CancellationToken cancellationToken)
    {
        var json = JsonSerializer.Serialize(project, JsonOptions);
        var fileName = $"{project.Id}.json";
        await _storageService.UploadTextAsync(json, fileName, ProjectsFolder, project.UserId.ToString(), cancellationToken);
    }

    private async Task DeleteProjectFileAsync(int userId, string projectId, CancellationToken cancellationToken)
    {
        var relativePath = GetProjectFilePath(userId, projectId);
        await _storageService.DeleteFileAsync(relativePath, cancellationToken);
    }

    private static string GetIndexFilePath(int userId)
    {
        return $"{ProjectsFolder}/{userId}/{IndexFileName}";
    }

    private static string GetProjectFilePath(int userId, string projectId)
    {
        return $"{ProjectsFolder}/{userId}/{projectId}.json";
    }
}
