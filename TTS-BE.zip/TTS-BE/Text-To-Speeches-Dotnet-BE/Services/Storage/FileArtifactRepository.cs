using Microsoft.Data.SqlClient;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Database;

namespace Text_To_Speeches_Dotnet_BE.Services.Storage;

public interface IFileArtifactRepository
{
    Task<FileArtifactRecord> UpsertAsync(FileArtifactRecord record, CancellationToken cancellationToken = default);
    Task<FileArtifactRecord?> FindByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task<List<FileArtifactRecord>> GetExpiredAsync(DateTime utcNow, int take, CancellationToken cancellationToken = default);
    Task DeleteByIdAsync(Guid id, CancellationToken cancellationToken = default);
}

public sealed class FileArtifactRepository : IFileArtifactRepository
{
    private readonly ISqlConnectionFactory _connectionFactory;

    public FileArtifactRepository(ISqlConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<FileArtifactRecord> UpsertAsync(FileArtifactRecord record, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           SET NOCOUNT ON;

                           UPDATE dbo.file_artifacts
                           SET
                             user_id = @userId,
                             user_folder = @userFolder,
                             job_id = @jobId,
                             feature = @feature,
                             file_name = @fileName,
                             content_type = @contentType,
                             size_bytes = @sizeBytes,
                             duration_minutes = @durationMinutes,
                             is_output = @isOutput,
                             created_at = @createdAt,
                             expires_at = @expiresAt
                           WHERE relative_path = @relativePath;

                           IF @@ROWCOUNT = 0
                           BEGIN
                             BEGIN TRY
                               INSERT INTO dbo.file_artifacts (
                                 id, user_id, user_folder, job_id, feature, file_name, relative_path,
                                 content_type, size_bytes, duration_minutes, is_output, created_at, expires_at
                               ) VALUES (
                                 @id, @userId, @userFolder, @jobId, @feature, @fileName, @relativePath,
                                 @contentType, @sizeBytes, @durationMinutes, @isOutput, @createdAt, @expiresAt
                               );
                             END TRY
                             BEGIN CATCH
                               IF ERROR_NUMBER() NOT IN (2601, 2627)
                               BEGIN
                                 THROW;
                               END

                               UPDATE dbo.file_artifacts
                               SET
                                 user_id = @userId,
                                 user_folder = @userFolder,
                                 job_id = @jobId,
                                 feature = @feature,
                                 file_name = @fileName,
                                 content_type = @contentType,
                                 size_bytes = @sizeBytes,
                                 duration_minutes = @durationMinutes,
                                 is_output = @isOutput,
                                 created_at = @createdAt,
                                 expires_at = @expiresAt
                               WHERE relative_path = @relativePath;
                             END CATCH
                           END

                           SELECT TOP 1
                             id, user_id, user_folder, job_id, feature, file_name, relative_path,
                             content_type, size_bytes, duration_minutes, is_output, created_at, expires_at
                           FROM dbo.file_artifacts
                           WHERE relative_path = @relativePath;
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", record.Id);
        command.Parameters.AddWithValue("@userId", (object?)record.UserId ?? DBNull.Value);
        command.Parameters.AddWithValue("@userFolder", record.UserFolder);
        command.Parameters.AddWithValue("@jobId", record.JobId);
        command.Parameters.AddWithValue("@feature", record.Feature);
        command.Parameters.AddWithValue("@fileName", record.FileName);
        command.Parameters.AddWithValue("@relativePath", record.RelativePath);
        command.Parameters.AddWithValue("@contentType", (object?)record.ContentType ?? DBNull.Value);
        command.Parameters.AddWithValue("@sizeBytes", record.SizeBytes);
        command.Parameters.AddWithValue("@durationMinutes", (object?)record.DurationMinutes ?? DBNull.Value);
        command.Parameters.AddWithValue("@isOutput", record.IsOutput);
        command.Parameters.AddWithValue("@createdAt", record.CreatedAt);
        command.Parameters.AddWithValue("@expiresAt", record.ExpiresAt);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
        {
            throw new InvalidOperationException("Failed to persist file artifact.");
        }

        return Map(reader);
    }

    public async Task<FileArtifactRecord?> FindByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           SELECT TOP 1
                             id, user_id, user_folder, job_id, feature, file_name, relative_path,
                             content_type, size_bytes, duration_minutes, is_output, created_at, expires_at
                           FROM dbo.file_artifacts
                           WHERE id = @id;
                           """;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", id);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        return await reader.ReadAsync(cancellationToken) ? Map(reader) : null;
    }

    public async Task<List<FileArtifactRecord>> GetExpiredAsync(DateTime utcNow, int take, CancellationToken cancellationToken = default)
    {
        const string sql = """
                           SELECT TOP (@take)
                             id, user_id, user_folder, job_id, feature, file_name, relative_path,
                             content_type, size_bytes, duration_minutes, is_output, created_at, expires_at
                           FROM dbo.file_artifacts
                           WHERE expires_at <= @utcNow
                           ORDER BY expires_at ASC;
                           """;

        var records = new List<FileArtifactRecord>();

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@utcNow", utcNow);
        command.Parameters.AddWithValue("@take", Math.Max(1, take));

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            records.Add(Map(reader));
        }

        return records;
    }

    public async Task DeleteByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        const string sql = "DELETE FROM dbo.file_artifacts WHERE id = @id;";

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@id", id);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static FileArtifactRecord Map(SqlDataReader reader)
    {
        return new FileArtifactRecord
        {
            Id = reader.GetGuid(reader.GetOrdinal("id")),
            UserId = reader.IsDBNull(reader.GetOrdinal("user_id")) ? null : reader.GetInt32(reader.GetOrdinal("user_id")),
            UserFolder = reader.GetString(reader.GetOrdinal("user_folder")),
            JobId = reader.GetString(reader.GetOrdinal("job_id")),
            Feature = reader.GetString(reader.GetOrdinal("feature")),
            FileName = reader.GetString(reader.GetOrdinal("file_name")),
            RelativePath = reader.GetString(reader.GetOrdinal("relative_path")),
            ContentType = reader.IsDBNull(reader.GetOrdinal("content_type")) ? null : reader.GetString(reader.GetOrdinal("content_type")),
            SizeBytes = reader.GetInt64(reader.GetOrdinal("size_bytes")),
            DurationMinutes = reader.IsDBNull(reader.GetOrdinal("duration_minutes")) ? null : reader.GetDouble(reader.GetOrdinal("duration_minutes")),
            IsOutput = reader.GetBoolean(reader.GetOrdinal("is_output")),
            CreatedAt = reader.GetDateTime(reader.GetOrdinal("created_at")),
            ExpiresAt = reader.GetDateTime(reader.GetOrdinal("expires_at"))
        };
    }
}
