using Azure;
using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;

namespace Text_To_Speeches_Dotnet_BE.Services.Storage;

public interface IAzureFileStorageService
{
    Task<AzureStoredFile> UploadFileAsync(Stream fileStream, string fileName, string userFolder, string jobId, CancellationToken cancellationToken = default);
    Task<AzureStoredFile> UploadTextAsync(string content, string fileName, string userFolder, string jobId, CancellationToken cancellationToken = default);
    Task<Stream> DownloadFileAsync(string relativePath, CancellationToken cancellationToken = default);
    Task<string?> GetContentTypeAsync(string relativePath, CancellationToken cancellationToken = default);
    Task DeleteFileAsync(string relativePath, CancellationToken cancellationToken = default);
}

public sealed class AzureFileStorageService : IAzureFileStorageService
{
    private readonly ShareClient _shareClient;

    public AzureFileStorageService(IOptions<AzureStorageOptions> storageOptions)
    {
        var options = storageOptions.Value;
        if (string.IsNullOrWhiteSpace(options.ConnectionString))
        {
            throw new InvalidOperationException("AzureStorage:ConnectionString is missing.");
        }

        if (string.IsNullOrWhiteSpace(options.FileShareName))
        {
            throw new InvalidOperationException("AzureStorage:FileShareName is missing.");
        }

        _shareClient = new ShareClient(options.ConnectionString, options.FileShareName);
        _shareClient.CreateIfNotExists();
    }

    public async Task<AzureStoredFile> UploadFileAsync(
        Stream fileStream,
        string fileName,
        string userFolder,
        string jobId,
        CancellationToken cancellationToken = default)
    {
        var safeUserFolder = SafeSegment(userFolder, "anonymous");
        var safeJobId = SafeSegment(jobId, Guid.NewGuid().ToString("N"));
        var safeFileName = SafeFileName(fileName);

        var directory = await EnsureDirectoryAsync(safeUserFolder, safeJobId, cancellationToken);
        var fileClient = directory.GetFileClient(safeFileName);

        if (fileStream.CanSeek)
        {
            fileStream.Position = 0;
        }

        using var content = await ToMemoryAsync(fileStream, cancellationToken);
        await fileClient.CreateAsync(content.Length, cancellationToken: cancellationToken);
        await fileClient.UploadRangeAsync(new HttpRange(0, content.Length), content, cancellationToken: cancellationToken);

        return new AzureStoredFile
        {
            FileName = safeFileName,
            RelativePath = $"{safeUserFolder}/{safeJobId}/{safeFileName}",
            Uri = fileClient.Uri.ToString()
        };
    }

    public async Task<AzureStoredFile> UploadTextAsync(
        string content,
        string fileName,
        string userFolder,
        string jobId,
        CancellationToken cancellationToken = default)
    {
        await using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(content ?? string.Empty), writable: false);
        return await UploadFileAsync(stream, fileName, userFolder, jobId, cancellationToken);
    }

    public async Task<Stream> DownloadFileAsync(string relativePath, CancellationToken cancellationToken = default)
    {
        var fileClient = GetFileClient(relativePath);
        var response = await fileClient.DownloadAsync(cancellationToken: cancellationToken);
        return response.Value.Content;
    }

    public async Task<string?> GetContentTypeAsync(string relativePath, CancellationToken cancellationToken = default)
    {
        var fileClient = GetFileClient(relativePath);
        try
        {
            var properties = await fileClient.GetPropertiesAsync(cancellationToken: cancellationToken);
            return properties.Value.ContentType;
        }
        catch (RequestFailedException ex) when (ex.Status == 404)
        {
            return null;
        }
    }

    public async Task DeleteFileAsync(string relativePath, CancellationToken cancellationToken = default)
    {
        var fileClient = GetFileClient(relativePath);
        await fileClient.DeleteIfExistsAsync(cancellationToken: cancellationToken);
    }

    private async Task<ShareDirectoryClient> EnsureDirectoryAsync(string userFolder, string jobId, CancellationToken cancellationToken)
    {
        var root = _shareClient.GetRootDirectoryClient();
        var userDirectory = root.GetSubdirectoryClient(userFolder);
        await userDirectory.CreateIfNotExistsAsync(cancellationToken: cancellationToken);

        var jobDirectory = userDirectory.GetSubdirectoryClient(jobId);
        await jobDirectory.CreateIfNotExistsAsync(cancellationToken: cancellationToken);
        return jobDirectory;
    }

    private ShareFileClient GetFileClient(string relativePath)
    {
        var normalized = (relativePath ?? string.Empty).Replace("\\", "/", StringComparison.Ordinal);
        var segments = normalized.Split('/', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (segments.Length < 3)
        {
            throw new InvalidOperationException("Invalid storage path.");
        }

        var root = _shareClient.GetRootDirectoryClient();
        ShareDirectoryClient currentDirectory = root.GetSubdirectoryClient(segments[0]);
        for (var i = 1; i < segments.Length - 1; i++)
        {
            currentDirectory = currentDirectory.GetSubdirectoryClient(segments[i]);
        }

        return currentDirectory.GetFileClient(segments[^1]);
    }

    private static async Task<MemoryStream> ToMemoryAsync(Stream source, CancellationToken cancellationToken)
    {
        var target = new MemoryStream();
        await source.CopyToAsync(target, cancellationToken);
        target.Position = 0;
        return target;
    }

    private static string SafeSegment(string? value, string fallback)
    {
        var trimmed = (value ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(trimmed))
        {
            return fallback;
        }

        var invalid = Path.GetInvalidFileNameChars();
        var cleanChars = trimmed.Where(ch => !invalid.Contains(ch) && ch != '/' && ch != '\\').ToArray();
        var clean = new string(cleanChars);
        return string.IsNullOrWhiteSpace(clean) ? fallback : clean;
    }

    private static string SafeFileName(string? value)
    {
        var fileName = Path.GetFileName(value ?? string.Empty);
        if (string.IsNullOrWhiteSpace(fileName))
        {
            return $"{Guid.NewGuid():N}.bin";
        }

        var invalid = Path.GetInvalidFileNameChars();
        var clean = new string(fileName.Where(ch => !invalid.Contains(ch)).ToArray());
        return string.IsNullOrWhiteSpace(clean) ? $"{Guid.NewGuid():N}.bin" : clean;
    }
}

public sealed class AzureStoredFile
{
    public string FileName { get; set; } = string.Empty;
    public string RelativePath { get; set; } = string.Empty;
    public string Uri { get; set; } = string.Empty;
}
