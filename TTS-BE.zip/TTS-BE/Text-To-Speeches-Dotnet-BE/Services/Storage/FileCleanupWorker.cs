namespace Text_To_Speeches_Dotnet_BE.Services.Storage;

public sealed class FileCleanupWorker : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<FileCleanupWorker> _logger;

    public FileCleanupWorker(
        IServiceScopeFactory scopeFactory,
        ILogger<FileCleanupWorker> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await RunCleanupBatchAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "File cleanup worker failed.");
            }

            await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
        }
    }

    private async Task RunCleanupBatchAsync(CancellationToken cancellationToken)
    {
        using var scope = _scopeFactory.CreateScope();
        var storageService = scope.ServiceProvider.GetRequiredService<IAzureFileStorageService>();
        var artifactRepository = scope.ServiceProvider.GetRequiredService<IFileArtifactRepository>();

        var expiredAt = DateTime.UtcNow;
        var expired = await artifactRepository.GetExpiredAsync(expiredAt, take: 500, cancellationToken);

        foreach (var record in expired)
        {
            try
            {
                await storageService.DeleteFileAsync(record.RelativePath, cancellationToken);
                await artifactRepository.DeleteByIdAsync(record.Id, cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to delete expired Azure file path: {Path}", record.RelativePath);
            }
        }

        if (expired.Count > 0)
        {
            _logger.LogInformation("Cleanup worker deleted {Count} expired file artifacts.", expired.Count);
        }
    }
}
