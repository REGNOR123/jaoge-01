using Text_To_Speeches_Dotnet_BE.Models;

namespace Text_To_Speeches_Dotnet_BE.Services.ScriptGeneration;

public interface IScriptGenerationService
{
    /// <summary>
    /// Generates a script based on the provided SKU and inputs using Azure OpenAI
    /// </summary>
    /// <param name="sku">Script type: youtube, short, podcast, explainer, custom</param>
    /// <param name="request">Script generation request with SKU-specific inputs</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Script generation response with generated script and metadata</returns>
    Task<ScriptGenerationResponse> GenerateScriptAsync(
        string sku,
        ScriptGenerationRequest request,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Generates a single field content for the auto-generate button
    /// </summary>
    /// <param name="sku">Script type: youtube, short, podcast, explainer, custom</param>
    /// <param name="request">Field generation request with field ID and context</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Field generation response with generated field content</returns>
    Task<GenerateFieldResponse> GenerateFieldAsync(
        string sku,
        GenerateFieldRequest request,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Transforms an existing script using Azure OpenAI
    /// </summary>
    /// <param name="sku">Script type context for the transformation</param>
    /// <param name="request">Transformation request with script and transformation type</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Transformation response with transformed script and metadata</returns>
    Task<ScriptTransformationResponse> TransformScriptAsync(
        string sku,
        ScriptTransformationRequest request,
        CancellationToken cancellationToken = default);
}
