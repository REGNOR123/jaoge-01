using System.Text.Json;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Chat;

namespace Text_To_Speeches_Dotnet_BE.Services.ScriptGeneration;

public sealed class ScriptGenerationService : IScriptGenerationService
{
    private readonly IAzureOpenAiChatService _chatService;
    private readonly ILogger<ScriptGenerationService> _logger;
    private readonly IWebHostEnvironment _environment;

    public ScriptGenerationService(
        IAzureOpenAiChatService chatService,
        ILogger<ScriptGenerationService> logger,
        IWebHostEnvironment environment)
    {
        _chatService = chatService;
        _logger = logger;
        _environment = environment;
    }

    public async Task<ScriptGenerationResponse> GenerateScriptAsync(
        string sku,
        ScriptGenerationRequest request,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Validate SKU
            if (!IsValidSku(sku))
            {
                return ErrorResponse("Invalid script type (SKU). Valid types: youtube, short, podcast, explainer, custom", "UNKNOWN_SKU");
            }

            // Build system prompt based on SKU
            var systemPrompt = BuildSystemPrompt(sku);

            // Build user message from inputs based on SKU
            var userMessage = BuildUserMessage(sku, request);

            if (string.IsNullOrEmpty(userMessage))
            {
                return ErrorResponse("Failed to build user message from inputs.", "VALIDATION_ERROR");
            }

            // Call Azure OpenAI
            var script = await _chatService.CompleteAsync(userMessage, systemPrompt, cancellationToken);

            // Calculate metadata
            var metadata = CalculateMetadata(script, sku);

            return new ScriptGenerationResponse
            {
                Success = true,
                Script = script,
                Metadata = metadata
            };
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Azure OpenAI configuration/runtime error for SKU: {sku}", sku);
            var errorMessage = _environment.IsDevelopment() ? ex.Message : "Azure OpenAI is not configured.";
            return ErrorResponse(errorMessage, "AZURE_OPENAI_ERROR");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Script generation error for SKU: {sku}", sku);
            return ErrorResponse("Failed to generate script.", "INTERNAL_ERROR");
        }
    }

    public async Task<GenerateFieldResponse> GenerateFieldAsync(
        string sku,
        GenerateFieldRequest request,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Validate SKU
            if (!IsValidSku(sku))
            {
                return ErrorFieldResponse("Invalid script type (SKU). Valid types: youtube, short, podcast, explainer, custom", "UNKNOWN_SKU");
            }

            // Validate field ID exists for this SKU
            if (!IsValidFieldForSku(sku, request.FieldId))
            {
                return ErrorFieldResponse($"Field '{request.FieldId}' is not supported for SKU '{sku}'", "INVALID_FIELD");
            }

            // Validate context is not empty
            if (request.Context == null || request.Context.Count == 0)
            {
                return ErrorFieldResponse("Context is required to generate field", "VALIDATION_ERROR");
            }

            // Build field-specific system prompt
            var systemPrompt = BuildFieldSystemPrompt(sku, request.FieldId);

            // Build field-specific user message
            var userMessage = BuildFieldPrompt(sku, request.FieldId, request.Context);

            if (string.IsNullOrEmpty(userMessage))
            {
                return ErrorFieldResponse("Failed to build field prompt.", "VALIDATION_ERROR");
            }

            // Call Azure OpenAI to generate field content
            var fieldContent = await _chatService.CompleteAsync(userMessage, systemPrompt, cancellationToken);

            // Trim the content to ensure no extra whitespace
            fieldContent = fieldContent?.Trim() ?? string.Empty;

            _logger.LogInformation("Field generated successfully for SKU: {sku}, Field: {fieldId}", sku, request.FieldId);

            return new GenerateFieldResponse
            {
                Success = true,
                Content = fieldContent
            };
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Azure OpenAI configuration/runtime error for SKU: {sku}, Field: {fieldId}", sku, request.FieldId);
            var errorMessage = _environment.IsDevelopment() ? ex.Message : "Azure OpenAI is not configured.";
            return ErrorFieldResponse(errorMessage, "AZURE_OPENAI_ERROR");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Field generation error for SKU: {sku}, Field: {fieldId}", sku, request.FieldId);
            return ErrorFieldResponse("Failed to generate field content.", "INTERNAL_ERROR");
        }
    }

    public async Task<ScriptTransformationResponse> TransformScriptAsync(
        string sku,
        ScriptTransformationRequest request,
        CancellationToken cancellationToken = default)
    {
        try
        {
            // Validate SKU
            if (!IsValidSku(sku))
            {
                return ErrorTransformResponse("Invalid script type (SKU). Valid types: youtube, short, podcast, explainer, custom", "UNKNOWN_SKU");
            }

            var wordCountBefore = CountWords(request.Script);

            // Build transformation system prompt
            var systemPrompt = BuildTransformationSystemPrompt(request.Transformation, request.Tone, sku);

            // Call Azure OpenAI for transformation
            var transformedScript = await _chatService.CompleteAsync(
                request.Script,
                systemPrompt,
                cancellationToken);

            var wordCountAfter = CountWords(transformedScript);
            var percentChange = wordCountBefore > 0
                ? ((wordCountAfter - wordCountBefore) / (double)wordCountBefore) * 100
                : 0;

            return new ScriptTransformationResponse
            {
                Success = true,
                Script = transformedScript,
                Metadata = new TransformationMetadata
                {
                    WordCountBefore = wordCountBefore,
                    WordCountAfter = wordCountAfter,
                    PercentChange = Math.Round(percentChange, 1)
                }
            };
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Azure OpenAI configuration/runtime error for SKU: {sku}", sku);
            var errorMessage = _environment.IsDevelopment() ? ex.Message : "Azure OpenAI is not configured.";
            return ErrorTransformResponse(errorMessage, "AZURE_OPENAI_ERROR");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Script transformation error for SKU: {sku}", sku);
            return ErrorTransformResponse("Failed to transform script.", "INTERNAL_ERROR");
        }
    }

    #region Private Methods

    private bool IsValidSku(string sku)
    {
        return sku switch
        {
            "youtube" or "short" or "podcast" or "explainer" or "custom" => true,
            _ => false
        };
    }

    private string BuildSystemPrompt(string sku)
    {
        return sku switch
        {
            "youtube" => """
                You are a professional YouTube scriptwriter with 10+ years of experience creating engaging, 
                high-converting video scripts. Your scripts:
                - Hook viewers in the first 10 seconds
                - Use clear section transitions
                - Include natural calls-to-action
                - Maintain conversational tone while being informative
                - Follow the structure: Hook → Introduction → Sections → Transitions → CTA → Outro

                Generate ONLY the script text. No markdown formatting, no headers like "Script:", no explanations.
                """,

            "short" => """
                You are an expert short-form video scriptwriter specializing in TikTok, Instagram Reels, and YouTube Shorts.
                Your scripts:
                - Grab attention in the first 1-2 seconds
                - Have punchy, memorable punchlines
                - Build momentum towards a satisfying climax
                - Use hook → hook → pay-off structure
                - Feel natural and spontaneous
                - Optimized for 15-90 second videos

                Generate ONLY the script text. No markdown formatting, no explanations, no timestamps.
                """,

            "podcast" => """
                You are an experienced podcast scriptwriter specializing in natural, conversational dialogue.
                Your scripts:
                - Feel natural and spontaneous (not robotic reading)
                - Have smooth transitions between segments
                - Include speaker cues when needed
                - Maintain consistent pacing and energy
                - Use proper segment breaks for clarity
                - Sound professional yet personable

                Generate ONLY the script text. Format with [SEGMENT: Title] markers for clarity. No additional explanations.
                """,

            "explainer" => """
                You are an experienced explainer video scriptwriter who can break down complex topics for various audiences.
                Your scripts:
                - Follow a clear problem → solution → benefit arc
                - Use simple, accessible language (avoid jargon unless explained)
                - Include relevant examples and analogies
                - Build understanding progressively
                - Maintain appropriate pacing for the audience level
                - Are engaging and maintain viewer interest

                Generate ONLY the script text. No markdown formatting, no headers, no explanations.
                """,

            "custom" => """
                You are a versatile professional scriptwriter capable of adapting to any topic and style.
                Your scripts:
                - Match the requested tone and length precisely
                - Are well-structured with clear beginning, middle, and end
                - Engage the intended audience
                - Include appropriate transitions and pacing
                - Are polished and ready to use

                Generate ONLY the script text. No markdown formatting, no meta-commentary, no explanations.
                """,

            _ => "You are a professional scriptwriter. Generate engaging, well-structured scripts for video content. Generate ONLY the script text."
        };
    }

    private string BuildUserMessage(string sku, ScriptGenerationRequest request)
    {
        if (request.Inputs == null || request.Inputs.Count == 0)
        {
            return string.Empty;
        }

        return sku switch
        {
            "youtube" => BuildYouTubePrompt(request.Inputs),
            "short" => BuildShortPrompt(request.Inputs),
            "podcast" => BuildPodcastPrompt(request.Inputs),
            "explainer" => BuildExplainerPrompt(request.Inputs),
            "custom" => BuildCustomPrompt(request.Inputs),
            _ => string.Empty
        };
    }

    private string BuildYouTubePrompt(Dictionary<string, object?> inputs)
    {
        var prompt = new System.Text.StringBuilder();
        prompt.AppendLine("Create a YouTube video script with the following specifications:");
        prompt.AppendLine();

        AppendIfPresent(prompt, "Topic", inputs, "topic");
        AppendIfPresent(prompt, "Target Audience", inputs, "targetAudience");
        AppendIfPresent(prompt, "Hook", inputs, "hook");
        AppendIfPresent(prompt, "Main Points (comma-separated)", inputs, "mainPoints");
        AppendIfPresent(prompt, "Call-to-Action", inputs, "cta");
        AppendIfPresent(prompt, "Tone", inputs, "tone");
        AppendIfPresent(prompt, "Length", inputs, "length");
        AppendIfPresent(prompt, "Pace", inputs, "pace");

        prompt.AppendLine();
        prompt.AppendLine("Ensure the script includes Hook, Introduction, Main Sections with Clear Transitions, and a Strong CTA.");

        return prompt.ToString();
    }

    private string BuildShortPrompt(Dictionary<string, object?> inputs)
    {
        var prompt = new System.Text.StringBuilder();
        prompt.AppendLine("Create a short-form video script (TikTok/Reel style) with the following specifications:");
        prompt.AppendLine();

        AppendIfPresent(prompt, "Concept/Topic", inputs, "concept");
        AppendIfPresent(prompt, "Key Message", inputs, "keyMessage");
        AppendIfPresent(prompt, "Hook", inputs, "hook");
        AppendIfPresent(prompt, "Body/Main Content", inputs, "body");
        AppendIfPresent(prompt, "Climax/Payoff", inputs, "climax");
        AppendIfPresent(prompt, "Tone", inputs, "tone");
        AppendIfPresent(prompt, "Duration", inputs, "duration");

        prompt.AppendLine();
        prompt.AppendLine("Make it punchy, memorable, and optimized for short-form video platforms.");

        return prompt.ToString();
    }

    private string BuildPodcastPrompt(Dictionary<string, object?> inputs)
    {
        var prompt = new System.Text.StringBuilder();
        prompt.AppendLine("Create a podcast episode script with the following specifications:");
        prompt.AppendLine();

        AppendIfPresent(prompt, "Topic", inputs, "topic");
        AppendIfPresent(prompt, "Format", inputs, "format");
        AppendIfPresent(prompt, "Opening/Introduction", inputs, "opening");
        AppendIfPresent(prompt, "Segments/Main Content", inputs, "segments");
        AppendIfPresent(prompt, "Conclusion", inputs, "conclusion");
        AppendIfPresent(prompt, "Tone", inputs, "tone");
        AppendIfPresent(prompt, "Depth Level", inputs, "depth");
        AppendIfPresent(prompt, "Duration", inputs, "duration");

        prompt.AppendLine();
        prompt.AppendLine("Make it conversational, engaging, and natural to listen to. Use speaker cues where appropriate.");

        return prompt.ToString();
    }

    private string BuildExplainerPrompt(Dictionary<string, object?> inputs)
    {
        var prompt = new System.Text.StringBuilder();
        prompt.AppendLine("Create an explainer video script with the following specifications:");
        prompt.AppendLine();

        AppendIfPresent(prompt, "Topic", inputs, "topic");
        AppendIfPresent(prompt, "Target Education Level", inputs, "targetLevel");
        AppendIfPresent(prompt, "Why This Matters (context)", inputs, "whyItMatters");
        AppendIfPresent(prompt, "Key Points to Cover", inputs, "keyPoints");
        AppendIfPresent(prompt, "Examples/Analogies", inputs, "examples");
        AppendIfPresent(prompt, "Tone", inputs, "tone");
        AppendIfPresent(prompt, "Length", inputs, "length");

        prompt.AppendLine();
        prompt.AppendLine("Explain clearly, use simple language, and build understanding progressively.");

        return prompt.ToString();
    }

    private string BuildCustomPrompt(Dictionary<string, object?> inputs)
    {
        var prompt = new System.Text.StringBuilder();
        prompt.AppendLine("Create a custom script with the following specifications:");
        prompt.AppendLine();

        AppendIfPresent(prompt, "Topic", inputs, "topic");
        AppendIfPresent(prompt, "Description/Instructions", inputs, "description");
        AppendIfPresent(prompt, "Tone", inputs, "tone");
        AppendIfPresent(prompt, "Length", inputs, "length");

        return prompt.ToString();
    }

    private void AppendIfPresent(
        System.Text.StringBuilder prompt,
        string label,
        Dictionary<string, object?> inputs,
        string key)
    {
        if (inputs.TryGetValue(key, out var value) && value != null)
        {
            prompt.AppendLine($"- {label}: {value}");
        }
    }

    private string BuildTransformationSystemPrompt(string transformationType, string? tone, string sku)
    {
        var basePrompt = $"You are a {sku} scriptwriter specializing in script editing and refinement. ";

        var transformationPrompt = transformationType switch
        {
            "rewrite" => "Rewrite the provided script to improve clarity, pacing, and engagement while keeping the same meaning and structure.",

            "shorten" => "Shorten the provided script while keeping all key points, removing filler content, and maintaining the overall message.",

            "expand" => "Expand the provided script with additional detail, examples, and elaboration without becoming repetitive or losing focus.",

            "tone-change" => !string.IsNullOrWhiteSpace(tone)
                ? $"Rewrite the provided script in a {tone} tone while preserving the core message and structure."
                : "Rewrite the provided script while adjusting the tone as needed.",

            _ => "Refine the provided script for better quality."
        };

        return $"{basePrompt}{transformationPrompt} Generate ONLY the transformed script text. No markdown formatting, no explanations, no meta-commentary.";
    }

    private ScriptMetadata CalculateMetadata(string script, string sku)
    {
        var wordCount = CountWords(script);
        var charCount = script.Length;
        var estimatedReadTime = EstimateReadTime(wordCount);
        var sections = GetSectionsForSku(sku);

        return new ScriptMetadata
        {
            EstimatedReadTime = estimatedReadTime,
            Sections = sections,
            WordCount = wordCount,
            CharacterCount = charCount
        };
    }

    private int CountWords(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return 0;
        }

        return text.Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries).Length;
    }

    private string EstimateReadTime(int wordCount)
    {
        // Average reading speed is ~150 words per minute
        var minutes = Math.Ceiling(wordCount / 150.0);
        var minutesInt = (int)minutes;

        if (minutesInt <= 1)
        {
            return "Less than 1 minute";
        }

        return $"{minutesInt} minutes";
    }

    private List<string> GetSectionsForSku(string sku)
    {
        return sku switch
        {
            "youtube" => new List<string> { "Hook", "Introduction", "Sections", "Transition statements", "CTA", "Outro" },
            "short" => new List<string> { "Hook", "Main content", "Climax", "Outro/CTA" },
            "podcast" => new List<string> { "Opening", "Segments", "Transitions", "Conclusion" },
            "explainer" => new List<string> { "Hook", "Problem", "Explanation", "Examples", "Conclusion" },
            "custom" => new List<string> { "Introduction", "Main Content", "Conclusion" },
            _ => new List<string>()
        };
    }

    private static ScriptGenerationResponse ErrorResponse(string error, string code)
    {
        return new ScriptGenerationResponse
        {
            Success = false,
            Error = error,
            Code = code
        };
    }

    private static GenerateFieldResponse ErrorFieldResponse(string error, string code)
    {
        return new GenerateFieldResponse
        {
            Success = false,
            Error = error,
            Code = code
        };
    }

    private static ScriptTransformationResponse ErrorTransformResponse(string error, string code)
    {
        return new ScriptTransformationResponse
        {
            Success = false,
            Error = error,
            Code = code
        };
    }

    private bool IsValidFieldForSku(string sku, string fieldId)
    {
        var validFields = sku switch
        {
            "youtube" => new[] { "hook", "mainpoints", "cta" },
            "short" => new[] { "hook", "body", "climax" },
            "podcast" => new[] { "opening", "segments", "conclusion" },
            "explainer" => new[] { "whyitmatters", "keypoints", "examples" },
            "custom" => Array.Empty<string>(), // Custom doesn't support auto-generate
            _ => Array.Empty<string>()
        };

        return validFields.Contains(fieldId.ToLowerInvariant());
    }

    private string BuildFieldSystemPrompt(string sku, string fieldId)
    {
        var basePrompt = sku switch
        {
            "youtube" => "You are a professional YouTube scriptwriter with 10+ years of experience.",
            "short" => "You are an expert short-form video scriptwriter specializing in punchy, engaging content.",
            "podcast" => "You are an experienced podcast scriptwriter specializing in natural, conversational dialogue.",
            "explainer" => "You are an experienced explainer video scriptwriter.",
            _ => "You are a professional scriptwriter."
        };

        var fieldSpecificGuidance = fieldId.ToLowerInvariant() switch
        {
            "hook" => "Generate a compelling hook that grabs attention immediately.",
            "mainpoints" => "Generate the main points or key arguments as a comma-separated list.",
            "cta" => "Generate a clear call-to-action that encourages engagement.",
            "body" => "Generate engaging body content that maintains momentum.",
            "climax" => "Generate a satisfying climax or payoff moment.",
            "opening" => "Generate a compelling opening that sets the tone.",
            "segments" => "Generate the main segments or outline for the content.",
            "conclusion" => "Generate a strong conclusion that ties everything together.",
            "whyitmatters" => "Generate context on why this topic matters.",
            "keypoints" => "Generate key points as a comma-separated list.",
            "examples" => "Generate examples to illustrate the concept.",
            _ => "Generate relevant content for this field."
        };

        return $"{basePrompt} {fieldSpecificGuidance} Generate ONLY the field content. No markdown, no explanations, no meta-commentary.";
    }

    private string BuildFieldPrompt(string sku, string fieldId, Dictionary<string, object?> context)
    {
        var prompt = new System.Text.StringBuilder();
        prompt.AppendLine($"Generate the '{fieldId}' field for a {sku} script with this context:");
        prompt.AppendLine();

        foreach (var kvp in context.Where(x => x.Value != null))
        {
            prompt.AppendLine($"- {kvp.Key}: {kvp.Value}");
        }

        return prompt.ToString();
    }

    #endregion
}
