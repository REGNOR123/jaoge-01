using System.Security.Cryptography;

namespace Text_To_Speeches_Dotnet_BE.Services.Security;

public interface IPasswordService
{
    string HashPassword(string password);
    bool VerifyPassword(string password, string? storedValue);
}

public sealed class PasswordService : IPasswordService
{
    private const int Iterations = 100000;
    private const int KeyLength = 64;
    private static readonly HashAlgorithmName Digest = HashAlgorithmName.SHA512;

    public string HashPassword(string password)
    {
        var saltBytes = RandomNumberGenerator.GetBytes(16);
        var hashBytes = Rfc2898DeriveBytes.Pbkdf2(
            password,
            saltBytes,
            Iterations,
            Digest,
            KeyLength);

        var saltHex = Convert.ToHexString(saltBytes).ToLowerInvariant();
        var hashHex = Convert.ToHexString(hashBytes).ToLowerInvariant();
        return $"{saltHex}:{hashHex}";
    }

    public bool VerifyPassword(string password, string? storedValue)
    {
        if (string.IsNullOrWhiteSpace(storedValue) || !storedValue.Contains(':'))
        {
            return false;
        }

        var parts = storedValue.Split(':', 2);
        if (parts.Length != 2)
        {
            return false;
        }

        byte[] saltBytes;
        byte[] originalHashBytes;
        try
        {
            saltBytes = Convert.FromHexString(parts[0]);
            originalHashBytes = Convert.FromHexString(parts[1]);
        }
        catch (FormatException)
        {
            return false;
        }

        var computedHashBytes = Rfc2898DeriveBytes.Pbkdf2(
            password,
            saltBytes,
            Iterations,
            Digest,
            KeyLength);

        if (originalHashBytes.Length != computedHashBytes.Length)
        {
            return false;
        }

        return CryptographicOperations.FixedTimeEquals(originalHashBytes, computedHashBytes);
    }
}
