using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Text_To_Speeches_Dotnet_BE.Services.Database;

namespace Text_To_Speeches_Dotnet_BE.Middleware;

public sealed class UserBanMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IMemoryCache _cache;
    private readonly ILogger<UserBanMiddleware> _logger;

    private static readonly TimeSpan CacheTtl = TimeSpan.FromSeconds(30);

    public UserBanMiddleware(
        RequestDelegate next,
        IServiceScopeFactory scopeFactory,
        IMemoryCache cache,
        ILogger<UserBanMiddleware> logger)
    {
        _next = next;
        _scopeFactory = scopeFactory;
        _cache = cache;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (context.User.Identity?.IsAuthenticated == true)
        {
            var idClaim = context.User.FindFirst("id")?.Value
                ?? context.User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (int.TryParse(idClaim, out var userId) && await IsBannedAsync(userId))
            {
                _logger.LogWarning("Banned user {UserId} attempted access to {Path}", userId, context.Request.Path);
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsJsonAsync(new
                {
                    success = false,
                    error = "Account suspended. Please contact support."
                });
                return;
            }
        }

        await _next(context);
    }

    private async Task<bool> IsBannedAsync(int userId)
    {
        var cacheKey = $"user_banned_{userId}";
        if (_cache.TryGetValue(cacheKey, out bool cached))
            return cached;

        var isBanned = false;
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<ISqlConnectionFactory>();
            await using var conn = factory.CreateConnection();
            await conn.OpenAsync();
            await using var cmd = new SqlCommand(
                "SELECT is_banned FROM dbo.users WHERE id = @userId",
                conn);
            cmd.Parameters.AddWithValue("@userId", userId);
            var result = await cmd.ExecuteScalarAsync();
            isBanned = result is not DBNull && Convert.ToBoolean(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to check ban status for user {UserId}", userId);
        }

        _cache.Set(cacheKey, isBanned, new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = CacheTtl
        });
        return isBanned;
    }
}
