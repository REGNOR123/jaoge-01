namespace Text_To_Speeches_Dotnet_BE.Middleware;

public sealed class MaintenanceMiddleware(RequestDelegate next, IConfiguration config)
{
    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.Path.StartsWithSegments("/api") &&
            !context.Request.Path.StartsWithSegments("/api/health"))
        {
            var inMaintenance = string.Equals(
                config["MAINTENANCE_MODE"], "true",
                StringComparison.OrdinalIgnoreCase);

            if (inMaintenance)
            {
                context.Response.StatusCode = StatusCodes.Status503ServiceUnavailable;
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsJsonAsync(new
                {
                    success = false,
                    error = "Service is temporarily unavailable for maintenance. Please try again later."
                });
                return;
            }
        }

        await next(context);
    }
}
