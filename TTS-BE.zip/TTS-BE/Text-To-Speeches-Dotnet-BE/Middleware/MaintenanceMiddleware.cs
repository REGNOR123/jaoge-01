using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Text_To_Speeches_Dotnet_BE.Services.Database;

namespace Text_To_Speeches_Dotnet_BE.Middleware;

public sealed class MaintenanceMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IMemoryCache _cache;
    private readonly ILogger<MaintenanceMiddleware> _logger;

    private const string CacheKey = "service_enabled_v1";
    private static readonly TimeSpan CacheRefresh = TimeSpan.FromMinutes(1);

    public MaintenanceMiddleware(
        RequestDelegate next,
        IServiceScopeFactory scopeFactory,
        IMemoryCache cache,
        ILogger<MaintenanceMiddleware> logger)
    {
        _next = next;
        _scopeFactory = scopeFactory;
        _cache = cache;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.Path.StartsWithSegments("/api") &&
            !context.Request.Path.StartsWithSegments("/api/health"))
        {
            var enabled = await GetServiceEnabledAsync();
            if (!enabled)
            {
                context.Response.StatusCode = StatusCodes.Status503ServiceUnavailable;
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsJsonAsync(new
                {
                    success = false,
                    error = "Service is temporarily unavailable for maintenance. Please try again later."
                });
                return;
            }
        }

        await _next(context);
    }

    private async Task<bool> GetServiceEnabledAsync()
    {
        if (_cache.TryGetValue(CacheKey, out bool cached))
            return cached;

        var enabled = true;
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<ISqlConnectionFactory>();
            await using var conn = factory.CreateConnection();
            await conn.OpenAsync();
            await using var cmd = new SqlCommand(
                "SELECT config_value FROM dbo.app_config WHERE config_key = 'service_enabled'",
                conn);
            var result = await cmd.ExecuteScalarAsync();
            enabled = result is not string s || !string.Equals(s, "false", StringComparison.OrdinalIgnoreCase);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to read service_enabled flag — defaulting to enabled");
        }

        _cache.Set(CacheKey, enabled, new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = CacheRefresh
        });
        return enabled;
    }
}
