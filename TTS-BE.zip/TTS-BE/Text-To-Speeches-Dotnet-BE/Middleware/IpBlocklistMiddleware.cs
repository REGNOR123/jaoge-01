using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Text_To_Speeches_Dotnet_BE.Services.Database;

namespace Text_To_Speeches_Dotnet_BE.Middleware;

public sealed class IpBlocklistMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IMemoryCache _cache;
    private readonly ILogger<IpBlocklistMiddleware> _logger;

    private const string CacheKey = "blocked_ips_v1";
    private static readonly TimeSpan CacheRefresh = TimeSpan.FromMinutes(5);

    public IpBlocklistMiddleware(
        RequestDelegate next,
        IServiceScopeFactory scopeFactory,
        IMemoryCache cache,
        ILogger<IpBlocklistMiddleware> logger)
    {
        _next = next;
        _scopeFactory = scopeFactory;
        _cache = cache;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var ip = context.Connection.RemoteIpAddress?.ToString();
        if (!string.IsNullOrWhiteSpace(ip))
        {
            var blocklist = await GetBlocklistAsync();
            if (blocklist.Contains(ip))
            {
                _logger.LogWarning("Blocked request from IP {Ip} to {Path}", ip, context.Request.Path);
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsJsonAsync(new { success = false, error = "Access denied." });
                return;
            }
        }

        await _next(context);
    }

    private async Task<HashSet<string>> GetBlocklistAsync()
    {
        if (_cache.TryGetValue(CacheKey, out HashSet<string>? cached) && cached is not null)
            return cached;

        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            using var scope = _scopeFactory.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<ISqlConnectionFactory>();
            await using var conn = factory.CreateConnection();
            await conn.OpenAsync();
            await using var cmd = new SqlCommand(
                "SELECT ip_address FROM dbo.blocked_ips WHERE blocked_until IS NULL OR blocked_until > SYSUTCDATETIME()",
                conn);
            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
                set.Add(reader.GetString(0));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to load IP blocklist — no IPs blocked this cycle");
        }

        _cache.Set(CacheKey, set, new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = CacheRefresh
        });
        return set;
    }
}
