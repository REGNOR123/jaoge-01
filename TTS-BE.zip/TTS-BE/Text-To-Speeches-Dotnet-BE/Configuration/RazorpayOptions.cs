namespace Text_To_Speeches_Dotnet_BE.Configuration;

public sealed class RazorpayOptions
{
    public string KeyId { get; set; } = string.Empty;
    public string KeySecret { get; set; } = string.Empty;
}
