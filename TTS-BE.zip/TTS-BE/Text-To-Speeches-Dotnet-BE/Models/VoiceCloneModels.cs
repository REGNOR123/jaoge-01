using System.ComponentModel.DataAnnotations;

namespace Text_To_Speeches_Dotnet_BE.Models;

public sealed class GenerateVoiceCloningKeyRequest
{
    [Required]
    [MaxLength(4_200_000)] // ~3 MB audio base64-encoded
    public string ReferenceAudioBase64 { get; set; } = string.Empty;

    [Required]
    [MaxLength(4_200_000)]
    public string ConsentAudioBase64 { get; set; } = string.Empty;

    [RegularExpression(@"^[a-zA-Z]{2,3}-[a-zA-Z]{2,4}$", ErrorMessage = "LanguageCode must be a BCP-47 tag like 'en-US'.")]
    public string LanguageCode { get; set; } = "en-US";

    [RegularExpression(@"^(MP3|LINEAR16|OGG_OPUS|MULAW|ALAW)$", ErrorMessage = "AudioEncoding must be one of: MP3, LINEAR16, OGG_OPUS, MULAW, ALAW.")]
    public string AudioEncoding { get; set; } = "MP3";
}

public sealed class SynthesizeWithClonedVoiceRequest
{
    [Required]
    [MaxLength(5000)]
    public string Text { get; set; } = string.Empty;

    [RegularExpression(@"^[a-zA-Z]{2,3}-[a-zA-Z]{2,4}$", ErrorMessage = "LanguageCode must be a BCP-47 tag like 'en-US'.")]
    public string LanguageCode { get; set; } = "en-US";
}
