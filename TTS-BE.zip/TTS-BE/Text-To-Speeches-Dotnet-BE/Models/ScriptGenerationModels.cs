using System.ComponentModel.DataAnnotations;

namespace Text_To_Speeches_Dotnet_BE.Models;

#region Request Models

public sealed class ScriptGenerationRequest
{
    [Required(ErrorMessage = "Inputs are required.")]
    public Dictionary<string, object?> Inputs { get; set; } = new();

    public string? Tone { get; set; }

    public string? Length { get; set; }
}

public sealed class ScriptTransformationRequest
{
    [Required(ErrorMessage = "Script is required.")]
    public string Script { get; set; } = string.Empty;

    [Required(ErrorMessage = "Transformation type is required.")]
    [RegularExpression("^(rewrite|shorten|expand|tone-change)$", ErrorMessage = "Invalid transformation type. Must be: rewrite, shorten, expand, or tone-change")]
    public string Transformation { get; set; } = string.Empty;

    public string? Tone { get; set; }
}

public sealed class GenerateFieldRequest
{
    [Required(ErrorMessage = "Field ID is required.")]
    public string FieldId { get; set; } = string.Empty;

    [Required(ErrorMessage = "Context is required.")]
    public Dictionary<string, object?> Context { get; set; } = new();
}

#endregion

#region Response Models

public sealed class ScriptGenerationResponse
{
    public bool Success { get; set; }

    public string? Script { get; set; }

    public ScriptMetadata? Metadata { get; set; }

    public string? Error { get; set; }

    public string? Code { get; set; }
}

public sealed class ScriptMetadata
{
    public string? EstimatedReadTime { get; set; }

    public List<string>? Sections { get; set; }

    public int WordCount { get; set; }

    public int CharacterCount { get; set; }
}

public sealed class ScriptTransformationResponse
{
    public bool Success { get; set; }

    public string? Script { get; set; }

    public TransformationMetadata? Metadata { get; set; }

    public string? Error { get; set; }

    public string? Code { get; set; }
}

public sealed class TransformationMetadata
{
    public int WordCountBefore { get; set; }

    public int WordCountAfter { get; set; }

    public double PercentChange { get; set; }
}

public sealed class GenerateFieldResponse
{
    public bool Success { get; set; }

    public string? Content { get; set; }

    public string? Error { get; set; }

    public string? Code { get; set; }
}

#endregion
