using System.ComponentModel.DataAnnotations;

namespace Text_To_Speeches_Dotnet_BE.Models;

public sealed class SpeechTtsRequest
{
    [Required(ErrorMessage = "Text is required.")]
    public string Text { get; set; } = string.Empty;

    [Required(ErrorMessage = "Voice is required.")]
    public string Voice { get; set; } = string.Empty;

    public double? Rate { get; set; }
    public double? Pitch { get; set; }
    public double? Volume { get; set; }

    public string? Style { get; set; }
    public double? Degree { get; set; }
}

public sealed class SpeechTranscribeRequest
{
    [Required(ErrorMessage = "Audio is required.")]
    public IFormFile? Audio { get; set; }

    public string? Language { get; set; }

    // Accepts common checkbox / form values (e.g., "true", "1", "on").
    public string? Translate { get; set; }

    // Target language for translation (e.g., "en", "hi", "fr"). If omitted, defaults to "en".
    public string? To { get; set; }
}

public sealed record TranscribedSegment(long StartMs, long EndMs, string Text);

public sealed record TranscribedWord(long StartMs, long EndMs, string Word);

public sealed class SpeechTranslateRequest
{
    [Required(ErrorMessage = "Audio is required.")]
    public IFormFile? Audio { get; set; }

    // Repeat form field: to=de&to=fr (preferred) or send a single value and repeat.
    public List<string> To { get; set; } = new();
}

public sealed class SpeechSpeechTranslateRequest
{
    [Required(ErrorMessage = "Audio is required.")]
    public IFormFile? Audio { get; set; }

    // Repeat form field: to=de&to=fr (preferred) or send a single value and repeat.
    public List<string> To { get; set; } = new();

    // "mp3" (default) or "wav"
    public string? OutputFormat { get; set; }

    // JSON object mapping target language to a specific Neural voice.
    // Example: {"de":"de-DE-KatjaNeural","fr":"fr-FR-DeniseNeural"}
    public string? VoicesJson { get; set; }

    // Used when voicesJson does not include a target language.
    public string? DefaultVoice { get; set; }
}

public sealed record TranslatedSegment(
    long StartMs,
    long EndMs,
    string DetectedLanguage,
    string Text,
    Dictionary<string, string> Translations);
