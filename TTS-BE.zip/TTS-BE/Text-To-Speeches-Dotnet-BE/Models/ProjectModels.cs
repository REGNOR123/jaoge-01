namespace Text_To_Speeches_Dotnet_BE.Models;

/// <summary>
/// Project type enum
/// </summary>
public enum ProjectType
{
    Voice,
    Transcript,
    Dub,
    SpeechTranslate,
    Script
}

/// <summary>
/// Project status enum
/// </summary>
public enum ProjectStatus
{
    Processing,
    Completed
}

/// <summary>
/// Project model stored in Azure File Storage
/// </summary>
public sealed class UserProject
{
    public string Id { get; set; } = string.Empty;
    public int UserId { get; set; }
    public string Name { get; set; } = string.Empty;
    public ProjectType Type { get; set; }
    public ProjectStatus Status { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime LastModifiedAt { get; set; }
    public ProjectData? Data { get; set; }
}

/// <summary>
/// Project data containing drafts and outputs
/// </summary>
public sealed class ProjectData
{
    public ProjectDrafts? Drafts { get; set; }
    public ProjectOutputs? Outputs { get; set; }
    public ProjectUsage? Usage { get; set; }
}

/// <summary>
/// Draft data for different project types
/// </summary>
public sealed class ProjectDrafts
{
    public VoiceDraft? Voice { get; set; }
    public TranscriptDraft? Transcript { get; set; }
    public DubDraft? Dub { get; set; }
    public SpeechTranslateDraft? SpeechTranslate { get; set; }
    public ScriptStudioDraft? ScriptStudio { get; set; }
}

public sealed class VoiceDraft
{
    public string? Script { get; set; }
    public string? Language { get; set; }
    public string? Voice { get; set; }
    public double? Rate { get; set; }
    public double? Pitch { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public sealed class TranscriptDraft
{
    public string? Language { get; set; }
    public bool? AutoPunctuation { get; set; }
    public bool? IncludeTimestamps { get; set; }
    public string? FileName { get; set; }
    public double? DurationSeconds { get; set; }
    public string? Transcript { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public sealed class DubDraft
{
    public string? Mode { get; set; }
    public string? SourceText { get; set; }
    public string? TranslatedText { get; set; }
    public string? SourceLang { get; set; }
    public string? TargetLang { get; set; }
    public string? Voice { get; set; }
    public DubModeDraft? Text { get; set; }
    public DubModeDraft? Audio { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public sealed class DubModeDraft
{
    public string? ProjectName { get; set; }
    public string? SourceText { get; set; }
    public string? TranscriptText { get; set; }
    public string? TranslatedText { get; set; }
    public string? SourceLang { get; set; }
    public string? TargetLang { get; set; }
    public string? Voice { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public sealed class SpeechTranslateDraft
{
    public List<string>? Targets { get; set; }
    public string? OutputFormat { get; set; }
    public bool? ShowTextOutput { get; set; }
    public Dictionary<string, string>? VoicesByTarget { get; set; }
    public string? DetectedLanguage { get; set; }
    public string? RecognizedText { get; set; }
    public Dictionary<string, string>? TranslationsByTarget { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public sealed class ScriptStudioDraft
{
    public string? ScriptType { get; set; }
    public string? Topic { get; set; }
    public string? Tone { get; set; }
    public string? Length { get; set; }
    public string? Script { get; set; }
    public DateTime UpdatedAt { get; set; }
}

/// <summary>
/// Output data
/// </summary>
public sealed class ProjectOutputs
{
    public List<ProjectScript>? Scripts { get; set; }
    public List<ProjectAudioVersion>? AudioVersions { get; set; }
    public List<ProjectTranscript>? Transcripts { get; set; }
    public List<ProjectLanguageVariant>? Languages { get; set; }
}

public sealed class ProjectScript
{
    public string Id { get; set; } = string.Empty;
    public string Text { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public string? FileId { get; set; }
    public string? ContentType { get; set; }
    public string? FileName { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public string? Source { get; set; }
}

public sealed class ProjectAudioVersion
{
    public string Id { get; set; } = string.Empty;
    public string AudioUrl { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public string? FileId { get; set; }
    public string? ContentType { get; set; }
    public string? FileName { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public string? Voice { get; set; }
    public string? VoiceLabel { get; set; }
    public Dictionary<string, object>? Settings { get; set; }
    public double? EstimatedMinutes { get; set; }
}

public sealed class ProjectTranscript
{
    public string Id { get; set; } = string.Empty;
    public string Text { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public string? FileId { get; set; }
    public string? ContentType { get; set; }
    public string? FileName { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public string? Language { get; set; }
    public bool? IncludeTimestamps { get; set; }
}

public sealed class ProjectLanguageVariant
{
    public string Id { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public string? SourceLang { get; set; }
    public string? TargetLang { get; set; }
    public string SourceText { get; set; } = string.Empty;
    public string TranslatedText { get; set; } = string.Empty;
}

public sealed class ProjectUsage
{
    public double? VoiceMinutesUsed { get; set; }
    public double? SttMinutesUsed { get; set; }
    public int? TranslationCharsUsed { get; set; }
}

/// <summary>
/// Request to create a new project
/// </summary>
public sealed class CreateProjectRequest
{
    public string Name { get; set; } = string.Empty;
    public ProjectType Type { get; set; }
    public ProjectStatus Status { get; set; } = ProjectStatus.Processing;
    public ProjectData? Data { get; set; }
}

/// <summary>
/// Request to update an existing project
/// </summary>
public sealed class UpdateProjectRequest
{
    public string? Name { get; set; }
    public ProjectType? Type { get; set; }
    public ProjectStatus? Status { get; set; }
    public ProjectData? Data { get; set; }
}

/// <summary>
/// Project list item (lightweight for listing)
/// </summary>
public sealed class ProjectListItem
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public ProjectType Type { get; set; }
    public ProjectStatus Status { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime LastModifiedAt { get; set; }
}
