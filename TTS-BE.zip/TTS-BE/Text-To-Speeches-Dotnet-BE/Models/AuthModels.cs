using System.ComponentModel.DataAnnotations;

namespace Text_To_Speeches_Dotnet_BE.Models;

public sealed class SignupRequest
{
    [Required(ErrorMessage = "Full name is required.")]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Valid email is required.")]
    [EmailAddress(ErrorMessage = "Valid email is required.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Password must be at least 6 characters long.")]
    [MinLength(6, ErrorMessage = "Password must be at least 6 characters long.")]
    public string Password { get; set; } = string.Empty;
}

public sealed class LoginRequest
{
    [Required(ErrorMessage = "Valid email is required.")]
    [EmailAddress(ErrorMessage = "Valid email is required.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Password is required.")]
    public string Password { get; set; } = string.Empty;
}

public sealed class ResendVerificationRequest
{
    [Required(ErrorMessage = "Valid email is required.")]
    [EmailAddress(ErrorMessage = "Valid email is required.")]
    public string Email { get; set; } = string.Empty;
}

public sealed class GoogleAuthRequest
{
    [Required(ErrorMessage = "Google ID token is required.")]
    public string IdToken { get; set; } = string.Empty;
}

public sealed class DeleteAccountRequest
{
    [Required(ErrorMessage = "Valid email is required.")]
    [EmailAddress(ErrorMessage = "Valid email is required.")]
    public string Email { get; set; } = string.Empty;
}

public sealed class VerifyEmailRequest
{
    [Required(ErrorMessage = "Verification token is required.")]
    public string Token { get; set; } = string.Empty;
}

public sealed class VerifyCodeRequest
{
    [Required(ErrorMessage = "Valid email is required.")]
    [EmailAddress(ErrorMessage = "Valid email is required.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Verification code is required.")]
    [StringLength(6, MinimumLength = 6, ErrorMessage = "Verification code must be 6 digits.")]
    [RegularExpression(@"^\d{6}$", ErrorMessage = "Verification code must be 6 digits.")]
    public string Code { get; set; } = string.Empty;
}
