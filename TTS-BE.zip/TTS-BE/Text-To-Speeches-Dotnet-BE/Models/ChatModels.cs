using System.ComponentModel.DataAnnotations;

namespace Text_To_Speeches_Dotnet_BE.Models;

public sealed class ChatRequest
{
    [Required(ErrorMessage = "Message is required.")]
    public string Message { get; set; } = string.Empty;

    public string? SystemPrompt { get; set; }
}
