using System.ComponentModel.DataAnnotations;

namespace Text_To_Speeches_Dotnet_BE.Models;

public sealed class UploadFileRequest
{
    [Required(ErrorMessage = "File is required.")]
    public IFormFile? File { get; set; }

    public string? Feature { get; set; }
    public string? JobId { get; set; }
    public double? DurationMinutes { get; set; }
    public bool IsOutput { get; set; }
}
