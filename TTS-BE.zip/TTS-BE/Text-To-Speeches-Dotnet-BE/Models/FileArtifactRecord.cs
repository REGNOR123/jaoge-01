namespace Text_To_Speeches_Dotnet_BE.Models;

public sealed class FileArtifactRecord
{
    public Guid Id { get; set; }
    public int? UserId { get; set; }
    public string UserFolder { get; set; } = "anonymous";
    public string JobId { get; set; } = string.Empty;
    public string Feature { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    public string RelativePath { get; set; } = string.Empty;
    public string? ContentType { get; set; }
    public long SizeBytes { get; set; }
    public double? DurationMinutes { get; set; }
    public bool IsOutput { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime ExpiresAt { get; set; }
}
