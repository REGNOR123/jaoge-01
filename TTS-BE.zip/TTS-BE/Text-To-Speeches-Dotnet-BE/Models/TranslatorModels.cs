using System.ComponentModel.DataAnnotations;

namespace Text_To_Speeches_Dotnet_BE.Models;

public sealed class DetectLanguageRequest
{
    [Required(ErrorMessage = "Text is required.")]
    public string Text { get; set; } = string.Empty;
}

public sealed class TranslateRequest
{
    [Required(ErrorMessage = "Text is required.")]
    public string Text { get; set; } = string.Empty;

    [Required(ErrorMessage = "Target language is required.")]
    public string To { get; set; } = string.Empty;

    // Optional detected source language — used to apply regional billing when source is regional
    public string? From { get; set; }
}
