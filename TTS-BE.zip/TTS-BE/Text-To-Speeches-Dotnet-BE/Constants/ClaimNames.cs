namespace Text_To_Speeches_Dotnet_BE.Constants;

public static class ClaimNames
{
    public const string UserId = "id";
    public const string Email = "email";
}
