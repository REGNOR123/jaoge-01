using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Translator;
using Text_To_Speeches_Dotnet_BE.Services.Credits;
using Text_To_Speeches_Dotnet_BE.Services.Speech;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Authorize]
[Route("api/translator")]
public sealed class TranslatorController : BaseApiController
{
    private readonly IAzureTranslatorService _translatorService;
    private readonly ICreditService _creditService;
    private readonly ILogger<TranslatorController> _logger;
    private readonly IWebHostEnvironment _environment;

    public TranslatorController(
        IAzureTranslatorService translatorService,
        ICreditService creditService,
        IWebHostEnvironment environment,
        ILogger<TranslatorController> logger)
    {
        _translatorService = translatorService;
        _creditService = creditService;
        _environment = environment;
        _logger = logger;
    }

    [AllowAnonymous]
    [HttpPost("detect")]
    [EnableRateLimiting("ReadLimiter")]
    public async Task<IActionResult> Detect(
        [FromBody] DetectLanguageRequest request,
        CancellationToken cancellationToken)
    {
        try
        {
            var userId = GetUserIdFromToken();
            if (userId.HasValue)
            {
                const long detectCost = 1;
                var balance = await _creditService.GetBalanceAsync(userId.Value, cancellationToken);
                if (balance < detectCost)
                    return StatusCode(402, new { success = false, error = "Insufficient credits.",
                        data = new { requiredCredits = detectCost, currentBalance = balance } });
            }

            var language = await _translatorService.DetectLanguageAsync(request.Text, cancellationToken);

            if (userId.HasValue)
                await _creditService.DeductCreditsAsync(userId.Value, "detect-language", 1, "Language detection", cancellationToken);

            return Ok(new
            {
                success = true,
                data = new { language },
                language
            });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Translator detect configuration/runtime error");
            return StatusCode(StatusCodes.Status500InternalServerError, new
            {
                success = false,
                error = _environment.IsDevelopment() ? ex.Message : "Translator is not configured."
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Translator detect error");
            return StatusCode(StatusCodes.Status502BadGateway, new
            {
                success = false,
                error = "Failed to detect language."
            });
        }
    }

    [HttpPost("translate")]
    [EnableRateLimiting("AiLimiter")]
    public async Task<IActionResult> Translate([FromBody] TranslateRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = GetUserIdFromToken();
            long creditCost = 0;
            string featureKey = VoiceResolver.ResolveTranslateFeatureKey(request.To, request.From);
            if (userId.HasValue)
            {
                creditCost = await _creditService.CalculateCreditCostAsync(featureKey, characters: request.Text?.Length ?? 0, cancellationToken: cancellationToken);
                var balance = await _creditService.GetBalanceAsync(userId.Value, cancellationToken);
                if (balance < creditCost)
                    return StatusCode(402, new { success = false, error = "Insufficient credits.",
                        data = new { requiredCredits = creditCost, currentBalance = balance } });
            }

            var translatedText = await _translatorService.TranslateAsync(request.Text, request.To, cancellationToken);

            if (userId.HasValue && creditCost > 0)
            {
                await _creditService.DeductCreditsAsync(userId.Value, featureKey, creditCost,
                    $"Text translation ({request.From ?? "auto"} → {request.To}): {request.Text?.Length} chars", cancellationToken);
            }

            return Ok(new
            {
                success = true,
                data = new { text = translatedText },
                translatedText
            });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Translator translate configuration/runtime error");
            return StatusCode(StatusCodes.Status500InternalServerError, new
            {
                success = false,
                error = _environment.IsDevelopment() ? ex.Message : "Translator is not configured."
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Translator translate error");
            return StatusCode(StatusCodes.Status502BadGateway, new
            {
                success = false,
                error = "Failed to translate text."
            });
        }
    }
}
