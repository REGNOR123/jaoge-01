using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Text_To_Speeches_Dotnet_BE.Constants;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
public abstract class BaseApiController : ControllerBase
{
    protected int? GetUserIdFromToken()
    {
        var idClaim = User.FindFirst(ClaimNames.UserId)?.Value ?? User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return int.TryParse(idClaim, out var userId) ? userId : null;
    }

    protected int GetRequiredUserId()
    {
        return GetUserIdFromToken()
               ?? throw new UnauthorizedAccessException("User is not authenticated.");
    }
}
