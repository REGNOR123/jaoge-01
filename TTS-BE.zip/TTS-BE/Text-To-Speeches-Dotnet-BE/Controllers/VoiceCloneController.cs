using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Credits;
using Text_To_Speeches_Dotnet_BE.Services.Users;
using Text_To_Speeches_Dotnet_BE.Services.VoiceClone;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[Route("api/voice-clone")]
public sealed class VoiceCloneController : BaseApiController
{
    private const int MaxSynthesizeChars = 5000;

    private readonly IGoogleTtsService _googleTts;
    private readonly IUserRepository _userRepository;
    private readonly ICreditService _creditService;
    private readonly ILogger<VoiceCloneController> _logger;

    public VoiceCloneController(
        IGoogleTtsService googleTts,
        IUserRepository userRepository,
        ICreditService creditService,
        ILogger<VoiceCloneController> logger)
    {
        _googleTts = googleTts;
        _userRepository = userRepository;
        _creditService = creditService;
        _logger = logger;
    }

    [HttpGet("key-status")]
    [Authorize]
    [EnableRateLimiting("ReadLimiter")]
    public async Task<IActionResult> GetKeyStatus(CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (!userId.HasValue)
            return Unauthorized(new { success = false, error = "Unauthorized." });

        var key = await _userRepository.GetVoiceCloningKeyAsync(userId.Value, cancellationToken);

        return Ok(new { success = true, data = new { hasKey = key is not null } });
    }

    [HttpPost("generate-key")]
    [Authorize]
    [EnableRateLimiting("AiLimiter")]
    public async Task<IActionResult> GenerateKey(
        [FromBody] GenerateVoiceCloningKeyRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.ReferenceAudioBase64))
            return BadRequest(new { success = false, error = "Reference audio is required." });

        if (string.IsNullOrWhiteSpace(request.ConsentAudioBase64))
            return BadRequest(new { success = false, error = "Consent audio is required." });

        var userId = GetUserIdFromToken();
        if (!userId.HasValue)
            return Unauthorized(new { success = false, error = "Unauthorized." });

        const string feature = "voice-clone-generate";
        var creditCost = await _creditService.CalculateCreditCostAsync(feature, characters: 0, cancellationToken);

        var (deducted, _) = await _creditService.DeductCreditsAsync(userId.Value, feature, creditCost, "Voice clone key generation", cancellationToken);
        if (!deducted)
        {
            var balance = await _creditService.GetBalanceAsync(userId.Value, cancellationToken);
            return StatusCode(402, new
            {
                success = false,
                error = "Insufficient credits.",
                data = new { requiredCredits = creditCost, currentBalance = balance }
            });
        }

        var voiceCloningKey = await _googleTts.GenerateVoiceCloningKeyAsync(
            request.ReferenceAudioBase64,
            request.ConsentAudioBase64,
            request.LanguageCode,
            request.AudioEncoding,
            cancellationToken);

        if (voiceCloningKey is null)
        {
            await _creditService.AllocateCreditsAsync(userId.Value, creditCost, "refund", "Refund: voice clone key generation failed", CancellationToken.None);
            return StatusCode(502, new { success = false, error = "Failed to generate voice cloning key. Check audio quality and try again." });
        }

        await _userRepository.SaveVoiceCloningKeyAsync(userId.Value, voiceCloningKey, cancellationToken);

        return Ok(new { success = true, data = new { message = "Voice clone created successfully." } });
    }

    [HttpPost("synthesize")]
    [Authorize]
    [EnableRateLimiting("AiLimiter")]
    public async Task<IActionResult> Synthesize(
        [FromBody] SynthesizeWithClonedVoiceRequest request,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.Text))
            return BadRequest(new { success = false, error = "Text is required." });

        if (request.Text.Length > MaxSynthesizeChars)
            return BadRequest(new { success = false, error = $"Text exceeds the maximum allowed length of {MaxSynthesizeChars} characters." });

        var userId = GetUserIdFromToken();
        if (!userId.HasValue)
            return Unauthorized(new { success = false, error = "Unauthorized." });

        var voiceCloningKey = await _userRepository.GetVoiceCloningKeyAsync(userId.Value, cancellationToken);
        if (voiceCloningKey is null)
            return NotFound(new { success = false, error = "No voice clone found. Please generate your voice clone first." });

        const string feature = "voice-clone-synthesize";
        var creditCost = await _creditService.CalculateCreditCostAsync(feature, characters: request.Text.Length, cancellationToken);

        var (deducted, _) = await _creditService.DeductCreditsAsync(userId.Value, feature, creditCost, $"Voice clone synthesis: {request.Text.Length} chars", cancellationToken);
        if (!deducted)
        {
            var balance = await _creditService.GetBalanceAsync(userId.Value, cancellationToken);
            return StatusCode(402, new
            {
                success = false,
                error = "Insufficient credits.",
                data = new { requiredCredits = creditCost, currentBalance = balance }
            });
        }

        var audioContent = await _googleTts.SynthesizeWithClonedVoiceAsync(
            request.Text,
            voiceCloningKey,
            request.LanguageCode,
            cancellationToken);

        if (audioContent is null)
        {
            await _creditService.AllocateCreditsAsync(userId.Value, creditCost, "refund", "Refund: voice clone synthesis failed", CancellationToken.None);
            return StatusCode(502, new { success = false, error = "Voice synthesis failed. Please try again." });
        }

        return Ok(new { success = true, data = new { audioContent } });
    }
}
