using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Text_To_Speeches_Dotnet_BE.Services.Credits;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Authorize]
[Route("api/credits")]
public sealed class CreditController : BaseApiController
{
    private readonly ICreditService _creditService;
    private readonly ILogger<CreditController> _logger;

    public CreditController(ICreditService creditService, ILogger<CreditController> logger)
    {
        _creditService = creditService;
        _logger = logger;
    }

    [HttpGet("balance")]
    public async Task<IActionResult> GetBalance(CancellationToken cancellationToken)
    {
        try
        {
            var userId = GetRequiredUserId();
            var balance = await _creditService.GetBalanceAsync(userId, cancellationToken);
            return Ok(new { success = true, data = new { balance } });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new { success = false, error = "Authentication required." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching credit balance");
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { success = false, error = "Failed to fetch credit balance." });
        }
    }

    [HttpPost("deduct-voice-preview")]
    public async Task<IActionResult> DeductVoicePreview(CancellationToken cancellationToken)
    {
        try
        {
            var userId = GetRequiredUserId();
            var (success, newBalance) = await _creditService.DeductCreditsAsync(
                userId, "voice-preview", 1, "Voice preview (per 2 previews)", cancellationToken);

            if (!success)
                return StatusCode(StatusCodes.Status402PaymentRequired, new
                {
                    success = false,
                    error = "Insufficient credits.",
                    data = new { currentBalance = newBalance, requiredCredits = 1 }
                });

            return Ok(new { success = true, data = new { balance = newBalance } });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new { success = false, error = "Authentication required." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deducting voice preview credit");
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { success = false, error = "Failed to deduct credit." });
        }
    }

    [AllowAnonymous]
    [HttpGet("feature-costs")]
    public async Task<IActionResult> GetFeatureCosts(CancellationToken cancellationToken)
    {
        try
        {
            var costs = await _creditService.GetDisplayFeatureCostsAsync(cancellationToken);
            return Ok(new { success = true, data = costs });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching feature costs");
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { success = false, error = "Failed to fetch feature costs." });
        }
    }
}
