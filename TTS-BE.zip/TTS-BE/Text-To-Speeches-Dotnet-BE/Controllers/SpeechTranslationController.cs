using Microsoft.CognitiveServices.Speech;
using Microsoft.CognitiveServices.Speech.Audio;
using Microsoft.CognitiveServices.Speech.Translation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Speech;
using Text_To_Speeches_Dotnet_BE.Services.Credits;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Authorize]
[Route("api/speech")]
public sealed class SpeechTranslationController : BaseApiController
{
    private const int MaxTargetLanguages = 10;

    private readonly IConfiguration _configuration;
    private readonly SpeechOptions _speechOptions;
    private readonly ISpeechSynthesisService _speechSynthesis;
    private readonly ICreditService _creditService;
    private readonly ILogger<SpeechTranslationController> _logger;
    private readonly IWebHostEnvironment _environment;

    public SpeechTranslationController(
        IConfiguration configuration,
        IOptions<SpeechOptions> speechOptions,
        ISpeechSynthesisService speechSynthesis,
        ICreditService creditService,
        IWebHostEnvironment environment,
        ILogger<SpeechTranslationController> logger)
    {
        _configuration = configuration;
        _speechOptions = speechOptions.Value;
        _speechSynthesis = speechSynthesis;
        _creditService = creditService;
        _environment = environment;
        _logger = logger;
    }

    [HttpPost("translate")]
    [EnableRateLimiting("AiLimiter")]
    [RequestSizeLimit(20 * 1024 * 1024)]
    public async Task<ActionResult<ApiResponse<object>>> TranslateAudio([FromForm] SpeechTranslateRequest request, CancellationToken cancellationToken)
    {
        var tempFiles = new List<string>();
        var translateUserId = GetRequiredUserId();
        long translateCost = 0;
        bool creditCharged = false;

        try
        {
            var speechKey = _configuration["SPEECH_KEY"] ?? _speechOptions.Key;
            var speechRegion = _configuration["SPEECH_REGION"] ?? _speechOptions.Region;

            if (string.IsNullOrWhiteSpace(speechKey) || string.IsNullOrWhiteSpace(speechRegion))
                return BadRequest(ApiResponse<object>.Fail("Missing SPEECH_KEY or SPEECH_REGION configuration."));

            if (request.Audio is null || request.Audio.Length == 0)
                return BadRequest(ApiResponse<object>.Fail("Audio file is required."));

            var targets = request.To.Where(t => !string.IsNullOrWhiteSpace(t)).Select(t => t.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (targets.Count == 0)
                return BadRequest(ApiResponse<object>.Fail("At least one target language is required (form field: to)."));

            if (targets.Count > MaxTargetLanguages)
                return BadRequest(ApiResponse<object>.Fail($"Maximum {MaxTargetLanguages} target languages per request."));

            var invalidTarget = targets.FirstOrDefault(t => !VoiceResolver.IsValidLanguageCode(t));
            if (invalidTarget is not null)
                return BadRequest(ApiResponse<object>.Fail($"Invalid language code: '{invalidTarget}'."));

            translateCost = await _creditService.CalculateCreditCostAsync("translate-text", cancellationToken: cancellationToken);
            var (deducted, _) = await _creditService.DeductCreditsAsync(translateUserId, "translate-text", translateCost, "Speech-to-text translation", cancellationToken);
            if (!deducted)
            {
                var balance = await _creditService.GetBalanceAsync(translateUserId, cancellationToken);
                return StatusCode(402, ApiResponse<object>.Fail("Insufficient credits.",
                    new { requiredCredits = translateCost, currentBalance = balance } as object));
            }
            creditCharged = true;

            var inputPath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}{Path.GetExtension(request.Audio.FileName)}");
            tempFiles.Add(inputPath);

            await using (var fs = System.IO.File.Create(inputPath))
            {
                await request.Audio.CopyToAsync(fs, cancellationToken);
            }

            var wavPath = inputPath;
            if (AudioUtilities.LooksLikeWavFile(inputPath))
            {
                // already WAV
            }
            else if (AudioUtilities.LooksLikeMp3File(inputPath))
            {
                wavPath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}.wav");
                tempFiles.Add(wavPath);
                AudioUtilities.ConvertAudioTo16kMonoWav(inputPath, wavPath);
            }
            else
            {
                await _creditService.AllocateCreditsAsync(translateUserId, translateCost, "refund", "Refund: unsupported audio format", CancellationToken.None);
                creditCharged = false;
                return StatusCode(StatusCodes.Status415UnsupportedMediaType,
                    ApiResponse<object>.Fail("Unsupported audio format. Please upload a WAV or MP3 file."));
            }

            var v2EndpointUrl = new Uri($"wss://{speechRegion}.stt.speech.microsoft.com/speech/universal/v2");
            var config = SpeechTranslationConfig.FromEndpoint(v2EndpointUrl, speechKey);
            foreach (var target in targets)
            {
                config.AddTargetLanguage(target);
            }

            var autoDetect = AutoDetectSourceLanguageConfig.FromOpenRange();

            using var audioConfig = AudioConfig.FromWavFileInput(wavPath);
            using var recognizer = new TranslationRecognizer(config, autoDetect, audioConfig);

            var segments = new List<TranslatedSegment>();
            var detectedLanguages = new List<string>();

            var done = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

            recognizer.Recognized += (_, e) =>
            {
                if (e.Result.Reason != ResultReason.TranslatedSpeech && e.Result.Reason != ResultReason.RecognizedSpeech)
                    return;

                var lid = e.Result.Properties.GetProperty(PropertyId.SpeechServiceConnection_AutoDetectSourceLanguageResult) ?? string.Empty;
                if (!string.IsNullOrWhiteSpace(lid))
                    detectedLanguages.Add(lid);

                var startMs = (long)TimeSpan.FromTicks(e.Result.OffsetInTicks).TotalMilliseconds;
                var endMs = (long)TimeSpan.FromTicks(e.Result.OffsetInTicks + e.Result.Duration.Ticks).TotalMilliseconds;

                var translationDict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var kv in e.Result.Translations)
                    translationDict[kv.Key] = kv.Value;

                segments.Add(new TranslatedSegment(startMs, endMs, lid, e.Result.Text ?? string.Empty, translationDict));
            };

            recognizer.Canceled += (_, e) =>
            {
                var isNormalEnd =
                    e.Reason == CancellationReason.EndOfStream ||
                    string.Equals(e.Reason.ToString(), "EndOfStream", StringComparison.OrdinalIgnoreCase) ||
                    (e.ErrorCode == CancellationErrorCode.NoError && e.Reason != CancellationReason.Error);

                if (isNormalEnd) { done.TrySetResult(); return; }

                done.TrySetException(new InvalidOperationException($"Speech translation canceled ({e.Reason}). {e.ErrorCode}: {e.ErrorDetails}"));
            };

            recognizer.SessionStopped += (_, _) => done.TrySetResult();

            await recognizer.StartContinuousRecognitionAsync().ConfigureAwait(false);
            await done.Task.WaitAsync(cancellationToken).ConfigureAwait(false);
            await recognizer.StopContinuousRecognitionAsync().ConfigureAwait(false);

            var detectedLanguage = detectedLanguages.FirstOrDefault(l => !string.IsNullOrWhiteSpace(l)) ?? string.Empty;
            var sourceText = string.Join(" ", segments.Select(s => s.Text).Where(t => !string.IsNullOrWhiteSpace(t))).Trim();

            var translations = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var target in targets)
            {
                var translated = string.Join(" ", segments
                    .Select(s => s.Translations.TryGetValue(target, out var v) ? v : string.Empty)
                    .Where(t => !string.IsNullOrWhiteSpace(t))).Trim();

                translations[target] = translated;
            }

            creditCharged = false;
            return Ok(ApiResponse<object>.Ok(new
            {
                detectedLanguage,
                text = sourceText,
                translations,
                segments = segments.OrderBy(s => s.StartMs).ToArray()
            }));
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Speech translation configuration/runtime error");
            if (creditCharged) await _creditService.AllocateCreditsAsync(translateUserId, translateCost, "refund", "Refund: speech translation error", CancellationToken.None);
            return StatusCode(StatusCodes.Status500InternalServerError,
                ApiResponse<object>.Fail(_environment.IsDevelopment() ? ex.Message : "Speech is not configured."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Speech translation error");
            if (creditCharged) await _creditService.AllocateCreditsAsync(translateUserId, translateCost, "refund", "Refund: speech translation error", CancellationToken.None);
            return StatusCode(StatusCodes.Status502BadGateway, ApiResponse<object>.Fail("Failed to translate audio."));
        }
        finally
        {
            foreach (var path in tempFiles)
            {
                try { System.IO.File.Delete(path); } catch { }
            }
        }
    }

    [HttpPost("translate-speech")]
    [EnableRateLimiting("AiLimiter")]
    [RequestSizeLimit(20 * 1024 * 1024)]
    public async Task<ActionResult<ApiResponse<object>>> TranslateSpeechToSpeech([FromForm] SpeechSpeechTranslateRequest request, CancellationToken cancellationToken)
    {
        var tempFiles = new List<string>();
        var speechUserId = GetRequiredUserId();
        long speechCost = 0;
        bool creditCharged = false;

        try
        {
            var speechKey = _configuration["SPEECH_KEY"] ?? _speechOptions.Key;
            var speechRegion = _configuration["SPEECH_REGION"] ?? _speechOptions.Region;

            if (string.IsNullOrWhiteSpace(speechKey) || string.IsNullOrWhiteSpace(speechRegion))
                return BadRequest(ApiResponse<object>.Fail("Missing SPEECH_KEY or SPEECH_REGION configuration."));

            if (request.Audio is null || request.Audio.Length == 0)
                return BadRequest(ApiResponse<object>.Fail("Audio file is required."));

            var targets = request.To
                .Where(t => !string.IsNullOrWhiteSpace(t))
                .Select(t => t.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (targets.Count == 0)
                return BadRequest(ApiResponse<object>.Fail("At least one target language is required (form field: to)."));

            if (targets.Count > MaxTargetLanguages)
                return BadRequest(ApiResponse<object>.Fail($"Maximum {MaxTargetLanguages} target languages per request."));

            var invalidSpeechTarget = targets.FirstOrDefault(t => !VoiceResolver.IsValidLanguageCode(t));
            if (invalidSpeechTarget is not null)
                return BadRequest(ApiResponse<object>.Fail($"Invalid language code: '{invalidSpeechTarget}'."));

            var outputKind = (request.OutputFormat ?? "mp3").Trim();
            var (outputFormatHeader, fallbackContentType, dataUrlPrefix, fileExtension) = GetOutputAudioFormat(outputKind);

            Dictionary<string, string> voicesByTarget = new(StringComparer.OrdinalIgnoreCase);
            if (!string.IsNullOrWhiteSpace(request.VoicesJson))
            {
                if (!VoiceResolver.TryParseVoicesJson(request.VoicesJson!, out voicesByTarget))
                    return BadRequest(ApiResponse<object>.Fail("Invalid voicesJson. Expected JSON object like {\"de\":\"de-DE-KatjaNeural\"}."));

                foreach (var kv in voicesByTarget)
                {
                    if (!VoiceResolver.IsKnownVoice(kv.Value))
                        return BadRequest(ApiResponse<object>.Fail($"Invalid voice '{kv.Value}' for language '{kv.Key}'."));
                }
            }

            if (!string.IsNullOrWhiteSpace(request.DefaultVoice) && !VoiceResolver.IsKnownVoice(request.DefaultVoice))
                return BadRequest(ApiResponse<object>.Fail("Invalid defaultVoice."));

            var inputPath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}{Path.GetExtension(request.Audio.FileName)}");
            tempFiles.Add(inputPath);

            await using (var fs = System.IO.File.Create(inputPath))
            {
                await request.Audio.CopyToAsync(fs, cancellationToken);
            }

            var audioDurationMinutes = AudioUtilities.TryGetAudioDurationMinutes(inputPath);
            var billableMinutes = (long)Math.Ceiling(audioDurationMinutes > 0 ? audioDurationMinutes : 1.0);
            var creditsPerMinute = await _creditService.CalculateCreditCostAsync("speech-translate", cancellationToken: cancellationToken);
            speechCost = creditsPerMinute * billableMinutes * targets.Count;

            var (deducted, _) = await _creditService.DeductCreditsAsync(speechUserId, "speech-translate", speechCost,
                $"Speech translate: {billableMinutes} min × {targets.Count} language(s) × {creditsPerMinute} credits", cancellationToken);
            if (!deducted)
            {
                var balance = await _creditService.GetBalanceAsync(speechUserId, cancellationToken);
                return StatusCode(402, ApiResponse<object>.Fail("Insufficient credits.",
                    new { requiredCredits = speechCost, currentBalance = balance } as object));
            }
            creditCharged = true;

            var wavPath = inputPath;
            if (AudioUtilities.LooksLikeWavFile(inputPath))
            {
                // already WAV
            }
            else if (AudioUtilities.LooksLikeMp3File(inputPath))
            {
                wavPath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}.wav");
                tempFiles.Add(wavPath);
                AudioUtilities.ConvertAudioTo16kMonoWav(inputPath, wavPath);
            }
            else
            {
                await _creditService.AllocateCreditsAsync(speechUserId, speechCost, "refund", "Refund: unsupported audio format", CancellationToken.None);
                creditCharged = false;
                return StatusCode(StatusCodes.Status415UnsupportedMediaType,
                    ApiResponse<object>.Fail("Unsupported audio format. Please upload a WAV or MP3 file."));
            }

            var v2EndpointUrl = new Uri($"wss://{speechRegion}.stt.speech.microsoft.com/speech/universal/v2");
            var config = SpeechTranslationConfig.FromEndpoint(v2EndpointUrl, speechKey);
            foreach (var target in targets)
            {
                config.AddTargetLanguage(target);
            }

            var autoDetect = AutoDetectSourceLanguageConfig.FromOpenRange();

            using var audioConfig = AudioConfig.FromWavFileInput(wavPath);
            using var recognizer = new TranslationRecognizer(config, autoDetect, audioConfig);

            var segments = new List<TranslatedSegment>();
            var detectedLanguages = new List<string>();

            var done = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

            recognizer.Recognized += (_, e) =>
            {
                if (e.Result.Reason != ResultReason.TranslatedSpeech && e.Result.Reason != ResultReason.RecognizedSpeech)
                    return;

                var lid = e.Result.Properties.GetProperty(PropertyId.SpeechServiceConnection_AutoDetectSourceLanguageResult) ?? string.Empty;
                if (!string.IsNullOrWhiteSpace(lid))
                    detectedLanguages.Add(lid);

                long startMs = 0;
                long endMs = 0;
                try
                {
                    startMs = (long)e.Result.OffsetInTicks / 10_000;
                    endMs = startMs + ((long)e.Result.Duration.Ticks / 10_000);
                }
                catch
                {
                    // ignore timestamp failures
                }

                var translationDict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var kv in e.Result.Translations)
                    translationDict[kv.Key] = kv.Value;

                segments.Add(new TranslatedSegment(startMs, endMs, lid, e.Result.Text ?? string.Empty, translationDict));
            };

            recognizer.Canceled += (_, e) =>
            {
                var isNormalEnd =
                    e.Reason == CancellationReason.EndOfStream ||
                    string.Equals(e.Reason.ToString(), "EndOfStream", StringComparison.OrdinalIgnoreCase) ||
                    (e.ErrorCode == CancellationErrorCode.NoError && e.Reason != CancellationReason.Error);

                if (isNormalEnd) { done.TrySetResult(); return; }

                done.TrySetException(new InvalidOperationException($"Speech translation canceled ({e.Reason}). {e.ErrorCode}: {e.ErrorDetails}"));
            };

            recognizer.SessionStopped += (_, _) => done.TrySetResult();

            await recognizer.StartContinuousRecognitionAsync().ConfigureAwait(false);
            await done.Task.WaitAsync(cancellationToken).ConfigureAwait(false);
            await recognizer.StopContinuousRecognitionAsync().ConfigureAwait(false);

            var detectedLanguage = detectedLanguages.FirstOrDefault(l => !string.IsNullOrWhiteSpace(l)) ?? string.Empty;
            var sourceText = string.Join(" ", segments.Select(s => s.Text).Where(t => !string.IsNullOrWhiteSpace(t))).Trim();

            var translations = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var target in targets)
            {
                var translated = string.Join(" ", segments
                    .Select(s => s.Translations.TryGetValue(target, out var v) ? v : string.Empty)
                    .Where(t => !string.IsNullOrWhiteSpace(t))).Trim();

                translations[target] = translated;
            }

            var audioByTarget = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

            foreach (var target in targets)
            {
                if (!translations.TryGetValue(target, out var targetText) || string.IsNullOrWhiteSpace(targetText))
                    continue;

                var voice = VoiceResolver.ResolveVoiceForTarget(target, voicesByTarget, request.DefaultVoice);
                if (string.IsNullOrWhiteSpace(voice))
                {
                    await _creditService.AllocateCreditsAsync(speechUserId, speechCost, "refund", "Refund: missing voice config", CancellationToken.None);
                    creditCharged = false;
                    return BadRequest(ApiResponse<object>.Fail($"No default voice configured for '{target}'. Provide voicesJson mapping or defaultVoice."));
                }

                var (bytes, contentType) = await _speechSynthesis.SynthesizeSpeechBytesAsync(
                    speechKey,
                    speechRegion,
                    voice,
                    targetText,
                    outputFormatHeader,
                    fallbackContentType,
                    cancellationToken);

                var base64 = Convert.ToBase64String(bytes);
                var dataUrl = $"{dataUrlPrefix}{base64}";
                var outputFileName = $"translated_{target}.{fileExtension}";

                audioByTarget[target] = new
                {
                    voice,
                    contentType,
                    fileName = outputFileName,
                    base64,
                    dataUrl
                };
            }

            creditCharged = false;
            return Ok(ApiResponse<object>.Ok(new
            {
                detectedLanguage,
                text = sourceText,
                translations,
                audio = audioByTarget,
                segments = segments.OrderBy(s => s.StartMs).ToArray()
            }));
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Speech-to-speech translation configuration/runtime error");
            if (creditCharged) await _creditService.AllocateCreditsAsync(speechUserId, speechCost, "refund", "Refund: speech-to-speech error", CancellationToken.None);
            return StatusCode(StatusCodes.Status500InternalServerError,
                ApiResponse<object>.Fail(_environment.IsDevelopment() ? ex.Message : "Speech is not configured."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Speech-to-speech translation error");
            if (creditCharged) await _creditService.AllocateCreditsAsync(speechUserId, speechCost, "refund", "Refund: speech-to-speech error", CancellationToken.None);
            return StatusCode(StatusCodes.Status502BadGateway, ApiResponse<object>.Fail("Failed to translate speech."));
        }
        finally
        {
            foreach (var path in tempFiles)
            {
                try { System.IO.File.Delete(path); } catch { }
            }
        }
    }

    private static (string outputFormatHeader, string contentType, string dataUrlPrefix, string fileExtension) GetOutputAudioFormat(string kind)
    {
        return kind.ToLowerInvariant() switch
        {
            "wav" or "wave" => ("riff-16khz-16bit-mono-pcm", "audio/wav", "data:audio/wav;base64,", "wav"),
            "mp3" or "mpeg" => ("audio-16khz-32kbitrate-mono-mp3", "audio/mpeg", "data:audio/mpeg;base64,", "mp3"),
            _ => ("audio-16khz-32kbitrate-mono-mp3", "audio/mpeg", "data:audio/mpeg;base64,", "mp3")
        };
    }
}
