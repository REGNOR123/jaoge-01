using Microsoft.CognitiveServices.Speech;
using Microsoft.CognitiveServices.Speech.Audio;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;
using System.Text.Json;
using Text_To_Speeches_Dotnet_BE.Configuration;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Speech;
using Text_To_Speeches_Dotnet_BE.Services.Translator;
using Text_To_Speeches_Dotnet_BE.Services.Credits;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Authorize]
[Route("api/speech")]
public sealed class TranscriptionController : BaseApiController
{
    private readonly IConfiguration _configuration;
    private readonly SpeechOptions _speechOptions;
    private readonly IAzureTranslatorService _translatorService;
    private readonly ICreditService _creditService;
    private readonly ILogger<TranscriptionController> _logger;

    public TranscriptionController(
        IConfiguration configuration,
        IOptions<SpeechOptions> speechOptions,
        IAzureTranslatorService translatorService,
        ICreditService creditService,
        ILogger<TranscriptionController> logger)
    {
        _configuration = configuration;
        _speechOptions = speechOptions.Value;
        _translatorService = translatorService;
        _creditService = creditService;
        _logger = logger;
    }

    [HttpPost("transcribe")]
    [HttpPost("~/transcribe")]
    [EnableRateLimiting("AiLimiter")]
    [RequestSizeLimit(20 * 1024 * 1024)]
    public async Task<IActionResult> Transcribe([FromForm] SpeechTranscribeRequest request, CancellationToken cancellationToken)
    {
        var tempFiles = new List<string>();
        var userId = GetRequiredUserId();
        long transcribeCost = 0;
        bool creditCharged = false;

        try
        {
            var speechKey = _configuration["SPEECH_KEY"] ?? _speechOptions.Key;
            var speechRegion = _configuration["SPEECH_REGION"] ?? _speechOptions.Region;

            if (string.IsNullOrWhiteSpace(speechKey) || string.IsNullOrWhiteSpace(speechRegion))
            {
                return BadRequest(new
                {
                    success = false,
                    error = "Missing SPEECH_KEY or SPEECH_REGION configuration."
                });
            }

            if (request.Audio is null || request.Audio.Length == 0)
            {
                return BadRequest(new { success = false, error = "Audio file is required." });
            }

            transcribeCost = await _creditService.CalculateCreditCostAsync("transcribe", cancellationToken: cancellationToken);
            var (deducted, _) = await _creditService.DeductCreditsAsync(userId, "transcribe", transcribeCost, "Audio transcription", cancellationToken);
            if (!deducted)
            {
                var balance = await _creditService.GetBalanceAsync(userId, cancellationToken);
                return StatusCode(402, new { success = false, error = "Insufficient credits.",
                    data = new { requiredCredits = transcribeCost, currentBalance = balance } });
            }
            creditCharged = true;

            var inputPath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}{Path.GetExtension(request.Audio.FileName)}");
            tempFiles.Add(inputPath);

            await using (var fs = System.IO.File.Create(inputPath))
            {
                await request.Audio.CopyToAsync(fs, cancellationToken);
            }

            var wavPath = inputPath;
            if (AudioUtilities.LooksLikeWavFile(inputPath))
            {
                // ok
            }
            else if (AudioUtilities.LooksLikeMp3File(inputPath))
            {
                wavPath = Path.Combine(Path.GetTempPath(), $"{Guid.NewGuid():N}.wav");
                tempFiles.Add(wavPath);
                AudioUtilities.ConvertAudioTo16kMonoWav(inputPath, wavPath);
            }
            else
            {
                await _creditService.AllocateCreditsAsync(userId, transcribeCost, "refund", "Refund: unsupported audio format", CancellationToken.None);
                creditCharged = false;
                return StatusCode(StatusCodes.Status415UnsupportedMediaType, new
                {
                    success = false,
                    error = "Unsupported audio format. Please upload a WAV or MP3 file."
                });
            }

            var language = string.IsNullOrWhiteSpace(request.Language) ? "en-US" : request.Language.Trim();

            if (!VoiceResolver.IsValidLanguageCode(language))
            {
                await _creditService.AllocateCreditsAsync(userId, transcribeCost, "refund", "Refund: invalid language code", CancellationToken.None);
                creditCharged = false;
                return BadRequest(new { success = false, error = "Invalid language code." });
            }

            var speechConfig = SpeechConfig.FromSubscription(speechKey, speechRegion);
            speechConfig.SpeechRecognitionLanguage = language;
            speechConfig.OutputFormat = OutputFormat.Detailed;
            speechConfig.RequestWordLevelTimestamps();
            speechConfig.SetProperty(PropertyId.SpeechServiceResponse_PostProcessingOption, "TrueText");
            speechConfig.SetProperty(PropertyId.SpeechServiceResponse_RequestSentenceBoundary, "true");

            using var audioConfig = AudioConfig.FromWavFileInput(wavPath);
            using var recognizer = new SpeechRecognizer(speechConfig, audioConfig);

            var segments = new List<TranscribedSegment>();
            var words = new List<TranscribedWord>();

            var done = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);

            recognizer.Recognized += (_, e) =>
            {
                if (e.Result.Reason != ResultReason.RecognizedSpeech)
                {
                    return;
                }

                var json = e.Result.Properties.GetProperty(PropertyId.SpeechServiceResponse_JsonResult);
                if (SpeechJsonParser.TryParseDetailedSpeechJson(json, out var segment, out var segmentWords))
                {
                    segments.Add(segment);
                    words.AddRange(segmentWords);
                }
            };

            recognizer.Canceled += (_, e) =>
            {
                var reasonText = e.Reason.ToString();
                var isNormalEnd =
                    e.Reason == CancellationReason.EndOfStream ||
                    string.Equals(reasonText, "EndOfStream", StringComparison.OrdinalIgnoreCase) ||
                    (e.ErrorCode == CancellationErrorCode.NoError && e.Reason != CancellationReason.Error);

                if (isNormalEnd)
                {
                    done.TrySetResult();
                    return;
                }

                var msg = $"Speech recognition canceled ({e.Reason}). {e.ErrorCode}: {e.ErrorDetails}";
                done.TrySetException(new InvalidOperationException(msg));
            };

            recognizer.SessionStopped += (_, _) => done.TrySetResult();

            await recognizer.StartContinuousRecognitionAsync().ConfigureAwait(false);
            await done.Task.WaitAsync(cancellationToken).ConfigureAwait(false);
            await recognizer.StopContinuousRecognitionAsync().ConfigureAwait(false);

            var fullText = string.Join(" ", segments.Select(s => s.Text).Where(t => !string.IsNullOrWhiteSpace(t))).Trim();

            string? originalText = null;
            string? translatedTo = null;
            if (IsTruthy(request.Translate) && !string.IsNullOrWhiteSpace(fullText))
            {
                originalText = fullText;
                translatedTo = VoiceResolver.NormalizeTranslatorLanguage(request.To);
                try
                {
                    fullText = await _translatorService.TranslateAsync(fullText, translatedTo, cancellationToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Transcript translation failed (to={To})", translatedTo);
                    await _creditService.AllocateCreditsAsync(userId, transcribeCost, "refund", "Refund: transcript translation error", CancellationToken.None);
                    creditCharged = false;
                    return StatusCode(StatusCodes.Status502BadGateway, new
                    {
                        success = false,
                        error = "Failed to translate transcript."
                    });
                }
            }

            creditCharged = false;
            return Ok(new
            {
                success = true,
                data = new
                {
                    language,
                    translatedTo,
                    originalText,
                    text = fullText,
                    segments = segments.OrderBy(s => s.StartMs).ToArray(),
                    words = words.OrderBy(w => w.StartMs).ToArray()
                }
            });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Speech transcription configuration/runtime error");
            if (creditCharged) await _creditService.AllocateCreditsAsync(userId, transcribeCost, "refund", "Refund: transcription error", CancellationToken.None);
            return StatusCode(StatusCodes.Status500InternalServerError, new
            {
                success = false,
                error = ex.Message
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Speech transcription error");
            if (creditCharged) await _creditService.AllocateCreditsAsync(userId, transcribeCost, "refund", "Refund: transcription error", CancellationToken.None);
            return StatusCode(StatusCodes.Status502BadGateway, new
            {
                success = false,
                error = "Failed to transcribe audio."
            });
        }
        finally
        {
            foreach (var path in tempFiles)
            {
                try
                {
                    System.IO.File.Delete(path);
                }
                catch
                {
                    // ignore cleanup errors
                }
            }
        }
    }

    private static bool IsTruthy(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return false;
        }

        return value.Trim() switch
        {
            "1" or "true" or "True" or "TRUE" or "on" or "On" or "ON" or "yes" or "Yes" or "YES" => true,
            _ => false
        };
    }
}
