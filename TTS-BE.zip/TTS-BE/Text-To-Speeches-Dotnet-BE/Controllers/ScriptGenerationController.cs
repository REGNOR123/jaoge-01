using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.ScriptGeneration;
using Text_To_Speeches_Dotnet_BE.Services.Credits;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Route("api/script-generation")]
[Authorize]
public sealed class ScriptGenerationController : BaseApiController
{
    private readonly IScriptGenerationService _scriptGenerationService;
    private readonly ICreditService _creditService;
    private readonly ILogger<ScriptGenerationController> _logger;

    public ScriptGenerationController(
        IScriptGenerationService scriptGenerationService,
        ICreditService creditService,
        ILogger<ScriptGenerationController> logger)
    {
        _scriptGenerationService = scriptGenerationService;
        _creditService = creditService;
        _logger = logger;
    }

    /// <summary>
    /// Generates a script based on the provided SKU type and inputs using Azure OpenAI
    /// </summary>
    /// <remarks>
    /// Generate a script for one of the supported SKU types:
    /// - youtube: Long-form YouTube videos
    /// - short: TikTok/Instagram Reels (30-90s)
    /// - podcast: Podcast episodes
    /// - explainer: Educational content
    /// - custom: Flexible, user-defined scripts
    /// </remarks>
    /// <param name="sku">Script type (youtube, short, podcast, explainer, custom)</param>
    /// <param name="request">Script generation request with SKU-specific inputs</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Generated script with metadata or error details</returns>
    /// <response code="200">Script generated successfully</response>
    /// <response code="400">Invalid inputs or validation error</response>
    /// <response code="500">Server error (Azure OpenAI or other issues)</response>
    [HttpPost("{sku}")]
    [EnableRateLimiting("AiLimiter")]
    [ProducesResponseType(typeof(ScriptGenerationResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ScriptGenerationResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ScriptGenerationResponse), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GenerateScript(
        [FromRoute] string sku,
        [FromBody] ScriptGenerationRequest request,
        CancellationToken cancellationToken)
    {
        // Normalize SKU to lowercase
        sku = sku?.ToLowerInvariant() ?? string.Empty;

        // Validate SKU
        if (!IsValidSku(sku))
        {
            _logger.LogWarning("Invalid SKU requested: {sku}", sku);
            var response = new ScriptGenerationResponse
            {
                Success = false,
                Error = "Invalid script type. Valid types: youtube, short, podcast, explainer, custom",
                Code = "UNKNOWN_SKU"
            };
            return BadRequest(response);
        }

        // Validate request model binding
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            _logger.LogWarning("Model validation failed for SKU {sku}: {errors}", sku, string.Join("; ", errors));

            var response = new ScriptGenerationResponse
            {
                Success = false,
                Error = errors.FirstOrDefault() ?? "Validation failed",
                Code = "VALIDATION_ERROR"
            };
            return BadRequest(response);
        }

        // Log request
        _logger.LogInformation("Script generation request for SKU: {sku}", sku);

        var userId = GetRequiredUserId();
        long scriptCost = await _creditService.CalculateCreditCostAsync("script-generate", cancellationToken: cancellationToken);

        var (deducted, _) = await _creditService.DeductCreditsAsync(userId, "script-generate", scriptCost, $"Script generation: {sku}", cancellationToken);
        if (!deducted)
        {
            var balance = await _creditService.GetBalanceAsync(userId, cancellationToken);
            return StatusCode(402, new { success = false, error = "Insufficient credits.",
                data = new { requiredCredits = scriptCost, currentBalance = balance } });
        }

        // Call service to generate script
        var result = await _scriptGenerationService.GenerateScriptAsync(sku, request, cancellationToken);

        // Return appropriate status code
        if (result.Success)
        {
            _logger.LogInformation("Script generated successfully for SKU: {sku}, WordCount: {wordCount}", sku, result.Metadata?.WordCount ?? 0);
            return Ok(result);
        }

        await _creditService.AllocateCreditsAsync(userId, scriptCost, "refund", $"Refund: script generation failed ({sku})", CancellationToken.None);

        // Determine appropriate error status code based on error code
        var statusCode = result.Code switch
        {
            "UNKNOWN_SKU" => StatusCodes.Status400BadRequest,
            "VALIDATION_ERROR" => StatusCodes.Status400BadRequest,
            "AZURE_OPENAI_ERROR" => StatusCodes.Status500InternalServerError,
            "INTERNAL_ERROR" => StatusCodes.Status500InternalServerError,
            _ => StatusCodes.Status500InternalServerError
        };

        _logger.LogError("Script generation failed for SKU: {sku}, Error: {error}", sku, result.Error);
        return StatusCode(statusCode, result);
    }

    /// <summary>
    /// Generates a single field content for the auto-generate button (Step 2)
    /// </summary>
    /// <remarks>
    /// Generate content for a specific field based on context. This is used for the "Auto-generate" buttons
    /// in the detailed information step. Supported fields vary by SKU:
    /// - youtube: hook, mainPoints, cta
    /// - short: hook, body, climax
    /// - podcast: opening, segments, conclusion
    /// - explainer: whyItMatters, keyPoints, examples
    /// - custom: (not supported)
    /// </remarks>
    /// <param name="sku">Script type (youtube, short, podcast, explainer, custom)</param>
    /// <param name="request">Field generation request with fieldId and context</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Generated field content or error details</returns>
    /// <response code="200">Field generated successfully</response>
    /// <response code="400">Invalid inputs or unsupported field</response>
    /// <response code="500">Server error (Azure OpenAI or other issues)</response>
    [HttpPost("{sku}/generate-field")]
    [EnableRateLimiting("AiLimiter")]
    [ProducesResponseType(typeof(GenerateFieldResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(GenerateFieldResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(GenerateFieldResponse), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GenerateField(
        [FromRoute] string sku,
        [FromBody] GenerateFieldRequest request,
        CancellationToken cancellationToken)
    {
        // Normalize SKU and fieldId to lowercase
        sku = sku?.ToLowerInvariant() ?? string.Empty;
        request.FieldId = request.FieldId?.ToLowerInvariant() ?? string.Empty;

        // Validate SKU
        if (!IsValidSku(sku))
        {
            _logger.LogWarning("Invalid SKU requested for field generation: {sku}", sku);
            var response = new GenerateFieldResponse
            {
                Success = false,
                Error = "Invalid script type. Valid types: youtube, short, podcast, explainer, custom",
                Code = "UNKNOWN_SKU"
            };
            return BadRequest(response);
        }

        // Validate request model binding
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            _logger.LogWarning("Model validation failed for field generation on SKU {sku}: {errors}", sku, string.Join("; ", errors));

            var response = new GenerateFieldResponse
            {
                Success = false,
                Error = errors.FirstOrDefault() ?? "Validation failed",
                Code = "VALIDATION_ERROR"
            };
            return BadRequest(response);
        }

        // Log request
        _logger.LogInformation("Field generation request for SKU: {sku}, FieldId: {fieldId}", sku, request.FieldId);

        var fieldUserId = GetRequiredUserId();
        long fieldCost = await _creditService.CalculateCreditCostAsync("auto-generate", cancellationToken: cancellationToken);

        var (fieldDeducted, _) = await _creditService.DeductCreditsAsync(fieldUserId, "auto-generate", fieldCost, $"Field generate: {request.FieldId}", cancellationToken);
        if (!fieldDeducted)
        {
            var balance = await _creditService.GetBalanceAsync(fieldUserId, cancellationToken);
            return StatusCode(402, new { success = false, error = "Insufficient credits.",
                data = new { requiredCredits = fieldCost, currentBalance = balance } });
        }

        // Call service to generate field
        var result = await _scriptGenerationService.GenerateFieldAsync(sku, request, cancellationToken);

        // Return appropriate status code
        if (result.Success)
        {
            _logger.LogInformation("Field generated successfully for SKU: {sku}, FieldId: {fieldId}, ContentLength: {contentLength}",
                sku, request.FieldId, result.Content?.Length ?? 0);
            return Ok(result);
        }

        await _creditService.AllocateCreditsAsync(fieldUserId, fieldCost, "refund", $"Refund: field generation failed ({request.FieldId})", CancellationToken.None);

        // Determine appropriate error status code based on error code
        var statusCode = result.Code switch
        {
            "UNKNOWN_SKU" => StatusCodes.Status400BadRequest,
            "INVALID_FIELD" => StatusCodes.Status400BadRequest,
            "VALIDATION_ERROR" => StatusCodes.Status400BadRequest,
            "AZURE_OPENAI_ERROR" => StatusCodes.Status500InternalServerError,
            "INTERNAL_ERROR" => StatusCodes.Status500InternalServerError,
            _ => StatusCodes.Status500InternalServerError
        };

        _logger.LogError("Field generation failed for SKU: {sku}, FieldId: {fieldId}, Error: {error}", sku, request.FieldId, result.Error);
        return StatusCode(statusCode, result);
    }

    /// <summary>
    /// Transforms an existing script (rewrite, shorten, expand, tone change)
    /// </summary>
    /// <remarks>
    /// Transform a script using one of the following transformation types:
    /// - rewrite: Improve clarity, pacing, and engagement
    /// - shorten: Make it more concise
    /// - expand: Add more detail
    /// - tone-change: Apply a specific tone to the script
    /// </remarks>
    /// <param name="sku">Script type (context for transformation)</param>
    /// <param name="request">Transformation request with script and transformation type</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>Transformed script with metadata or error details</returns>
    /// <response code="200">Script transformed successfully</response>
    /// <response code="400">Invalid inputs or validation error</response>
    /// <response code="500">Server error (Azure OpenAI or other issues)</response>
    [HttpPost("{sku}/transform")]
    [EnableRateLimiting("AiLimiter")]
    [ProducesResponseType(typeof(ScriptTransformationResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ScriptTransformationResponse), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ScriptTransformationResponse), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> TransformScript(
        [FromRoute] string sku,
        [FromBody] ScriptTransformationRequest request,
        CancellationToken cancellationToken)
    {
        // Normalize SKU and transformation type to lowercase
        sku = sku?.ToLowerInvariant() ?? string.Empty;
        request.Transformation = request.Transformation?.ToLowerInvariant() ?? string.Empty;

        // Validate SKU
        if (!IsValidSku(sku))
        {
            _logger.LogWarning("Invalid SKU requested for transformation: {sku}", sku);
            var response = new ScriptTransformationResponse
            {
                Success = false,
                Error = "Invalid script type. Valid types: youtube, short, podcast, explainer, custom",
                Code = "UNKNOWN_SKU"
            };
            return BadRequest(response);
        }

        // Validate request model binding
        if (!ModelState.IsValid)
        {
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .ToList();

            _logger.LogWarning("Model validation failed for transformation on SKU {sku}: {errors}", sku, string.Join("; ", errors));

            var response = new ScriptTransformationResponse
            {
                Success = false,
                Error = errors.FirstOrDefault() ?? "Validation failed",
                Code = "VALIDATION_ERROR"
            };
            return BadRequest(response);
        }

        // Log request
        _logger.LogInformation("Script transformation request for SKU: {sku}, Type: {transformation}", sku, request.Transformation);

        var transformUserId = GetRequiredUserId();
        long transformCost = await _creditService.CalculateCreditCostAsync("script-transform", cancellationToken: cancellationToken);

        var (transformDeducted, _) = await _creditService.DeductCreditsAsync(transformUserId, "script-transform", transformCost, $"Script transform: {request.Transformation}", cancellationToken);
        if (!transformDeducted)
        {
            var balance = await _creditService.GetBalanceAsync(transformUserId, cancellationToken);
            return StatusCode(402, new { success = false, error = "Insufficient credits.",
                data = new { requiredCredits = transformCost, currentBalance = balance } });
        }

        // Call service to transform script
        var result = await _scriptGenerationService.TransformScriptAsync(sku, request, cancellationToken);

        // Return appropriate status code
        if (result.Success)
        {
            _logger.LogInformation("Script transformed successfully for SKU: {sku}, Transformation: {transformation}, WordCount before: {before}, after: {after}",
                sku, request.Transformation, result.Metadata?.WordCountBefore ?? 0, result.Metadata?.WordCountAfter ?? 0);
            return Ok(result);
        }

        await _creditService.AllocateCreditsAsync(transformUserId, transformCost, "refund", $"Refund: script transform failed ({request.Transformation})", CancellationToken.None);

        // Determine appropriate error status code based on error code
        var statusCode = result.Code switch
        {
            "UNKNOWN_SKU" => StatusCodes.Status400BadRequest,
            "VALIDATION_ERROR" => StatusCodes.Status400BadRequest,
            "AZURE_OPENAI_ERROR" => StatusCodes.Status500InternalServerError,
            "INTERNAL_ERROR" => StatusCodes.Status500InternalServerError,
            _ => StatusCodes.Status500InternalServerError
        };

        _logger.LogError("Script transformation failed for SKU: {sku}, Error: {error}", sku, result.Error);
        return StatusCode(statusCode, result);
    }

    #region Private Methods

    private static bool IsValidSku(string sku)
    {
        return sku switch
        {
            "youtube" or "short" or "podcast" or "explainer" or "custom" => true,
            _ => false
        };
    }

    #endregion
}
