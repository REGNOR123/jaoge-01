using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using System.Text.Json;
using Text_To_Speeches_Dotnet_BE.Services.Database;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Route("api/plans")]
[EnableRateLimiting("ReadLimiter")]
public sealed class PlansController : ControllerBase
{
    private const string PlansCacheKey = "plans_v1";
    private static readonly TimeSpan PlansCacheTtl = TimeSpan.FromMinutes(5);

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly IMemoryCache _cache;
    private readonly ILogger<PlansController> _logger;

    public PlansController(ISqlConnectionFactory connectionFactory, IMemoryCache cache, ILogger<PlansController> logger)
    {
        _connectionFactory = connectionFactory;
        _cache = cache;
        _logger = logger;
    }

    [HttpGet]
    public async Task<IActionResult> GetPlans(CancellationToken cancellationToken)
    {
        if (_cache.TryGetValue(PlansCacheKey, out object? cached) && cached is not null)
            return Ok(cached);

        try
        {
            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(cancellationToken);

            await using var cmd = new SqlCommand(
                """
                SELECT name, display_name, monthly_price, annual_price,
                       inr_monthly_price, inr_annual_price,
                       credits_per_month, is_one_time_grant,
                       is_popular, badge, cta_label, features_json
                FROM dbo.plans
                WHERE is_active = 1
                ORDER BY sort_order
                """,
                connection);

            var plans = new List<object>();
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                var featuresJson = reader.IsDBNull(11) ? null : reader.GetString(11);
                string[]? features = null;
                if (!string.IsNullOrWhiteSpace(featuresJson))
                {
                    try { features = JsonSerializer.Deserialize<string[]>(featuresJson); } catch { }
                }

                plans.Add(new
                {
                    name              = reader.GetString(0),
                    displayName       = reader.GetString(1),
                    monthlyPrice      = reader.GetDecimal(2),
                    annualPrice       = reader.GetDecimal(3),
                    inrMonthlyPrice   = reader.IsDBNull(4) ? 0m : reader.GetDecimal(4),
                    inrAnnualPrice    = reader.IsDBNull(5) ? 0m : reader.GetDecimal(5),
                    creditsPerMonth   = reader.GetInt64(6),
                    isOneTimeGrant    = reader.GetBoolean(7),
                    popular           = reader.GetBoolean(8),
                    badge             = reader.IsDBNull(9)  ? null : reader.GetString(9),
                    ctaLabel          = reader.IsDBNull(10) ? null : reader.GetString(10),
                    features          = features ?? Array.Empty<string>(),
                });
            }

            var response = new { success = true, data = plans };
            _cache.Set(PlansCacheKey, (object)response, PlansCacheTtl);
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching plans");
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { success = false, error = "Failed to fetch plans." });
        }
    }
}
