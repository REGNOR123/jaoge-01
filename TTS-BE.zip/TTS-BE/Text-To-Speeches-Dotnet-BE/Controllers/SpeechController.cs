using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Text_To_Speeches_Dotnet_BE.Configuration;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Speech;
using Text_To_Speeches_Dotnet_BE.Services.Credits;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Authorize]
[Route("api/speech")]
public sealed class SpeechController : BaseApiController
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IConfiguration _configuration;
    private readonly SpeechOptions _speechOptions;
    private readonly ICreditService _creditService;
    private readonly ILogger<SpeechController> _logger;

    public SpeechController(
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        IOptions<SpeechOptions> speechOptions,
        ICreditService creditService,
        ILogger<SpeechController> logger)
    {
        _httpClientFactory = httpClientFactory;
        _configuration = configuration;
        _speechOptions = speechOptions.Value;
        _creditService = creditService;
        _logger = logger;
    }

    [EnableRateLimiting("AiLimiter")]
    [HttpGet("token")]
    public async Task<IActionResult> GetSpeechToken(CancellationToken cancellationToken)
    {
        try
        {
            var speechKey = _configuration["SPEECH_KEY"] ?? _speechOptions.Key;
            var speechRegion = _configuration["SPEECH_REGION"] ?? _speechOptions.Region;
            var speechEndpoint = _configuration["SPEECH_ENDPOINT"] ?? _speechOptions.Endpoint;

            if (string.IsNullOrWhiteSpace(speechKey) || string.IsNullOrWhiteSpace(speechRegion))
            {
                return BadRequest(new
                {
                    success = false,
                    error = "Missing SPEECH_KEY or SPEECH_REGION configuration."
                });
            }

            var baseEndpoint = string.IsNullOrWhiteSpace(speechEndpoint)
                ? $"https://{speechRegion}.api.cognitive.microsoft.com"
                : speechEndpoint;

            var tokenUrl = $"{baseEndpoint.TrimEnd('/')}/sts/v1.0/issueToken";

            using var request = new HttpRequestMessage(HttpMethod.Post, tokenUrl);
            request.Headers.Add("Ocp-Apim-Subscription-Key", speechKey);
            request.Content = new StringContent(string.Empty);
            request.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/x-www-form-urlencoded");

            var client = _httpClientFactory.CreateClient();
            using var response = await client.SendAsync(request, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                return StatusCode(StatusCodes.Status401Unauthorized, new
                {
                    success = false,
                    error = "There was an error authorizing your speech key."
                });
            }

            var token = await response.Content.ReadAsStringAsync(cancellationToken);
            return Ok(new
            {
                success = true,
                data = new
                {
                    token,
                    region = speechRegion
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Speech token error");
            return StatusCode(StatusCodes.Status500InternalServerError, new
            {
                success = false,
                error = "Failed to get speech token."
            });
        }
    }

    private const int MaxTtsChars = 5000;

    [EnableRateLimiting("AiLimiter")]
    [HttpPost("tts")]
    public async Task<IActionResult> TextToSpeech([FromBody] SpeechTtsRequest request, CancellationToken cancellationToken)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.Text))
                return BadRequest(new { success = false, error = "Text is required." });

            if (request.Text.Length > MaxTtsChars)
                return BadRequest(new { success = false, error = $"Text exceeds the maximum allowed length of {MaxTtsChars} characters." });

            if (!string.IsNullOrWhiteSpace(request.Voice) && !VoiceResolver.IsKnownVoice(request.Voice))
                return BadRequest(new { success = false, error = "Invalid voice selection." });
            var speechKey = _configuration["SPEECH_KEY"] ?? _speechOptions.Key;
            var speechRegion = _configuration["SPEECH_REGION"] ?? _speechOptions.Region;

            if (string.IsNullOrWhiteSpace(speechKey) || string.IsNullOrWhiteSpace(speechRegion))
            {
                return BadRequest(new
                {
                    success = false,
                    error = "Missing SPEECH_KEY or SPEECH_REGION configuration."
                });
            }

            var userId = GetRequiredUserId();
            var featureKey = VoiceResolver.ResolveFeatureKey(request.Voice);
            var creditCost = await _creditService.CalculateCreditCostAsync(featureKey, characters: request.Text?.Length ?? 0, cancellationToken: cancellationToken);

            var (deducted, _) = await _creditService.DeductCreditsAsync(userId, featureKey, creditCost,
                $"TTS: {request.Text?.Length} chars", cancellationToken);
            if (!deducted)
            {
                var balance = await _creditService.GetBalanceAsync(userId, cancellationToken);
                return StatusCode(402, new { success = false, error = "Insufficient credits.",
                    data = new { requiredCredits = creditCost, currentBalance = balance } });
            }

            var ttsEndpoint = $"https://{speechRegion}.tts.speech.microsoft.com/cognitiveservices/v1";
            var ssml = SsmlBuilder.BuildSsml(request);

            using var httpRequest = new HttpRequestMessage(HttpMethod.Post, ttsEndpoint);
            httpRequest.Headers.Add("Ocp-Apim-Subscription-Key", speechKey);
            httpRequest.Headers.Add("X-Microsoft-OutputFormat", "audio-16khz-32kbitrate-mono-mp3");
            httpRequest.Headers.UserAgent.ParseAdd("TextToSpeechesBackend/1.0");

            httpRequest.Content = new StringContent(ssml, Encoding.UTF8, "application/ssml+xml");
            httpRequest.Content.Headers.ContentType = new MediaTypeHeaderValue("application/ssml+xml") { CharSet = "utf-8" };

            var client = _httpClientFactory.CreateClient();
            using var response = await client.SendAsync(httpRequest, cancellationToken);
            var bytes = await response.Content.ReadAsByteArrayAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                var responseBody = TryDecode(bytes);
                _logger.LogWarning("TTS failed ({Status}): {Body}", (int)response.StatusCode, responseBody);
                await _creditService.AllocateCreditsAsync(userId, creditCost, "refund", "Refund: TTS Azure error", CancellationToken.None);
                return StatusCode(StatusCodes.Status502BadGateway, new
                {
                    success = false,
                    error = "Azure TTS request failed."
                });
            }

            var base64 = Convert.ToBase64String(bytes);
            var dataUrl = $"data:audio/mpeg;base64,{base64}";

            return Ok(new
            {
                success = true,
                data = new
                {
                    audioDataUrl = dataUrl,
                    audioUrl = dataUrl
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Speech TTS error");
            return StatusCode(StatusCodes.Status500InternalServerError, new
            {
                success = false,
                error = "Failed to synthesize speech."
            });
        }
    }

    private static string TryDecode(byte[] bytes)
    {
        try
        {
            return Encoding.UTF8.GetString(bytes);
        }
        catch
        {
            return "<binary>";
        }
    }

    [HttpPost("detect-language")]
    [EnableRateLimiting("AiLimiter")]
    public async Task<IActionResult> DetectAudioLanguage(IFormFile audio, CancellationToken cancellationToken)
    {
        try
        {
            var speechKey = _configuration["SPEECH_KEY"] ?? _speechOptions.Key;
            var speechRegion = _configuration["SPEECH_REGION"] ?? _speechOptions.Region;
            var speechEndpoint = _configuration["SPEECH_ENDPOINT"] ?? _speechOptions.Endpoint;

            if (string.IsNullOrWhiteSpace(speechKey) || string.IsNullOrWhiteSpace(speechRegion))
                return BadRequest(new { success = false, error = "Missing SPEECH_KEY or SPEECH_REGION configuration." });

            if (audio == null || audio.Length == 0)
                return BadRequest(new { success = false, error = "No audio file provided." });

            var userId = GetUserIdFromToken();
            long detectCost = 0;
            if (userId.HasValue)
            {
                detectCost = await _creditService.CalculateCreditCostAsync("detect-language", cancellationToken: cancellationToken);
                var balance = await _creditService.GetBalanceAsync(userId.Value, cancellationToken);
                if (balance < detectCost)
                    return StatusCode(402, new { success = false, error = "Insufficient credits.",
                        data = new { requiredCredits = detectCost, currentBalance = balance } });
            }

            var baseEndpoint = string.IsNullOrWhiteSpace(speechEndpoint)
                ? $"https://{speechRegion}.api.cognitive.microsoft.com"
                : speechEndpoint.TrimEnd('/');

            var endpoint = $"{baseEndpoint}/speechtotext/v3.2/transcriptions:transcribe";

            // Read audio into memory so the stream is not disposed before the HTTP request fires
            using var ms = new MemoryStream();
            await audio.CopyToAsync(ms, cancellationToken);
            var audioBytes = ms.ToArray();

            var definition = JsonSerializer.Serialize(new
            {
                locales = new[]
                {
                    "en-US", "hi-IN", "ta-IN", "te-IN", "ml-IN", "bn-IN", "mr-IN",
                    "gu-IN", "kn-IN", "pa-IN", "ur-IN", "or-IN", "as-IN",
                    "ms-MY", "fil-PH", "id-ID", "de-DE", "fr-FR", "es-ES",
                    "ja-JP", "ko-KR", "zh-CN", "ar-SA", "pt-BR", "ru-RU",
                    "vi-VN", "th-TH"
                },
                channels = new[] { 0 }
            });

            // Use ByteArrayContent to avoid charset being appended to Content-Type
            var defContent = new ByteArrayContent(Encoding.UTF8.GetBytes(definition));
            defContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var audioMime = ResolveAudioMime(audio.FileName, audio.ContentType);
            var audioContent = new ByteArrayContent(audioBytes);
            audioContent.Headers.ContentType = new MediaTypeHeaderValue(audioMime);

            using var content = new MultipartFormDataContent();
            content.Add(defContent, "definition");
            content.Add(audioContent, "audio", audio.FileName ?? "audio.mp3");

            using var httpRequest = new HttpRequestMessage(HttpMethod.Post, endpoint);
            httpRequest.Headers.Add("Ocp-Apim-Subscription-Key", speechKey);
            httpRequest.Content = content;

            var client = _httpClientFactory.CreateClient();
            using var response = await client.SendAsync(httpRequest, cancellationToken);
            var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("Speech detect-language failed ({Status}): {Body}", (int)response.StatusCode, responseBody);
                return StatusCode(StatusCodes.Status502BadGateway, new { success = false, error = "Language detection failed." });
            }

            using var doc = JsonDocument.Parse(responseBody);
            var root = doc.RootElement;

            string? locale = null;
            if (root.TryGetProperty("combinedPhrases", out var phrases) && phrases.GetArrayLength() > 0)
            {
                if (phrases[0].TryGetProperty("locale", out var localeEl))
                    locale = localeEl.GetString();
            }

            if (userId.HasValue && detectCost > 0)
                await _creditService.DeductCreditsAsync(userId.Value, "detect-language", detectCost, "Language detection", cancellationToken);

            return Ok(new { success = true, data = new { language = locale } });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Speech detect-language error");
            return StatusCode(StatusCodes.Status500InternalServerError, new
            {
                success = false,
                error = "Failed to detect audio language."
            });
        }
    }

    private static string ResolveAudioMime(string? fileName, string? contentType)
    {
        if (!string.IsNullOrWhiteSpace(contentType) &&
            contentType != "application/octet-stream" &&
            contentType.StartsWith("audio/", StringComparison.OrdinalIgnoreCase))
            return contentType;

        var ext = Path.GetExtension(fileName ?? "").ToLowerInvariant();
        return ext switch
        {
            ".mp3"  => "audio/mpeg",
            ".wav"  => "audio/wav",
            ".ogg"  => "audio/ogg",
            ".m4a"  => "audio/mp4",
            ".flac" => "audio/flac",
            ".webm" => "audio/webm",
            _       => "audio/mpeg"
        };
    }
}
