using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;
using Text_To_Speeches_Dotnet_BE.Services.Credits;
using Text_To_Speeches_Dotnet_BE.Services.Database;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Authorize]
[Route("api/payment")]
public sealed class PaymentController : BaseApiController
{
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ICreditService _creditService;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly RazorpayOptions _razorpayOptions;
    private readonly ILogger<PaymentController> _logger;

    public PaymentController(
        ISqlConnectionFactory connectionFactory,
        ICreditService creditService,
        IHttpClientFactory httpClientFactory,
        IOptions<RazorpayOptions> razorpayOptions,
        ILogger<PaymentController> logger)
    {
        _connectionFactory = connectionFactory;
        _creditService = creditService;
        _httpClientFactory = httpClientFactory;
        _razorpayOptions = razorpayOptions.Value;
        _logger = logger;
    }

    // Returns the Razorpay key_id for the frontend checkout
    [AllowAnonymous]
    [HttpGet("razorpay-key")]
    public IActionResult GetRazorpayKey() =>
        Ok(new { success = true, data = new { keyId = _razorpayOptions.KeyId } });

    // Creates a Razorpay order and stores it in payment_orders
    [HttpPost("create-order")]
    [EnableRateLimiting("PaymentLimiter")]
    public async Task<IActionResult> CreateOrder([FromBody] CreateOrderRequest request, CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();

            var plan = await FetchPlanAsync(request.PlanName, ct);
            if (plan is null)
                return BadRequest(new { success = false, error = "Unknown plan." });

            var amountInr = (int)(request.BillingCycle == "annual" ? plan.InrAnnual : plan.InrMonthly);
            var amountPaise = amountInr * 100;
            var receipt = $"rcpt_{userId}_{DateTimeOffset.UtcNow.ToUnixTimeSeconds()}";

            // Create Razorpay order via their REST API
            var client = _httpClientFactory.CreateClient("razorpay");
            var credentials = Convert.ToBase64String(
                Encoding.UTF8.GetBytes($"{_razorpayOptions.KeyId}:{_razorpayOptions.KeySecret}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);

            var payload = new { amount = amountPaise, currency = "INR", receipt };
            var response = await client.PostAsJsonAsync("orders", payload, ct);

            if (!response.IsSuccessStatusCode)
            {
                var errorBody = await response.Content.ReadAsStringAsync(ct);
                _logger.LogError("Razorpay order creation failed: {Error}", errorBody);
                return StatusCode(StatusCodes.Status502BadGateway,
                    new { success = false, error = "Failed to create payment order. Please try again." });
            }

            var json = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken: ct);
            var razorpayOrderId = json.GetProperty("id").GetString()!;

            // Persist the order locally
            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);
            await using var cmd = new SqlCommand("""
                INSERT INTO dbo.payment_orders
                    (user_id, razorpay_order_id, plan_name, plan_display_name, amount_inr, credits_granted, status, currency)
                VALUES (@userId, @orderId, @planName, @planDisplay, @amountInr, @credits, 'created', 'INR')
                """, connection);
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@orderId", razorpayOrderId);
            cmd.Parameters.AddWithValue("@planName", request.PlanName.ToLowerInvariant());
            cmd.Parameters.AddWithValue("@planDisplay", plan.DisplayName);
            cmd.Parameters.AddWithValue("@amountInr", (decimal)amountInr);
            cmd.Parameters.AddWithValue("@credits", plan.Credits);
            await cmd.ExecuteNonQueryAsync(ct);

            return Ok(new
            {
                success = true,
                data = new { orderId = razorpayOrderId, amountPaise, currency = "INR" }
            });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new { success = false, error = "Authentication required." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating payment order");
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { success = false, error = "Failed to create order." });
        }
    }

    // Verifies Razorpay payment signature, grants credits, and updates user plan
    [HttpPost("verify")]
    [EnableRateLimiting("PaymentLimiter")]
    public async Task<IActionResult> VerifyPayment([FromBody] VerifyPaymentRequest request, CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();

            // HMAC-SHA256 signature verification
            var sigPayload = $"{request.RazorpayOrderId}|{request.RazorpayPaymentId}";
            using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(_razorpayOptions.KeySecret));
            var computedHash = Convert.ToHexString(
                hmac.ComputeHash(Encoding.UTF8.GetBytes(sigPayload))).ToLowerInvariant();

            if (computedHash != request.RazorpaySignature.ToLowerInvariant())
                return BadRequest(new { success = false, error = "Payment signature verification failed." });

            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);

            // Fetch the stored order
            await using var selectCmd = new SqlCommand("""
                SELECT user_id, plan_name, plan_display_name, credits_granted, status
                FROM dbo.payment_orders
                WHERE razorpay_order_id = @orderId
                """, connection);
            selectCmd.Parameters.AddWithValue("@orderId", request.RazorpayOrderId);

            await using var reader = await selectCmd.ExecuteReaderAsync(ct);
            if (!await reader.ReadAsync(ct))
                return NotFound(new { success = false, error = "Order not found." });

            var orderUserId  = reader.GetInt32(0);
            var planName     = reader.GetString(1);
            var planDisplay  = reader.GetString(2);
            var credits      = reader.GetInt64(3);
            var status       = reader.GetString(4);
            await reader.CloseAsync();

            if (orderUserId != userId)
                return Unauthorized(new { success = false, error = "Order does not belong to this account." });

            // Idempotent — already processed
            if (status == "paid")
            {
                var bal = await _creditService.GetBalanceAsync(userId, ct);
                return Ok(new { success = true, data = new { newBalance = bal, creditsGranted = credits, planName } });
            }

            // Mark order paid and update user plan in one transaction
            await using var tx = (SqlTransaction)await connection.BeginTransactionAsync(ct);
            try
            {
                await using var updateOrder = new SqlCommand("""
                    UPDATE dbo.payment_orders
                    SET status = 'paid', razorpay_payment_id = @paymentId, paid_at = SYSUTCDATETIME()
                    WHERE razorpay_order_id = @orderId
                    """, connection, tx);
                updateOrder.Parameters.AddWithValue("@paymentId", request.RazorpayPaymentId);
                updateOrder.Parameters.AddWithValue("@orderId", request.RazorpayOrderId);
                await updateOrder.ExecuteNonQueryAsync(ct);

                await using var updatePlan = new SqlCommand("""
                    UPDATE dbo.users SET current_plan = @planName WHERE id = @userId
                    """, connection, tx);
                updatePlan.Parameters.AddWithValue("@planName", planName);
                updatePlan.Parameters.AddWithValue("@userId", userId);
                await updatePlan.ExecuteNonQueryAsync(ct);

                await tx.CommitAsync(ct);
            }
            catch
            {
                await tx.RollbackAsync(ct);
                throw;
            }

            // Allocate credits (CreditService manages its own transaction)
            await _creditService.AllocateCreditsAsync(
                userId, credits, "payment", $"{planDisplay} plan — {credits} credits", ct);

            var newBalance = await _creditService.GetBalanceAsync(userId, ct);
            return Ok(new { success = true, data = new { newBalance, creditsGranted = credits, planName } });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new { success = false, error = "Authentication required." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error verifying payment");
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { success = false, error = "Payment verification failed. Please contact support." });
        }
    }

    // Returns usage summary: current plan, credits left, total credits awarded
    [HttpGet("summary")]
    public async Task<IActionResult> GetSummary(CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();
            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);

            await using var cmd = new SqlCommand("""
                SELECT
                    u.credits,
                    u.current_plan,
                    ISNULL((
                        SELECT SUM(credit_delta)
                        FROM dbo.credit_ledger
                        WHERE user_id = @userId AND credit_delta > 0
                    ), 0)
                FROM dbo.users u
                WHERE u.id = @userId
                """, connection);
            cmd.Parameters.AddWithValue("@userId", userId);

            await using var reader = await cmd.ExecuteReaderAsync(ct);
            if (!await reader.ReadAsync(ct))
                return NotFound(new { success = false, error = "User not found." });

            var creditLeft   = Convert.ToInt64(reader.GetValue(0));
            var currentPlan  = reader.GetString(1);
            var totalAwarded = Convert.ToInt64(reader.GetValue(2));

            return Ok(new
            {
                success = true,
                data = new { creditLeft, currentPlan, totalCreditsAwarded = totalAwarded }
            });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new { success = false, error = "Authentication required." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching usage summary");
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { success = false, error = "Failed to fetch usage summary." });
        }
    }

    // Returns payment history for the authenticated user
    [HttpGet("history")]
    public async Task<IActionResult> GetPaymentHistory(CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();
            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);

            await using var cmd = new SqlCommand("""
                SELECT id, razorpay_order_id, razorpay_payment_id,
                       plan_display_name, amount_inr, credits_granted,
                       status, currency, created_at, paid_at
                FROM dbo.payment_orders
                WHERE user_id = @userId
                ORDER BY created_at DESC
                """, connection);
            cmd.Parameters.AddWithValue("@userId", userId);

            var payments = new List<object>();
            await using var reader = await cmd.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
            {
                payments.Add(new
                {
                    id               = reader.GetGuid(0).ToString(),
                    razorpayOrderId  = reader.GetString(1),
                    razorpayPaymentId = reader.IsDBNull(2) ? null : reader.GetString(2),
                    planDisplayName  = reader.GetString(3),
                    amountInr        = reader.GetDecimal(4),
                    creditsGranted   = reader.GetInt64(5),
                    status           = reader.GetString(6),
                    currency         = reader.GetString(7),
                    createdAt        = reader.GetDateTime(8).ToString("O"),
                    paidAt           = reader.IsDBNull(9) ? null : reader.GetDateTime(9).ToString("O"),
                });
            }

            return Ok(new { success = true, data = payments });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new { success = false, error = "Authentication required." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching payment history");
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { success = false, error = "Failed to fetch payment history." });
        }
    }

    // Returns invoice data for a specific paid order
    [HttpGet("invoice/{orderId}")]
    public async Task<IActionResult> GetInvoice(string orderId, CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();

            if (!Guid.TryParse(orderId, out var orderGuid))
                return BadRequest(new { success = false, error = "Invalid order ID." });

            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);

            await using var cmd = new SqlCommand("""
                SELECT po.id, po.razorpay_order_id, po.razorpay_payment_id,
                       po.plan_display_name, po.amount_inr, po.credits_granted,
                       po.status, po.currency, po.paid_at,
                       u.email, u.full_name
                FROM dbo.payment_orders po
                INNER JOIN dbo.users u ON po.user_id = u.id
                WHERE po.id = @orderId AND po.user_id = @userId AND po.status = 'paid'
                """, connection);
            cmd.Parameters.AddWithValue("@orderId", orderGuid);
            cmd.Parameters.AddWithValue("@userId", userId);

            await using var reader = await cmd.ExecuteReaderAsync(ct);
            if (!await reader.ReadAsync(ct))
                return NotFound(new { success = false, error = "Invoice not found." });

            return Ok(new
            {
                success = true,
                data = new
                {
                    invoiceId         = reader.GetGuid(0).ToString(),
                    razorpayOrderId   = reader.GetString(1),
                    razorpayPaymentId = reader.IsDBNull(2) ? null : reader.GetString(2),
                    planDisplayName   = reader.GetString(3),
                    amountInr         = reader.GetDecimal(4),
                    creditsGranted    = reader.GetInt64(5),
                    status            = reader.GetString(6),
                    currency          = reader.GetString(7),
                    paidAt            = reader.IsDBNull(8) ? null : reader.GetDateTime(8).ToString("O"),
                    userEmail         = reader.GetString(9),
                    userName          = reader.GetString(10),
                }
            });
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new { success = false, error = "Authentication required." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching invoice");
            return StatusCode(StatusCodes.Status500InternalServerError,
                new { success = false, error = "Failed to fetch invoice." });
        }
    }

    private async Task<PlanRow?> FetchPlanAsync(string planName, CancellationToken ct)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(ct);
        await using var cmd = new SqlCommand("""
            SELECT inr_monthly_price, inr_annual_price, credits_per_month, display_name
            FROM dbo.plans
            WHERE name = @name AND is_active = 1
            """, connection);
        cmd.Parameters.AddWithValue("@name", planName.ToLowerInvariant());
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct)) return null;
        return new PlanRow(reader.GetDecimal(0), reader.GetDecimal(1), reader.GetInt64(2), reader.GetString(3));
    }
}

public sealed record CreateOrderRequest(string PlanName, string BillingCycle);
public sealed record VerifyPaymentRequest(string RazorpayOrderId, string RazorpayPaymentId, string RazorpaySignature);
public sealed record PlanRow(decimal InrMonthly, decimal InrAnnual, long Credits, string DisplayName);
