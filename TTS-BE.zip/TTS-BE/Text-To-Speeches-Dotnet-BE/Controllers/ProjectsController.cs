using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Storage;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ProjectsController : BaseApiController
{
    private readonly IProjectService _projectService;
    private readonly ILogger<ProjectsController> _logger;

    public ProjectsController(IProjectService projectService, ILogger<ProjectsController> logger)
    {
        _projectService = projectService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<ApiResponse<object>>> ListProjects(CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId is null)
            return Unauthorized(ApiResponse<object>.Fail("User not authenticated."));

        var projects = await _projectService.ListProjectsAsync(userId.Value, cancellationToken);
        return Ok(ApiResponse<object>.Ok((object)projects));
    }

    [HttpGet("{projectId}")]
    public async Task<ActionResult<ApiResponse<object>>> GetProject(string projectId, CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId is null)
            return Unauthorized(ApiResponse<object>.Fail("User not authenticated."));

        var project = await _projectService.GetProjectAsync(userId.Value, projectId, cancellationToken);
        if (project is null)
            return NotFound(ApiResponse<object>.Fail("Project not found."));

        return Ok(ApiResponse<object>.Ok((object)project));
    }

    [HttpPost]
    public async Task<ActionResult<ApiResponse<object>>> CreateProject([FromBody] CreateProjectRequest request, CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId is null)
            return Unauthorized(ApiResponse<object>.Fail("User not authenticated."));

        try
        {
            var project = await _projectService.CreateProjectAsync(userId.Value, request, cancellationToken);
            return Created($"/api/projects/{project.Id}", ApiResponse<object>.Ok((object)project));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create project for user {UserId}", userId.Value);
            return StatusCode(500, ApiResponse<object>.Fail("Failed to create project."));
        }
    }

    [HttpPut("{projectId}")]
    public async Task<ActionResult<ApiResponse<object>>> UpdateProject(string projectId, [FromBody] UpdateProjectRequest request, CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId is null)
            return Unauthorized(ApiResponse<object>.Fail("User not authenticated."));

        try
        {
            var project = await _projectService.UpdateProjectAsync(userId.Value, projectId, request, cancellationToken);
            if (project is null)
                return NotFound(ApiResponse<object>.Fail("Project not found."));

            return Ok(ApiResponse<object>.Ok((object)project));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to update project {ProjectId} for user {UserId}", projectId, userId.Value);
            return StatusCode(500, ApiResponse<object>.Fail("Failed to update project."));
        }
    }

    [HttpDelete("{projectId}")]
    public async Task<ActionResult<ApiResponse<object>>> DeleteProject(string projectId, CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId is null)
            return Unauthorized(ApiResponse<object>.Fail("User not authenticated."));

        var deleted = await _projectService.DeleteProjectAsync(userId.Value, projectId, cancellationToken);
        if (!deleted)
            return NotFound(ApiResponse<object>.Fail("Project not found or failed to delete."));

        return Ok(ApiResponse<object>.Ok(null!, "Project deleted successfully."));
    }
}
