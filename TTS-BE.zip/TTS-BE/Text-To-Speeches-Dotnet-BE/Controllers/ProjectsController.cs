using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Storage;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ProjectsController : BaseApiController
{
    private readonly IProjectService _projectService;
    private readonly ILogger<ProjectsController> _logger;

    public ProjectsController(IProjectService projectService, ILogger<ProjectsController> logger)
    {
        _projectService = projectService;
        _logger = logger;
    }

    /// <summary>
    /// List all projects for the current user
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ListProjects(CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId == null)
        {
            return Unauthorized(new { success = false, error = "User not authenticated." });
        }

        var projects = await _projectService.ListProjectsAsync(userId.Value, cancellationToken);
        return Ok(new { success = true, data = projects });
    }

    /// <summary>
    /// Get a single project by ID
    /// </summary>
    [HttpGet("{projectId}")]
    public async Task<IActionResult> GetProject(string projectId, CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId == null)
        {
            return Unauthorized(new { success = false, error = "User not authenticated." });
        }

        var project = await _projectService.GetProjectAsync(userId.Value, projectId, cancellationToken);
        if (project == null)
        {
            return NotFound(new { success = false, error = "Project not found." });
        }

        return Ok(new { success = true, data = project });
    }

    /// <summary>
    /// Create a new project
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> CreateProject([FromBody] CreateProjectRequest request, CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId == null)
        {
            return Unauthorized(new { success = false, error = "User not authenticated." });
        }

        try
        {
            var project = await _projectService.CreateProjectAsync(userId.Value, request, cancellationToken);
            return Created($"/api/projects/{project.Id}", new { success = true, data = project });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create project for user {UserId}", userId.Value);
            return StatusCode(500, new { success = false, error = "Failed to create project." });
        }
    }

    /// <summary>
    /// Update an existing project
    /// </summary>
    [HttpPut("{projectId}")]
    public async Task<IActionResult> UpdateProject(string projectId, [FromBody] UpdateProjectRequest request, CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId == null)
        {
            return Unauthorized(new { success = false, error = "User not authenticated." });
        }

        try
        {
            var project = await _projectService.UpdateProjectAsync(userId.Value, projectId, request, cancellationToken);
            if (project == null)
            {
                return NotFound(new { success = false, error = "Project not found." });
            }

            return Ok(new { success = true, data = project });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to update project {ProjectId} for user {UserId}", projectId, userId.Value);
            return StatusCode(500, new { success = false, error = "Failed to update project." });
        }
    }

    /// <summary>
    /// Delete a project
    /// </summary>
    [HttpDelete("{projectId}")]
    public async Task<IActionResult> DeleteProject(string projectId, CancellationToken cancellationToken)
    {
        var userId = GetUserIdFromToken();
        if (userId == null)
        {
            return Unauthorized(new { success = false, error = "User not authenticated." });
        }

        var deleted = await _projectService.DeleteProjectAsync(userId.Value, projectId, cancellationToken);
        if (!deleted)
        {
            return NotFound(new { success = false, error = "Project not found or failed to delete." });
        }

        return Ok(new { success = true, message = "Project deleted successfully." });
    }
}
