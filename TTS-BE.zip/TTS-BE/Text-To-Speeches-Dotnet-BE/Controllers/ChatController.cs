using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Chat;
using Text_To_Speeches_Dotnet_BE.Services.Credits;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Route("api/chat")]
[Authorize]
public sealed class ChatController : BaseApiController
{
    private readonly IAzureOpenAiChatService _chatService;
    private readonly ICreditService _creditService;
    private readonly ILogger<ChatController> _logger;
    private readonly IWebHostEnvironment _environment;

    private const int MaxMessageChars = 2000;
    private const int MaxSystemPromptChars = 500;

    private static readonly string[] InjectionPatterns =
    [
        "ignore previous instructions",
        "ignore all instructions",
        "ignore your instructions",
        "you are now",
        "pretend you are",
        "act as if",
        "jailbreak",
        "developer mode",
        "dan mode",
        "do anything now",
        "bypass",
        "override instructions",
    ];

    public ChatController(
        IAzureOpenAiChatService chatService,
        ICreditService creditService,
        IWebHostEnvironment environment,
        ILogger<ChatController> logger)
    {
        _chatService = chatService;
        _creditService = creditService;
        _environment = environment;
        _logger = logger;
    }

    [HttpPost]
    [EnableRateLimiting("AiLimiter")]
    public async Task<ActionResult<ApiResponse<object>>> Chat([FromBody] ChatRequest request, CancellationToken cancellationToken)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.Message))
                return BadRequest(ApiResponse<object>.Fail("Message is required."));

            if (request.Message.Length > MaxMessageChars)
                return BadRequest(ApiResponse<object>.Fail($"Message exceeds the maximum allowed length of {MaxMessageChars} characters."));

            if (!string.IsNullOrWhiteSpace(request.SystemPrompt) && request.SystemPrompt.Length > MaxSystemPromptChars)
                return BadRequest(ApiResponse<object>.Fail($"System prompt exceeds the maximum allowed length of {MaxSystemPromptChars} characters."));

            var combinedInput = (request.Message + " " + (request.SystemPrompt ?? string.Empty)).ToLowerInvariant();
            if (InjectionPatterns.Any(p => combinedInput.Contains(p, StringComparison.OrdinalIgnoreCase)))
            {
                _logger.LogWarning("Prompt injection attempt detected from user {UserId}", GetUserIdFromToken());
                return BadRequest(ApiResponse<object>.Fail("Invalid request content."));
            }

            var userId = GetUserIdFromToken();
            long chatCost = 0;
            if (userId.HasValue)
            {
                chatCost = await _creditService.CalculateCreditCostAsync("ai-enhance", cancellationToken: cancellationToken);
                var balance = await _creditService.GetBalanceAsync(userId.Value, cancellationToken);
                if (balance < chatCost)
                    return StatusCode(402, ApiResponse<object>.Fail("Insufficient credits.",
                        new { requiredCredits = chatCost, currentBalance = balance } as object));
            }

            var reply = await _chatService.CompleteAsync(request.Message, request.SystemPrompt, cancellationToken);

            if (userId.HasValue)
                await _creditService.DeductCreditsAsync(userId.Value, "ai-enhance", chatCost, "AI chat request", cancellationToken);

            return Ok(ApiResponse<object>.Ok(new { reply }));
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Azure OpenAI configuration/runtime error");
            return StatusCode(StatusCodes.Status500InternalServerError,
                ApiResponse<object>.Fail(_environment.IsDevelopment() ? ex.Message : "Azure OpenAI is not configured."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Azure OpenAI chat error");
            return StatusCode(StatusCodes.Status502BadGateway, ApiResponse<object>.Fail("Failed to generate chat response."));
        }
    }
}
