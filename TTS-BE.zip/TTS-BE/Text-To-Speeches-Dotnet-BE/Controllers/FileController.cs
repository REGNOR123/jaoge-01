using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Storage;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Authorize]
[Route("api/files")]
public sealed class FileController : BaseApiController
{
    private readonly IAzureFileStorageService _storageService;
    private readonly IFileArtifactRepository _fileArtifactRepository;
    private readonly AzureStorageOptions _storageOptions;

    public FileController(
        IAzureFileStorageService storageService,
        IFileArtifactRepository fileArtifactRepository,
        IOptions<AzureStorageOptions> storageOptions)
    {
        _storageService = storageService;
        _fileArtifactRepository = fileArtifactRepository;
        _storageOptions = storageOptions.Value;
    }

    [HttpPost("upload")]
    [RequestSizeLimit(50 * 1024 * 1024)]
    public async Task<IActionResult> Upload([FromForm] UploadFileRequest request, CancellationToken cancellationToken)
    {
        if (request.File is null || request.File.Length == 0)
        {
            return BadRequest(new { success = false, error = "File is required." });
        }

        var userId = GetUserIdFromToken();
        var userFolder = userId?.ToString() ?? "anonymous";
        var feature = string.IsNullOrWhiteSpace(request.Feature) ? "user-upload" : request.Feature.Trim();
        var jobId = string.IsNullOrWhiteSpace(request.JobId) ? Guid.NewGuid().ToString("N") : request.JobId.Trim();

        await using var stream = request.File.OpenReadStream();
        var stored = await _storageService.UploadFileAsync(stream, request.File.FileName, userFolder, jobId, cancellationToken);

        var retention = _storageOptions.RetentionHours > 0 ? _storageOptions.RetentionHours : 24;
        var record = new FileArtifactRecord
        {
            Id = Guid.NewGuid(),
            UserId = userId,
            UserFolder = userFolder,
            JobId = jobId,
            Feature = feature,
            FileName = stored.FileName,
            RelativePath = stored.RelativePath,
            ContentType = request.File.ContentType,
            SizeBytes = request.File.Length,
            DurationMinutes = request.DurationMinutes,
            IsOutput = request.IsOutput,
            CreatedAt = DateTime.UtcNow,
            ExpiresAt = DateTime.UtcNow.AddHours(retention)
        };

        record = await _fileArtifactRepository.UpsertAsync(record, cancellationToken);

        return Ok(new
        {
            success = true,
            data = new
            {
                fileId = record.Id,
                fileName = record.FileName,
                contentType = record.ContentType,
                feature,
                jobId,
                durationMinutes = record.DurationMinutes,
                isOutput = record.IsOutput,
                uploadedAt = record.CreatedAt.ToString("O"),
                expiresAt = record.ExpiresAt.ToString("O"),
                sizeBytes = record.SizeBytes,
                url = stored.Uri,
                relativePath = stored.RelativePath
            }
        });
    }

    [HttpGet("{fileId:guid}")]
    public async Task<IActionResult> Download(Guid fileId, CancellationToken cancellationToken)
    {
        var record = await _fileArtifactRepository.FindByIdAsync(fileId, cancellationToken);
        if (record is null)
        {
            return NotFound(new { success = false, error = "File not found." });
        }

        var currentUserId = GetUserIdFromToken();
        if (record.UserId.HasValue && record.UserId != currentUserId)
        {
            return Forbid();
        }

        var stream = await _storageService.DownloadFileAsync(record.RelativePath, cancellationToken);
        var contentType = await _storageService.GetContentTypeAsync(record.RelativePath, cancellationToken)
            ?? record.ContentType
            ?? "application/octet-stream";

        return File(stream, contentType, record.FileName);
    }

    [HttpDelete("{fileId:guid}")]
    public async Task<IActionResult> Delete(Guid fileId, CancellationToken cancellationToken)
    {
        var record = await _fileArtifactRepository.FindByIdAsync(fileId, cancellationToken);
        if (record is null)
        {
            return NotFound(new { success = false, error = "File not found." });
        }

        var currentUserId = GetUserIdFromToken();
        if (record.UserId.HasValue && record.UserId != currentUserId)
        {
            return Forbid();
        }

        await _storageService.DeleteFileAsync(record.RelativePath, cancellationToken);
        await _fileArtifactRepository.DeleteByIdAsync(record.Id, cancellationToken);

        return Ok(new { success = true, message = "File deleted." });
    }
}
