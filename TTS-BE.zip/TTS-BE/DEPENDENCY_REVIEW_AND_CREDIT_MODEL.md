# Comprehensive Dependency Review & Credit-Based Usage Model

> **Date:** 2026-04-14
> **Platform:** TextToSpeeches.in
> **Stack:** .NET 8.0 (Backend) + React 19 / Vite 6 (Frontend)
> **Hosting:** Azure (East Asia + Southeast Asia regions)

---

## Part 1: Complete Dependency Inventory

### A. Azure Services (8 Services)

| # | Service | Azure Resource | Region | Purpose |
|---|---------|---------------|--------|---------|
| 1 | **Azure App Service** | text-to-speeches-dotnet-be | East Asia | Backend API hosting (.NET 8.0) |
| 2 | **Azure Static Web Apps** | agreeable-river-04bdd3f00 | Global | Frontend hosting (React SPA) |
| 3 | **Azure SQL Database** | text-to-speeches-sql-database | East Asia | Relational data (users, billing, usage, plans) |
| 4 | **Azure Storage (File Share)** | texttospeechesfilestore | East Asia | Audio files, transcripts (24h retention) |
| 5 | **Azure Cognitive Services - Speech** | — | East Asia | Neural TTS, STT, Speech Translation |
| 6 | **Azure Cognitive Services - Translator** | — | East Asia | Language detection, text translation (20+ langs) |
| 7 | **Azure OpenAI** | amit-mm2e902k | Southeast Asia | GPT-5-mini for scripts, chat, transforms |
| 8 | **Azure Functions** | (embedded in SWA) | — | Chat completion proxy (Node.js) |

### B. Third-Party Services (4 Services)

| # | Service | Purpose | Pricing Model |
|---|---------|---------|---------------|
| 9 | **Razorpay** | Payment gateway (INR) | 2% per transaction |
| 10 | **Brevo** | Transactional email (verification) | Free: 300/day; Starter: $9/mo |
| 11 | **Google OAuth 2.0** | User authentication | Free |
| 12 | **Google Gemini** | Language detection (frontend) | Free tier |

### C. Backend Dependencies (NuGet — .NET 8.0)

| Package | Version | Purpose |
|---------|---------|---------|
| Azure.Identity | 1.18.0 | DefaultAzureCredential |
| Azure.Storage.Files.Shares | 12.25.0 | File Share operations |
| Microsoft.CognitiveServices.Speech | 1.43.0 | Speech SDK |
| Microsoft.Data.SqlClient | 6.0.2 | Azure SQL Database |
| NAudio | 2.2.1 | Audio processing |
| Google.Apis.Auth | 1.69.0 | Google token validation |
| Microsoft.AspNetCore.Authentication.JwtBearer | 8.0.14 | JWT auth |
| Swashbuckle.AspNetCore | 6.6.2 | Swagger/OpenAPI docs |

### D. Frontend Dependencies (npm — React 19)

| Package | Version | Purpose |
|---------|---------|---------|
| microsoft-cognitiveservices-speech-sdk | 1.48.0 | Speech SDK (client) |
| @react-oauth/google | 0.13.4 | Google OAuth |
| @google/genai | 1.40.0 | Gemini API |
| react / react-dom | 19.2.4 | UI framework |
| react-router-dom | 7.13.0 | Client-side routing |
| @tanstack/react-table | 8.21.3 | Data tables |
| tailwindcss | 3.4.17 | CSS framework |
| vite | 6.2.0 | Build tool |

---

## Part 2: API Endpoints & Resource Cost Classification

### Feature-to-Service Mapping (12 Features)

| Feature | Endpoint | Azure Services Called | Cost Level |
|---------|----------|---------------------|------------|
| **Create Voice (TTS)** | `POST /api/speech/tts` | Speech (Neural TTS) + File Share | MEDIUM |
| **Transcription** | `POST /api/speech/transcribe` | Speech (STT) + optional Translator + File Share | HIGH |
| **Speech Translation (text)** | `POST /api/speech/translate` | Speech (Translation) + File Share | HIGH |
| **Speech-to-Speech Translation** | `POST /api/speech/translate-speech` | Speech (Translation + TTS per language) + File Share | VERY HIGH |
| **Text Translation** | `POST /api/translator/translate` | Translator | LOW |
| **Language Detection** | `POST /api/translator/detect` | Translator | LOW |
| **Script Generation** | `POST /api/script-generation/{sku}` | Azure OpenAI | MEDIUM |
| **Field Auto-Generate** | `POST /api/script-generation/{sku}/generate-field` | Azure OpenAI | LOW |
| **Script Transform** | `POST /api/script-generation/{sku}/transform` | Azure OpenAI | MEDIUM |
| **AI Chat** | `POST /api/chat` | Azure OpenAI | LOW-MEDIUM |
| **File Upload** | `POST /api/files/upload` | File Share | LOW |
| **File Download** | `GET /api/files/{id}` | File Share | LOW |

### Background Workers

| Worker | File | Interval | Purpose |
|--------|------|----------|---------|
| FileCleanupWorker | `Services/Storage/FileCleanupWorker.cs` | Hourly | Delete expired files (24h retention, batch 500) |
| SubscriptionRenewalWorker | `Services/Payments/SubscriptionRenewalWorker.cs` | Hourly | Expire/renew subscriptions, create invoices |

### Authentication

| Method | Provider | Library |
|--------|----------|---------|
| Email/Password | Custom (bcrypt hash) | Microsoft.IdentityModel.Tokens |
| Google OAuth | Google Sign-In | Google.Apis.Auth + @react-oauth/google |
| JWT Bearer | Self-issued (HMAC-SHA256, 7d expiry) | JwtBearer middleware |

---

## Part 3: Azure Service Tier Analysis & Cost Projections

### 3.1 Azure Cognitive Services — Speech (74-77% of total costs)

**Current tier:** S0 (Standard) pay-as-you-go

| Component | Unit Price (USD) | Unit |
|-----------|-----------------|------|
| Neural TTS | $16.00 | per 1M characters |
| Speech-to-Text (real-time) | $1.00 | per audio hour |
| Speech Translation | $2.50 | per audio hour |

**Projected costs by scale:**

| Scale | TTS Chars/mo | STT Hours/mo | Translation Hours/mo | **Monthly Cost** |
|-------|-------------|-------------|---------------------|-----------------|
| 100 users | ~5M | ~10 | ~2 | **$95** |
| 1K users | ~50M | ~100 | ~20 | **$950** |
| 10K users | ~500M | ~1,000 | ~200 | **$9,500** |
| 100K users | ~5B | ~10,000 | ~2,000 | **$95,000** |

**Optimal tier strategy:**
- **0–10K users:** Stay on S0 pay-as-you-go (no commitment required)
- **10K+ users:** Negotiate 1-year commitment tier (20-40% discount = $1,900-$3,800/mo savings)
- **100K+ users:** Custom enterprise agreement (potential $19K-$38K/mo savings)

### 3.2 Azure Cognitive Services — Translator

**Current tier:** S1 ($10/1M characters)

| Scale | Chars/mo | **Monthly Cost** |
|-------|---------|-----------------|
| 100 users | ~2M | **$0** (free tier: 2M/mo) |
| 1K users | ~20M | **$200** |
| 10K users | ~200M | **$2,000** |
| 100K users | ~2B | **$20,000** |

**Optimal tier strategy:**
- **0–100 users:** Free tier (2M chars/month)
- **1K+ users:** S1 pay-as-you-go
- **100K+ users:** Volume pricing negotiation

### 3.3 Azure OpenAI (GPT-5-mini)

**Current tier:** S0 pay-as-you-go, Southeast Asia

| Call Type | Avg Tokens/call | Est. Cost/call |
|-----------|----------------|----------------|
| Chat | ~600 | ~$0.00045 |
| Script Generation | ~1,800 | ~$0.00135 |
| Field Generate | ~500 | ~$0.000375 |
| Transform | ~2,000 | ~$0.0015 |

| Scale | API Calls/mo | **Monthly Cost** |
|-------|-------------|-----------------|
| 100 users | ~2,000 | **$2** |
| 1K users | ~20,000 | **$15** |
| 10K users | ~200,000 | **$150** |
| 100K users | ~2,000,000 | **$1,500** |

**Optimal tier strategy:** GPT-5-mini is already cost-optimal (<2% of total). Consider provisioned throughput at 100K+ for latency only.

### 3.4 Azure SQL Database

| Scale | Recommended Tier | **Monthly Cost** |
|-------|-----------------|-----------------|
| 100 users | S1 (20 DTUs) | **$15** |
| 1K users | S2 (50 DTUs) | **$75** |
| 10K users | GP_Gen5_2 (vCore) | **$350** |
| 100K users | GP_Gen5_4 (vCore) | **$700** |

**Optimal tier strategy:** Migrate from DTU-based to vCore-based General Purpose at 10K+.

### 3.5 Azure Storage — File Share (Premium)

| Scale | Peak Storage (24h window) | **Monthly Cost** |
|-------|--------------------------|-----------------|
| 100 users | ~5 GB | **$17** (100 GiB min) |
| 1K users | ~50 GB | **$17** |
| 10K users | ~200 GB | **$34** |
| 100K users | ~2 TB | **$340** |

**Optimal tier strategy:** At 10K+, evaluate Blob Storage Hot tier ($0.018/GB) — 10x cheaper than Premium File Share.

### 3.6 Azure App Service

| Scale | Recommended Tier | Instances | **Monthly Cost** |
|-------|-----------------|-----------|-----------------|
| 100 users | B1 (Basic) | 1 | **$13** |
| 1K users | S1 (Standard) | 1 | **$73** |
| 10K users | P1v3 (Premium) | 2 | **$276** |
| 100K users | P2v3 (Premium) | 4 | **$1,100** |

### 3.7 Other Services

| Service | All Scales | Notes |
|---------|-----------|-------|
| Azure Static Web Apps | $0–$9/mo | Free tier sufficient; Standard for SLA |
| Brevo | $0–$18/mo | Free up to 300 emails/day |
| Razorpay | 2% of revenue | Scales with revenue |
| Google OAuth / Gemini | $0 | Free tier |

### 3.8 Total Platform Cost Summary

| Scale | Speech | Translator | OpenAI | SQL | Storage | App Svc | Others | **Total/mo** |
|-------|--------|-----------|--------|-----|---------|---------|--------|------------|
| **100 users** | $95 | $0 | $2 | $15 | $17 | $13 | $5 | **$147** |
| **1K users** | $950 | $200 | $15 | $75 | $17 | $73 | $50 | **$1,380** |
| **10K users** | $9,500 | $2,000 | $150 | $350 | $34 | $276 | $500 | **$12,810** |
| **100K users** | $95,000 | $20,000 | $1,500 | $700 | $340 | $1,100 | $5,000 | **$123,640** |

> **Key Insight:** Azure Speech constitutes **74-77% of total costs** at every scale point. The credit system must be weighted heavily toward speech operations.

---

## Part 4: Current Plan Structure (Verified from Database)

*Source: `DatabaseInitializer.cs` lines 302-324 (plans), 436-458 (usage_plans)*

### Pricing

| Plan ID | Name | Monthly (INR) | Yearly (INR) | Purchasable |
|---------|------|--------------|-------------|-------------|
| free-starter | Free Starter | 0 | 0 | No |
| creator | Creator | 249 | 2,508 | Yes |
| pro | Pro | 699 | 6,996 | Yes |
| business | Business | 1,999 | 19,992 | Yes |
| enterprise | Enterprise | Custom | Custom | No |

### Usage Quotas

| Plan | Proc. Min | Max File Min | AI Enhance | Auto Gen | Voice Previews | Concurrent | Characters | Storage MB |
|------|----------|-------------|-----------|---------|:-------------:|------------|-----------|-----------|
| Free Starter | 15 | 10 | 25 | 25 | 10 | 1 | 5,000 | 100 |
| Creator | 150 | 20 | 200 | 200 | 50 | 2 | 60,000 | 1,024 |
| Pro | 750 | 60 | 1,500 | 1,500 | 200 | 5 | 500,000 | 5,120 |
| Business | 4,000 | 120 | 8,000 | 8,000 | 1,000 | 10 | 2,000,000 | 25,600 |
| Enterprise | 100,000 | 10,000 | 100,000 | 100,000 | 100,000 | 100 | 100,000,000 | 102,400 |

### Guest Limits (24h window)
Characters: 1,000 | Voice Minutes: 5 | AI Enhancements: 5 | Auto-Generate: 5 | Voice Previews: 5

### Current Plan Issues

| Issue | Status |
|-------|--------|
| **Business margin too thin (~24%)** | **RESOLVED** — Price increased to ₹1,999 (margin ~38%) |
| **Creator-to-Pro jump is unbalanced** | **RESOLVED** — 2.8x price gives 6x resources (compelling upgrade) |
| **AI quotas over-generous in higher tiers** | **RESOLVED** — Business AI enhancements/auto-gen reduced from 12K to 8K |
| **Storage tracking adds complexity without revenue** | Unchanged — 24h retention keeps storage cost negligible |

---

## Part 5: Credit-Based Usage Model Design

### 5.1 Design Principles

1. **1 base credit = ~₹0.01 of Azure cost** — transparent, auditable foundation
2. **4x markup** applied for user-facing credits (covers infra, dev, support, profit)
3. **Universal currency** — unifies chars, minutes, enhancements into one number
4. **Additive** — credits layer on top of existing per-dimension tracking (safety rails remain)

### 5.2 Azure Cost Per Unit

| Resource | Unit | Azure Cost (USD) | Azure Cost (INR @ ₹83) | Base Credits |
|----------|------|-----------------|----------------------|-------------|
| Neural TTS | 1,000 chars | $0.016 | ₹1.33 | 133 |
| Speech-to-Text | 1 minute | $0.0167 | ₹1.39 | 139 |
| Speech Translation | 1 minute | $0.0417 | ₹3.46 | 346 |
| Text Translation | 1,000 chars | $0.01 | ₹0.83 | 83 |
| Azure OpenAI (avg call) | 1 call | $0.001 | ₹0.08 | 8 |
| File Storage | 1 MB/day | $0.000006 | ₹0.0005 | ~0 |

### 5.3 User-Facing Credit Schedule

| Feature | Unit | Credits/Unit | Rationale |
|---------|------|:----------:|-----------|
| **Create Voice (TTS)** | 1,000 characters | **5** | Core feature, highest volume |
| **Transcription (STT)** | 1 minute audio | **6** | ~1.04x TTS per-minute equivalent |
| **Speech Translation (text)** | 1 minute audio | **14** | 2.5x STT cost (translation premium) |
| **Speech-to-Speech Translation** | 1 min + per target | **14 + 5/lang** | Compound: translation + TTS per output |
| **Text Translation** | 1,000 characters | **3** | Cheapest Azure API |
| **Language Detection** | 1 request | **1** | Near-zero cost, nominal |
| **Script Generation** | 1 generation | **4** | ~1,800 tokens avg |
| **AI Chat / Enhancement** | 1 request | **2** | ~600 tokens avg |
| **Field Auto-Generate** | 1 field | **2** | ~500 tokens avg |
| **Script Transform** | 1 transform | **3** | ~2,000 tokens avg |
| **Voice Preview** | 1 preview | **1** | Fixed cost per preview (short text ~100 chars) |
| **File Storage** | 100 MB/day | **1** | Negligible, nominal tracking |

### 5.4 Credit Calculation Formula

Maps directly to existing `usage_records` columns (`feature`, `characters_used`, `minutes_used`, `enhancement_used`):

```csharp
public static int CalculateCredits(string feature, int characters, double minutes, int enhancements) =>
    feature switch
    {
        "create-voice"     => (int)Math.Ceiling(characters / 1000.0) * 5,
        "transcribe"       => (int)Math.Ceiling(minutes) * 6,
        "translate-text"   => (int)Math.Ceiling(characters / 1000.0) * 14,
        "translate-dub"    => (int)Math.Ceiling(minutes) * 14 + (int)Math.Ceiling(characters / 1000.0) * 5,
        "text-translate"   => (int)Math.Ceiling(characters / 1000.0) * 3,
        "detect-language"  => 1,
        "script-generate"  => enhancements * 4,
        "ai-enhance"       => enhancements * 2,
        "auto-generate"    => enhancements * 2,
        "script-transform" => enhancements * 3,
        _                  => 0
    };
```

### 5.5 Credit Allocation per Plan

| Plan | Max Usage Profile (credits) | Credit Allocation | Price (INR) | ₹/Credit | Margin |
|------|:-------------------------:|:-----------------:|:-----------:|:--------:|:------:|
| **Free Starter** | 215 | **200** | 0 | — | — |
| **Creator** | 2,170 | **2,500** | 249 | ₹0.10 | ~75% |
| **Pro** | 13,100 | **15,000** | 699 | ₹0.047 | ~53% |
| **Business** | 73,500 | **100,000** | 1,999 | ₹0.020 | ~38% |
| **Enterprise** | Custom | **500,000+** | Custom | Negotiated | ~30% |

### 5.6 Active Plan Structure

| Dimension | Free Starter | Creator | Pro | Business | Enterprise |
|-----------|:-----------:|:-------:|:---:|:--------:|:----------:|
| **Monthly Credits** | 200 | 2,500 | 15,000 | 100,000 | Custom |
| **Price (INR/mo)** | 0 | 249 | 699 | 1,999 | Custom |
| **Yearly (INR/yr)** | 0 | 2,508 | 6,996 | 19,992 | Custom |
| Characters | 5,000 | 60,000 | 500,000 | 2,000,000 | Unlimited |
| Processing Min | 15 | 150 | 750 | 4,000 | Unlimited |
| Max File Min | 10 | 20 | 60 | 120 | 480 |
| AI Enhancements | 25 | 200 | 1,500 | 8,000 | Unlimited |
| Auto-Generate | 25 | 200 | 1,500 | 8,000 | Unlimited |
| Voice Previews | 10 | 50 | 200 | 1,000 | Unlimited |
| Concurrent Jobs | 1 | 2 | 5 | 10 | 50 |
| Storage (MB) | 100 | 1,024 | 5,120 | 25,600 | 102,400 |

**Changes applied from previous plans:**
- **Creator:** ₹199 → ₹249 (+25%), quotas adjusted (processing min 120→150, chars 50K→60K, AI 300→200)
- **Pro:** ₹499 → ₹699 (+40%), quotas adjusted (processing min 600→750, chars 300K→500K, AI 2K→1.5K, concurrent 4→5)
- **Business:** ₹1,299 → ₹1,999 (+54%), margin improved from ~24% to ~38% (processing min 3K→4K, chars 1.5M→2M, AI 12K→8K)
- **Per-dimension limits remain as safety rails** alongside the credit system

### 5.7 Add-On Credit Packs

| Pack | Credits | Price (INR) | ₹/Credit | Margin |
|------|:-------:|:-----------:|:--------:|:------:|
| Small | 500 | 79 | ₹0.158 | ~84% |
| Medium | 2,000 | 249 | ₹0.125 | ~80% |
| Large | 10,000 | 999 | ₹0.100 | ~75% |

> Add-on packs carry **higher per-credit cost** than subscriptions to incentivize plan upgrades.

---

## Part 6: Implementation Architecture

### 6.1 New Database Tables

**`credit_ledger`** — immutable transaction log:

```sql
CREATE TABLE dbo.credit_ledger (
    id              UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
    user_id         INT NOT NULL,
    usage_record_id UNIQUEIDENTIFIER NULL,
    credit_delta    INT NOT NULL,
    balance_after   BIGINT NOT NULL,
    source          NVARCHAR(50) NOT NULL,  -- plan_allocation | consumption | addon_purchase | refund
    feature         NVARCHAR(50) NULL,
    description     NVARCHAR(200) NULL,
    created_at      DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_credit_ledger_users FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE CASCADE
);
```

**`credit_pricing`** — admin-configurable rates with version history:

```sql
CREATE TABLE dbo.credit_pricing (
    feature         NVARCHAR(50) NOT NULL,
    unit_type       NVARCHAR(20) NOT NULL,
    credits_per_unit INT NOT NULL,
    effective_from  DATETIME2 NOT NULL,
    effective_to    DATETIME2 NULL,
    PRIMARY KEY (feature, effective_from)
);
```

### 6.2 Service Layer

**New:** `Services/Credits/CreditService.cs` implementing `ICreditService`:
- `CalculateCreditsForUsage()` — pure calculation from feature + usage dimensions
- `DeductCreditsAsync()` — atomic ledger write with balance update
- `GetBalanceAsync()` — current credit balance
- `AllocateCreditsAsync()` — monthly allocation or add-on purchase

### 6.3 Integration Points

| Integration Point | File | Change |
|-------------------|------|--------|
| Usage gate | `UsageGateService.cs` | Add credit balance check after per-dimension checks |
| Usage tracking | `ArtifactTrackingService.cs` | Call `DeductCreditsAsync` after recording usage |
| Renewal | `SubscriptionRenewalWorker.cs` | Call `AllocateCreditsAsync` on renewal |
| API | `UsageController.cs` | Add `GET /api/credits/balance`; include credits in usage response |
| DB migration | `DatabaseInitializer.cs` | Add credit tables + updated plan seeds |

### 6.4 Implementation Phases

| Phase | Scope | User-Visible |
|:-----:|-------|:------------:|
| **1** | Credit tables, `CreditService`, ledger writes | No |
| **2** | Credit check in `UsageGateService` (shadow mode) | No |
| **3** | Credit balance on dashboard, pre-operation estimates | Yes |
| **4** | Plan price adjustments, updated credit allocations | Yes |
| **5** | Add-on credit pack purchase via Razorpay | Yes |

---

## Part 7: Risk Analysis & Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| **Speech Translation cost bomb** | 10-min speech-to-speech × 5 langs = ~264 credits (exceeds Free tier) | `max_file_minutes` cap + credit balance = double gate |
| **Credit opacity** | Users confused by abstract credits | Show credit cost pre-operation; publish rate card page |
| **Price increase backlash** | Existing users react negatively | Grandfather current subscribers 3-6 months |
| **INR/USD exchange risk** | 10% INR depreciation = 10% margin loss | `credit_pricing.effective_from/to` enables quarterly rate reviews |
| **OpenAI cost variance** | Token usage varies per request | Fixed credits/request (not per-token); `max_tokens=2000` caps worst case |

---

## Part 8: Key Files Reference

| File | Path | Role in Credit System |
|------|------|----------------------|
| UsageGateService | `Services/Usage/UsageGateService.cs` | Add credit balance check |
| UsageRepository | `Services/Usage/UsageRepository.cs` | Extend for credit queries |
| DatabaseInitializer | `Services/Database/DatabaseInitializer.cs` | Credit tables migration + plan seeds |
| ArtifactTrackingService | `Services/Shared/ArtifactTrackingService.cs` | Hook credit deduction |
| SubscriptionRenewalWorker | `Services/Payments/SubscriptionRenewalWorker.cs` | Credit allocation on renewal |
| UsageController | `Controllers/UsageController.cs` | Expose credit balance endpoint |
| FeatureNames | `Constants/FeatureNames.cs` | Feature name constants |
| AppOptions | `Configuration/AppOptions.cs` | Add CreditOptions |
