# Text-To-Speeches-Dotnet-BE

## Local Configuration

Use environment variables or `dotnet user-secrets`. Do not commit real secrets.

### 1. Initialize user-secrets

```powershell
cd Text-To-Speeches-Dotnet-BE
dotnet user-secrets init
```

### 2. Set values (same keys as Node project)

```powershell
dotnet user-secrets set "PORT" "5127"
dotnet user-secrets set "NODE_ENV" "development"
dotnet user-secrets set "DB_SERVER" "your-server.database.windows.net"
dotnet user-secrets set "DB_PORT" "1433"
dotnet user-secrets set "DB_USER" "your-db-user"
dotnet user-secrets set "DB_PASSWORD" "your-db-password"
dotnet user-secrets set "DB_NAME" "your-db-name"
dotnet user-secrets set "DB_ENCRYPT" "true"
dotnet user-secrets set "DB_TRUST_SERVER_CERTIFICATE" "false"
dotnet user-secrets set "JWT_SECRET" "your-jwt-secret"
dotnet user-secrets set "JWT_EXPIRES_IN" "7d"
dotnet user-secrets set "GOOGLE_CLIENT_ID" "your-google-client-id"
dotnet user-secrets set "CLIENT_URL" "http://localhost:3000"
dotnet user-secrets set "BREVO_API_KEY" "your-brevo-api-key"
dotnet user-secrets set "BREVO_SENDER_EMAIL" "no-reply@example.com"
dotnet user-secrets set "BREVO_SENDER_NAME" "TextToSpeeches"
dotnet user-secrets set "EMAIL_VERIFICATION_TOKEN_EXPIRES_HOURS" "24"
dotnet user-secrets set "SPEECH_KEY" "your-speech-key"
dotnet user-secrets set "SPEECH_REGION" "eastasia"
dotnet user-secrets set "SPEECH_ENDPOINT" "https://eastasia.api.cognitive.microsoft.com/"
```

### 3. Run API

```powershell
dotnet run --project Text-To-Speeches-Dotnet-BE
```

Also see `Text-To-Speeches-Dotnet-BE/.env.example` for the full key list.
