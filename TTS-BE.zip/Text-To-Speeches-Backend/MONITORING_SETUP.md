# Abuse Monitoring & Alerting Setup

## Azure Application Insights Queries

### Query 1: Real-time Bot Detection Events
```kusto
traces
| where message contains "bot" or message contains "suspicious"
| extend ip = extract(@"IP (\d+\.\d+\.\d+\.\d+)", 1, message)
| summarize 
    DetectionCount = count(),
    LastSeen = max(timestamp),
    Messages = make_set(message)
    by ip
| sort by DetectionCount desc
| limit 20
```

### Query 2: Blocked IPs Timeline
```kusto
traces
| where message contains "Blocked"
| extend ip = extract(@"(\d+\.\d+\.\d+\.\d+)", 1, message)
| make-series BlockCount = count() default 0 on timestamp from ago(24h) to now() step 1h by ip
| render timechart
```

### Query 3: Suspicious Request Patterns
```kusto
requests
| where isnotempty(customDimensions.ip)
| where customDimensions.reason contains "bot" or customDimensions.reason contains "suspicious"
| summarize 
    Count = count(),
    FailureRate = (todouble(sum(tolong(resultCode) >= 400)) / count()) * 100
    by customDimensions.ip, client_Browser
| where FailureRate > 50
| sort by Count desc
```

### Query 4: Rate Limit Violations (per IP)
```kusto
requests
| where responseCode == 429  // Too Many Requests
| extend ip = client_IP
| summarize 
    ViolationCount = count(),
    AvgResponseTime = avg(duration),
    Endpoints = make_set(name)
    by ip
| sort by ViolationCount desc
| limit 25
```

### Query 5: Failed Authentication Attempts (Brute Force Detection)
```kusto
requests
| where name contains "Login" or name contains "Signup"
| where responseCode == 401 or responseCode == 403
| extend ip = client_IP
| summarize 
    FailedAttempts = count(),
    TimeRange = (max(timestamp) - min(timestamp)),
    UniqueUserAgents = dcount(client_Browser)
    by ip
| where FailedAttempts >= 5
| sort by FailedAttempts desc
```

### Query 6: Endpoint Abuse by Path
```kusto
requests
| extend ip = client_IP
| summarize 
    RequestCount = count(),
    AvgResponseTime = avg(duration),
    SuccessRate = (todouble(sum(tolong(resultCode) < 400)) / count()) * 100
    by name, ip
| where RequestCount > 100
| sort by RequestCount desc
```

### Query 7: Distributed Attack Detection (Same Path, Multiple IPs)
```kusto
requests
| where name contains "tts" or name contains "speech"  // Target endpoint
| extend ip = client_IP
| summarize IpCount = dcount(ip), RequestCount = count() by name, bin(timestamp, 1m)
| where IpCount >= 10  // 10+ different IPs hitting same endpoint in 1 minute
| sort by timestamp desc
```

### Query 8: User-Agent Anomalies
```kusto
requests
| extend ua = tostring(client_Browser), ip = client_IP
| where ua contains "curl" or ua contains "wget" or ua contains "python" or ua contains "bot"
| summarize 
    Count = count(),
    IPs = make_set(ip),
    Endpoints = make_set(name)
    by ua
| sort by Count desc
```

## Alert Rules Setup

### Alert 1: Sudden Rate Limit Spike
```
Metric: requests with responseCode 429
Condition: Count > 50 in last 5 minutes
Severity: High
Action: Email + PagerDuty
```

In Azure Portal:
1. Application Insights → Alerts → New Alert Rule
2. Condition: 
   ```
   requests
   | where responseCode == 429
   | summarize count()
   ```
3. Threshold: > 50
4. Evaluation Period: 5 minutes

### Alert 2: Multiple Failed Logins from Single IP
```
Metric: Failed auth attempts
Condition: >= 10 failures in 1 minute from single IP
Severity: High
Action: Block IP + Alert
```

Implementation:
```kusto
requests
| where name contains "Login" and (responseCode == 401 or responseCode == 403)
| extend ip = client_IP
| summarize count() by ip
| where count_ >= 10
```

### Alert 3: Bot Detection Rate > 20/min
```
Metric: Bot detections per minute
Condition: > 20 in last minute
Severity: Medium
Action: Email + Increase rate limiting
```

## Create Azure Dashboard

### Step 1: Create New Dashboard
1. Azure Portal → Dashboards → + New dashboard
2. Name: "API Security Monitoring"

### Step 2: Add Query Tiles
1. Add → Query → Paste each query above
2. Pin to dashboard
3. Set refresh: 5 minutes

### Step 3: Example Dashboard Layout
```
┌─────────────────────────────────────────────┐
│  Real-time Bot Detections (last 24h)        │
│  [Line Chart: Detection trends]             │
├─────────────────────────────────────────────┤
│  Top Blocked IPs          │  Rate Limit Hits  │
│  [Table: IPs]             │  [Gauge: Count]   │
├─────────────────────────────────────────────┤
│  Failed Auth Attempts     │  User Agents      │
│  [Heatmap: By hour]       │  [Pie: Types]     │
└─────────────────────────────────────────────┘
```

## Automated Response Actions

### Action 1: Auto-block on Rate Limit Spike
Create Azure Function:
```csharp
public static async Task Run(
    [QueueTrigger("bot-detections")] BotEvent botEvent,
    IAsyncCollector<BlockedIpRecord> blockQueue,
    ILogger log)
{
    log.LogWarning($"Blocking IP {botEvent.IpAddress}");
    
    await blockQueue.AddAsync(new BlockedIpRecord
    {
        IpAddress = botEvent.IpAddress,
        BlockedUntil = DateTime.UtcNow.AddHours(1),
        Reason = botEvent.DetectionReason
    });
}
```

### Action 2: Escalate Alerts
```
Severity Matrix:
- 1 bot detected: Log only
- 5+ bots from same IP/1min: Block 1 hour + Warn
- 20+ bots from multiple IPs/1min: Block 24 hours + Alert team
- 100+ requests/1min: Trigger DDoS mitigation
```

## Weekly Abuse Report

### Template Report (Send Every Monday)
```
SECURITY REPORT: Week of [DATE]

📊 STATISTICS
- Total API Requests: [X]
- Blocked Requests: [Y] ([Z]%)
- Bot Detections: [A]
- Failed Auth: [B]

🚨 INCIDENTS
1. [Time]: Bot network from [Region] blocked
2. [Time]: Brute force attempt on login endpoint
3. [Time]: Distributed rate limit attack

🔒 TOP THREATS (Last 7 days)
1. [IP]: [Reason] - [Action taken]
2. [IP]: [Reason] - [Action taken]

✅ ACTIONS TAKEN
- Blocked [X] IPs
- Updated bot patterns (+[Y] new)
- Increased rate limits on [Endpoint]

📈 TRENDS
- Bot attacks: [Up/Down] X%
- Rate limit violations: [Up/Down] X%
- Failed logins: [Up/Down] X%
```

## Log Aggregation Setup

### Send Logs to Azure Log Analytics
In Program.cs:
```csharp
builder.Logging.AddApplicationInsights();
builder.Logging.AddApplicationInsightsWebJobs();

// In appsettings.json
"ApplicationInsights": {
  "InstrumentationKey": "[YOUR_KEY]",
  "LogLevel": {
    "BotDetectionMiddleware": "Warning",
    "IpBlocklistMiddleware": "Warning",
    "UserBanMiddleware": "Warning"
  }
}
```

## External Integration

### Integrate with IP Reputation API (Optional)

```csharp
// In BotDetectionMiddleware.cs
private async Task<int> CheckIpReputationAsync(string ip)
{
    var client = new HttpClient();
    var response = await client.GetAsync($"https://api.abuseipdb.com/api/v2/check?ip={ip}");
    var data = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
    return data.RootElement.GetProperty("data")
        .GetProperty("abuseConfidenceScore").GetInt32();
}
```

### Slack Integration
```csharp
// In Alert rule, add Webhook action
await client.PostAsync(slackWebhook, new StringContent(
    JsonConvert.SerializeObject(new 
    { 
        text = $"🚨 High bot activity detected: {count} attempts from {ip}"
    })
));
```

## Compliance & Privacy

✅ **GDPR Compliant:**
- IP addresses logged with retention policy (90 days)
- User data not exposed in bot logs
- Logs include consent notice

✅ **CCPA Compliant:**
- Users can request IP log deletion
- Transient cache (not persisted long-term)
- Legitimate interest documented

## Testing Alerts

### Test Alert 1: Generate 429 Responses
```bash
for i in {1..100}; do 
  curl -s "https://api.yourdomain.com/api/health" &
done
wait
```

### Test Alert 2: Simulate Bot Activity
```bash
for i in {1..10}; do 
  curl -H "User-Agent: curl/7.64.1" \
       "https://api.yourdomain.com/api/speech/tts" &
done
wait
```

## Performance Baseline

Expected metrics after setup:
- False positive rate: 1-3%
- Detection latency: <10ms per request
- Alert delivery: <1 minute
- Dashboard query: <5 seconds

---

**Status:** Ready to deploy ✅
**Time to implement:** 30-45 minutes
**Maintenance:** Review alerts weekly
