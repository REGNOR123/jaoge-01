using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using Text_To_Speeches_Dotnet_BE.Configuration;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Credits;
using Text_To_Speeches_Dotnet_BE.Services.Database;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Authorize]
[Route("api/payment")]
public sealed class PaymentController : BaseApiController
{
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ICreditService _creditService;
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly RazorpayOptions _razorpayOptions;
    private readonly ILogger<PaymentController> _logger;

    public PaymentController(
        ISqlConnectionFactory connectionFactory,
        ICreditService creditService,
        IHttpClientFactory httpClientFactory,
        IOptions<RazorpayOptions> razorpayOptions,
        ILogger<PaymentController> logger)
    {
        _connectionFactory = connectionFactory;
        _creditService = creditService;
        _httpClientFactory = httpClientFactory;
        _razorpayOptions = razorpayOptions.Value;
        _logger = logger;
    }

    [HttpPost("create-order")]
    [EnableRateLimiting("PaymentLimiter")]
    public async Task<ActionResult<ApiResponse<object>>> CreateOrder([FromBody] CreateOrderRequest request, CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();

            var plan = await FetchPlanAsync(request.PlanName, ct);
            if (plan is null)
                return BadRequest(ApiResponse<object>.Fail("Unknown plan."));

            // Velocity check: block if user created 3+ orders in the last 5 minutes
            await using var velocityConn = _connectionFactory.CreateConnection();
            await velocityConn.OpenWithRetryAsync(ct);
            await using var velocityCmd = new SqlCommand("""
                SELECT COUNT(*) FROM dbo.payment_orders
                WHERE user_id = @userId AND created_at >= DATEADD(MINUTE, -5, SYSUTCDATETIME())
                """, velocityConn);
            velocityCmd.Parameters.AddWithValue("@userId", userId);
            var recentOrders = (int)(await velocityCmd.ExecuteScalarAsync(ct))!;
            if (recentOrders >= 3)
            {
                _logger.LogWarning("Payment velocity limit exceeded for user {UserId}: {Count} orders in 5 min", userId, recentOrders);
                return StatusCode(StatusCodes.Status429TooManyRequests,
                    ApiResponse<object>.Fail("Too many payment attempts. Please wait a few minutes before trying again."));
            }

            var currency = string.IsNullOrWhiteSpace(request.Currency) ? "INR" : request.Currency.ToUpperInvariant();
            if (currency != "INR" && currency != "USD")
                return BadRequest(ApiResponse<object>.Fail("Unsupported currency. Use INR or USD."));

            int amountSmallestUnit;
            if (currency == "USD")
            {
                var amountUsd = (decimal)(request.BillingCycle == "annual" ? plan.AnnualUsd : plan.MonthlyUsd);
                amountSmallestUnit = (int)(amountUsd * 100); // cents
            }
            else
            {
                var amountInr = (decimal)(request.BillingCycle == "annual" ? plan.InrAnnual : plan.InrMonthly);
                amountSmallestUnit = (int)(amountInr * 100); // paise
            }

            var receipt = $"rcpt_{userId}_{DateTimeOffset.UtcNow.ToUnixTimeSeconds()}";

            var client = _httpClientFactory.CreateClient("razorpay");
            var credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_razorpayOptions.KeyId}:{_razorpayOptions.KeySecret}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);

            var payload = new { amount = amountSmallestUnit, currency, receipt };
            var response = await client.PostAsJsonAsync("orders", payload, ct);

            if (!response.IsSuccessStatusCode)
            {
                var errorBody = await response.Content.ReadAsStringAsync(ct);
                _logger.LogError("Razorpay order creation failed: {Error}", errorBody);
                return StatusCode(StatusCodes.Status502BadGateway, ApiResponse<object>.Fail("Failed to create payment order. Please try again."));
            }

            var json = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken: ct);
            var razorpayOrderId = json.GetProperty("id").GetString()!;

            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);
            await using var cmd = new SqlCommand("""
                INSERT INTO dbo.payment_orders
                    (user_id, razorpay_order_id, plan_name, plan_display_name, amount_inr, credits_granted, status, currency)
                VALUES (@userId, @orderId, @planName, @planDisplay, @amount, @credits, 'created', @currency)
                """, connection);
            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@orderId", razorpayOrderId);
            cmd.Parameters.AddWithValue("@planName", request.PlanName.ToLowerInvariant());
            cmd.Parameters.AddWithValue("@planDisplay", plan.DisplayName);
            cmd.Parameters.AddWithValue("@amount", (decimal)(amountSmallestUnit / 100));
            cmd.Parameters.AddWithValue("@credits", plan.Credits);
            cmd.Parameters.AddWithValue("@currency", currency);
            await cmd.ExecuteNonQueryAsync(ct);

            return Ok(ApiResponse<object>.Ok(new { orderId = razorpayOrderId, amountSmallestUnit, currency }));
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(ApiResponse<object>.Fail("Authentication required."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating payment order");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Failed to create order."));
        }
    }

    [HttpPost("verify")]
    [EnableRateLimiting("PaymentLimiter")]
    public async Task<ActionResult<ApiResponse<object>>> VerifyPayment([FromBody] VerifyPaymentRequest request, CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();

            var sigPayload = $"{request.RazorpayOrderId}|{request.RazorpayPaymentId}";
            using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(_razorpayOptions.KeySecret));
            var computedHash = Convert.ToHexString(hmac.ComputeHash(Encoding.UTF8.GetBytes(sigPayload))).ToLowerInvariant();

            if (computedHash != request.RazorpaySignature.ToLowerInvariant())
                return BadRequest(ApiResponse<object>.Fail("Payment signature verification failed."));

            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);

            await using var selectCmd = new SqlCommand("""
                SELECT user_id, plan_name, plan_display_name, credits_granted, status
                FROM dbo.payment_orders
                WHERE razorpay_order_id = @orderId
                """, connection);
            selectCmd.Parameters.AddWithValue("@orderId", request.RazorpayOrderId);

            await using var reader = await selectCmd.ExecuteReaderAsync(ct);
            if (!await reader.ReadAsync(ct))
                return NotFound(ApiResponse<object>.Fail("Order not found."));

            var orderUserId = reader.GetInt32(0);
            var planName    = reader.GetString(1);
            var planDisplay = reader.GetString(2);
            var credits     = reader.GetInt64(3);
            var status      = reader.GetString(4);
            await reader.CloseAsync();

            if (orderUserId != userId)
                return Unauthorized(ApiResponse<object>.Fail("Order does not belong to this account."));

            if (status == "paid")
            {
                var bal = await _creditService.GetBalanceAsync(userId, ct);
                return Ok(ApiResponse<object>.Ok(new { newBalance = bal, creditsGranted = credits, planName }));
            }

            await using var tx = (SqlTransaction)await connection.BeginTransactionAsync(ct);
            try
            {
                await using var updateOrder = new SqlCommand("""
                    UPDATE dbo.payment_orders
                    SET status = 'paid', razorpay_payment_id = @paymentId, paid_at = SYSUTCDATETIME()
                    WHERE razorpay_order_id = @orderId
                    """, connection, tx);
                updateOrder.Parameters.AddWithValue("@paymentId", request.RazorpayPaymentId);
                updateOrder.Parameters.AddWithValue("@orderId", request.RazorpayOrderId);
                await updateOrder.ExecuteNonQueryAsync(ct);

                await using var updatePlan = new SqlCommand("""
                    UPDATE dbo.users SET current_plan = @planName WHERE id = @userId
                    """, connection, tx);
                updatePlan.Parameters.AddWithValue("@planName", planName);
                updatePlan.Parameters.AddWithValue("@userId", userId);
                await updatePlan.ExecuteNonQueryAsync(ct);

                await tx.CommitAsync(ct);
            }
            catch
            {
                await tx.RollbackAsync(ct);
                throw;
            }

            await _creditService.AllocateCreditsAsync(userId, credits, "payment", $"{planDisplay} plan — {credits} credits", ct);

            var newBalance = await _creditService.GetBalanceAsync(userId, ct);
            return Ok(ApiResponse<object>.Ok(new { newBalance, creditsGranted = credits, planName }));
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(ApiResponse<object>.Fail("Authentication required."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error verifying payment");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Payment verification failed. Please contact support."));
        }
    }

    [HttpGet("summary")]
    [EnableRateLimiting("PaymentReadLimiter")]
    public async Task<ActionResult<ApiResponse<object>>> GetSummary(CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();
            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);

            await using var cmd = new SqlCommand("""
                SELECT
                    u.credits,
                    u.current_plan,
                    ISNULL((
                        SELECT SUM(credit_delta)
                        FROM dbo.credit_ledger
                        WHERE user_id = @userId AND credit_delta > 0
                    ), 0)
                FROM dbo.users u
                WHERE u.id = @userId
                """, connection);
            cmd.Parameters.AddWithValue("@userId", userId);

            await using var reader = await cmd.ExecuteReaderAsync(ct);
            if (!await reader.ReadAsync(ct))
                return NotFound(ApiResponse<object>.Fail("User not found."));

            return Ok(ApiResponse<object>.Ok(new
            {
                creditLeft         = Convert.ToInt64(reader.GetValue(0)),
                currentPlan        = reader.GetString(1),
                totalCreditsAwarded = Convert.ToInt64(reader.GetValue(2))
            }));
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(ApiResponse<object>.Fail("Authentication required."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching usage summary");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Failed to fetch usage summary."));
        }
    }

    [HttpGet("history")]
    [EnableRateLimiting("PaymentReadLimiter")]
    public async Task<ActionResult<ApiResponse<object>>> GetPaymentHistory(CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();
            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);

            await using var cmd = new SqlCommand("""
                SELECT id, razorpay_order_id, razorpay_payment_id,
                       plan_display_name, amount_inr, credits_granted,
                       status, currency, created_at, paid_at
                FROM dbo.payment_orders
                WHERE user_id = @userId
                ORDER BY created_at DESC
                """, connection);
            cmd.Parameters.AddWithValue("@userId", userId);

            var payments = new List<object>();
            await using var reader = await cmd.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
            {
                payments.Add(new
                {
                    id                = reader.GetGuid(0).ToString(),
                    razorpayOrderId   = reader.GetString(1),
                    razorpayPaymentId = reader.IsDBNull(2) ? null : reader.GetString(2),
                    planDisplayName   = reader.GetString(3),
                    amountInr         = reader.GetDecimal(4),
                    creditsGranted    = reader.GetInt64(5),
                    status            = reader.GetString(6),
                    currency          = reader.GetString(7),
                    createdAt         = reader.GetDateTime(8).ToString("O"),
                    paidAt            = reader.IsDBNull(9) ? null : reader.GetDateTime(9).ToString("O"),
                });
            }

            return Ok(ApiResponse<object>.Ok((object)payments));
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(ApiResponse<object>.Fail("Authentication required."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching payment history");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Failed to fetch payment history."));
        }
    }

    [HttpGet("invoice/{orderId}")]
    [EnableRateLimiting("PaymentReadLimiter")]
    public async Task<ActionResult<ApiResponse<object>>> GetInvoice(string orderId, CancellationToken ct)
    {
        try
        {
            var userId = GetRequiredUserId();

            if (!Guid.TryParse(orderId, out var orderGuid))
                return BadRequest(ApiResponse<object>.Fail("Invalid order ID."));

            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(ct);

            await using var cmd = new SqlCommand("""
                SELECT po.id, po.razorpay_order_id, po.razorpay_payment_id,
                       po.plan_display_name, po.amount_inr, po.credits_granted,
                       po.status, po.currency, po.paid_at,
                       u.email, u.full_name
                FROM dbo.payment_orders po
                INNER JOIN dbo.users u ON po.user_id = u.id
                WHERE po.id = @orderId AND po.user_id = @userId AND po.status = 'paid'
                """, connection);
            cmd.Parameters.AddWithValue("@orderId", orderGuid);
            cmd.Parameters.AddWithValue("@userId", userId);

            await using var reader = await cmd.ExecuteReaderAsync(ct);
            if (!await reader.ReadAsync(ct))
                return NotFound(ApiResponse<object>.Fail("Invoice not found."));

            return Ok(ApiResponse<object>.Ok(new
            {
                invoiceId         = reader.GetGuid(0).ToString(),
                razorpayOrderId   = reader.GetString(1),
                razorpayPaymentId = reader.IsDBNull(2) ? null : reader.GetString(2),
                planDisplayName   = reader.GetString(3),
                amountInr         = reader.GetDecimal(4),
                creditsGranted    = reader.GetInt64(5),
                status            = reader.GetString(6),
                currency          = reader.GetString(7),
                paidAt            = reader.IsDBNull(8) ? null : reader.GetDateTime(8).ToString("O"),
                userEmail         = reader.GetString(9),
                userName          = reader.GetString(10),
            }));
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(ApiResponse<object>.Fail("Authentication required."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching invoice");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Failed to fetch invoice."));
        }
    }

    private async Task<PlanRow?> FetchPlanAsync(string planName, CancellationToken ct)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenAsync(ct);
        await using var cmd = new SqlCommand("""
            SELECT inr_monthly_price, inr_annual_price, monthly_price, annual_price, credits_per_month, display_name
            FROM dbo.plans
            WHERE name = @name AND is_active = 1
            """, connection);
        cmd.Parameters.AddWithValue("@name", planName.ToLowerInvariant());
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct)) return null;
        return new PlanRow(reader.GetDecimal(0), reader.GetDecimal(1), reader.GetDecimal(2), reader.GetDecimal(3), reader.GetInt64(4), reader.GetString(5));
    }
}

public sealed record CreateOrderRequest(string PlanName, string BillingCycle, string? Currency = "INR");
public sealed record VerifyPaymentRequest(string RazorpayOrderId, string RazorpayPaymentId, string RazorpaySignature);
public sealed record PlanRow(decimal InrMonthly, decimal InrAnnual, decimal MonthlyUsd, decimal AnnualUsd, long Credits, string DisplayName);
