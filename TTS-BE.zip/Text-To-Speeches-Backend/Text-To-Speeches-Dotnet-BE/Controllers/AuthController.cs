using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Google.Apis.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Text_To_Speeches_Dotnet_BE.Configuration;
using Text_To_Speeches_Dotnet_BE.Models;
using Text_To_Speeches_Dotnet_BE.Services.Credits;
using Text_To_Speeches_Dotnet_BE.Services.Email;
using Text_To_Speeches_Dotnet_BE.Services.Security;
using Text_To_Speeches_Dotnet_BE.Services.Users;

namespace Text_To_Speeches_Dotnet_BE.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : BaseApiController
{
    private readonly IUserRepository _userRepository;
    private readonly IPasswordService _passwordService;
    private readonly IEmailService _emailService;
    private readonly ICreditService _creditService;
    private readonly ILogger<AuthController> _logger;
    private readonly IConfiguration _configuration;
    private readonly JwtOptions _jwtOptions;
    private readonly GoogleOptions _googleOptions;
    private readonly EmailVerificationOptions _emailVerificationOptions;
    private readonly ServerOptions _serverOptions;

    public AuthController(
        IUserRepository userRepository,
        IPasswordService passwordService,
        IEmailService emailService,
        ICreditService creditService,
        IConfiguration configuration,
        IOptions<JwtOptions> jwtOptions,
        IOptions<GoogleOptions> googleOptions,
        IOptions<EmailVerificationOptions> emailVerificationOptions,
        IOptions<ServerOptions> serverOptions,
        ILogger<AuthController> logger)
    {
        _userRepository = userRepository;
        _passwordService = passwordService;
        _emailService = emailService;
        _creditService = creditService;
        _configuration = configuration;
        _jwtOptions = jwtOptions.Value;
        _googleOptions = googleOptions.Value;
        _emailVerificationOptions = emailVerificationOptions.Value;
        _serverOptions = serverOptions.Value;
        _logger = logger;
    }

    [HttpPost("signup")]
    [EnableRateLimiting("AuthLimiter")]
    public async Task<ActionResult<ApiResponse<object>>> Signup([FromBody] SignupRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var normalizedEmail = request.Email.ToLowerInvariant().Trim();
            var existingUser = await _userRepository.FindByEmailAsync(normalizedEmail, cancellationToken);

            var passwordHash = _passwordService.HashPassword(request.Password);
            var (verificationToken, expiresAt) = CreateVerificationPayload();

            if (existingUser is not null)
            {
                if (!string.IsNullOrWhiteSpace(existingUser.PasswordHash) && existingUser.EmailVerified)
                    return Conflict(ApiResponse<object>.Fail("Email already registered. Please login."));

                if (string.IsNullOrWhiteSpace(existingUser.PasswordHash) && !string.IsNullOrWhiteSpace(existingUser.GoogleId))
                    return Conflict(ApiResponse<object>.Fail("This email is already registered with Google sign-in."));

                await _userRepository.UpdatePendingManualUserAsync(existingUser.Id, request.FullName, passwordHash, verificationToken, expiresAt, cancellationToken);
            }
            else
            {
                await _userRepository.CreateOrUpdatePendingSignupAsync(request.FullName, normalizedEmail, passwordHash, verificationToken, expiresAt, cancellationToken);
            }

            try
            {
                await _emailService.SendVerificationEmailAsync(normalizedEmail, verificationToken, cancellationToken);
            }
            catch (Exception emailError)
            {
                _logger.LogError(emailError, "Verification email send failed during signup");
                return StatusCode(StatusCodes.Status503ServiceUnavailable,
                    ApiResponse<object>.Fail("Could not send verification email right now. Please try again."));
            }

            return StatusCode(StatusCodes.Status201Created,
                ApiResponse<object>.Ok(null!, "Verification email sent. Verify your email to complete signup."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Signup error");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));
        }
    }

    [HttpPost("login")]
    [EnableRateLimiting("AuthLimiter")]
    public async Task<ActionResult<ApiResponse<object>>> Login([FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var normalizedEmail = request.Email.ToLowerInvariant().Trim();
            var user = await _userRepository.FindByEmailAsync(normalizedEmail, cancellationToken);

            if (user is null || string.IsNullOrWhiteSpace(user.PasswordHash))
                return Unauthorized(ApiResponse<object>.Fail("Invalid email or password."));

            if (!_passwordService.VerifyPassword(request.Password, user.PasswordHash))
                return Unauthorized(ApiResponse<object>.Fail("Invalid email or password."));

            if (!user.EmailVerified)
                return StatusCode(StatusCodes.Status403Forbidden, ApiResponse<object>.Fail("Please verify your email before logging in."));

            var token = CreateAuthToken(user.Id, user.Email);

            return Ok(ApiResponse<object>.Ok(new
            {
                token,
                user = new { id = user.Id, fullName = user.FullName, email = user.Email, profilePicture = user.ProfilePicture, emailVerified = user.EmailVerified }
            }, "Login successful."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Login error");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));
        }
    }

    [HttpGet("verify-email")]
    public async Task<ActionResult<ApiResponse<object>>> VerifyEmail([FromQuery] VerifyEmailRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var pendingSignup = await _userRepository.FindPendingByVerificationTokenAsync(request.Token, cancellationToken);
            if (pendingSignup is not null)
            {
                if (pendingSignup.EmailVerificationExpiresAt < DateTime.UtcNow)
                    return BadRequest(ApiResponse<object>.Fail("Verification token has expired. Please request a new one."));

                var existingUser = await _userRepository.FindByEmailAsync(pendingSignup.Email, cancellationToken);
                if (existingUser is not null)
                    return Conflict(ApiResponse<object>.Fail("Email already registered. Please login."));

                var newUserId = await _userRepository.CreateVerifiedManualUserFromPendingIdAsync(pendingSignup.Id, cancellationToken);
                if (newUserId.HasValue)
                    await _creditService.AllocateSignupGrantAsync(newUserId.Value, cancellationToken);

                return Ok(ApiResponse<object>.Ok(null!, "Email verified successfully. You can now login."));
            }

            var legacyUser = await _userRepository.FindByVerificationTokenAsync(request.Token, cancellationToken);
            if (legacyUser is null)
                return BadRequest(ApiResponse<object>.Fail("Invalid verification token."));

            if (!legacyUser.EmailVerificationExpiresAt.HasValue || legacyUser.EmailVerificationExpiresAt.Value < DateTime.UtcNow)
                return BadRequest(ApiResponse<object>.Fail("Verification token has expired. Please request a new one."));

            await _userRepository.VerifyEmailAsync(legacyUser.Id, cancellationToken);
            await _creditService.AllocateSignupGrantAsync(legacyUser.Id, cancellationToken);
            return Ok(ApiResponse<object>.Ok(null!, "Email verified successfully. You can now login."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Verify email error");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));
        }
    }

    [HttpPost("resend-verification")]
    public async Task<ActionResult<ApiResponse<object>>> ResendVerification([FromBody] ResendVerificationRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var normalizedEmail = request.Email.ToLowerInvariant().Trim();
            var user = await _userRepository.FindByEmailAsync(normalizedEmail, cancellationToken);

            if (user is not null && user.EmailVerified)
                return BadRequest(ApiResponse<object>.Fail("Email already verified."));

            var (verificationToken, expiresAt) = CreateVerificationPayload();
            var pendingSignup = await _userRepository.FindPendingByEmailAsync(normalizedEmail, cancellationToken);

            if (pendingSignup is not null)
            {
                await _userRepository.UpdatePendingVerificationTokenByEmailAsync(normalizedEmail, verificationToken, expiresAt, cancellationToken);
            }
            else if (user is not null && !string.IsNullOrWhiteSpace(user.PasswordHash) && !user.EmailVerified)
            {
                await _userRepository.UpdateVerificationTokenAsync(user.Id, verificationToken, expiresAt, cancellationToken);
            }
            else
            {
                return NotFound(ApiResponse<object>.Fail("No manual signup found for this email."));
            }

            try
            {
                await _emailService.SendVerificationEmailAsync(normalizedEmail, verificationToken, cancellationToken);
            }
            catch (Exception emailError)
            {
                _logger.LogError(emailError, "Verification email send failed during resend");
                return StatusCode(StatusCodes.Status503ServiceUnavailable,
                    ApiResponse<object>.Fail("Could not send verification email right now. Please try again."));
            }

            return Ok(ApiResponse<object>.Ok(null!, "Verification email sent again."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Resend verification error");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));
        }
    }

    [HttpPost("verify-code")]
    public async Task<ActionResult<ApiResponse<object>>> VerifyCode([FromBody] VerifyCodeRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var normalizedEmail = request.Email.ToLowerInvariant().Trim();

            var pendingSignup = await _userRepository.FindPendingByEmailAsync(normalizedEmail, cancellationToken);
            if (pendingSignup is not null)
            {
                if (pendingSignup.EmailVerificationToken != request.Code)
                    return BadRequest(ApiResponse<object>.Fail("Invalid verification code."));

                if (pendingSignup.EmailVerificationExpiresAt < DateTime.UtcNow)
                    return BadRequest(ApiResponse<object>.Fail("Verification code has expired. Please request a new one."));

                var conflict = await _userRepository.FindByEmailAsync(normalizedEmail, cancellationToken);
                if (conflict is not null && conflict.EmailVerified)
                    return Conflict(ApiResponse<object>.Fail("Email already registered. Please login."));

                var newUserId = await _userRepository.CreateVerifiedManualUserFromPendingIdAsync(pendingSignup.Id, cancellationToken);
                if (newUserId is null)
                    return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));

                await _creditService.AllocateSignupGrantAsync(newUserId.Value, cancellationToken);

                var newUser = await _userRepository.FindByIdAsync(newUserId.Value, cancellationToken);
                if (newUser is null)
                    return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));

                var jwtToken = CreateAuthToken(newUser.Id, newUser.Email);
                return Ok(ApiResponse<object>.Ok(new
                {
                    token = jwtToken,
                    user = new { id = newUser.Id, fullName = newUser.FullName, email = newUser.Email, profilePicture = newUser.ProfilePicture, emailVerified = newUser.EmailVerified }
                }, "Email verified successfully."));
            }

            var legacyUser = await _userRepository.FindByEmailAsync(normalizedEmail, cancellationToken);
            if (legacyUser is null)
                return NotFound(ApiResponse<object>.Fail("No pending signup found for this email."));

            if (legacyUser.EmailVerified)
                return BadRequest(ApiResponse<object>.Fail("Email already verified. Please login."));

            if (legacyUser.EmailVerificationToken != request.Code)
                return BadRequest(ApiResponse<object>.Fail("Invalid verification code."));

            if (!legacyUser.EmailVerificationExpiresAt.HasValue || legacyUser.EmailVerificationExpiresAt.Value < DateTime.UtcNow)
                return BadRequest(ApiResponse<object>.Fail("Verification code has expired. Please request a new one."));

            await _userRepository.VerifyEmailAsync(legacyUser.Id, cancellationToken);
            await _creditService.AllocateSignupGrantAsync(legacyUser.Id, cancellationToken);

            var authToken = CreateAuthToken(legacyUser.Id, legacyUser.Email);
            return Ok(ApiResponse<object>.Ok(new
            {
                token = authToken,
                user = new { id = legacyUser.Id, fullName = legacyUser.FullName, email = legacyUser.Email, profilePicture = legacyUser.ProfilePicture, emailVerified = true }
            }, "Email verified successfully."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Verify code error");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));
        }
    }

    [HttpPost("google")]
    public async Task<ActionResult<ApiResponse<object>>> GoogleAuth([FromBody] GoogleAuthRequest request, CancellationToken cancellationToken)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.IdToken))
                return BadRequest(ApiResponse<object>.Fail("Google ID token is required."));

            var googleClientId = _configuration["GOOGLE_CLIENT_ID"] ?? _googleOptions.ClientId;
            if (string.IsNullOrWhiteSpace(googleClientId))
                return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Google client ID is not configured."));

            GoogleJsonWebSignature.Payload payload;
            try
            {
                payload = await GoogleJsonWebSignature.ValidateAsync(
                    request.IdToken,
                    new GoogleJsonWebSignature.ValidationSettings { Audience = new[] { googleClientId } });
            }
            catch
            {
                return Unauthorized(ApiResponse<object>.Fail("Invalid Google token."));
            }

            var googleId = payload.Subject;
            var email = payload.Email;
            var fullName = payload.Name;
            var profilePicture = payload.Picture;

            if (string.IsNullOrWhiteSpace(googleId) || string.IsNullOrWhiteSpace(email))
                return Unauthorized(ApiResponse<object>.Fail("Invalid Google token."));

            var normalizedEmail = email.ToLowerInvariant().Trim();
            var effectiveFullName = string.IsNullOrWhiteSpace(fullName) ? normalizedEmail : fullName;

            var userByGoogleId = await _userRepository.FindByGoogleIdAsync(googleId, cancellationToken);
            var isNewUser = false;
            int userId;
            string userEmail;
            string userFullName;
            string? userProfilePicture;
            bool emailVerified;

            if (userByGoogleId is not null)
            {
                await _userRepository.UpdateProfileAsync(userByGoogleId.Id, effectiveFullName, profilePicture, cancellationToken);
                userId = userByGoogleId.Id;
                userEmail = userByGoogleId.Email;
                userFullName = effectiveFullName;
                userProfilePicture = profilePicture ?? userByGoogleId.ProfilePicture;
                emailVerified = userByGoogleId.EmailVerified;
            }
            else
            {
                var existingEmailUser = await _userRepository.FindByEmailAsync(normalizedEmail, cancellationToken);
                if (existingEmailUser is not null)
                {
                    await _userRepository.LinkGoogleAccountAsync(existingEmailUser.Id, googleId, effectiveFullName, profilePicture, cancellationToken);
                    var linkedUser = await _userRepository.FindByIdAsync(existingEmailUser.Id, cancellationToken);
                    if (linkedUser is null)
                        return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));

                    userId = linkedUser.Id;
                    userEmail = linkedUser.Email;
                    userFullName = linkedUser.FullName;
                    userProfilePicture = linkedUser.ProfilePicture;
                    emailVerified = linkedUser.EmailVerified;
                }
                else
                {
                    var newUserId = await _userRepository.CreateGoogleUserAsync(googleId, effectiveFullName, normalizedEmail, profilePicture, cancellationToken);
                    var newUser = await _userRepository.FindByIdAsync(newUserId, cancellationToken);
                    if (newUser is null)
                        return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));

                    isNewUser = true;
                    userId = newUser.Id;
                    userEmail = newUser.Email;
                    userFullName = newUser.FullName;
                    userProfilePicture = newUser.ProfilePicture;
                    emailVerified = newUser.EmailVerified;

                    await _creditService.AllocateSignupGrantAsync(userId, cancellationToken);
                }
            }

            var token = CreateAuthToken(userId, userEmail);
            return Ok(ApiResponse<object>.Ok(new
            {
                token,
                user = new { id = userId, fullName = userFullName, email = userEmail, profilePicture = userProfilePicture ?? profilePicture, emailVerified }
            }, isNewUser ? "Account created successfully." : "Login successful."));
        }
        catch (SqlException ex)
        {
            _logger.LogError(ex, "Google auth failed due to SQL issue");
            return StatusCode(StatusCodes.Status503ServiceUnavailable, ApiResponse<object>.Fail("Authentication service is temporarily unavailable. Please try again."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Google auth error");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));
        }
    }

    [Authorize]
    [HttpGet("me")]
    public async Task<ActionResult<ApiResponse<object>>> GetMe(CancellationToken cancellationToken)
    {
        try
        {
            var userId = GetUserIdFromToken();
            if (userId is null)
                return Unauthorized(ApiResponse<object>.Fail("Invalid or expired token."));

            var user = await _userRepository.FindByIdAsync(userId.Value, cancellationToken);
            if (user is null)
                return NotFound(ApiResponse<object>.Fail("User not found."));

            return Ok(ApiResponse<object>.Ok(new
            {
                id = user.Id,
                googleId = user.GoogleId,
                fullName = user.FullName,
                email = user.Email,
                emailVerified = user.EmailVerified,
                profilePicture = user.ProfilePicture,
                createdAt = user.CreatedAt,
                currentPlan = user.CurrentPlan,
                credits = user.Credits
            }));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "GetMe error");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));
        }
    }

    [Authorize]
    [HttpDelete("delete-account")]
    public async Task<ActionResult<ApiResponse<object>>> DeleteAccount([FromBody] DeleteAccountRequest request, CancellationToken cancellationToken)
    {
        try
        {
            var userId = GetUserIdFromToken();
            if (userId is null)
                return Unauthorized(ApiResponse<object>.Fail("Invalid or expired token."));

            var user = await _userRepository.FindByIdAsync(userId.Value, cancellationToken);
            if (user is null)
                return NotFound(ApiResponse<object>.Fail("User not found."));

            if (!string.Equals(user.Email, request.Email.ToLowerInvariant().Trim(), StringComparison.OrdinalIgnoreCase))
                return BadRequest(ApiResponse<object>.Fail("Entered email does not match your account email."));

            var deleted = await _userRepository.DeleteByIdAsync(user.Id, cancellationToken);
            if (!deleted)
                return NotFound(ApiResponse<object>.Fail("User not found."));

            return Ok(ApiResponse<object>.Ok(null!, "Account deleted permanently."));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Delete account error");
            return StatusCode(StatusCodes.Status500InternalServerError, ApiResponse<object>.Fail("Internal server error."));
        }
    }

    private string CreateAuthToken(int userId, string email)
    {
        var jwtSecret = _configuration["JWT_SECRET"] ?? _jwtOptions.Secret;
        if (string.IsNullOrWhiteSpace(jwtSecret))
            throw new InvalidOperationException("JWT secret is not configured.");

        var claims = new List<Claim>
        {
            new("id", userId.ToString()),
            new("email", email),
            new(ClaimTypes.NameIdentifier, userId.ToString())
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var expiresInRaw = _configuration["JWT_EXPIRES_IN"] ?? _jwtOptions.ExpiresIn ?? "7d";
        var expiresAt = DateTime.UtcNow.Add(ParseJwtExpiry(expiresInRaw));

        var token = new JwtSecurityToken(
            issuer: "texttospeeches.in",
            audience: "texttospeeches-api",
            claims: claims,
            expires: expiresAt,
            signingCredentials: credentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private static (string token, DateTime expiresAt) CreateVerificationPayload()
    {
        var code = RandomNumberGenerator.GetInt32(100000, 1000000).ToString();
        return (code, DateTime.UtcNow.AddMinutes(15));
    }

    private static TimeSpan ParseJwtExpiry(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return TimeSpan.FromDays(7);

        if (double.TryParse(raw, out var seconds)) return TimeSpan.FromSeconds(seconds);

        var unit = raw[^1];
        if (!double.TryParse(raw[..^1], out var value)) return TimeSpan.FromDays(7);

        return char.ToLowerInvariant(unit) switch
        {
            's' => TimeSpan.FromSeconds(value),
            'm' => TimeSpan.FromMinutes(value),
            'h' => TimeSpan.FromHours(value),
            'd' => TimeSpan.FromDays(value),
            _ => TimeSpan.FromDays(7)
        };
    }
}
