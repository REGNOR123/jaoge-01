using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Text_To_Speeches_Dotnet_BE.Services.Database;

namespace Text_To_Speeches_Dotnet_BE.Services.Credits;

public sealed class CreditService : ICreditService
{
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly IMemoryCache _cache;
    private readonly ILogger<CreditService> _logger;

    private static readonly TimeSpan CacheTtl = TimeSpan.FromMinutes(10);
    private const string FeatureCostsCacheKey = "feature_costs_v1";
    private const string SignupGrantCacheKey = "signup_grant_v1";

    public CreditService(
        ISqlConnectionFactory connectionFactory,
        IMemoryCache cache,
        ILogger<CreditService> logger)
    {
        _connectionFactory = connectionFactory;
        _cache = cache;
        _logger = logger;
    }

    public async Task<long> GetBalanceAsync(int userId, CancellationToken cancellationToken = default)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var cmd = new SqlCommand(
            "SELECT credits FROM dbo.users WHERE id = @userId",
            connection);
        cmd.Parameters.AddWithValue("@userId", userId);

        var result = await cmd.ExecuteScalarAsync(cancellationToken);
        return result is long balance ? balance : Convert.ToInt64(result ?? 0L);
    }

    public async Task<(bool Success, long NewBalance)> DeductCreditsAsync(
        int userId,
        string feature,
        long amount,
        string? description = null,
        CancellationToken cancellationToken = default)
    {
        // Velocity check: reject if > 10 deductions in the last 60 seconds
        await using var velConn = _connectionFactory.CreateConnection();
        await velConn.OpenAsync(cancellationToken);
        await using var velCmd = new SqlCommand(
            """
            SELECT COUNT(*)
            FROM dbo.credit_ledger
            WHERE user_id = @userId
              AND source = 'consumption'
              AND created_at >= DATEADD(SECOND, -60, SYSUTCDATETIME())
            """, velConn);
        velCmd.Parameters.AddWithValue("@userId", userId);
        var recentCount = (int)(await velCmd.ExecuteScalarAsync(cancellationToken))!;
        if (recentCount >= 10)
        {
            _logger.LogWarning("Velocity limit hit for user {UserId}: {Count} deductions in last 60s", userId, recentCount);
            var bal = await GetBalanceAsync(userId, cancellationToken);
            return (false, bal);
        }

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);
        await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync(
            System.Data.IsolationLevel.ReadCommitted, cancellationToken);

        try
        {
            await using var selectCmd = new SqlCommand(
                "SELECT credits, credits_frozen FROM dbo.users WITH (UPDLOCK, ROWLOCK) WHERE id = @userId",
                connection, transaction);
            selectCmd.Parameters.AddWithValue("@userId", userId);

            await using var selectReader = await selectCmd.ExecuteReaderAsync(cancellationToken);
            if (!await selectReader.ReadAsync(cancellationToken))
            {
                await transaction.RollbackAsync(cancellationToken);
                return (false, 0);
            }
            var currentBalance = selectReader.IsDBNull(0) ? 0L : Convert.ToInt64(selectReader.GetValue(0));
            var creditsFrozen = !selectReader.IsDBNull(1) && Convert.ToBoolean(selectReader.GetValue(1));
            await selectReader.CloseAsync();

            if (creditsFrozen)
            {
                _logger.LogWarning("Credit deduction blocked for frozen user {UserId}", userId);
                await transaction.RollbackAsync(cancellationToken);
                return (false, currentBalance);
            }

            if (currentBalance < amount)
            {
                await transaction.RollbackAsync(cancellationToken);
                return (false, currentBalance);
            }

            var newBalance = currentBalance - amount;

            await using var updateCmd = new SqlCommand(
                "UPDATE dbo.users SET credits = @newBalance, updated_at = SYSUTCDATETIME() WHERE id = @userId",
                connection, transaction);
            updateCmd.Parameters.AddWithValue("@newBalance", newBalance);
            updateCmd.Parameters.AddWithValue("@userId", userId);
            await updateCmd.ExecuteNonQueryAsync(cancellationToken);

            await using var ledgerCmd = new SqlCommand("""
                INSERT INTO dbo.credit_ledger (user_id, credit_delta, balance_after, source, feature, description)
                VALUES (@userId, @delta, @balanceAfter, @source, @feature, @description)
                """, connection, transaction);
            ledgerCmd.Parameters.AddWithValue("@userId", userId);
            ledgerCmd.Parameters.AddWithValue("@delta", -amount);
            ledgerCmd.Parameters.AddWithValue("@balanceAfter", newBalance);
            ledgerCmd.Parameters.AddWithValue("@source", "consumption");
            ledgerCmd.Parameters.AddWithValue("@feature", (object?)feature ?? DBNull.Value);
            ledgerCmd.Parameters.AddWithValue("@description", (object?)description ?? DBNull.Value);
            await ledgerCmd.ExecuteNonQueryAsync(cancellationToken);

            await transaction.CommitAsync(cancellationToken);
            return (true, newBalance);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Credit deduction failed for user {UserId}, feature {Feature}", userId, feature);
            await transaction.RollbackAsync(cancellationToken);
            throw;
        }
    }

    public async Task AllocateCreditsAsync(
        int userId,
        long amount,
        string source,
        string? description = null,
        CancellationToken cancellationToken = default)
    {
        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);
        await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync(
            System.Data.IsolationLevel.ReadCommitted, cancellationToken);

        try
        {
            await using var updateCmd = new SqlCommand(
                "UPDATE dbo.users SET credits = credits + @amount, updated_at = SYSUTCDATETIME() WHERE id = @userId",
                connection, transaction);
            updateCmd.Parameters.AddWithValue("@amount", amount);
            updateCmd.Parameters.AddWithValue("@userId", userId);
            await updateCmd.ExecuteNonQueryAsync(cancellationToken);

            await using var balanceCmd = new SqlCommand(
                "SELECT credits FROM dbo.users WHERE id = @userId",
                connection, transaction);
            balanceCmd.Parameters.AddWithValue("@userId", userId);
            var result = await balanceCmd.ExecuteScalarAsync(cancellationToken);
            var newBalance = result is long b ? b : Convert.ToInt64(result ?? 0L);

            await using var ledgerCmd = new SqlCommand("""
                INSERT INTO dbo.credit_ledger (user_id, credit_delta, balance_after, source, feature, description)
                VALUES (@userId, @delta, @balanceAfter, @source, NULL, @description)
                """, connection, transaction);
            ledgerCmd.Parameters.AddWithValue("@userId", userId);
            ledgerCmd.Parameters.AddWithValue("@delta", amount);
            ledgerCmd.Parameters.AddWithValue("@balanceAfter", newBalance);
            ledgerCmd.Parameters.AddWithValue("@source", source);
            ledgerCmd.Parameters.AddWithValue("@description", (object?)description ?? DBNull.Value);
            await ledgerCmd.ExecuteNonQueryAsync(cancellationToken);

            await transaction.CommitAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Credit allocation failed for user {UserId}", userId);
            await transaction.RollbackAsync(cancellationToken);
            throw;
        }
    }

    public async Task AllocateSignupGrantAsync(int userId, CancellationToken cancellationToken = default)
    {
        try
        {
            var grantAmount = await GetSignupGrantAmountAsync(cancellationToken);
            if (grantAmount <= 0) return;

            await AllocateCreditsAsync(userId, grantAmount, "signup_grant", "Welcome — free credits", cancellationToken);
        }
        catch (SqlException ex)
        {
            _logger.LogWarning(ex, "Skipping signup grant allocation for user {UserId} due to database schema/availability issue.", userId);
        }
    }

    public async Task<long> CalculateCreditCostAsync(
        string feature,
        int characters = 0,
        CancellationToken cancellationToken = default)
    {
        var costs = await GetFeatureCostsAsync(cancellationToken);

        if (!costs.TryGetValue(feature, out var row))
            return 0;

        if (row.CostPerNChars.HasValue && row.CostPerNChars.Value > 0 && characters > 0)
        {
            var units = (long)Math.Ceiling((double)characters / row.CostPerNChars.Value);
            return Math.Max(row.MinCost, units * row.CreditCost);
        }

        return row.CreditCost;
    }

    public async Task<IReadOnlyList<FeatureCostDto>> GetDisplayFeatureCostsAsync(CancellationToken cancellationToken = default)
    {
        const string DisplayCacheKey = "feature_costs_display_v1";

        if (_cache.TryGetValue(DisplayCacheKey, out IReadOnlyList<FeatureCostDto>? cached) && cached is not null)
            return cached;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var cmd = new SqlCommand(
            "SELECT feature, display_name, credit_cost, cost_per_n_chars, min_cost, display_unit FROM dbo.feature_costs ORDER BY feature",
            connection);

        var list = new List<FeatureCostDto>();
        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            list.Add(new FeatureCostDto(
                reader.GetString(0),
                reader.GetString(1),
                reader.GetInt64(2),
                reader.IsDBNull(3) ? null : reader.GetInt32(3),
                reader.GetInt64(4),
                reader.GetString(5)
            ));
        }

        _cache.Set(DisplayCacheKey, (IReadOnlyList<FeatureCostDto>)list, new MemoryCacheEntryOptions
        {
            SlidingExpiration = CacheTtl
        });
        return list;
    }

    private async Task<long> GetSignupGrantAmountAsync(CancellationToken cancellationToken)
    {
        if (_cache.TryGetValue(SignupGrantCacheKey, out long cached))
            return cached;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var cmd = new SqlCommand(
            "SELECT config_value FROM dbo.app_config WHERE config_key = 'signup_credit_grant'",
            connection);

        var result = await cmd.ExecuteScalarAsync(cancellationToken);
        var amount = result is string s && long.TryParse(s, out var v) ? v : 200L;

        _cache.Set(SignupGrantCacheKey, amount, new MemoryCacheEntryOptions
        {
            SlidingExpiration = CacheTtl
        });

        return amount;
    }

    private async Task<Dictionary<string, FeatureCostRow>> GetFeatureCostsAsync(CancellationToken cancellationToken)
    {
        if (_cache.TryGetValue(FeatureCostsCacheKey, out Dictionary<string, FeatureCostRow>? cached) && cached is not null)
            return cached;

        await using var connection = _connectionFactory.CreateConnection();
        await connection.OpenWithRetryAsync(cancellationToken);

        await using var cmd = new SqlCommand(
            "SELECT feature, credit_cost, cost_per_n_chars, min_cost FROM dbo.feature_costs",
            connection);

        var dict = new Dictionary<string, FeatureCostRow>(StringComparer.OrdinalIgnoreCase);
        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            var key = reader.GetString(0);
            dict[key] = new FeatureCostRow(
                reader.GetInt64(1),
                reader.IsDBNull(2) ? null : reader.GetInt32(2),
                reader.GetInt64(3)
            );
        }

        _cache.Set(FeatureCostsCacheKey, dict, new MemoryCacheEntryOptions
        {
            SlidingExpiration = CacheTtl
        });

        return dict;
    }

    private sealed record FeatureCostRow(long CreditCost, int? CostPerNChars, long MinCost);

    private static bool HasMissingObjectOrColumn(SqlException ex)
    {
        foreach (SqlError error in ex.Errors)
        {
            if (error.Number is 207 or 208)
            {
                return true;
            }
        }

        return false;
    }

    private static bool HasMissingTable(SqlException ex)
    {
        foreach (SqlError error in ex.Errors)
        {
            if (error.Number == 208)
            {
                return true;
            }
        }

        return false;
    }
}
