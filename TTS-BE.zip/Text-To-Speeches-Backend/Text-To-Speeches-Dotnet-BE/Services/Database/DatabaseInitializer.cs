using Microsoft.Data.SqlClient;
using Text_To_Speeches_Dotnet_BE.Configuration;

namespace Text_To_Speeches_Dotnet_BE.Services.Database;

public interface IDatabaseInitializer
{
    Task InitializeAsync(CancellationToken cancellationToken = default);
}

public sealed class DatabaseInitializer : IDatabaseInitializer
{
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly DatabaseOptions _databaseOptions;
    private readonly ILogger<DatabaseInitializer> _logger;

    public DatabaseInitializer(
        ISqlConnectionFactory connectionFactory,
        Microsoft.Extensions.Options.IOptions<DatabaseOptions> databaseOptions,
        ILogger<DatabaseInitializer> logger)
    {
        _connectionFactory = connectionFactory;
        _databaseOptions = databaseOptions.Value;
        _logger = logger;
    }

    public async Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await using var connection = _connectionFactory.CreateConnection();
            await connection.OpenWithRetryAsync(cancellationToken);
            await RunSchemaMigrationAsync(connection, cancellationToken);

            _logger.LogInformation("Database tables ready (users, pending_signups, file_artifacts, credit_ledger, feature_costs, app_config, plans, blocked_ips, security_events)");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Database initialization failed");

            var hint = GetConnectionHint(ex);
            if (!string.IsNullOrWhiteSpace(hint))
            {
                _logger.LogError("Database diagnostic: {Hint}", hint);
            }

            var db = _databaseOptions;
            _logger.LogError(
                "Database target: server={Server} port={Port} encrypt={Encrypt}",
                db.Server,
                db.Port,
                db.Encrypt ? "enabled" : "disabled");

            throw;
        }
    }

    private async Task RunSchemaMigrationAsync(SqlConnection connection, CancellationToken cancellationToken)
    {
        const string usersSql = """
            IF OBJECT_ID('dbo.users', 'U') IS NULL
            BEGIN
              CREATE TABLE dbo.users (
                id INT IDENTITY(1,1) PRIMARY KEY,
                google_id NVARCHAR(255) NULL UNIQUE,
                full_name NVARCHAR(255) NOT NULL,
                email NVARCHAR(255) NOT NULL UNIQUE,
                password_hash NVARCHAR(255) NULL,
                email_verified BIT NOT NULL DEFAULT 0,
                email_verification_token NVARCHAR(64) NULL,
                email_verification_expires_at DATETIME2 NULL,
                profile_picture NVARCHAR(MAX) NULL,
                created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                updated_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
              );
            END
            """;

        const string pendingSignupsSql = """
            IF OBJECT_ID('dbo.pending_signups', 'U') IS NULL
            BEGIN
              CREATE TABLE dbo.pending_signups (
                id INT IDENTITY(1,1) PRIMARY KEY,
                full_name NVARCHAR(255) NOT NULL,
                email NVARCHAR(255) NOT NULL UNIQUE,
                password_hash NVARCHAR(255) NOT NULL,
                email_verification_token NVARCHAR(64) NOT NULL UNIQUE,
                email_verification_expires_at DATETIME2 NOT NULL,
                created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                updated_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
              );
            END
            """;

        const string backfillSql = """
            UPDATE dbo.users
            SET email_verified = 1
            WHERE google_id IS NOT NULL AND email_verified = 0
            """;

        const string fileArtifactsSql = """
            IF OBJECT_ID('dbo.file_artifacts', 'U') IS NULL
            BEGIN
              CREATE TABLE dbo.file_artifacts (
                id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
                user_id INT NULL,
                user_folder NVARCHAR(64) NOT NULL,
                job_id NVARCHAR(64) NOT NULL,
                feature NVARCHAR(50) NOT NULL,
                file_name NVARCHAR(255) NOT NULL,
                relative_path NVARCHAR(600) NOT NULL UNIQUE,
                content_type NVARCHAR(200) NULL,
                size_bytes BIGINT NOT NULL,
                duration_minutes FLOAT NULL,
                is_output BIT NOT NULL DEFAULT 0,
                created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                expires_at DATETIME2 NOT NULL
              );

              CREATE INDEX IX_file_artifacts_expires ON dbo.file_artifacts(expires_at);
              CREATE INDEX IX_file_artifacts_user_created ON dbo.file_artifacts(user_id, created_at);
            END
            """;

        const string addCreditsSql = """
            IF NOT EXISTS (
                SELECT 1 FROM sys.columns
                WHERE object_id = OBJECT_ID('dbo.users') AND name = 'credits'
            )
            BEGIN
                ALTER TABLE dbo.users ADD credits BIGINT NOT NULL DEFAULT 0;
            END
            """;

        const string addProfilePictureSql = """
            IF NOT EXISTS (
                SELECT 1 FROM sys.columns
                WHERE object_id = OBJECT_ID('dbo.users') AND name = 'profile_picture'
            )
            BEGIN
                ALTER TABLE dbo.users ADD profile_picture NVARCHAR(MAX) NULL;
            END
            """;

        const string creditLedgerSql = """
            IF OBJECT_ID('dbo.credit_ledger', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.credit_ledger (
                    id              UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
                    user_id         INT NOT NULL,
                    credit_delta    BIGINT NOT NULL,
                    balance_after   BIGINT NOT NULL,
                    source          NVARCHAR(50) NOT NULL,
                    feature         NVARCHAR(50) NULL,
                    description     NVARCHAR(200) NULL,
                    created_at      DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                    CONSTRAINT FK_credit_ledger_users FOREIGN KEY (user_id)
                        REFERENCES dbo.users(id) ON DELETE CASCADE
                );

                CREATE INDEX IX_credit_ledger_user ON dbo.credit_ledger(user_id, created_at);
            END
            """;

        const string featureCostsTableSql = """
            IF OBJECT_ID('dbo.feature_costs', 'U') IS NULL
                CREATE TABLE dbo.feature_costs (
                    feature          NVARCHAR(50) NOT NULL PRIMARY KEY,
                    credit_cost      BIGINT NOT NULL,
                    cost_per_n_chars INT NULL,
                    min_cost         BIGINT NOT NULL DEFAULT 1,
                    display_name     NVARCHAR(100) NOT NULL DEFAULT '',
                    display_unit     NVARCHAR(100) NOT NULL DEFAULT ''
                );

            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.feature_costs') AND name = 'display_name')
                ALTER TABLE dbo.feature_costs ADD display_name NVARCHAR(100) NOT NULL DEFAULT '';

            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.feature_costs') AND name = 'display_unit')
                ALTER TABLE dbo.feature_costs ADD display_unit NVARCHAR(100) NOT NULL DEFAULT '';
            """;

        const string featureCostsSeedSql = """
            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs)
            BEGIN
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit) VALUES
                ('create-voice',     1,  100,  1, 'Create AI Voice',        'per 1,000 characters'),
                ('transcribe',       10, NULL, 10,'Transcribe Audio',       'per audio file'),
                ('translate-text',   15, NULL, 15,'Speech Translate',       'per file'),
                ('translate-dub',    1,  125,  1, 'Translate & Dub',        'per 1,000 characters'),
                ('speech-translate', 20, NULL, 20,'Speech Translate',       'per min × language'),
                ('text-translate',   3,  1000, 1, 'Text Translation',       'per 1,000 characters'),
                ('detect-language',  1,  NULL, 1, 'Language Detection',     'per request'),
                ('script-generate',  4,  NULL, 4, 'AI Script Studio',       'per script'),
                ('auto-generate',    2,  NULL, 2, 'AI Field Generate',      'per field'),
                ('script-transform', 3,  NULL, 3, 'Script Transform',       'per transform'),
                ('ai-enhance',       2,  NULL, 2, 'AI Text Enhance',        'per request'),
                ('voice-preview',    1,  NULL, 1, 'Voice Preview',          'per 2 previews');
            END

            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs WHERE feature = 'voice-preview')
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
                VALUES ('voice-preview', 1, NULL, 1, 'Voice Preview', 'per 2 previews');

            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs WHERE feature = 'create-voice-regional')
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
                VALUES ('create-voice-regional', 2, 100, 1, 'Create AI Voice (Regional)', 'per 1,000 characters');

            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs WHERE feature = 'create-voice-hd')
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
                VALUES ('create-voice-hd', 3, 100, 1, 'Create AI Voice (Neural HD)', 'per 1,000 characters');

            -- Fix create-voice billing granularity: 1 credit per 200 chars = 5 per 1,000 chars but bills proportionally
            UPDATE dbo.feature_costs SET credit_cost = 1, cost_per_n_chars = 100
            WHERE feature = 'create-voice' AND cost_per_n_chars IN (1000, 200);

            -- Rename display names to match main workflow branding
            UPDATE dbo.feature_costs SET display_name = 'Create AI Voice'  WHERE feature = 'create-voice'   AND display_name IN ('Text to Speech', 'Voice Generation');
            UPDATE dbo.feature_costs SET display_name = 'Transcribe Audio' WHERE feature = 'transcribe'     AND display_name IN ('Audio Transcription', 'Transcription');
            UPDATE dbo.feature_costs SET display_name = 'Speech Translate' WHERE feature = 'translate-text' AND display_name IN ('Speech Translation', 'Audio Translation');
            UPDATE dbo.feature_costs SET display_name = 'AI Script Studio' WHERE feature = 'script-generate' AND display_name IN ('Script Generation', 'Script Studio');

            -- Switch translate-dub to bundle pricing: 1 credit per 125 chars (TTS portion only, translation charged separately)
            UPDATE dbo.feature_costs SET credit_cost = 1, cost_per_n_chars = 125, min_cost = 1, display_unit = 'per 1,000 characters'
            WHERE feature = 'translate-dub' AND (cost_per_n_chars IS NULL OR cost_per_n_chars != 125);

            -- Add speech-translate feature for duration-based billing (20 credits per min per language)
            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs WHERE feature = 'speech-translate')
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
                VALUES ('speech-translate', 20, NULL, 20, 'Speech Translate', 'per min × language');

            UPDATE dbo.feature_costs SET display_name = 'Speech Translate' WHERE feature = 'speech-translate' AND display_name = 'Speech Translate (Dub)';
            """;

        const string appConfigSql = """
            IF OBJECT_ID('dbo.app_config', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.app_config (
                    config_key   NVARCHAR(100) NOT NULL PRIMARY KEY,
                    config_value NVARCHAR(500) NOT NULL,
                    description  NVARCHAR(300) NULL
                );

                INSERT INTO dbo.app_config (config_key, config_value, description) VALUES
                ('signup_credit_grant', '200', 'Free credits awarded to every new verified user');
            END
            """;

        const string plansTableSql = """
            IF OBJECT_ID('dbo.plans', 'U') IS NULL
                CREATE TABLE dbo.plans (
                    id                INT IDENTITY(1,1) PRIMARY KEY,
                    name              NVARCHAR(50)  NOT NULL UNIQUE,
                    display_name      NVARCHAR(100) NOT NULL DEFAULT '',
                    monthly_price     DECIMAL(10,2) NOT NULL DEFAULT 0,
                    annual_price      DECIMAL(10,2) NOT NULL DEFAULT 0,
                    credits_per_month BIGINT        NOT NULL DEFAULT 0,
                    is_one_time_grant BIT           NOT NULL DEFAULT 0,
                    is_active         BIT           NOT NULL DEFAULT 1,
                    sort_order        INT           NOT NULL DEFAULT 0
                );

            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.plans') AND name = 'display_name')
                ALTER TABLE dbo.plans ADD display_name NVARCHAR(100) NOT NULL DEFAULT '';

            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.plans') AND name = 'monthly_price')
                ALTER TABLE dbo.plans ADD monthly_price DECIMAL(10,2) NOT NULL DEFAULT 0;

            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.plans') AND name = 'annual_price')
                ALTER TABLE dbo.plans ADD annual_price DECIMAL(10,2) NOT NULL DEFAULT 0;

            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.plans') AND name = 'credits_per_month')
                ALTER TABLE dbo.plans ADD credits_per_month BIGINT NOT NULL DEFAULT 0;

            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.plans') AND name = 'is_one_time_grant')
                ALTER TABLE dbo.plans ADD is_one_time_grant BIT NOT NULL DEFAULT 0;

            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.plans') AND name = 'sort_order')
                ALTER TABLE dbo.plans ADD sort_order INT NOT NULL DEFAULT 0;
            """;

        const string plansSeedSql = """
            IF NOT EXISTS (SELECT 1 FROM dbo.plans)
            BEGIN
                INSERT INTO dbo.plans (name, display_name, monthly_price, annual_price, credits_per_month, is_one_time_grant, sort_order) VALUES
                ('free',     'Free',     0.00,  0.00,  200,   1, 1),
                ('pro',      'Pro',      9.00,  7.00,  3000,  0, 2),
                ('business', 'Business', 29.00, 23.00, 15000, 0, 3);
            END
            """;

        await ExecuteNonQueryAsync(connection, usersSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, pendingSignupsSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, fileArtifactsSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, backfillSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, addCreditsSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, addProfilePictureSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, creditLedgerSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, featureCostsTableSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, featureCostsSeedSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, appConfigSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, plansTableSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, plansSeedSql, cancellationToken);

        const string addVoiceCloningKeySql = """
            IF NOT EXISTS (
                SELECT 1 FROM sys.columns
                WHERE object_id = OBJECT_ID('dbo.users') AND name = 'voice_cloning_key'
            )
            BEGIN
                ALTER TABLE dbo.users ADD voice_cloning_key NVARCHAR(MAX) NULL;
            END
            """;

        const string voiceCloneFeatureCostsSql = """
            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs WHERE feature = 'voice-clone-generate')
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
                VALUES ('voice-clone-generate', 50, NULL, 50, 'Voice Clone Setup', 'per clone');

            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs WHERE feature = 'voice-clone-synthesize')
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
                VALUES ('voice-clone-synthesize', 10, NULL, 10, 'Voice Clone Synthesis', 'per synthesis');
            """;

        await ExecuteNonQueryAsync(connection, addVoiceCloningKeySql, cancellationToken);
        await ExecuteNonQueryAsync(connection, voiceCloneFeatureCostsSql, cancellationToken);

        const string regionalVoiceFeatureCostsSql = """
            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs WHERE feature = 'create-voice-regional')
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
                VALUES ('create-voice-regional', 2, 100, 1, 'Regional AI Voice', 'per 1,000 characters');

            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs WHERE feature = 'create-voice-hd')
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
                VALUES ('create-voice-hd', 3, 100, 1, 'Neural HD Voice', 'per 1,000 characters');
            """;

        await ExecuteNonQueryAsync(connection, regionalVoiceFeatureCostsSql, cancellationToken);

        const string regionalTranslateFeatureCostsSql = """
            IF NOT EXISTS (SELECT 1 FROM dbo.feature_costs WHERE feature = 'text-translate-regional')
                INSERT INTO dbo.feature_costs (feature, credit_cost, cost_per_n_chars, min_cost, display_name, display_unit)
                VALUES ('text-translate-regional', 6, 1000, 1, 'Regional Text Translation', 'per 1,000 characters');
            """;

        await ExecuteNonQueryAsync(connection, regionalTranslateFeatureCostsSql, cancellationToken);

        const string correctAiEnhanceCostSql = """
            UPDATE dbo.feature_costs
            SET credit_cost = 2, min_cost = 2
            WHERE feature = 'ai-enhance' AND credit_cost != 2;
            """;

        await ExecuteNonQueryAsync(connection, correctAiEnhanceCostSql, cancellationToken);

        const string paymentOrdersSql = """
            IF OBJECT_ID('dbo.payment_orders', 'U') IS NULL
                CREATE TABLE dbo.payment_orders (
                    id                  UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
                    user_id             INT NOT NULL,
                    razorpay_order_id   NVARCHAR(100) NOT NULL UNIQUE,
                    razorpay_payment_id NVARCHAR(100) NULL,
                    plan_name           NVARCHAR(50)  NOT NULL,
                    plan_display_name   NVARCHAR(100) NOT NULL,
                    amount_inr          DECIMAL(10,2) NOT NULL,
                    credits_granted     BIGINT        NOT NULL DEFAULT 0,
                    status              NVARCHAR(20)  NOT NULL DEFAULT 'created',
                    currency            NVARCHAR(10)  NOT NULL DEFAULT 'INR',
                    created_at          DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
                    paid_at             DATETIME2     NULL,
                    CONSTRAINT FK_payment_orders_users FOREIGN KEY (user_id)
                        REFERENCES dbo.users(id) ON DELETE CASCADE
                );
            """;

        const string addCurrentPlanSql = """
            IF NOT EXISTS (
                SELECT 1 FROM sys.columns
                WHERE object_id = OBJECT_ID('dbo.users') AND name = 'current_plan'
            )
                ALTER TABLE dbo.users ADD current_plan NVARCHAR(50) NOT NULL DEFAULT 'free';
            """;

        await ExecuteNonQueryAsync(connection, paymentOrdersSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, addCurrentPlanSql, cancellationToken);

        // Security columns on users
        const string addSecurityColumnsSql = """
            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.users') AND name = 'is_banned')
                ALTER TABLE dbo.users ADD is_banned BIT NOT NULL DEFAULT 0;

            IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.users') AND name = 'credits_frozen')
                ALTER TABLE dbo.users ADD credits_frozen BIT NOT NULL DEFAULT 0;
            """;

        // IP blocklist table
        const string blockedIpsSql = """
            IF OBJECT_ID('dbo.blocked_ips', 'U') IS NULL
                CREATE TABLE dbo.blocked_ips (
                    id           INT IDENTITY(1,1) PRIMARY KEY,
                    ip_address   NVARCHAR(45) NOT NULL UNIQUE,
                    reason       NVARCHAR(200) NULL,
                    blocked_until DATETIME2 NULL,
                    created_at   DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
                );
            """;

        // Security event audit log
        const string securityEventsSql = """
            IF OBJECT_ID('dbo.security_events', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.security_events (
                    id          UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
                    user_id     INT NULL,
                    ip_address  NVARCHAR(45) NULL,
                    event_type  NVARCHAR(50) NOT NULL,
                    details     NVARCHAR(500) NULL,
                    created_at  DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
                );

                CREATE INDEX IX_security_events_user ON dbo.security_events(user_id, created_at);
                CREATE INDEX IX_security_events_type ON dbo.security_events(event_type, created_at);
            END
            """;

        // Kill-switch config seed
        const string serviceEnabledConfigSql = """
            IF NOT EXISTS (SELECT 1 FROM dbo.app_config WHERE config_key = 'service_enabled')
                INSERT INTO dbo.app_config (config_key, config_value, description)
                VALUES ('service_enabled', 'true', 'Set to false to activate maintenance mode on all API routes');
            """;

        await ExecuteNonQueryAsync(connection, addSecurityColumnsSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, blockedIpsSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, securityEventsSql, cancellationToken);
        await ExecuteNonQueryAsync(connection, serviceEnabledConfigSql, cancellationToken);
    }

    private static async Task ExecuteNonQueryAsync(SqlConnection connection, string sql, CancellationToken cancellationToken)
    {
        await using var command = new SqlCommand(sql, connection);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static string? GetConnectionHint(Exception ex)
    {
        if (ex is SqlException sqlEx)
        {
            if (sqlEx.Number == -2)
            {
                return "Connection timed out. Check Azure SQL firewall rules, network access, and outbound access to port 1433.";
            }

            if (sqlEx.Number == 18456)
            {
                return "Authentication failed. Verify DB_USER and DB_PASSWORD.";
            }
        }

        if (ex.InnerException is System.Net.Sockets.SocketException socketEx)
        {
            return socketEx.SocketErrorCode switch
            {
                System.Net.Sockets.SocketError.HostNotFound => "Database server could not be resolved. Verify DB_SERVER and DNS/network connectivity.",
                System.Net.Sockets.SocketError.TryAgain => "Database server could not be resolved. Verify DB_SERVER and DNS/network connectivity.",
                System.Net.Sockets.SocketError.ConnectionRefused => "Connection was refused by the server/port. Verify DB_SERVER, DB_PORT, and SQL Server availability.",
                System.Net.Sockets.SocketError.TimedOut => "Connection timed out. Check Azure SQL firewall rules, network access, and outbound access to port 1433.",
                _ => null
            };
        }

        if (ex.Message.Contains("SSL", StringComparison.OrdinalIgnoreCase) ||
            ex.Message.Contains("TLS", StringComparison.OrdinalIgnoreCase))
        {
            return "TLS/socket connection failed. Verify DB_ENCRYPT and DB_TRUST_SERVER_CERTIFICATE.";
        }

        return null;
    }
}
