namespace Text_To_Speeches_Dotnet_BE.Middleware;

public sealed class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;

    public SecurityHeadersMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext context)
    {
        var headers = context.Response.Headers;

        headers.XContentTypeOptions = "nosniff";
        headers.XFrameOptions = "DENY";
        headers["Referrer-Policy"] = "strict-origin-when-cross-origin";
        headers["X-Permitted-Cross-Domain-Policies"] = "none";
        headers["X-XSS-Protection"] = "0"; // disable legacy XSS filter; rely on CSP

        headers["Content-Security-Policy"] =
            "default-src 'self'; " +
            "script-src 'self' https://checkout.razorpay.com; " +
            "connect-src 'self' https://*.azurewebsites.net https://api.razorpay.com; " +
            "img-src 'self' data: https:; " +
            "media-src 'self' data:; " +
            "frame-src https://api.razorpay.com; " +
            "object-src 'none'; " +
            "base-uri 'self';";

        headers["Permissions-Policy"] =
            "camera=(), microphone=(self), geolocation=(), payment=()";

        await _next(context);
    }
}
