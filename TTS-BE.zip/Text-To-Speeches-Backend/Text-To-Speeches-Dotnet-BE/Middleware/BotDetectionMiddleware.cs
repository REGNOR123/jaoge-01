using Microsoft.Extensions.Caching.Memory;

namespace Text_To_Speeches_Dotnet_BE.Middleware;

public sealed class BotDetectionMiddleware
{
    private readonly RequestDelegate _next;
    private readonly IMemoryCache _cache;
    private readonly ILogger<BotDetectionMiddleware> _logger;

    // Exact substring patterns that identify non-browser clients (java handled separately)
    private static readonly string[] BlockedUaSubstrings =
    [
        "bot", "crawler", "spider", "scraper", "seeker", "curl", "wget", "python",
        "perl", "ruby", "php", "go-http-client", "httpclient",
        "axios", "scrapy", "selenium", "puppeteer", "playwright", "headlesschrome",
        "apachebench", "wrk", "loadrunner", "jmeter", "nessus", "masscan",
        "nmap", "sqlmap", "metasploit", "nikto", "openvas", "burp", "zap"
    ];

    private static readonly string[] AllowedBotSubstrings =
    [
        "googlebot", "bingbot", "slurp", "duckduckbot", "baiduspider", "yandexbot",
        "facebookexternalhit", "linkedinbot", "twitterbot", "whatsapp", "telegrambot"
    ];

    // Paths that only automated scanners/probes hit — never legitimate users
    private static readonly HashSet<string> ScannerPaths = new(StringComparer.OrdinalIgnoreCase)
    {
        "/.env", "/.env.local", "/.env.production", "/.git/config",
        "/wp-admin", "/wp-login.php", "/wp-config.php", "/xmlrpc.php",
        "/phpmyadmin", "/pma", "/admin", "/administrator",
        "/.htaccess", "/.htpasswd", "/etc/passwd", "/etc/shadow",
        "/.aws/credentials", "/server-status", "/server-info",
        "/actuator", "/actuator/env", "/actuator/health",
        "/debug", "/telescope", "/horizon",
        "/composer.json", "/package.json", "/.vscode/settings.json",
        "/config.php", "/configuration.php", "/backup",
        "/api/v1/users", "/api/v2/users"
    };

    // Sensitive API path prefixes — apply rapid-fire detection here
    private static readonly string[] SensitivePrefixes =
    [
        "/api/payment", "/api/credits", "/api/auth"
    ];

    public BotDetectionMiddleware(
        RequestDelegate next,
        IMemoryCache cache,
        ILogger<BotDetectionMiddleware> logger)
    {
        _next = next;
        _cache = cache;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var ip = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var path = context.Request.Path.ToString();

        // Fast-path: IP already flagged as bot
        if (IsKnownBot(ip))
        {
            _logger.LogWarning("Blocked known-bot IP {Ip} → {Path}", ip, path);
            await RespondAsync(context, "bot_blocked");
            return;
        }

        // Scanner/probe path — block immediately and flag IP
        if (IsScannerPath(path))
        {
            _logger.LogWarning("Scanner path probe from IP {Ip}: {Path}", ip, path);
            FlagBot(ip, TimeSpan.FromHours(6));
            await RespondAsync(context, "scanner_probe");
            return;
        }

        var userAgent = context.Request.Headers.UserAgent.ToString();

        // User-Agent analysis
        var uaResult = AnalyzeUserAgent(userAgent);
        if (uaResult.IsBot && !uaResult.IsWhitelisted)
        {
            _logger.LogWarning(
                "Bot User-Agent from IP {Ip}: {UA} (confidence {Pct}%)", ip, userAgent, uaResult.Confidence);

            var attempts = IncrementCounter($"bot_attempts:{ip}", TimeSpan.FromMinutes(1));
            if (attempts >= 3)
                FlagBot(ip, TimeSpan.FromHours(1));

            await RespondAsync(context, "suspicious_agent");
            return;
        }

        // Rapid-fire detection on sensitive paths
        if (IsSensitivePath(path) && IsRapidFire(ip))
        {
            _logger.LogWarning("Rapid-fire requests from IP {Ip} on sensitive path {Path}", ip, path);
            FlagBot(ip, TimeSpan.FromMinutes(15));
            await RespondAsync(context, "rapid_fire");
            return;
        }

        // Heuristic suspicious-request checks (non-blocking: count and flag after threshold)
        if (IsSuspiciousRequest(context))
        {
            _logger.LogWarning("Suspicious request pattern from IP {Ip} → {Path}", ip, path);
            var count = IncrementCounter($"suspicious:{ip}", TimeSpan.FromMinutes(5));
            if (count >= 5)
                FlagBot(ip, TimeSpan.FromHours(2));
        }

        await _next(context);
    }

    // ── Analysis helpers ───────────────────────────────────────────────────

    private static BotResult AnalyzeUserAgent(string userAgent)
    {
        if (string.IsNullOrEmpty(userAgent))
            return new BotResult(IsBot: true, Confidence: 90);

        var ua = userAgent.ToLowerInvariant();

        foreach (var allowed in AllowedBotSubstrings)
            if (ua.Contains(allowed))
                return new BotResult(IsBot: true, IsWhitelisted: true, Confidence: 100);

        var matches = 0;

        foreach (var pattern in BlockedUaSubstrings)
            if (ua.Contains(pattern))
                matches++;

        // java (non-browser) — exclude "javascript"
        if (ua.Contains("java") && !ua.Contains("javascript"))
            matches++;

        if (matches >= 2) return new BotResult(IsBot: true, Confidence: 100);
        if (matches == 1) return new BotResult(IsBot: true, Confidence: 75);

        if (ua.Length is > 0 and < 20)
            return new BotResult(IsBot: true, Confidence: 60);

        if (ua.Contains("like gecko") && !ua.Contains("mozilla"))
            return new BotResult(IsBot: true, Confidence: 70);

        return new BotResult(IsBot: false, Confidence: 0);
    }

    private static bool IsScannerPath(string path)
    {
        if (ScannerPaths.Contains(path))
            return true;

        // Prefix match for nested scanner paths (e.g. /.git/HEAD)
        foreach (var scanPath in ScannerPaths)
            if (path.StartsWith(scanPath + "/", StringComparison.OrdinalIgnoreCase))
                return true;

        return false;
    }

    private static bool IsSensitivePath(string path)
    {
        foreach (var prefix in SensitivePrefixes)
            if (path.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                return true;
        return false;
    }

    private bool IsRapidFire(string ip)
    {
        // More than 20 requests to sensitive paths within 10 seconds = rapid-fire
        const int threshold = 20;
        var key = $"rapid:{ip}";

        if (!_cache.TryGetValue(key, out int count))
            count = 0;

        _cache.Set(key, count + 1, new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(10),
            // Do not extend on access — sliding would defeat the purpose
        });

        return count >= threshold;
    }

    private bool IsSuspiciousRequest(HttpContext context)
    {
        var headers = context.Request.Headers;
        var accept = headers.Accept.ToString();
        var acceptLang = headers.AcceptLanguage.ToString();

        // Real browsers always send Accept and Accept-Language on non-preflight requests
        if (string.IsNullOrEmpty(accept) && string.IsNullOrEmpty(acceptLang))
            return true;

        // POST/PUT without Content-Type is a script, not a browser
        if ((context.Request.Method is "POST" or "PUT") &&
            string.IsNullOrEmpty(headers.ContentType.ToString()))
            return true;

        var query = context.Request.QueryString.ToString();

        // SQL injection probe patterns in query string
        if (ContainsSqlInjectionPattern(query))
            return true;

        // Excessive URL encoding is an obfuscation signal
        if (query.Length > 10)
        {
            var pctCount = query.Count(c => c == '%');
            if (pctCount > query.Length / 4)
                return true;
        }

        return false;
    }

    private static bool ContainsSqlInjectionPattern(string input)
    {
        if (string.IsNullOrEmpty(input)) return false;
        var lower = input.ToLowerInvariant();
        return lower.Contains("union") || lower.Contains(" select ") ||
               lower.Contains("drop ") || lower.Contains("<script") ||
               lower.Contains("1=1") || lower.Contains("or 1") ||
               lower.Contains("--") || lower.Contains(";--");
    }

    // ── State helpers ──────────────────────────────────────────────────────

    private bool IsKnownBot(string ip) =>
        _cache.TryGetValue($"blocked_bot:{ip}", out bool blocked) && blocked;

    private void FlagBot(string ip, TimeSpan duration) =>
        _cache.Set($"blocked_bot:{ip}", true, duration);

    private int IncrementCounter(string key, TimeSpan window)
    {
        var current = _cache.GetOrCreate(key, entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = window;
            return 0;
        });
        _cache.Set(key, current + 1, window);
        return current + 1;
    }

    private static async Task RespondAsync(HttpContext context, string reason)
    {
        context.Response.StatusCode = StatusCodes.Status429TooManyRequests;
        context.Response.ContentType = "application/json";
        context.Response.Headers["Retry-After"] = "3600";
        await context.Response.WriteAsJsonAsync(new
        {
            success = false,
            error = "Too many requests. Please try again later.",
            reason
        });
    }

    private sealed record BotResult(bool IsBot, int Confidence, bool IsWhitelisted = false);
}
