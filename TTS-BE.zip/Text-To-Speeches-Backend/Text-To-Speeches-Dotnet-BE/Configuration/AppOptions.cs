namespace Text_To_Speeches_Dotnet_BE.Configuration;

public sealed class ServerOptions
{
    public int Port { get; set; } = 5127;
    public string NodeEnv { get; set; } = "development";
}

public sealed class DatabaseOptions
{
    public string? Server { get; set; }
    public int Port { get; set; } = 1433;
    public string? User { get; set; }
    public string? Password { get; set; }
    public string? Database { get; set; }
    public bool Encrypt { get; set; } = true;
    public bool TrustServerCertificate { get; set; }
}

public sealed class JwtOptions
{
    public string? Secret { get; set; }
    public string ExpiresIn { get; set; } = "7d";
}

public sealed class GoogleOptions
{
    public string? ClientId { get; set; }
    public string? ClientSecret { get; set; }
}

public sealed class FrontendOptions
{
    public string ClientUrl { get; set; } = string.Empty;
}

public sealed class EmailVerificationOptions
{
    public int TokenExpiresHours { get; set; } = 24;
}

public sealed class BrevoOptions
{
    public string? ApiKey { get; set; }
    public string? SenderEmail { get; set; }
    public string? SenderName { get; set; }
}

public sealed class SpeechOptions
{
    public string? Key { get; set; }
    public string? Region { get; set; }
    public string? Endpoint { get; set; }
}

public sealed class TranslatorOptions
{
    public string? Key { get; set; }
    public string? Region { get; set; }
    public string? Endpoint { get; set; }
}

public sealed class AzureOpenAIOptions
{
    public string? Endpoint { get; set; }
    public string? Deployment { get; set; }
    public string ApiVersion { get; set; } = "2025-04-01-preview";
    public string? ApiKey { get; set; }
    public string SystemPrompt { get; set; } = "You are a helpful assistant. Reply in the same language as the user unless asked otherwise.";
    public int MaxTokens { get; set; } = 512;
    public float Temperature { get; set; } = 1.0f;
}

public sealed class AzureStorageOptions
{
    public string? ConnectionString { get; set; }
    public string FileShareName { get; set; } = "userfiles";
    public int RetentionHours { get; set; } = 24;
}

public sealed class GoogleTtsOptions
{
    public string ApiKey { get; set; } = string.Empty;
    public string ProjectId { get; set; } = string.Empty;
}
