
import React from 'react';
import { MAX_TEXT_LENGTH } from './src/constants';
import { useSpeechSynthesis } from './src/hooks/useSpeechSynthesis';
import Header from './src/components/Header';
import Footer from './src/components/Footer';
import SaveSessionModal from './src/components/SaveSessionModal';
import IntroSection from './src/components/IntroSection';
import VocalDynamics from './src/components/VocalDynamics';
import ExpressionEngine from './src/components/ExpressionEngine';
import GenerateButton from './src/components/GenerateButton';
import ArchiveSidebar from './src/components/ArchiveSidebar';
import VoiceLibrarySidebar from './src/components/VoiceLibrarySidebar';
import AudioPlayer from './src/components/AudioPlayer';

const App: React.FC = () => {
  const {
    theme, toggleTheme,
    text, setText, isTextTooLong, isTextEmpty,
    selectedVoice, setSelectedVoice, selectedVoiceInfo,
    rate, setRate, pitch, setPitch, volume, setVolume,
    isVocalDynamicsOpen, setIsVocalDynamicsOpen, resetVocalDynamics,
    style, setStyle, degree, setDegree,
    isExpressionEngineOpen, setIsExpressionEngineOpen,
    isDetecting, detectedLang, isMismatched,
    isProcessing, progress, error, handleGenerate,
    pendingEntry, setPendingEntry, recordingName, setRecordingName, saveToLibrary,
    historySearch, setHistorySearch, filteredHistory,
    handleDeleteHistoryItem, handlePlayHistoryItem,
    audioRef, currentEntry, handleClosePlayer,
    voiceSearch, setVoiceSearch, filteredVoices,
  } = useSpeechSynthesis();

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20">
      <audio ref={audioRef} className="hidden" />

      {pendingEntry && (
        <SaveSessionModal
          pendingEntry={pendingEntry}
          recordingName={recordingName}
          onRecordingNameChange={setRecordingName}
          onDiscard={() => setPendingEntry(null)}
          onSave={saveToLibrary}
        />
      )}

      <Header theme={theme} onToggleTheme={toggleTheme} />

      <main className="flex-1 max-w-[1800px] mx-auto w-full px-8 py-10 grid grid-cols-1 lg:grid-cols-12 gap-10">
        <ArchiveSidebar
          historySearch={historySearch}
          onHistorySearchChange={setHistorySearch}
          filteredHistory={filteredHistory}
          onDelete={handleDeleteHistoryItem}
          onPlay={handlePlayHistoryItem}
        />

        {/* CENTER: WORKSPACE */}
        <div className="lg:col-span-6 space-y-10">
          <IntroSection />

          <section className="glass studio-card !p-12 relative overflow-hidden group">
            <div className="flex items-center justify-between mb-10">
              <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Vocal Canvas</h2>
              {isDetecting ? (
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Analyzing Dialect...</span>
                </div>
              ) : detectedLang && detectedLang !== "Unknown" && (
                <div className="px-4 py-2 rounded-full border bg-emerald-500/10 text-[10px] font-black uppercase tracking-widest text-emerald-600 border-emerald-500/20">{detectedLang} Mode</div>
              )}
            </div>

            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={MAX_TEXT_LENGTH}
              placeholder="Insert your text here to generate the human like AI voices..."
              className="w-full h-56 bg-transparent text-xl font-medium text-slate-900 dark:text-slate-100 placeholder-slate-300 focus:outline-none resize-none leading-relaxed"
            />
            <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest mt-2">
              <span className="text-slate-400">Neural Buffer Capacity</span>
              <span className={isTextTooLong ? 'text-red-500' : 'text-slate-500'}>{text.length} / {MAX_TEXT_LENGTH}</span>
            </div>

            <div className="mt-12 space-y-6">
              <VocalDynamics
                isOpen={isVocalDynamicsOpen}
                onToggle={() => setIsVocalDynamicsOpen(!isVocalDynamicsOpen)}
                rate={rate}
                pitch={pitch}
                volume={volume}
                onRateChange={setRate}
                onPitchChange={setPitch}
                onVolumeChange={setVolume}
                onReset={resetVocalDynamics}
              />

              <ExpressionEngine
                isOpen={isExpressionEngineOpen}
                onToggle={() => setIsExpressionEngineOpen(!isExpressionEngineOpen)}
                style={style}
                degree={degree}
                onStyleChange={setStyle}
                onDegreeChange={setDegree}
              />
            </div>

            <GenerateButton
              isProcessing={isProcessing}
              isTextEmpty={isTextEmpty}
              isTextTooLong={isTextTooLong}
              isMismatched={isMismatched}
              progress={progress}
              detectedLang={detectedLang}
              selectedVoiceInfo={selectedVoiceInfo}
              error={error}
              onGenerate={handleGenerate} isAuthenticated={false}            />
          </section>
        </div>

        <VoiceLibrarySidebar
          voiceSearch={voiceSearch}
          onVoiceSearchChange={setVoiceSearch}
          filteredVoices={filteredVoices}
          selectedVoice={selectedVoice}
          onSelectVoice={setSelectedVoice}
        />
      </main>

      <Footer />

      {currentEntry && <AudioPlayer entry={currentEntry} audioRef={audioRef} onClose={handleClosePlayer} />}
    </div>
  );
};

export default App;
