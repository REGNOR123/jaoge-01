const ALLOWED_ROLES = new Set(["system", "user", "assistant"]);

const readEnv = (name, fallback = undefined) => {
  const raw = process.env[name];
  if (typeof raw === "string" && raw.trim().length > 0) return raw.trim();
  return fallback;
};

const isAzureEndpoint = (endpoint) =>
  typeof endpoint === "string" && endpoint.toLowerCase().includes(".openai.azure.com");

const json = (status, body) => ({
  status,
  headers: {
    "Content-Type": "application/json",
  },
  body,
});

const toNumber = (value, fallback) => {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "") {
    const asNumber = Number(value);
    if (Number.isFinite(asNumber)) return asNumber;
  }
  return fallback;
};

const safeString = (value) => (typeof value === "string" ? value : "");

const normalizeHistory = (history) => {
  if (!Array.isArray(history)) return [];

  const result = [];
  for (const item of history) {
    const role = safeString(item?.role);
    const content = safeString(item?.content);
    if (!ALLOWED_ROLES.has(role)) {
      throw new Error(`Invalid history role: ${role || "(empty)"}`);
    }
    if (!content.trim()) continue;
    result.push({ role, content });
  }
  return result;
};

module.exports = async function (context, req) {
  try {
    const OPENAI_ENDPOINT = readEnv("OPENAI_ENDPOINT");
    const OPENAI_API_KEY = readEnv("OPENAI_API_KEY");
    const OPENAI_MODEL = readEnv("OPENAI_MODEL");
    const OPENAI_API_VERSION = readEnv("OPENAI_API_VERSION", "2024-02-15-preview");

    if (!OPENAI_ENDPOINT || !OPENAI_API_KEY) {
      context.res = json(500, {
        success: false,
        error:
          "Missing required configuration: OPENAI_ENDPOINT and OPENAI_API_KEY must be set.",
      });
      return;
    }

    const body = req?.body ?? {};
    const message = safeString(body?.message);
    if (!message.trim()) {
      context.res = json(400, { success: false, error: "message is required." });
      return;
    }

    const history = normalizeHistory(body?.history);
    const systemPrompt = safeString(body?.systemPrompt);
    const requestedModel = safeString(body?.model);
    const model = requestedModel || OPENAI_MODEL || "";

    if (!model.trim()) {
      context.res = json(500, {
        success: false,
        error:
          "Missing required configuration: OPENAI_MODEL must be set (or provide model in the request).",
      });
      return;
    }

    const temperature = toNumber(body?.temperature, 0.7);
    const maxTokens = toNumber(body?.maxTokens, 300);

    const messages = [];
    if (systemPrompt.trim()) {
      messages.push({ role: "system", content: systemPrompt });
    }
    messages.push(...history);
    messages.push({ role: "user", content: message });

    const endpoint = OPENAI_ENDPOINT.replace(/\/+$/, "");
    const azure = isAzureEndpoint(endpoint);

    let url;
    let payload;
    const headers = {
      "Content-Type": "application/json",
    };

    if (azure) {
      headers["api-key"] = OPENAI_API_KEY;
      url = `${endpoint}/openai/deployments/${encodeURIComponent(
        model,
      )}/chat/completions?api-version=${encodeURIComponent(OPENAI_API_VERSION)}`;
      payload = {
        messages,
        temperature,
        max_tokens: maxTokens,
      };
    } else {
      headers["Authorization"] = `Bearer ${OPENAI_API_KEY}`;
      const base = endpoint.endsWith("/v1") ? endpoint : `${endpoint}/v1`;
      url = `${base}/chat/completions`;
      payload = {
        model,
        messages,
        temperature,
        max_tokens: maxTokens,
      };
    }

    const response = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      const errorMessage =
        data?.error?.message ||
        data?.message ||
        data?.error ||
        `Upstream request failed with status ${response.status}.`;
      context.res = json(response.status, { success: false, error: errorMessage });
      return;
    }

    const assistantMessage =
      data?.choices?.[0]?.message?.content ??
      data?.choices?.[0]?.delta?.content ??
      "";

    if (typeof assistantMessage !== "string" || !assistantMessage.trim()) {
      context.res = json(502, {
        success: false,
        error: "Unexpected response from model provider (missing assistant message).",
      });
      return;
    }

    const usage = data?.usage || {};
    const promptTokens = toNumber(usage?.prompt_tokens, 0);
    const completionTokens = toNumber(usage?.completion_tokens, 0);
    const totalTokens = toNumber(usage?.total_tokens, promptTokens + completionTokens);

    context.res = json(200, {
      success: true,
      data: {
        message: assistantMessage,
        model,
        usage: { promptTokens, completionTokens, totalTokens },
      },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unexpected error.";
    context.res = json(500, { success: false, error: message });
  }
};

