import { isDraftProject, type Project } from "../utils/projectsStorage";

export type ProjectTableStatus = "Completed" | "Processing" | "Draft";
export type ProjectTableType = "TRANSCRIPT" | "DUB" | "VOICE" | "SPEECHTRANSLATE" | "SCRIPT";

export type DateRangeValue = {
  from: string;
  to: string;
};

export type ProjectTableRow = {
  id: string;
  projectName: string;
  status: ProjectTableStatus;
  type: ProjectTableType;
  createdAt: string;
  lastModified: string;
};

export const formatProjectDate = (value: string) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "--";
  return date.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
};

export const formatRelativeDate = (value: string): string => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "--";
  const now = Date.now();
  const diffMs = now - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHrs = Math.floor(diffMin / 60);
  if (diffHrs < 24) return `${diffHrs}h ago`;
  const diffDays = Math.floor(diffHrs / 24);
  if (diffDays === 1) return "Yesterday";
  if (diffDays < 7) return `${diffDays}d ago`;
  return formatProjectDate(value);
};

export const withinDateRange = (value: string, range: DateRangeValue) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return false;

  if (range.from) {
    const start = new Date(range.from);
    start.setHours(0, 0, 0, 0);
    if (date < start) return false;
  }

  if (range.to) {
    const end = new Date(range.to);
    end.setHours(23, 59, 59, 999);
    if (date > end) return false;
  }

  return true;
};

const normalizeProjectType = (type: Project["type"]): ProjectTableType | null => {
  switch (type) {
    case "Transcript":
      return "TRANSCRIPT";
    case "Dub":
      return "DUB";
    case "Voice":
      return "VOICE";
    case "SpeechTranslate":
      return "SPEECHTRANSLATE";
    case "Script":
      return "SCRIPT";
    default:
      return null;
  }
};

export const toProjectTableRows = (projects: Project[]): ProjectTableRow[] => {
  return projects
    .map((project) => {
      const type = normalizeProjectType(project.type);
      if (!type) return null;

      return {
        id: project.id,
        projectName: project.name,
        status: isDraftProject(project) ? "Draft" : project.status,
        type,
        createdAt: project.created,
        lastModified: project.lastModified,
      } satisfies ProjectTableRow;
    })
    .filter((project): project is ProjectTableRow => Boolean(project));
};

