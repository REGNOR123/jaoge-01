export interface Language {
  code: string;
  name: string;
}

export const TARGET_LANGUAGES: Language[] = [
  { code: "en", name: "English" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "es", name: "Spanish" },
  { code: "it", name: "Italian" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "zh", name: "Chinese" },
  { code: "hi", name: "Hindi" },
  { code: "ar", name: "Arabic" },
  { code: "ru", name: "Russian" },
  { code: "tr", name: "Turkish" },
  { code: "vi", name: "Vietnamese" },
  { code: "nl", name: "Dutch" },
  { code: "pl", name: "Polish" },
  { code: "sv", name: "Swedish" },
  { code: "pt", name: "Portuguese" },
  { code: "el", name: "Greek" },
  { code: "th", name: "Thai" },
  { code: "he", name: "Hebrew" },
  { code: "da", name: "Danish" },
  { code: "fi", name: "Finnish" },
  { code: "no", name: "Norwegian" },
  // Indian Regional
  { code: "ta", name: "Tamil" },
  { code: "te", name: "Telugu" },
  { code: "kn", name: "Kannada" },
  { code: "ml", name: "Malayalam" },
  { code: "mr", name: "Marathi" },
  { code: "gu", name: "Gujarati" },
  { code: "pa", name: "Punjabi" },
  { code: "ur", name: "Urdu" },
  { code: "bn", name: "Bengali" },
  { code: "or", name: "Odia" },
  { code: "as", name: "Assamese" },
  // Southeast Asian
  { code: "id", name: "Indonesian" },
  { code: "fil", name: "Filipino" },
  { code: "ms", name: "Malay" },
];

export const RECOGNITION_LANGUAGES: Language[] = [
  { code: "en-US", name: "English (United States)" },
  { code: "en-GB", name: "English (United Kingdom)" },
  { code: "hi-IN", name: "Hindi (India)" },
  { code: "fr-FR", name: "French (France)" },
  { code: "de-DE", name: "German (Germany)" },
  { code: "es-ES", name: "Spanish (Spain)" },
  { code: "ja-JP", name: "Japanese (Japan)" },
  { code: "ko-KR", name: "Korean (Korea)" },
  { code: "zh-CN", name: "Chinese (Mandarin)" },
];

export const LANGUAGE_MAP: Record<string, string> = Object.fromEntries(
  TARGET_LANGUAGES.map((l) => [l.code, l.name]),
);
