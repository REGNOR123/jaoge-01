const PREFILL_SCRIPT_KEY = "tts_prefill_script_v1";

export interface PrefillScriptData {
  script: string;
  title?: string;
  sku?: string;
  tone?: string;
}

/**
 * Store a script (plain string or rich object) for the create-voice page to pick up.
 */
export const setPrefillScript = (data: string | PrefillScriptData) => {
  try {
    const payload =
      typeof data === "string" ? JSON.stringify({ script: data }) : JSON.stringify(data);
    sessionStorage.setItem(PREFILL_SCRIPT_KEY, payload);
  } catch {
    // ignore
  }
};

/**
 * Consume the stored script as a plain string (backward-compatible).
 */
export const consumePrefillScript = (): string | null => {
  try {
    const raw = sessionStorage.getItem(PREFILL_SCRIPT_KEY);
    if (!raw) return null;
    sessionStorage.removeItem(PREFILL_SCRIPT_KEY);
    try {
      const parsed = JSON.parse(raw);
      return typeof parsed === "object" && parsed.script
        ? parsed.script
        : raw;
    } catch {
      return raw;
    }
  } catch {
    return null;
  }
};

/**
 * Consume the stored script as a rich data object.
 */
export const consumePrefillScriptData = (): PrefillScriptData | null => {
  try {
    const raw = sessionStorage.getItem(PREFILL_SCRIPT_KEY);
    if (!raw) return null;
    sessionStorage.removeItem(PREFILL_SCRIPT_KEY);
    try {
      const parsed = JSON.parse(raw);
      return typeof parsed === "object" ? parsed : { script: raw };
    } catch {
      return { script: raw };
    }
  } catch {
    return null;
  }
};
