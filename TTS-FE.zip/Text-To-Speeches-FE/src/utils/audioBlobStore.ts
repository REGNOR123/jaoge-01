type StoredAudioBlob = {
  id: string;
  blob: Blob;
  createdAt: string;
  mimeType: string;
};

const DB_NAME = "tts_audio_uploads_v1";
const STORE_NAME = "audio_blobs";
const DB_VERSION = 1;

const openDb = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
  });
};

const withStore = async <T>(
  mode: IDBTransactionMode,
  fn: (store: IDBObjectStore) => IDBRequest<T>,
): Promise<T> => {
  const db = await openDb();
  return new Promise<T>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, mode);
    const store = tx.objectStore(STORE_NAME);
    const req = fn(store);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    tx.oncomplete = () => db.close();
    tx.onerror = () => {
      // prefer request error when possible
      reject(tx.error || req.error);
      db.close();
    };
  });
};

export const loadAudioBlob = async (id: string): Promise<Blob | null> => {
  const record = await withStore<StoredAudioBlob | undefined>("readonly", (store) => store.get(id));
  if (!record) return null;
  if (!(record as any).blob) return null;
  return (record as any).blob as Blob;
};

