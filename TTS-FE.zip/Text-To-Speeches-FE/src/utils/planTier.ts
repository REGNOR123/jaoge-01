export type PlanTier = "Free" | "Pro" | "Business" | "Enterprise" | "Unknown";

export const getPlanTierFromName = (planName: string | null | undefined): PlanTier => {
  const name = (planName || "").toLowerCase();
  if (!name) return "Unknown";
  if (name.includes("enterprise")) return "Enterprise";
  if (name.includes("business")) return "Business";
  if (name.includes("pro")) return "Pro";
  if (name.includes("free")) return "Free";
  return "Unknown";
};

export type UsageLimits = {
  voiceMinutesTotal: number | null;
  sttMinutesTotal: number | null;
  translationCharsTotal: number | null;
};

export const getDefaultUsageLimits = (tier: PlanTier): UsageLimits => {
  switch (tier) {
    case "Free":
      return { voiceMinutesTotal: 30, sttMinutesTotal: 30, translationCharsTotal: 10_000 };
    case "Pro":
      return { voiceMinutesTotal: 300, sttMinutesTotal: 300, translationCharsTotal: 250_000 };
    case "Business":
      return { voiceMinutesTotal: 2_000, sttMinutesTotal: 2_000, translationCharsTotal: 2_000_000 };
    case "Enterprise":
      return { voiceMinutesTotal: null, sttMinutesTotal: null, translationCharsTotal: null };
    default:
      return { voiceMinutesTotal: null, sttMinutesTotal: null, translationCharsTotal: null };
  }
};

