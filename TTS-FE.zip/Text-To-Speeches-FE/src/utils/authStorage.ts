export const AUTH_TOKEN_KEY = 'tts_auth_token';
export const AUTH_USER_KEY = 'tts_auth_user';
const AUTH_LAST_EMAIL_KEY = 'tts_auth_last_email';
const AUTH_LAST_NAME_KEY = 'tts_auth_last_name';
const REMEMBER_EMAIL_KEY = 'remember_email';

export function getLastEmail(): string {
  try {
    return localStorage.getItem(AUTH_LAST_EMAIL_KEY) || '';
  } catch {
    return '';
  }
}

export function setLastEmail(email: string): void {
  try {
    localStorage.setItem(AUTH_LAST_EMAIL_KEY, email);
  } catch {
    // ignore
  }
}

export function getLastName(): string {
  try {
    return localStorage.getItem(AUTH_LAST_NAME_KEY) || '';
  } catch {
    return '';
  }
}

export function setLastName(name: string): void {
  try {
    localStorage.setItem(AUTH_LAST_NAME_KEY, name);
  } catch {
    // ignore
  }
}

const isValidEmailFormat = (email: string): boolean => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

export function getRememberedEmail(): string {
  try {
    const rememberedEmail = localStorage.getItem(REMEMBER_EMAIL_KEY);
    if (!rememberedEmail) {
      return '';
    }

    const trimmedEmail = rememberedEmail.trim();
    if (!isValidEmailFormat(trimmedEmail)) {
      localStorage.removeItem(REMEMBER_EMAIL_KEY);
      return '';
    }

    return trimmedEmail;
  } catch {
    return '';
  }
}

export function setRememberedEmail(email: string): void {
  try {
    localStorage.setItem(REMEMBER_EMAIL_KEY, email.trim());
  } catch {
    // ignore
  }
}

export function clearRememberedEmail(): void {
  try {
    localStorage.removeItem(REMEMBER_EMAIL_KEY);
  } catch {
    // ignore
  }
}

export function clearAuthStorage(): void {
  try {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(AUTH_USER_KEY);
    localStorage.removeItem(AUTH_LAST_EMAIL_KEY);
    localStorage.removeItem(AUTH_LAST_NAME_KEY);
  } catch {
    // ignore
  }
}

