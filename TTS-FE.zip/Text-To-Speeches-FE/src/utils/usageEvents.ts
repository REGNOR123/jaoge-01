/**
 * Usage Event Tracking (Frontend)
 *
 * NOTE: Per architecture, the frontend does NOT store usage events.
 * The backend automatically tracks usage when feature endpoints are called.
 *
 * This function is a placeholder to maintain compatibility with existing code.
 * Actual usage tracking happens server-side in:
 * - TryTrackMinutesAsync
 * - TryTrackEnhancementAsync
 * - TryTrackJobStartedAsync / TryTrackJobCompletedAsync
 *
 * Frontend responsibilities:
 * 1. Show usage estimates before action
 * 2. Call backend feature endpoints (which trigger tracking)
 * 3. Display usage from GET /api/usage
 */

export interface UsageEvent {
  type: "voice" | "stt" | "translation" | string;
  unit: "minutes" | "chars" | string;
  amount: number;
  projectId: string;
  meta?: Record<string, any>;
}

/**
 * Records a usage event (placeholder - backend tracks actual usage)
 *
 * @param event - The usage event to record
 *
 * @example
 * addUsageEvent({
 *   type: "voice",
 *   unit: "minutes",
 *   amount: 2.5,
 *   projectId: "project-123",
 *   meta: { source: "create-voice", voice: "en-US-AriaNeural" }
 * });
 */
export const addUsageEvent = (event: UsageEvent): void => {
  // Frontend does not store usage events.
  // Backend automatically tracks when feature endpoints are called.
  // This function is retained for backward compatibility and potential debugging.

  if (process.env.NODE_ENV === "development") {
    console.debug("[UsageEvent]", event);
  }
};

