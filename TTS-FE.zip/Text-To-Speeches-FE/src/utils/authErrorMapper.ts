type AuthFlow = 'signup' | 'login' | 'verify' | 'resend';

interface AuthErrorInput {
  flow: AuthFlow;
  status?: number;
  error?: string;
  errors?: string[];
}

const FALLBACK_BY_FLOW: Record<AuthFlow, string> = {
  signup: 'Signup failed. Please try again.',
  login: 'Login failed. Please check your credentials.',
  verify: 'Verification failed. The link may be expired or invalid.',
  resend: 'Failed to resend verification email.',
};

export const mapAuthErrorMessage = ({
  flow,
  status,
  error,
  errors,
}: AuthErrorInput): string => {
  const normalizedError = (error || '').toLowerCase();
  const hasAlreadyRegisteredMessage =
    normalizedError.includes('already registered') ||
    normalizedError.includes('already exists') ||
    normalizedError.includes('email exists') ||
    normalizedError.includes('email already');

  if (status === 422 && errors?.length) {
    return errors.join(' ');
  }

  if (flow === 'verify' && status === 400) {
    return 'Invalid or expired verification token.';
  }

  if (flow === 'signup' && (status === 409 || hasAlreadyRegisteredMessage)) {
    return 'This email is already registered with us, please choose different email.';
  }

  if (status === 409) {
    return error || 'Email already registered.';
  }

  if (error) {
    return error;
  }

  return FALLBACK_BY_FLOW[flow];
};
