interface GoogleJwtPayload {
  email?: string;
}

const decodeBase64Url = (value: string): string => {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
  return atob(padded);
};

export const getGoogleCredentialEmail = (credential: string): string | null => {
  try {
    const parts = credential.split(".");
    if (parts.length < 2) {
      return null;
    }

    const payload = JSON.parse(decodeBase64Url(parts[1])) as GoogleJwtPayload;
    return typeof payload.email === "string" ? payload.email : null;
  } catch {
    return null;
  }
};
