export const isWavFile = (file: File): boolean => {
  return file.type === "audio/wav" || file.name.toLowerCase().endsWith(".wav");
};

export const isMp3File = (file: File): boolean => {
  return file.type === "audio/mpeg" || file.name.toLowerCase().endsWith(".mp3");
};

const getAudioContext = (): AudioContext => {
  const AudioContextCtor =
    (window as any).AudioContext || (window as any).webkitAudioContext;
  if (!AudioContextCtor) {
    throw new Error("Audio decoding is not supported in this browser.");
  }
  return new AudioContextCtor();
};

const getOfflineAudioContext = (
  channels: number,
  length: number,
  sampleRate: number,
): OfflineAudioContext => {
  const OfflineAudioContextCtor =
    (window as any).OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  if (!OfflineAudioContextCtor) {
    throw new Error("Offline audio rendering is not supported in this browser.");
  }
  return new OfflineAudioContextCtor(channels, length, sampleRate);
};

export const decodeAudioFileToBuffer = async (file: File): Promise<AudioBuffer> => {
  const audioCtx = getAudioContext();
  try {
    const data = await file.arrayBuffer();
    return await audioCtx.decodeAudioData(data.slice(0));
  } catch (err) {
    throw new Error("Failed to decode audio file.");
  } finally {
    try {
      await audioCtx.close();
    } catch {
      // ignore
    }
  }
};

export const resampleToMono16k = async (input: AudioBuffer): Promise<AudioBuffer> => {
  const targetSampleRate = 16000;
  const durationSeconds = input.duration || input.length / input.sampleRate;
  const targetLength = Math.max(1, Math.ceil(durationSeconds * targetSampleRate));

  const offline = getOfflineAudioContext(1, targetLength, targetSampleRate);
  const src = offline.createBufferSource();
  src.buffer = input;

  const merger = offline.createChannelMerger(input.numberOfChannels);
  src.connect(merger);

  const gain = offline.createGain();
  merger.connect(gain);
  gain.connect(offline.destination);

  src.start(0);
  return await offline.startRendering();
};

const floatTo16BitPCM = (output: DataView, offset: number, input: Float32Array) => {
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i]));
    output.setInt16(offset + i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
};

const writeString = (view: DataView, offset: number, str: string) => {
  for (let i = 0; i < str.length; i++) {
    view.setUint8(offset + i, str.charCodeAt(i));
  }
};

export const encodeWavPcm16Mono = (buffer: AudioBuffer): ArrayBuffer => {
  const channelData = buffer.getChannelData(0);
  const sampleRate = buffer.sampleRate;
  const bytesPerSample = 2;
  const blockAlign = bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  const dataSize = channelData.length * bytesPerSample;

  const wavBuffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(wavBuffer);

  writeString(view, 0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeString(view, 8, "WAVE");
  writeString(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeString(view, 36, "data");
  view.setUint32(40, dataSize, true);
  floatTo16BitPCM(view, 44, channelData);

  return wavBuffer;
};


