export type ProjectType = "Voice" | "Transcript" | "Dub" | "SpeechTranslate" | "Script";
export type ProjectStatus = "Completed" | "Processing";

export type ProjectScript = {
  id: string;
  text: string;
  createdAt: string;
  fileId?: string;
  contentType?: string;
  fileName?: string;
  expiresAt?: string;
  source?: string;
};

export type ProjectAudioVersion = {
  id: string;
  audioUrl: string;
  createdAt: string;
  fileId?: string;
  contentType?: string;
  fileName?: string;
  expiresAt?: string;
  voice?: string;
  voiceLabel?: string;
  settings?: Record<string, unknown>;
  estimatedMinutes?: number;
};

export type ProjectTranscript = {
  id: string;
  text: string;
  createdAt: string;
  fileId?: string;
  contentType?: string;
  fileName?: string;
  expiresAt?: string;
  language?: string;
  includeTimestamps?: boolean;
};

export type ProjectLanguageVariant = {
  id: string;
  createdAt: string;
  sourceLang?: string;
  targetLang?: string;
  sourceText: string;
  translatedText: string;
};

export type ProjectUsage = {
  voiceMinutesUsed?: number;
  sttMinutesUsed?: number;
  translationCharsUsed?: number;
};

export type ProjectData = {
  drafts?: {
    voice?: {
      script?: string;
      language?: string;
      voice?: string;
      rate?: number;
      pitch?: number;
      updatedAt: string;
    };
    transcript?: {
      language?: string;
      autoPunctuation?: boolean;
      includeTimestamps?: boolean;
      fileName?: string;
      durationSeconds?: number;
      transcript?: string;
      updatedAt: string;
    };
    dub?: {
      mode?: "text" | "audio";
      sourceText?: string;
      translatedText?: string;
      sourceLang?: string;
      targetLang?: string;
      voice?: string;
      text?: {
        projectName?: string;
        sourceText?: string;
        translatedText?: string;
        sourceLang?: string;
        targetLang?: string;
        voice?: string;
        updatedAt: string;
      };
      audio?: {
        projectName?: string;
        transcriptText?: string;
        translatedText?: string;
        sourceLang?: string;
        targetLang?: string;
        voice?: string;
        updatedAt: string;
      };
      updatedAt: string;
    };
    speechTranslate?: {
      targets?: string[];
      outputFormat?: "mp3" | "wav";
      showTextOutput?: boolean;
      voicesByTarget?: Record<string, string>;
      detectedLanguage?: string;
      recognizedText?: string;
      translationsByTarget?: Record<string, string>;
      updatedAt: string;
    };
    scriptStudio?: {
      scriptType?: string;
      formInputs?: Record<string, string>;
      topic?: string;
      tone?: string;
      length?: string;
      script?: string;
      updatedAt: string;
    };
  };
  outputs?: {
    scripts?: ProjectScript[];
    audioVersions?: ProjectAudioVersion[];
    transcripts?: ProjectTranscript[];
    languages?: ProjectLanguageVariant[];
  };
  usage?: ProjectUsage;
};

export type Project = {
  id: string;
  name: string;
  type: ProjectType;
  status: ProjectStatus;
  created: string;
  lastModified: string;
  data?: ProjectData;
};

const PROJECTS_KEY = "tts_projects_v1";
const MAX_PROJECTS = 50; // Limit to prevent quota issues

const safeParse = <T>(value: string | null): T | null => {
  if (!value) return null;
  try {
    return JSON.parse(value) as T;
  } catch {
    return null;
  }
};

/** Read raw projects array from localStorage (no sorting/normalization beyond basic validation) */
const readRawProjects = (): Project[] => {
  if (typeof window === "undefined") return [];
  const parsed = safeParse<Project[]>(localStorage.getItem(PROJECTS_KEY));
  if (!Array.isArray(parsed)) return [];
  return parsed
    .filter((p) => p && typeof p.id === "string" && typeof p.name === "string")
    .map((p) => {
      const created = typeof (p as any).created === "string" ? (p as any).created : p.lastModified;
      return { ...p, created } as Project;
    });
};

export const listProjects = (): Project[] => {
  return readRawProjects()
    .sort((a, b) => new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime());
};

export const getProjectById = (id: string): Project | null => {
  return readRawProjects().find((p) => p.id === id) || null;
};

export const isDraftProject = (project: Project): boolean => {
  if (project.status === "Completed") return false;
  const drafts = project.data?.drafts;
  if (!drafts) return false;
  return Boolean(drafts.voice || drafts.transcript || drafts.dub || drafts.scriptStudio || drafts.speechTranslate);
};

/**
 * Clean up old projects to free localStorage space
 * Removes oldest projects beyond MAX_PROJECTS limit
 */
const cleanupOldProjects = (projects: Project[]): Project[] => {
  if (projects.length <= MAX_PROJECTS) return projects;
  
  // Sort by lastModified (newest first) and keep only MAX_PROJECTS
  const sorted = [...projects].sort(
    (a, b) => new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime()
  );
  
  const kept = sorted.slice(0, MAX_PROJECTS);
  const removed = sorted.length - MAX_PROJECTS;
  console.log(`Cleaned up ${removed} old projects to free storage space`);
  
  return kept;
};

/**
 * Trim large data fields from projects to reduce storage size
 */
const trimProjectData = (project: Project): Project => {
  if (!project.data) return project;
  
  const trimmedData = { ...project.data };
  
  // Trim large audio URLs (data URLs can be huge)
  if (trimmedData.outputs?.audioVersions) {
    trimmedData.outputs = {
      ...trimmedData.outputs,
      audioVersions: trimmedData.outputs.audioVersions.map((audio) => {
        // Keep managed file references, remove data URLs
        if (audio.audioUrl?.startsWith("data:")) {
          return { ...audio, audioUrl: "" };
        }
        return audio;
      }),
    };
  }
  
  // Trim large scripts (keep only first 1000 chars for preview)
  if (trimmedData.outputs?.scripts) {
    trimmedData.outputs = {
      ...trimmedData.outputs,
      scripts: trimmedData.outputs.scripts.map((script) => ({
        ...script,
        text: script.text?.length > 1000 ? script.text.slice(0, 1000) + "..." : script.text,
      })),
    };
  }
  
  return { ...project, data: trimmedData };
};

const writeProjects = (projects: Project[]): boolean => {
  try {
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
    return true;
  } catch (e) {
    // Check if it's a quota error
    if (e instanceof DOMException && (e.name === "QuotaExceededError" || e.code === 22)) {
      console.warn("localStorage quota exceeded, attempting cleanup...");
      
      // Try 1: Clean up old projects
      const cleaned = cleanupOldProjects(projects);
      if (cleaned.length < projects.length) {
        try {
          localStorage.setItem(PROJECTS_KEY, JSON.stringify(cleaned));
          console.log("Successfully wrote projects after cleanup");
          return true;
        } catch {
          // Continue to next strategy
        }
      }
      
      // Try 2: Trim data from all projects
      const trimmed = cleaned.map(trimProjectData);
      try {
        localStorage.setItem(PROJECTS_KEY, JSON.stringify(trimmed));
        console.log("Successfully wrote projects after trimming data");
        return true;
      } catch {
        // Continue to next strategy
      }
      
      // Try 3: Keep only minimal project info (last resort)
      const minimal = trimmed.slice(0, 20).map((p) => ({
        id: p.id,
        name: p.name,
        type: p.type,
        status: p.status,
        created: p.created,
        lastModified: p.lastModified,
      }));
      try {
        localStorage.setItem(PROJECTS_KEY, JSON.stringify(minimal));
        console.log("Successfully wrote minimal projects after aggressive cleanup");
        return true;
      } catch {
        console.error("Failed to write projects even after aggressive cleanup");
      }
    }
    
    console.error("Failed to write projects to localStorage:", e);
    return false;
  }
};

const upsertProject = (project: Project): Project | null => {
  const projects = listProjects();
  const idx = projects.findIndex((p) => p.id === project.id);
  const next = idx >= 0 ? projects.map((p, i) => (i === idx ? project : p)) : [project, ...projects];
  if (!writeProjects(next)) return null;
  return project;
};

export const createProject = (params: {
  name: string;
  type: ProjectType;
  status?: ProjectStatus;
  data?: ProjectData;
}): Project | null => {
  const now = new Date().toISOString();
  const project: Project = {
    id: crypto.randomUUID(),
    name: params.name.trim() || "Untitled Project",
    type: params.type,
    status: params.status || "Processing",
    created: now,
    lastModified: now,
    ...(params.data ? { data: params.data } : {}),
  };
  return upsertProject(project);
};

export const updateProject = (
  id: string,
  patch: Partial<Omit<Project, "id">>,
): Project | null => {
  const existing = getProjectById(id);
  if (!existing) return null;
  const updated: Project = {
    ...existing,
    ...patch,
    created: patch.created || existing.created,
    lastModified: patch.lastModified || new Date().toISOString(),
  };
  return upsertProject(updated);
};

export const deleteProject = (id: string): boolean => {
  const projects = readRawProjects();
  const next = projects.filter((p) => p.id !== id);
  if (next.length === projects.length) return false;
  return writeProjects(next);
};

export const deleteProjects = (ids: string[]): boolean => {
  if (ids.length === 0) return true;
  const idSet = new Set(ids);
  const projects = readRawProjects();
  const next = projects.filter((p) => !idSet.has(p.id));
  if (next.length === projects.length) return false;
  return writeProjects(next);
};

export const duplicateProject = (id: string): Project | null => {
  const existing = getProjectById(id);
  if (!existing) return null;
  const now = new Date().toISOString();
  const copy: Project = {
    ...existing,
    id: crypto.randomUUID(),
    name: `${existing.name} (Copy)`,
    created: now,
    lastModified: now,
    data: existing.data ? JSON.parse(JSON.stringify(existing.data)) : undefined,
  };
  return upsertProject(copy);
};

export const updateProjectsStatus = (ids: string[], status: ProjectStatus): boolean => {
  if (ids.length === 0) return true;
  const idSet = new Set(ids);
  const projects = readRawProjects();
  const now = new Date().toISOString();
  const next = projects.map((p) =>
    idSet.has(p.id) ? { ...p, status, lastModified: now } : p
  );
  return writeProjects(next);
};

