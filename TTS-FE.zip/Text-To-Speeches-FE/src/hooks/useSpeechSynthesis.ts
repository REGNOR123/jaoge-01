
import { useState, useRef, useEffect, useMemo } from 'react';
import { VoiceName, SpeechEntry, SpeechStyle } from '../types';
import { MAX_TEXT_LENGTH, AVAILABLE_VOICES } from '../constants';
import { generateAzureSpeech } from '../services/azureService';
import { detectTextLanguage, translateText } from '../services/langService';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useCredits } from '../contexts/CreditContext';

export const useSpeechSynthesis = () => {
  const { isAuthenticated, token } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { refreshBalance } = useCredits();

  const [text, setText] = useState('');
  const [selectedVoice, setSelectedVoice] = useState<VoiceName>(VoiceName.JENNY);
  const [rate, setRate] = useState(0);
  const [pitch, setPitch] = useState(0);
  const [volume, setVolume] = useState(100);
  const [style, setStyle] = useState<SpeechStyle>('general');
  const [degree, setDegree] = useState(1.0);

  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isDetecting, setIsDetecting] = useState(false);
  const [detectedLang, setDetectedLang] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [insufficientCreditsInfo, setInsuffCreditsInfo] = useState<{ required: number; current: number } | null>(null);

  const [history, setHistory] = useState<SpeechEntry[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const savedHistory = localStorage.getItem('speechSynthesisHistory');
      return savedHistory ? JSON.parse(savedHistory) : [];
    } catch (err) {
      console.warn('Failed to load history from localStorage:', err);
      return [];
    }
  });
  const [currentEntry, setCurrentEntry] = useState<SpeechEntry | null>(null);
  const [pendingEntry, setPendingEntry] = useState<Partial<SpeechEntry> | null>(null);
  const [recordingName, setRecordingName] = useState('');

  const [historySearch, setHistorySearch] = useState('');
  const [voiceSearch, setVoiceSearch] = useState('');

  const [isVocalDynamicsOpen, setIsVocalDynamicsOpen] = useState(true);
  const [isExpressionEngineOpen, setIsExpressionEngineOpen] = useState(false);
  const [isVoiceLibraryOpen, setIsVoiceLibraryOpen] = useState(true);
  const [isTranslating, setIsTranslating] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const detectTimeout = useRef<number | null>(null);
  const progressInterval = useRef<number | null>(null);
  const lastDetectedText = useRef<string>("");

  // Cleanup effect
  useEffect(() => {
    return () => {
      if (progressInterval.current) window.clearInterval(progressInterval.current);
    };
  }, []);

  // Persist history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('speechSynthesisHistory', JSON.stringify(history));
    } catch (err) {
      console.warn('Failed to save history to localStorage:', err);
    }
  }, [history]);

  // Language detection effect
  useEffect(() => {
    if (detectTimeout.current) window.clearTimeout(detectTimeout.current);
    // Allow language detection for both authenticated users and guests
    const trimmedText = text.trim();
    if (trimmedText.length < 5) {
      lastDetectedText.current = trimmedText;
      setDetectedLang(null);
      setIsDetecting(false);
      return;
    }
    if (trimmedText === lastDetectedText.current) {
      return;
    }
    setIsDetecting(true);
    detectTimeout.current = window.setTimeout(async () => {
      try {
        const lang = await detectTextLanguage(trimmedText, token);
        setDetectedLang(lang);
        lastDetectedText.current = trimmedText;
      } catch (err) {
        console.warn("Language detection failed.");
      } finally {
        setIsDetecting(false);
      }
    }, 1000);
    return () => {
      if (detectTimeout.current) window.clearTimeout(detectTimeout.current);
    };
  }, [text]);

  const selectedVoiceInfo = AVAILABLE_VOICES.find(v => v.id === selectedVoice);

  const doesLanguageMatch = () => {
    if (!detectedLang || !selectedVoiceInfo) return true;
    if (detectedLang === "Unknown") return true;
    return selectedVoiceInfo.lang.toLowerCase().includes(detectedLang.toLowerCase());
  };

  const isTextTooLong = text.length > MAX_TEXT_LENGTH;
  const isMismatched = !!(detectedLang && detectedLang !== "Unknown" && !doesLanguageMatch());
  const isTextEmpty = text.trim().length === 0;

  const handleGenerate = async () => {
    if (isTextEmpty) { setError('Please enter some text.'); return null; }
    if (isMismatched) return null;
    if (isTextTooLong) { setError(`Character limit exceeded (${MAX_TEXT_LENGTH} max).`); return null; }

    setIsProcessing(true);
    setProgress(0);
    setError(null);

    progressInterval.current = window.setInterval(() => {
      setProgress(prev => {
        if (prev >= 95) return prev;
        const diff = Math.random() * 8 + 2;
        return Math.min(95, Math.floor(prev + diff));
      });
    }, 250);

    try {
      if (!selectedVoiceInfo) throw new Error("Invalid voice selection");
      const audioUrl = await generateAzureSpeech(text.trim(), selectedVoice, rate, pitch, volume, style, degree, token);

      setProgress(100);
      await new Promise(r => setTimeout(r, 400));

      const generatedEntry = {
        text: text.trim(),
        voice: selectedVoice,
        voiceLabel: `${selectedVoiceInfo.name} (${selectedVoiceInfo.lang})`,
        audioUrl: audioUrl,
        settings: { rate, pitch, volume, style, degree }
      };

      setPendingEntry(generatedEntry);
      setRecordingName(`Clip - ${style} - ${selectedVoiceInfo.name}`);
      void refreshBalance();
      return generatedEntry;
    } catch (err: any) {
      if ((err as any).insufficientCredits) {
        setInsuffCreditsInfo({ required: (err as any).requiredCredits ?? 0, current: (err as any).currentBalance ?? 0 });
      } else {
        setError(err.message || 'Synthesis failed. This voice might not support the selected expression style.');
      }
      return null;
    } finally {
      if (progressInterval.current) window.clearInterval(progressInterval.current);
      setIsProcessing(false);
      setProgress(0);
    }
  };

  const saveToLibrary = () => {
    if (!pendingEntry || !recordingName.trim()) return;
    const newEntry: SpeechEntry = {
      id: crypto.randomUUID(),
      recordingName: recordingName.trim(),
      text: pendingEntry.text!,
      voice: pendingEntry.voice!,
      voiceLabel: pendingEntry.voiceLabel!,
      timestamp: Date.now(),
      audioUrl: pendingEntry.audioUrl!,
      settings: pendingEntry.settings as any
    };
    setHistory(prev => [newEntry, ...prev]);
    setPendingEntry(null);
    setRecordingName('');
  };

  const resetVocalDynamics = () => {
    setRate(0);
    setPitch(0);
    setVolume(100);
  };

  const handleClosePlayer = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current.src = "";
    }
    setCurrentEntry(null);
  };

  const handleDeleteHistoryItem = (id: string) => {
    if (currentEntry?.id === id) handleClosePlayer();
    setHistory(prev => prev.filter(item => item.id !== id));
  };

  const handlePlayHistoryItem = (entry: SpeechEntry) => {
    if (audioRef.current && entry.audioUrl) {
      setCurrentEntry(entry);
      audioRef.current.src = entry.audioUrl;
      audioRef.current.load();
      audioRef.current.play().catch((err) => {
        console.error('Failed to play audio:', err);
        setError('Failed to play audio. Please try again.');
      });
    }
  };

  const handleTranslateText = async () => {
    if (!isAuthenticated) return;
    if (!detectedLang || !selectedVoiceInfo || isTranslating) return;
    
    setIsTranslating(true);
    try {
      // Get the target language code from the selected voice's language
      const voiceLangCode = selectedVoiceInfo.id.split('-')[0]; // e.g., "es" from "es-MX-DaliaNeural"
      const translated = await translateText(text, voiceLangCode, token);
      
      if (translated) {
        setText(translated);
        setDetectedLang(selectedVoiceInfo.lang);
      } else {
        setError('Translation failed. Please try again.');
      }
    } catch (err) {
      setError('Translation error. Please try again.');
      console.error('Translation error:', err);
    } finally {
      setIsTranslating(false);
    }
  };

  const filteredHistory = useMemo(() => {
    return history.filter(entry =>
      entry.recordingName.toLowerCase().includes(historySearch.toLowerCase()) ||
      entry.voiceLabel.toLowerCase().includes(historySearch.toLowerCase())
    );
  }, [history, historySearch]);

  const filteredVoices = useMemo(() => {
    return AVAILABLE_VOICES.filter(voice =>
      voice.name.toLowerCase().includes(voiceSearch.toLowerCase()) ||
      voice.lang.toLowerCase().includes(voiceSearch.toLowerCase())
    );
  }, [voiceSearch]);

  return {
    // Theme
    theme,
    toggleTheme,
    // Text input
    text,
    setText,
    isTextTooLong,
    isTextEmpty,
    // Voice
    selectedVoice,
    setSelectedVoice,
    selectedVoiceInfo,
    // Vocal dynamics
    rate,
    setRate,
    pitch,
    setPitch,
    volume,
    setVolume,
    isVocalDynamicsOpen,
    setIsVocalDynamicsOpen,
    resetVocalDynamics,
    // Expression
    style,
    setStyle,
    degree,
    setDegree,
    isExpressionEngineOpen,
    setIsExpressionEngineOpen,
    isVoiceLibraryOpen,
    setIsVoiceLibraryOpen,
    // Language detection
    isDetecting,
    detectedLang,
    isMismatched,
    isTranslating,
    handleTranslateText,
    // Processing
    isProcessing,
    progress,
    error,
    insufficientCreditsInfo,
    clearInsuffCreditsInfo: () => setInsuffCreditsInfo(null),
    handleGenerate,
    // Save / pending
    pendingEntry,
    setPendingEntry,
    recordingName,
    setRecordingName,
    saveToLibrary,
    // History
    historySearch,
    setHistorySearch,
    filteredHistory,
    handleDeleteHistoryItem,
    handlePlayHistoryItem,
    // Audio player
    audioRef,
    currentEntry,
    handleClosePlayer,
    // Voice search
    voiceSearch,
    setVoiceSearch,
    filteredVoices,
    isAuthenticated,
  };
};
