import { useCallback, useEffect, useState } from "react";
import {
  fetchSimpleUsageSummary,
  type SimpleUsageSummary,
} from "../services/usageApiService";

export type UseSimpleUsageResult = {
  // Data
  usage: SimpleUsageSummary | null;

  // Loading state
  loading: boolean;

  // Error state
  error: string | null;

  // Actions
  refresh: () => void;
  setDateRange: (startDate?: string, endDate?: string) => void;
};

export const useSimpleUsage = (token: string | null): UseSimpleUsageResult => {
  // Data state
  const [usage, setUsage] = useState<SimpleUsageSummary | null>(null);

  // Loading state
  const [loading, setLoading] = useState(false);

  // Error state
  const [error, setError] = useState<string | null>(null);

  // Date range state
  const [startDate, setStartDate] = useState<string | undefined>(undefined);
  const [endDate, setEndDate] = useState<string | undefined>(undefined);

  // Load usage data
  const loadUsage = useCallback(async () => {
    if (!token) return;

    setLoading(true);
    setError(null);

    const result = await fetchSimpleUsageSummary(token, startDate, endDate);

    if (result.success) {
      setUsage(result.data);
    } else {
      setError(result.error);
    }

    setLoading(false);
  }, [token, startDate, endDate]);

  // Initial load
  useEffect(() => {
    if (!token) {
      setUsage(null);
      setError(null);
      return;
    }

    loadUsage();
  }, [token, loadUsage]);

  // Actions
  const setDateRange = useCallback((start?: string, end?: string) => {
    setStartDate(start);
    setEndDate(end);
  }, []);

  const refresh = useCallback(() => {
    loadUsage();
  }, [loadUsage]);

  return {
    usage,
    loading,
    error,
    refresh,
    setDateRange,
  };
};
