import { useCallback, useEffect, useState } from "react";
import {
  fetchDetailedUsage,
  fetchUsageBreakdown,
  fetchUsageHistory,
  type DateFilterType,
  type DetailedUsageResponse,
  type UsageBreakdown,
  type UsageHistoryResponse,
} from "../services/usageApiService";

export type UseUsagePageResult = {
  // Data
  detailedUsage: DetailedUsageResponse | null;
  breakdown: UsageBreakdown | null;
  history: UsageHistoryResponse | null;

  // Loading states
  loading: boolean;
  breakdownLoading: boolean;
  historyLoading: boolean;

  // Error states
  error: string | null;
  breakdownError: string | null;
  historyError: string | null;

  // Filter state
  dateFilter: DateFilterType;
  historyFilter: DateFilterType;

  // Actions
  setDateFilter: (filter: DateFilterType) => void;
  setHistoryFilter: (filter: DateFilterType) => void;
  loadBreakdownPage: (page: number) => void;
  sortBreakdown: (sortBy: string, descending: boolean) => void;
  refresh: () => void;
};

export const useUsagePage = (token: string | null): UseUsagePageResult => {
  // Data states
  const [detailedUsage, setDetailedUsage] = useState<DetailedUsageResponse | null>(null);
  const [breakdown, setBreakdown] = useState<UsageBreakdown | null>(null);
  const [history, setHistory] = useState<UsageHistoryResponse | null>(null);

  // Loading states
  const [loading, setLoading] = useState(false);
  const [breakdownLoading, setBreakdownLoading] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Error states
  const [error, setError] = useState<string | null>(null);
  const [breakdownError, setBreakdownError] = useState<string | null>(null);
  const [historyError, setHistoryError] = useState<string | null>(null);

  // Filter states
  const [dateFilter, setDateFilter] = useState<DateFilterType>("monthly");
  const [historyFilter, setHistoryFilter] = useState<DateFilterType>("daily");

  // Breakdown pagination/sorting state
  const [breakdownPage, setBreakdownPage] = useState(1);
  const [breakdownSortBy, setBreakdownSortBy] = useState("minutesConsumed");
  const [breakdownDescending, setBreakdownDescending] = useState(true);

  // Load detailed usage
  const loadDetailedUsage = useCallback(async () => {
    if (!token) return;

    setLoading(true);
    setError(null);

    const result = await fetchDetailedUsage(token, dateFilter);

    if (result.success) {
      setDetailedUsage(result.data);
    } else {
      setError(result.error);
    }

    setLoading(false);
  }, [token, dateFilter]);

  // Load breakdown with pagination
  const loadBreakdown = useCallback(async () => {
    if (!token) return;

    setBreakdownLoading(true);
    setBreakdownError(null);

    const result = await fetchUsageBreakdown(token, {
      page: breakdownPage,
      pageSize: 10,
      sortBy: breakdownSortBy,
      descending: breakdownDescending,
      filter: dateFilter,
    });

    if (result.success) {
      setBreakdown(result.data);
    } else {
      setBreakdownError(result.error);
    }

    setBreakdownLoading(false);
  }, [token, breakdownPage, breakdownSortBy, breakdownDescending, dateFilter]);

  // Load history for charts
  const loadHistory = useCallback(async () => {
    if (!token) return;

    setHistoryLoading(true);
    setHistoryError(null);

    const days = historyFilter === "daily" ? 30 : historyFilter === "weekly" ? 90 : 365;
    const result = await fetchUsageHistory(token, historyFilter, undefined, days);

    if (result.success) {
      setHistory(result.data);
    } else {
      setHistoryError(result.error);
    }

    setHistoryLoading(false);
  }, [token, historyFilter]);

  // Initial load
  useEffect(() => {
    if (!token) {
      setDetailedUsage(null);
      setBreakdown(null);
      setHistory(null);
      setError(null);
      return;
    }

    loadDetailedUsage();
    loadHistory();
  }, [token, loadDetailedUsage, loadHistory]);

  // Load breakdown when dependencies change
  useEffect(() => {
    if (token) {
      loadBreakdown();
    }
  }, [token, loadBreakdown]);

  // Actions
  const handleSetDateFilter = useCallback((filter: DateFilterType) => {
    setDateFilter(filter);
    setBreakdownPage(1); // Reset pagination when filter changes
  }, []);

  const handleSetHistoryFilter = useCallback((filter: DateFilterType) => {
    setHistoryFilter(filter);
  }, []);

  const loadBreakdownPage = useCallback((page: number) => {
    setBreakdownPage(page);
  }, []);

  const sortBreakdown = useCallback((sortBy: string, descending: boolean) => {
    setBreakdownSortBy(sortBy);
    setBreakdownDescending(descending);
    setBreakdownPage(1); // Reset to first page when sorting changes
  }, []);

  const refresh = useCallback(() => {
    loadDetailedUsage();
    loadBreakdown();
    loadHistory();
  }, [loadDetailedUsage, loadBreakdown, loadHistory]);

  return {
    detailedUsage,
    breakdown,
    history,
    loading,
    breakdownLoading,
    historyLoading,
    error,
    breakdownError,
    historyError,
    dateFilter,
    historyFilter,
    setDateFilter: handleSetDateFilter,
    setHistoryFilter: handleSetHistoryFilter,
    loadBreakdownPage,
    sortBreakdown,
    refresh,
  };
};
