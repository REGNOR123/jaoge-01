import { useAuth } from '../contexts/AuthContext';
import { useDbWakeUp } from './useDbWakeUp';
import { DbWakeUpState } from './useDbWakeUp';

export const useApiWithDbWakeUp = () => {
  const { setShowDbWakeUp, setDbWakeUpState } = useAuth();
  const { wakeUpDatabase } = useDbWakeUp();

  const fetchWithWakeUp = async (
    endpoint: string,
    options: RequestInit = {}
  ): Promise<Response> => {
    const makeRequest = () => fetch(endpoint, options);

    const response = await makeRequest();

    if (response.status === 500) {
      setShowDbWakeUp(true);

      const isOnline = await wakeUpDatabase((state: DbWakeUpState) => {
        setDbWakeUpState(state);
      }, 60);

      if (isOnline) {
        const retryResponse = await makeRequest();
        setShowDbWakeUp(false);
        setDbWakeUpState(null);
        return retryResponse;
      }

      setShowDbWakeUp(false);
      setDbWakeUpState(null);
    }

    return response;
  };

  return { fetchWithWakeUp };
};
