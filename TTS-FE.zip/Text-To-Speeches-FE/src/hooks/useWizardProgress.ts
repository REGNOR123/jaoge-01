import { useCallback, useEffect, useRef, useState } from "react";

type UseWizardProgressOptions = {
  /** Interval in ms between increments (default: 140) */
  interval?: number;
  /** Max random bump size added to base (default: 12) */
  maxBump?: number;
  /** Base bump added each tick (default: 6) */
  baseBump?: number;
  /** Pause at this percent until finish is called (default: 90) */
  ceiling?: number;
  /** Delay in ms to hold 100% before resetting (default: 500) */
  finishDelay?: number;
};

export type WizardProgress = {
  inProgress: boolean;
  percent: number;
  start: () => void;
  stop: () => void;
  finish: () => Promise<void>;
};

export function useWizardProgress(options?: UseWizardProgressOptions): WizardProgress {
  const {
    interval = 140,
    maxBump = 12,
    baseBump = 6,
    ceiling = 90,
    finishDelay = 500,
  } = options ?? {};

  const [inProgress, setInProgress] = useState(false);
  const [percent, setPercent] = useState(0);
  const intervalRef = useRef<number | null>(null);

  const clearTimer = useCallback(() => {
    if (intervalRef.current != null) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  const stop = useCallback(() => {
    clearTimer();
    setInProgress(false);
    setPercent(0);
  }, [clearTimer]);

  const start = useCallback(() => {
    stop();
    setInProgress(true);
    setPercent(0);
    intervalRef.current = window.setInterval(() => {
      setPercent((prev) => {
        if (prev >= ceiling) return prev;
        const bump = Math.random() * maxBump + baseBump;
        return Math.min(ceiling, Math.floor(prev + bump));
      });
    }, interval);
  }, [stop, interval, maxBump, baseBump, ceiling]);

  const finish = useCallback(async () => {
    clearTimer();
    setPercent(100);
    await new Promise((r) => window.setTimeout(r, finishDelay));
    setInProgress(false);
    setPercent(0);
  }, [clearTimer, finishDelay]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current != null) {
        window.clearInterval(intervalRef.current);
      }
    };
  }, []);

  return { inProgress, percent, start, stop, finish };
}
