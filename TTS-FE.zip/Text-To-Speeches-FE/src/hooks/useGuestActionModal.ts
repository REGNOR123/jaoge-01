import { useState, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';

interface UseGuestActionModalResult {
  isModalOpen: boolean;
  actionName: string | undefined;
  openModal: (actionName?: string) => void;
  closeModal: () => void;
  checkAndProceed: (actionName?: string) => boolean;
  isGuest: boolean;
}

/**
 * Hook to manage the guest action modal.
 * Shows a modal prompting guests to sign up when they try actions.
 * 
 * Usage:
 * ```tsx
 * const { checkAndProceed, isModalOpen, closeModal, actionName } = useGuestActionModal();
 * 
 * const handleCreateVoice = () => {
 *   if (!checkAndProceed('Create Voice')) return;
 *   // proceed with action
 * };
 * 
 * return (
 *   <>
 *     <button onClick={handleCreateVoice}>Create Voice</button>
 *     <GuestActionModal 
 *       isOpen={isModalOpen} 
 *       onClose={closeModal}
 *       actionName={actionName}
 *       onContinueAsGuest={() => { closeModal(); handleCreateVoice(); }}
 *     />
 *   </>
 * );
 * ```
 */
export function useGuestActionModal(): UseGuestActionModalResult {
  const { isAuthenticated, isLoading } = useAuth();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [actionName, setActionName] = useState<string | undefined>(undefined);
  
  const isGuest = !isLoading && !isAuthenticated;

  const openModal = useCallback((name?: string) => {
    setActionName(name);
    setIsModalOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setActionName(undefined);
  }, []);

  /**
   * Check if user is guest and show modal if so.
   * Returns true if authenticated (can proceed), false if guest (modal shown).
   */
  const checkAndProceed = useCallback((name?: string): boolean => {
    if (isLoading) return false;
    if (isAuthenticated) return true;
    
    // User is guest - show modal
    openModal(name);
    return false;
  }, [isLoading, isAuthenticated, openModal]);

  return {
    isModalOpen,
    actionName,
    openModal,
    closeModal,
    checkAndProceed,
    isGuest,
  };
}

export default useGuestActionModal;
