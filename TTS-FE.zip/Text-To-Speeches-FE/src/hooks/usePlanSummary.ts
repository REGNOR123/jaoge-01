import { useEffect, useMemo, useState } from "react";
import { fetchPlanSummary, type PlanSummary } from "../services/dashboardApiService";
import { getDefaultUsageLimits, getPlanTierFromName } from "../utils/planTier";

export const usePlanSummary = (token: string | null) => {
  const [planSummary, setPlanSummary] = useState<PlanSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      setPlanSummary(null);
      setLoading(false);
      setError(null);
      return;
    }

    let active = true;
    const run = async () => {
      setLoading(true);
      setError(null);
      const res = await fetchPlanSummary(token);
      if (!active) return;
      if (res.success === true) setPlanSummary(res.data);
      else setError(res.error);
      setLoading(false);
    };
    run();
    return () => {
      active = false;
    };
  }, [token]);

  const tier = useMemo(() => getPlanTierFromName(planSummary?.planName), [planSummary?.planName]);
  const defaultLimits = useMemo(() => getDefaultUsageLimits(tier), [tier]);

  const voiceMinutesTotal = useMemo(() => {
    if (defaultLimits.voiceMinutesTotal != null) return defaultLimits.voiceMinutesTotal;
    if (typeof planSummary?.minutesRemaining === "number") return null;
    return null;
  }, [defaultLimits.voiceMinutesTotal, planSummary?.minutesRemaining]);

  return {
    planSummary,
    loading,
    error,
    tier,
    defaultLimits: { ...defaultLimits, voiceMinutesTotal },
  };
};
