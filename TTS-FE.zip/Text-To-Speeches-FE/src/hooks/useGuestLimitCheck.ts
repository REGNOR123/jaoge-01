import { useCallback, useState } from "react";
import { useGuestUsage, type UsageType } from "../contexts/GuestUsageContext";

type UseGuestLimitCheckResult = {
  /** Check if action is allowed and show modal if not */
  checkAndProceed: (type: UsageType, amount?: number) => boolean;
  /** Increment usage after successful action */
  recordUsage: (type: UsageType, amount?: number) => void;
  /** Whether the limit modal is showing */
  isLimitModalOpen: boolean;
  /** The usage type that triggered the modal */
  limitType: UsageType | null;
  /** Close the limit modal */
  closeModal: () => void;
  /** Check if user is a guest */
  isGuest: boolean;
  /** Get remaining quota for a type */
  getRemaining: (type: UsageType) => number;
  /** Get usage percentage for a type */
  getUsagePercentage: (type: UsageType) => number;
};

/**
 * Hook for managing guest usage limits in feature components.
 * 
 * Usage:
 * ```tsx
 * const { checkAndProceed, recordUsage, isLimitModalOpen, closeModal } = useGuestLimitCheck();
 * 
 * const handleGenerate = async () => {
 *   // Check limit before action
 *   if (!checkAndProceed("characters", text.length)) return;
 *   
 *   // Perform action
 *   const result = await generateSpeech(text);
 *   
 *   // Record usage after success
 *   if (result.success) {
 *     recordUsage("characters", text.length);
 *   }
 * };
 * ```
 */
export const useGuestLimitCheck = (): UseGuestLimitCheckResult => {
  const {
    isGuest,
    canUse,
    incrementUsage,
    getRemaining,
    getUsagePercentage,
  } = useGuestUsage();

  const [isLimitModalOpen, setIsLimitModalOpen] = useState(false);
  const [limitType, setLimitType] = useState<UsageType | null>(null);

  const checkAndProceed = useCallback((type: UsageType, amount: number = 1): boolean => {
    // Authenticated users can proceed (they have their own limits)
    if (!isGuest) return true;

    // Check if guest has remaining quota
    if (canUse(type, amount)) {
      return true;
    }

    // Limit reached - show modal
    setLimitType(type);
    setIsLimitModalOpen(true);
    return false;
  }, [isGuest, canUse]);

  const recordUsage = useCallback((type: UsageType, amount: number = 1): void => {
    if (isGuest) {
      incrementUsage(type, amount);
    }
  }, [isGuest, incrementUsage]);

  const closeModal = useCallback((): void => {
    setIsLimitModalOpen(false);
    setLimitType(null);
  }, []);

  return {
    checkAndProceed,
    recordUsage,
    isLimitModalOpen,
    limitType,
    closeModal,
    isGuest,
    getRemaining,
    getUsagePercentage,
  };
};

/**
 * Helper to estimate voice minutes from character count.
 * Average speaking rate: ~150 words per minute
 * Average word length: ~5 characters
 * So ~750 characters per minute
 */
export const estimateVoiceMinutes = (characters: number): number => {
  const charsPerMinute = 750;
  return Math.ceil(characters / charsPerMinute);
};

/**
 * Helper to estimate voice minutes from audio duration in seconds.
 */
export const secondsToMinutes = (seconds: number): number => {
  return Math.ceil(seconds / 60);
};
