export interface DbWakeUpState {
  isWaking: boolean;
  progress: number;
  message: string;
  elapsedSeconds: number;
  nextRetryIn: number;
}

export const useDbWakeUp = () => {
  const wakeUpDatabase = async (
    onProgress?: (state: DbWakeUpState) => void,
    timeoutSeconds = 60
  ): Promise<boolean> => {
    const messages = [
      'Waking up the database...',
      'Almost there...',
      'One more moment...',
      'Getting ready...',
      'Syncing resources...',
      'Finalizing connection...',
    ];

    const startTime = Date.now();
    let attempt = 0;
    let backoffMs = 1000;

    while (Date.now() - startTime < timeoutSeconds * 1000) {
      try {
        const response = await fetch('/api/health/wake-database', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
        });
        const data = await response.json();

        if (data.online) return true;
      } catch (err) {
        // Network error, will retry
      }

      const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
      const progress = Math.min(90, Math.round((elapsedSeconds / timeoutSeconds) * 90));

      onProgress?.({
        isWaking: true,
        progress,
        message: messages[attempt % messages.length],
        elapsedSeconds,
        nextRetryIn: Math.ceil(backoffMs / 1000),
      });

      await new Promise(resolve => setTimeout(resolve, backoffMs));
      backoffMs = Math.min(backoffMs * 2, 15000);
      attempt++;
    }

    return false;
  };

  return { wakeUpDatabase };
};
