import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  AuthUser,
  loginWithEmail,
  signupWithEmail,
  loginWithGoogle,
  getCurrentUser,
  verifyEmailCode,
} from '../services/authApiService';
import {
  AUTH_TOKEN_KEY,
  AUTH_USER_KEY,
  clearAuthStorage,
  setLastEmail,
  setLastName,
} from '../utils/authStorage';

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; status?: number; error?: string; errors?: string[] }>;
  signup: (fullName: string, email: string, password: string) => Promise<{ success: boolean; status?: number; message?: string; error?: string; errors?: string[]; authenticated?: boolean; verificationUrl?: string }>;
  verifyCode: (email: string, code: string) => Promise<{ success: boolean; status?: number; error?: string; errors?: string[] }>;
  googleLogin: (credential: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateUser: (user: AuthUser) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Restore session from localStorage on mount
  useEffect(() => {
    const restoreSession = async () => {
      const savedToken = localStorage.getItem(AUTH_TOKEN_KEY);
      const savedUser = localStorage.getItem(AUTH_USER_KEY);

      if (savedToken) {
        const restoreCachedUser = () => {
          if (!savedUser) {
            clearAuthStorage();
            return;
          }

          try {
            const parsedUser = JSON.parse(savedUser);
            setUser(parsedUser);
            setToken(savedToken);
            setLastEmail(parsedUser.email);
            setLastName(parsedUser.fullName);
          } catch {
            clearAuthStorage();
          }
        };

        try {
          // Validate token with backend
          const res = await getCurrentUser(savedToken);
          if (res.success && res.user) {
            setUser(res.user);
            setToken(savedToken);
            localStorage.setItem(AUTH_USER_KEY, JSON.stringify(res.user));
            setLastEmail(res.user.email);
            setLastName(res.user.fullName);
          } else if (res.status === 401 || res.status === 403) {
            // Explicit unauthorized response means token is no longer valid.
            clearAuthStorage();
          } else {
            // Backend may be temporarily unavailable (cold start, timeout, etc.),
            // so keep the previous local session instead of forcing logout.
            restoreCachedUser();
          }
        } catch {
          // If backend unreachable, use cached user data if available.
          restoreCachedUser();
        }
      }
      setIsLoading(false);
    };

    restoreSession();
  }, []);

  const persistSession = useCallback((authToken: string, authUser: AuthUser) => {
    setToken(authToken);
    setUser(authUser);
    localStorage.setItem(AUTH_TOKEN_KEY, authToken);
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(authUser));
    setLastEmail(authUser.email);
    setLastName(authUser.fullName);
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const res = await loginWithEmail(email, password);
    if (res.success && res.token && res.user) {
      persistSession(res.token, res.user);
      return { success: true };
    }
    return { success: false, status: res.status, error: res.error, errors: res.errors };
  }, [persistSession]);

  const signup = useCallback(async (fullName: string, email: string, password: string) => {
    const res = await signupWithEmail(fullName, email, password);
    if (res.success) {
      if (res.token && res.user) {
        persistSession(res.token, res.user);
        return {
          success: true,
          status: res.status,
          message: res.message,
          authenticated: true,
          verificationUrl: res.verificationUrl,
        };
      }
      return {
        success: true,
        status: res.status,
        message: res.message,
        authenticated: false,
        verificationUrl: res.verificationUrl,
      };
    }
    return {
      success: false,
      status: res.status,
      error: res.error,
      errors: res.errors,
    };
  }, [persistSession]);

  const verifyCode = useCallback(async (email: string, code: string) => {
    const res = await verifyEmailCode(email, code);
    if (res.success && res.token && res.user) {
      persistSession(res.token, res.user);
      return { success: true };
    }
    return { success: false, status: res.status, error: res.error, errors: res.errors };
  }, [persistSession]);

  const googleLoginHandler = useCallback(async (credential: string) => {
    const res = await loginWithGoogle(credential);
    if (res.success && res.token && res.user) {
      persistSession(res.token, res.user);
      return { success: true };
    }
    return { success: false, error: res.error };
  }, [persistSession]);

  const logout = useCallback(() => {
    setUser(null);
    setToken(null);
    clearAuthStorage();
  }, []);

  const updateUser = useCallback((updatedUser: AuthUser) => {
    setUser(updatedUser);
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(updatedUser));
    setLastEmail(updatedUser.email);
    setLastName(updatedUser.fullName);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user && !!token,
        isLoading,
        login,
        signup,
        verifyCode,
        googleLogin: googleLoginHandler,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
