import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { getCreditBalance } from '../services/creditApiService';

export interface CreditContextType {
  balance: number | null;
  isLoading: boolean;
  refreshBalance: () => Promise<void>;
  estimateCost: (feature: string, chars?: number) => number;
}

const CreditContext = createContext<CreditContextType | undefined>(undefined);

const FALLBACK_COSTS: Record<string, { creditCost: number; costPerNChars: number | null; minCost: number }> = {
  'create-voice':     { creditCost: 1,  costPerNChars: 100,  minCost: 1 },
  'transcribe':       { creditCost: 10, costPerNChars: null, minCost: 10 },
  'translate-text':   { creditCost: 15, costPerNChars: null, minCost: 15 },
  'speech-translate': { creditCost: 20, costPerNChars: null, minCost: 20 },
  'translate-dub':    { creditCost: 1,  costPerNChars: 125,  minCost: 1 },
  'text-translate':   { creditCost: 3,  costPerNChars: 1000, minCost: 1 },
  'detect-language':  { creditCost: 1,  costPerNChars: null, minCost: 1 },
  'script-generate':  { creditCost: 4,  costPerNChars: null, minCost: 4 },
  'auto-generate':    { creditCost: 2,  costPerNChars: null, minCost: 2 },
  'script-transform': { creditCost: 3,  costPerNChars: null, minCost: 3 },
  'ai-enhance':       { creditCost: 2,  costPerNChars: null, minCost: 2 },
  'voice-clone-generate':  { creditCost: 50, costPerNChars: null, minCost: 50 },
  'voice-clone-synthesize': { creditCost: 10, costPerNChars: null, minCost: 10 },
};

export const CreditProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, token } = useAuth();
  const [balance, setBalance] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const refreshBalance = useCallback(async () => {
    if (!isAuthenticated || !token) {
      setBalance(null);
      return;
    }
    setIsLoading(true);
    try {
      const res = await getCreditBalance(token);
      if (res.success && res.data != null) {
        setBalance(res.data.balance);
      }
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated, token]);

  useEffect(() => {
    refreshBalance();
  }, [refreshBalance]);

  const estimateCost = useCallback((feature: string, chars = 0): number => {
    const cost = FALLBACK_COSTS[feature];
    if (!cost) return 0;
    if (cost.costPerNChars && chars > 0) {
      return Math.max(cost.minCost, Math.ceil(chars / cost.costPerNChars) * cost.creditCost);
    }
    return cost.creditCost;
  }, []);

  return (
    <CreditContext.Provider value={{ balance, isLoading, refreshBalance, estimateCost }}>
      {children}
    </CreditContext.Provider>
  );
};

export const useCredits = (): CreditContextType => {
  const context = useContext(CreditContext);
  if (!context) throw new Error('useCredits must be used within a CreditProvider');
  return context;
};
