import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef, type ReactNode } from "react";
import { useAuth } from "./AuthContext";

const GUEST_ID_KEY = "guest_id";
const GUEST_USAGE_KEY = "guest_usage";
const TWENTY_FOUR_HOURS_MS = 24 * 60 * 60 * 1000;

// Guest plan limits (hidden trial plan)
export const GUEST_PLAN_LIMITS = {
  characters: 1000,
  voiceMinutes: 5,
  aiEnhancements: 5,
  autoGenerate: 5,
} as const;

export type GuestUsage = {
  guest_id: string;
  characters_used: number;
  voice_minutes_used: number;
  ai_enhancements_used: number;
  auto_generate_used: number;
  created_at: number;
  // Store limits for reference
  limits: {
    characters: number;
    voiceMinutes: number;
    aiEnhancements: number;
    autoGenerate: number;
  };
};

export type UsageType = "characters" | "voiceMinutes" | "aiEnhancements" | "autoGenerate";

type LimitCheckResult = {
  allowed: boolean;
  remaining: number;
  used: number;
  limit: number;
  usageType: UsageType;
};

type GuestUsageContextType = {
  guestId: string | null;
  isGuest: boolean;
  usage: GuestUsage | null;
  checkLimit: (type: UsageType, amount?: number) => LimitCheckResult;
  canUse: (type: UsageType, amount?: number) => boolean;
  incrementUsage: (type: UsageType, amount?: number) => void;
  getRemaining: (type: UsageType) => number;
  getUsed: (type: UsageType) => number;
  getLimit: (type: UsageType) => number;
  getUsagePercentage: (type: UsageType) => number;
  resetUsage: () => void;
  showLimitModal: boolean;
  limitModalType: UsageType | null;
  openLimitModal: (type: UsageType) => void;
  showLimitReachedModal: (type: UsageType) => void;
  closeLimitModal: () => void;
  clearGuestData: () => void;
  // Force refresh from localStorage
  refreshUsage: () => void;
};

const GuestUsageContext = createContext<GuestUsageContextType | undefined>(undefined);

// Generate a unique guest ID using UUID
const generateGuestId = (): string => {
  return crypto.randomUUID();
};

// Get or create guest ID
const getOrCreateGuestId = (): string => {
  try {
    const existingId = localStorage.getItem(GUEST_ID_KEY);
    if (existingId) return existingId;
    
    const newId = generateGuestId();
    localStorage.setItem(GUEST_ID_KEY, newId);
    return newId;
  } catch {
    // Fallback if localStorage is unavailable
    return generateGuestId();
  }
};

const createDefaultUsage = (guestId: string): GuestUsage => ({
  guest_id: guestId,
  characters_used: 0,
  voice_minutes_used: 0,
  ai_enhancements_used: 0,
  auto_generate_used: 0,
  created_at: Date.now(),
  limits: {
    characters: GUEST_PLAN_LIMITS.characters,
    voiceMinutes: GUEST_PLAN_LIMITS.voiceMinutes,
    aiEnhancements: GUEST_PLAN_LIMITS.aiEnhancements,
    autoGenerate: GUEST_PLAN_LIMITS.autoGenerate,
  },
});

// Simple encoding to prevent casual tampering
const encodeUsage = (usage: GuestUsage): string => {
  const json = JSON.stringify(usage);
  // Simple checksum: sum of char codes
  const checksum = json.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
  return btoa(JSON.stringify({ data: json, checksum }));
};

const decodeUsage = (encoded: string): GuestUsage | null => {
  try {
    const decoded = JSON.parse(atob(encoded)) as { data: string; checksum: number };
    const expectedChecksum = decoded.data.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
    
    // Verify checksum
    if (decoded.checksum !== expectedChecksum) {
      console.warn("Guest usage checksum mismatch - data may have been tampered");
      return null;
    }
    
    return JSON.parse(decoded.data) as GuestUsage;
  } catch {
    return null;
  }
};

const loadUsageFromStorage = (): GuestUsage | null => {
  try {
    const stored = localStorage.getItem(GUEST_USAGE_KEY);
    if (!stored) return null;

    // Try to decode (new format) or parse directly (old format)
    let parsed: GuestUsage | null = null;
    
    // Try new encoded format first
    parsed = decodeUsage(stored);
    
    // Fallback to old JSON format for backwards compatibility
    if (!parsed) {
      try {
        parsed = JSON.parse(stored) as GuestUsage;
      } catch {
        // Invalid data
      }
    }
    
    if (!parsed) {
      localStorage.removeItem(GUEST_USAGE_KEY);
      return null;
    }
    
    // Reset if older than 24 hours
    if (Date.now() - parsed.created_at > TWENTY_FOUR_HOURS_MS) {
      localStorage.removeItem(GUEST_USAGE_KEY);
      localStorage.removeItem(GUEST_ID_KEY);
      return null;
    }

    // Ensure guest_id exists (migration from old format)
    if (!parsed.guest_id) {
      parsed.guest_id = getOrCreateGuestId();
    }
    
    // Ensure limits exist (migration)
    if (!parsed.limits) {
      parsed.limits = {
        characters: GUEST_PLAN_LIMITS.characters,
        voiceMinutes: GUEST_PLAN_LIMITS.voiceMinutes,
        aiEnhancements: GUEST_PLAN_LIMITS.aiEnhancements,
        autoGenerate: GUEST_PLAN_LIMITS.autoGenerate,
      };
    }

    return parsed;
  } catch {
    localStorage.removeItem(GUEST_USAGE_KEY);
    return null;
  }
};

const saveUsageToStorage = (usage: GuestUsage): void => {
  try {
    const encoded = encodeUsage(usage);
    localStorage.setItem(GUEST_USAGE_KEY, encoded);
    
    // Dispatch custom event for cross-component updates
    window.dispatchEvent(new CustomEvent('guest-usage-updated', { detail: usage }));
  } catch {
    // Storage full or unavailable
  }
};

const getUsageField = (usage: GuestUsage, type: UsageType): number => {
  switch (type) {
    case "characters":
      return usage.characters_used;
    case "voiceMinutes":
      return usage.voice_minutes_used;
    case "aiEnhancements":
      return usage.ai_enhancements_used;
    case "autoGenerate":
      return usage.auto_generate_used;
  }
};

const getLimitForType = (type: UsageType): number => {
  switch (type) {
    case "characters":
      return GUEST_PLAN_LIMITS.characters;
    case "voiceMinutes":
      return GUEST_PLAN_LIMITS.voiceMinutes;
    case "aiEnhancements":
      return GUEST_PLAN_LIMITS.aiEnhancements;
    case "autoGenerate":
      return GUEST_PLAN_LIMITS.autoGenerate;
  }
};

export const GuestUsageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  const [usage, setUsage] = useState<GuestUsage | null>(null);
  const [guestId, setGuestId] = useState<string | null>(null);
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [limitModalType, setLimitModalType] = useState<UsageType | null>(null);
  
  // Version counter to force re-renders when usage updates
  const [, forceUpdate] = useState(0);

  // Determine if user is a guest (not authenticated)
  const isGuest = useMemo(() => !isLoading && !isAuthenticated, [isLoading, isAuthenticated]);

  // Refresh usage from localStorage
  const refreshUsage = useCallback(() => {
    const stored = loadUsageFromStorage();
    if (stored) {
      setUsage(stored);
      setGuestId(stored.guest_id);
    }
    forceUpdate(v => v + 1);
  }, []);

  // Initialize or load guest usage
  useEffect(() => {
    if (isGuest) {
      const stored = loadUsageFromStorage();
      if (stored) {
        setUsage(stored);
        setGuestId(stored.guest_id);
      } else {
        const newGuestId = getOrCreateGuestId();
        const newUsage = createDefaultUsage(newGuestId);
        saveUsageToStorage(newUsage);
        setUsage(newUsage);
        setGuestId(newGuestId);
      }
    } else {
      // Don't clear guest data when authenticated - just hide it
      // This allows merging on signup
      setUsage(null);
      setGuestId(null);
    }
  }, [isGuest]);

  // Listen for cross-component usage updates
  useEffect(() => {
    const handleUsageUpdate = (event: CustomEvent<GuestUsage>) => {
      setUsage(event.detail);
      forceUpdate(v => v + 1);
    };

    window.addEventListener('guest-usage-updated', handleUsageUpdate as EventListener);
    
    return () => {
      window.removeEventListener('guest-usage-updated', handleUsageUpdate as EventListener);
    };
  }, []);

  const getUsed = useCallback((type: UsageType): number => {
    if (!usage) return 0;
    return getUsageField(usage, type);
  }, [usage]);

  const getLimit = useCallback((type: UsageType): number => {
    return getLimitForType(type);
  }, []);

  const getRemaining = useCallback((type: UsageType): number => {
    const limit = getLimit(type);
    const used = getUsed(type);
    return Math.max(0, limit - used);
  }, [getLimit, getUsed]);

  const getUsagePercentage = useCallback((type: UsageType): number => {
    const limit = getLimit(type);
    const used = getUsed(type);
    return Math.min(100, Math.round((used / limit) * 100));
  }, [getLimit, getUsed]);

  const checkLimit = useCallback((type: UsageType, amount: number = 1): LimitCheckResult => {
    const limit = getLimit(type);
    const used = getUsed(type);
    const remaining = Math.max(0, limit - used);
    const allowed = remaining >= amount;

    return {
      allowed,
      remaining,
      used,
      limit,
      usageType: type,
    };
  }, [getLimit, getUsed]);

  const canUse = useCallback((type: UsageType, amount: number = 1): boolean => {
    if (!isGuest) return true; // Authenticated users have their own limits
    return checkLimit(type, amount).allowed;
  }, [isGuest, checkLimit]);

  const incrementUsage = useCallback((type: UsageType, amount: number = 1): void => {
    if (!isGuest) return;

    setUsage(currentUsage => {
      if (!currentUsage) return currentUsage;
      
      const newUsage = { ...currentUsage };
      switch (type) {
        case "characters":
          newUsage.characters_used += amount;
          break;
        case "voiceMinutes":
          newUsage.voice_minutes_used += amount;
          break;
        case "aiEnhancements":
          newUsage.ai_enhancements_used += 1;
          break;
        case "autoGenerate":
          newUsage.auto_generate_used += 1;
          break;
      }

      // Persist to localStorage (this also dispatches event for other components)
      saveUsageToStorage(newUsage);
      return newUsage;
    });
  }, [isGuest]);

  const resetUsage = useCallback((): void => {
    const id = guestId || getOrCreateGuestId();
    const newUsage = createDefaultUsage(id);
    setUsage(newUsage);
    saveUsageToStorage(newUsage);
  }, [guestId]);

  const openLimitModal = useCallback((type: UsageType): void => {
    setLimitModalType(type);
    setShowLimitModal(true);
  }, []);

  const showLimitReachedModal = useCallback((type: UsageType): void => {
    openLimitModal(type);
  }, [openLimitModal]);

  const closeLimitModal = useCallback((): void => {
    setShowLimitModal(false);
    setLimitModalType(null);
  }, []);

  const clearGuestData = useCallback((): void => {
    localStorage.removeItem(GUEST_USAGE_KEY);
    localStorage.removeItem(GUEST_ID_KEY);
    setUsage(null);
    setGuestId(null);
  }, []);

  const contextValue = useMemo<GuestUsageContextType>(() => ({
    guestId,
    isGuest,
    usage,
    checkLimit,
    canUse,
    incrementUsage,
    getRemaining,
    getUsed,
    getLimit,
    getUsagePercentage,
    resetUsage,
    showLimitModal,
    limitModalType,
    openLimitModal,
    showLimitReachedModal,
    closeLimitModal,
    clearGuestData,
    refreshUsage,
  }), [
    guestId,
    isGuest,
    usage,
    checkLimit,
    canUse,
    incrementUsage,
    getRemaining,
    getUsed,
    getLimit,
    getUsagePercentage,
    resetUsage,
    showLimitModal,
    limitModalType,
    openLimitModal,
    showLimitReachedModal,
    closeLimitModal,
    clearGuestData,
    refreshUsage,
  ]);

  return (
    <GuestUsageContext.Provider value={contextValue}>
      {children}
    </GuestUsageContext.Provider>
  );
};

export const useGuestUsage = (): GuestUsageContextType => {
  const context = useContext(GuestUsageContext);
  if (context === undefined) {
    throw new Error("useGuestUsage must be used within a GuestUsageProvider");
  }
  return context;
};

// Helper function to get readable usage type label
export const getUsageTypeLabel = (type: UsageType): string => {
  switch (type) {
    case "characters":
      return "characters";
    case "voiceMinutes":
      return "voice minutes";
    case "aiEnhancements":
      return "AI enhancements";
    case "autoGenerate":
      return "auto-generations";
  }
};
