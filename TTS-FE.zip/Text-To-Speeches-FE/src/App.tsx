
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import PrivacyPage from './pages/PrivacyPage';
import TermsPage from './pages/TermsPage';
import DocsPage from './pages/DocsPage';
import HelpPage from './pages/HelpPage';
import PricingPage from './pages/PricingPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import VerifyEmailPage from './pages/VerifyEmailPage';
import VerifyCodePage from './pages/VerifyCodePage';
import AboutPage from './pages/AboutPage';
import ChatWidget from './components/ChatWidget';
import AppShell from './components/app/AppShell';
import DashboardPage from './pages/DashboardPage';
import CreateVoicePage from './pages/CreateVoicePage';
import ScriptStudioPage from './pages/ScriptStudioPage';
import AccountPage from './pages/AccountPage';
import TranscribePage from './pages/TranscribePage';
import TranslateDubPage from './pages/TranslateDubPage';
import ProjectsPage from './pages/ProjectsPage';
import ProjectDetailPage from './pages/ProjectDetailPage';
import SpeechTranslatePage from "./pages/SpeechTranslatePage";
import VoiceClonePage from "./pages/VoiceClonePage";
import { DialogProvider } from "./components/dialogs";

const App: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();

  // Loading spinner while checking auth
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-white to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
          <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <DialogProvider>
        <Routes>
          {/* Public Routes */}
          <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <LoginPage />} />
          <Route path="/signup" element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <SignupPage />} />
          <Route path="/verify-email" element={<VerifyEmailPage />} />
          <Route path="/verify-code" element={<VerifyCodePage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/docs" element={<DocsPage />} />
          <Route path="/help" element={<HelpPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/pricing" element={<PricingPage />} />

          {/* Home */}
          <Route path="/" element={<Navigate to="/dashboard" replace />} />

          {/* Legacy feature routes -> app */}
          <Route path="/translate" element={<Navigate to="/translate-dub" replace />} />
          <Route path="/speech-to-text" element={<Navigate to="/transcribe" replace />} />
          <Route path="/speech-to-speech" element={<Navigate to="/translate-dub" replace />} />
          <Route path="/audio-library" element={<Navigate to="/projects" replace />} />

          {/* App (Post-login layout) */}
          <Route element={<AppShell />}>
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/create-voice" element={<CreateVoicePage />} />
            <Route path="/transcribe" element={<TranscribePage />} />
            <Route path="/translate-dub" element={<TranslateDubPage />} />
            <Route path="/speech-translate" element={<SpeechTranslatePage />} />
            <Route path="/voice-clone" element={<VoiceClonePage />} />
            <Route path="/script-studio" element={<ScriptStudioPage />} />
            <Route path="/projects" element={<ProjectsPage />} />
            <Route path="/projects/:projectId" element={<ProjectDetailPage />} />
            <Route path="/account" element={isAuthenticated ? <AccountPage /> : <Navigate to="/login" replace state={{ from: "/account" }} />} />
            <Route path="/app/*" element={<Navigate to="/dashboard" replace />} />
          </Route>

          <Route path="/dashboard/*" element={<Navigate to="/dashboard" replace />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>

        <ChatWidget />
      </DialogProvider>
    </>
  );
};

export default App;
