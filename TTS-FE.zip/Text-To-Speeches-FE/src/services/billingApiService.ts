import { API_BASE } from "./apiBase";

export type ApiResult<T> =
  | { success: true; status: number; data: T }
  | { success: false; status?: number; error: string };

export type BillingSummary = {
  planName: string | null;
  planBadge: string | null;
  planPrice: number | null;
  planCurrency: string | null;
  planInterval: string | null;
  cycleStart: string | null;
  cycleEnd: string | null;
  nextBillingDate: string | null;
  daysRemaining: number | null;
};

export type BillingMetrics = {
  currentPlanPrice: number | null;
  currentCycleSpend: number | null;
  totalSpend: number | null;
  nextBillingAmount: number | null;
  currency: string | null;
};

export type PaymentMethod = {
  cardBrand: string | null;
  last4: string | null;
  expiryMonth: number | null;
  expiryYear: number | null;
  billingEmail: string | null;
};

export type Invoice = {
  id: string;
  date: string;
  number?: string;
  amount?: number | null;
  currency?: string;
  status?: string;
  downloadUrl?: string;
};

const getAuthHeaders = (token: string): Record<string, string> => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${token}`,
});

const getResponseMessage = (data: any, fallback: string): string => {
  return data?.message || data?.error || fallback;
};

const toNumberOrNull = (value: unknown): number | null => {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  return null;
};

const toStringOrNull = (value: unknown): string | null => {
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : null;
};

const parseBody = async (response: Response): Promise<any> => {
  try {
    return await response.json();
  } catch {
    return null;
  }
};

const readEnvEndpoint = (key: string): string => {
  const raw = (import.meta as any)?.env?.[key];
  return typeof raw === "string" ? raw.trim() : "";
};

export const fetchBillingSummary = async (token: string): Promise<ApiResult<BillingSummary>> => {
  const endpoint = readEnvEndpoint("VITE_BILLING_SUMMARY_ENDPOINT") || `${API_BASE}/billing/summary`;
  try {
    const response = await fetch(endpoint, { method: "GET", headers: getAuthHeaders(token) });
    const data = await parseBody(response);
    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Failed to load billing summary."),
      };
    }

    const payload = data?.data ?? data ?? {};
    const result: BillingSummary = {
      planName: toStringOrNull(payload?.planName ?? payload?.name),
      planBadge: toStringOrNull(payload?.planBadge ?? payload?.tier),
      planPrice: toNumberOrNull(payload?.planPrice ?? payload?.price),
      planCurrency: toStringOrNull(payload?.planCurrency ?? payload?.currency),
      planInterval: toStringOrNull(payload?.planInterval ?? payload?.interval),
      cycleStart: toStringOrNull(payload?.cycleStart ?? payload?.billingCycleStart),
      cycleEnd: toStringOrNull(payload?.cycleEnd ?? payload?.billingCycleEnd),
      nextBillingDate: toStringOrNull(payload?.nextBillingDate),
      daysRemaining: toNumberOrNull(payload?.daysRemaining),
    };
    return { success: true, status: response.status, data: result };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

export const fetchBillingMetrics = async (token: string): Promise<ApiResult<BillingMetrics>> => {
  const endpoint = readEnvEndpoint("VITE_BILLING_METRICS_ENDPOINT") || `${API_BASE}/billing/metrics`;
  try {
    const response = await fetch(endpoint, { method: "GET", headers: getAuthHeaders(token) });
    const data = await parseBody(response);
    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Failed to load billing metrics."),
      };
    }

    const payload = data?.data ?? data ?? {};
    const result: BillingMetrics = {
      currentPlanPrice: toNumberOrNull(payload?.currentPlanPrice),
      currentCycleSpend: toNumberOrNull(payload?.currentCycleSpend),
      totalSpend: toNumberOrNull(payload?.totalSpend),
      nextBillingAmount: toNumberOrNull(payload?.nextBillingAmount),
      currency: toStringOrNull(payload?.currency),
    };
    return { success: true, status: response.status, data: result };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

export const fetchPaymentMethod = async (token: string): Promise<ApiResult<PaymentMethod>> => {
  const endpoint =
    readEnvEndpoint("VITE_BILLING_PAYMENT_METHOD_ENDPOINT") || `${API_BASE}/billing/payment-method`;
  try {
    const response = await fetch(endpoint, { method: "GET", headers: getAuthHeaders(token) });
    const data = await parseBody(response);
    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Failed to load payment method."),
      };
    }

    const payload = data?.data ?? data ?? {};
    const result: PaymentMethod = {
      cardBrand: toStringOrNull(payload?.cardBrand ?? payload?.brand),
      last4: toStringOrNull(payload?.last4),
      expiryMonth: toNumberOrNull(payload?.expiryMonth ?? payload?.expMonth),
      expiryYear: toNumberOrNull(payload?.expiryYear ?? payload?.expYear),
      billingEmail: toStringOrNull(payload?.billingEmail ?? payload?.email),
    };
    return { success: true, status: response.status, data: result };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

export const fetchInvoices = async (token: string): Promise<ApiResult<Invoice[]>> => {
  const endpoint =
    readEnvEndpoint("VITE_INVOICES_ENDPOINT") || `${API_BASE}/billing/invoices`;

  try {
    const response = await fetch(endpoint, {
      method: "GET",
      headers: getAuthHeaders(token),
    });

    const data = await parseBody(response);
    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Failed to load invoices."),
      };
    }

    const payload = data?.data ?? data;
    const items = Array.isArray(payload) ? payload : payload?.items ?? payload?.invoices ?? [];
    if (!Array.isArray(items)) {
      return { success: false, status: response.status, error: "Unexpected invoice response." };
    }

    const normalized: Invoice[] = items
      .map((it: any) => {
        const id = it?.id ?? it?.invoiceId ?? it?._id;
        const date = it?.date ?? it?.createdAt ?? it?.created ?? it?.issuedAt;
        if (typeof id !== "string") return null;
        const dateIso =
          typeof date === "string"
            ? date
            : typeof date === "number"
              ? new Date(date).toISOString()
              : new Date().toISOString();

        return {
          id,
          date: dateIso,
          number: typeof it?.number === "string" ? it.number : undefined,
          amount: toNumberOrNull(it?.amount),
          currency: typeof it?.currency === "string" ? it.currency : undefined,
          status: typeof it?.status === "string" ? it.status : undefined,
          downloadUrl:
            typeof it?.downloadUrl === "string"
              ? it.downloadUrl
              : typeof it?.pdfUrl === "string"
                ? it.pdfUrl
                : undefined,
        } satisfies Invoice;
      })
      .filter(Boolean) as Invoice[];

    return { success: true, status: response.status, data: normalized };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

export const upgradePlan = async (token: string): Promise<ApiResult<{ ok: true }>> => {
  const endpoint = readEnvEndpoint("VITE_BILLING_UPGRADE_ENDPOINT") || `${API_BASE}/billing/upgrade`;
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: getAuthHeaders(token),
      body: JSON.stringify({}),
    });

    const data = await parseBody(response);
    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Failed to upgrade plan."),
      };
    }

    return { success: true, status: response.status, data: { ok: true } };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

export const cancelSubscription = async (token: string): Promise<ApiResult<{ ok: true }>> => {
  const endpoint =
    readEnvEndpoint("VITE_BILLING_CANCEL_ENDPOINT") || `${API_BASE}/billing/cancel`;

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: getAuthHeaders(token),
      body: JSON.stringify({}),
    });

    const data = await parseBody(response);
    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Failed to cancel subscription."),
      };
    }

    return { success: true, status: response.status, data: { ok: true } };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};
