/**
 * Shared API utility functions used across service modules.
 */

/** Parse a fetch Response body, returning JSON if possible or a text wrapper. */
export const parseBody = async (response: Response): Promise<any> => {
  try {
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) return await response.json();
    const text = await response.text();
    return text ? { message: text } : {};
  } catch {
    return {};
  }
};

/** Build authorization headers with Content-Type: application/json. */
export const getAuthHeaders = (token: string): Record<string, string> => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${token}`,
});

/** Build headers with optional authorization (token may be null/undefined). */
export const getHeaders = (token?: string | null): Record<string, string> => {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  return headers;
};
