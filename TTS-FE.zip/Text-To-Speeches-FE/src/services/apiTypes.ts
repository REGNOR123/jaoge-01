/**
 * Shared API result type used by API services.
 */
export type ApiResult<T> =
  | { success: true; status: number; data: T }
  | { success: false; status?: number; error: string };
