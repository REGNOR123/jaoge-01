const LOCAL_API_BASE = 'http://localhost:5127';

const PROD_API_BASE = 'https://text-to-speeches-be-f0g0fkd4f2e7h9ev.eastasia-01.azurewebsites.net';

const isLocalHost =
  window.location.hostname === 'localhost' ||
  window.location.hostname === '127.0.0.1';

const configuredApiBase =
  (import.meta.env.VITE_API_BASE_URL as string | undefined)?.trim() || '';

const normalizeApiBase = (value: string): string => {
  return value.endsWith('/api') ? value : `${value}/api`;
};

export const resolveApiBase = (): string => {
  if (configuredApiBase) {
    return normalizeApiBase(configuredApiBase);
  }

  if (import.meta.env.DEV && isLocalHost) {
    return normalizeApiBase(LOCAL_API_BASE);
  }

  return normalizeApiBase(isLocalHost ? LOCAL_API_BASE : PROD_API_BASE);
};

export const API_BASE = resolveApiBase();

