
import { API_BASE } from './apiBase';

type OtpResponse = {
  success: boolean;
  status?: number;
  message?: string;
  error?: string;
  token?: string;
  data?: {
    token?: string;
  };
};

const parseBody = async (response: Response): Promise<any> => {
  try {
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      return await response.json();
    }
    const text = await response.text();
    return text ? { message: text } : {};
  } catch {
    return {};
  }
};

/**
 * OTP requests should be handled by the backend so keys/secrets stay server-side.
 * Backend should implement: POST /api/auth/otp/request
 */
export const requestOtp = async (
  email: string,
): Promise<{ success: boolean; error?: string }> => {
  try {
    const response = await fetch(`${API_BASE}/auth/otp/request`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });

    const data = (await parseBody(response)) as OtpResponse | any;
    if (!response.ok || data?.success === false) {
      return {
        success: false,
        error: data?.error || data?.message || 'Failed to request OTP.',
      };
    }

    return { success: true };
  } catch (err: any) {
    console.error('OTP request error:', err);
    return { success: false, error: 'Network error. Please try again.' };
  }
};

/**
 * OTP verification should be handled by the backend.
 * Backend should implement: POST /api/auth/otp/verify
 */
export const verifyOtp = async (
  email: string,
  otp: string,
): Promise<{ success: boolean; token?: string; error?: string }> => {
  try {
    const response = await fetch(`${API_BASE}/auth/otp/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, otp }),
    });

    const data = (await parseBody(response)) as OtpResponse | any;
    if (!response.ok || data?.success === false) {
      return {
        success: false,
        error: data?.error || data?.message || 'OTP verification failed.',
      };
    }

    const token: string | undefined = data?.data?.token || data?.token;
    if (!token) {
      return { success: false, error: 'OTP verification failed: missing token.' };
    }

    return { success: true, token };
  } catch (err: any) {
    console.error('OTP verify error:', err);
    return { success: false, error: 'Network error. Please try again.' };
  }
};
