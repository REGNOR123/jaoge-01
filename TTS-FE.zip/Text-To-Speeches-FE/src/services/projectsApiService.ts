/**
 * Projects API Service
 * Replaces localStorage-based project storage with Azure File Storage backend
 * 
 * This module provides both async API functions and sync-compatible wrappers
 * that use a local cache for backward compatibility with existing wizard code.
 */

const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api';

// ============================================================================
// Type Definitions
// ============================================================================

export type ProjectType = "Voice" | "Transcript" | "Dub" | "SpeechTranslate" | "Script";
export type ProjectStatus = "Completed" | "Processing";

export type ProjectScript = {
  id: string;
  text: string;
  createdAt: string;
  fileId?: string;
  contentType?: string;
  fileName?: string;
  expiresAt?: string;
  source?: string;
};

export type ProjectAudioVersion = {
  id: string;
  audioUrl: string;
  createdAt: string;
  fileId?: string;
  contentType?: string;
  fileName?: string;
  expiresAt?: string;
  voice?: string;
  voiceLabel?: string;
  settings?: Record<string, unknown>;
  estimatedMinutes?: number;
};

export type ProjectTranscript = {
  id: string;
  text: string;
  createdAt: string;
  fileId?: string;
  contentType?: string;
  fileName?: string;
  expiresAt?: string;
  language?: string;
  includeTimestamps?: boolean;
};

export type ProjectLanguageVariant = {
  id: string;
  createdAt: string;
  sourceLang?: string;
  targetLang?: string;
  sourceText: string;
  translatedText: string;
};

export type ProjectUsage = {
  voiceMinutesUsed?: number;
  sttMinutesUsed?: number;
  translationCharsUsed?: number;
};

export type ProjectData = {
  drafts?: {
    voice?: {
      script?: string;
      language?: string;
      voice?: string;
      rate?: number;
      pitch?: number;
      updatedAt: string;
    };
    transcript?: {
      language?: string;
      autoPunctuation?: boolean;
      includeTimestamps?: boolean;
      fileName?: string;
      durationSeconds?: number;
      transcript?: string;
      updatedAt: string;
    };
    dub?: {
      mode?: "text" | "audio";
      sourceText?: string;
      translatedText?: string;
      sourceLang?: string;
      targetLang?: string;
      voice?: string;
      text?: {
        projectName?: string;
        sourceText?: string;
        translatedText?: string;
        sourceLang?: string;
        targetLang?: string;
        voice?: string;
        updatedAt: string;
      };
      audio?: {
        projectName?: string;
        transcriptText?: string;
        translatedText?: string;
        sourceLang?: string;
        targetLang?: string;
        voice?: string;
        updatedAt: string;
      };
      updatedAt: string;
    };
    speechTranslate?: {
      targets?: string[];
      outputFormat?: "mp3" | "wav";
      showTextOutput?: boolean;
      voicesByTarget?: Record<string, string>;
      detectedLanguage?: string;
      recognizedText?: string;
      translationsByTarget?: Record<string, string>;
      updatedAt: string;
    };
    scriptStudio?: {
      scriptType?: string;
      topic?: string;
      tone?: string;
      length?: string;
      script?: string;
      updatedAt: string;
    };
  };
  outputs?: {
    scripts?: ProjectScript[];
    audioVersions?: ProjectAudioVersion[];
    transcripts?: ProjectTranscript[];
    languages?: ProjectLanguageVariant[];
  };
  usage?: ProjectUsage;
};

// Backend uses createdAt/lastModifiedAt, frontend historically used created/lastModified
export type Project = {
  id: string;
  name: string;
  type: ProjectType;
  status: ProjectStatus;
  created: string;        // Alias for createdAt (for backward compatibility)
  lastModified: string;   // Alias for lastModifiedAt (for backward compatibility)
  data?: ProjectData;
};

// Backend response format
type BackendProject = {
  id: string;
  name: string;
  type: ProjectType;
  status: ProjectStatus;
  createdAt: string;
  lastModifiedAt: string;
  data?: ProjectData;
};

export type ProjectListItem = {
  id: string;
  name: string;
  type: ProjectType;
  status: ProjectStatus;
  created: string;
  lastModified: string;
};

export type CreateProjectRequest = {
  name: string;
  type: ProjectType;
  status?: ProjectStatus;
  data?: ProjectData;
};

export type UpdateProjectRequest = {
  name?: string;
  type?: ProjectType;
  status?: ProjectStatus;
  data?: ProjectData;
};

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

// ============================================================================
// Local Cache for Sync Compatibility
// ============================================================================

let cachedProjects: Project[] = [];
let cacheInitialized = false;
let cacheInitPromise: Promise<void> | null = null;
const pendingUpdates = new Map<string, ReturnType<typeof setTimeout>>();
const DEBOUNCE_MS = 300;

/**
 * Convert backend project format to frontend format
 */
function toFrontendProject(backend: BackendProject): Project {
  return {
    id: backend.id,
    name: backend.name,
    type: backend.type,
    status: backend.status,
    created: backend.createdAt,
    lastModified: backend.lastModifiedAt,
    data: backend.data,
  };
}

/**
 * Convert frontend project format to backend request format
 */
function toBackendRequest(project: Partial<Project>): UpdateProjectRequest {
  return {
    name: project.name,
    type: project.type,
    status: project.status,
    data: project.data,
  };
}

// ============================================================================
// Auth Helper
// ============================================================================

function getAuthHeaders(): HeadersInit {
  const token = localStorage.getItem('tts_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

function isAuthenticated(): boolean {
  return Boolean(localStorage.getItem('tts_token'));
}

// ============================================================================
// Async API Functions (Primary)
// ============================================================================

/**
 * Fetch all projects from API and update cache
 */
export async function fetchProjects(): Promise<Project[]> {
  if (!isAuthenticated()) {
    cachedProjects = [];
    cacheInitialized = true;
    return [];
  }

  try {
    const response = await fetch(`${API_BASE}/projects`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });

    if (!response.ok) {
      console.error('Failed to list projects:', response.status);
      return cachedProjects;
    }

    const result: ApiResponse<BackendProject[]> = await response.json();
    const projects = (result.data || []).map(toFrontendProject);
    cachedProjects = projects;
    cacheInitialized = true;
    return projects;
  } catch (error) {
    console.error('Error listing projects:', error);
    return cachedProjects;
  }
}

/**
 * Fetch a single project from API
 */
export async function fetchProjectById(projectId: string): Promise<Project | null> {
  if (!isAuthenticated()) return null;

  try {
    const response = await fetch(`${API_BASE}/projects/${projectId}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });

    if (!response.ok) {
      console.error('Failed to get project:', response.status);
      return null;
    }

    const result: ApiResponse<BackendProject> = await response.json();
    if (!result.data) return null;
    
    const project = toFrontendProject(result.data);
    
    // Update cache
    const index = cachedProjects.findIndex(p => p.id === projectId);
    if (index >= 0) {
      cachedProjects[index] = project;
    } else {
      cachedProjects.push(project);
    }
    
    return project;
  } catch (error) {
    console.error('Error getting project:', error);
    return null;
  }
}

/**
 * Create a new project via API
 */
export async function createProjectAsync(request: CreateProjectRequest): Promise<Project | null> {
  if (!isAuthenticated()) return null;

  try {
    const response = await fetch(`${API_BASE}/projects`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      console.error('Failed to create project:', response.status);
      return null;
    }

    const result: ApiResponse<BackendProject> = await response.json();
    if (!result.data) return null;
    
    const project = toFrontendProject(result.data);
    cachedProjects.unshift(project);
    return project;
  } catch (error) {
    console.error('Error creating project:', error);
    return null;
  }
}

/**
 * Update an existing project via API
 */
export async function updateProjectAsync(projectId: string, request: UpdateProjectRequest): Promise<Project | null> {
  if (!isAuthenticated()) return null;

  try {
    const response = await fetch(`${API_BASE}/projects/${projectId}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      console.error('Failed to update project:', response.status);
      return null;
    }

    const result: ApiResponse<BackendProject> = await response.json();
    if (!result.data) return null;
    
    const project = toFrontendProject(result.data);
    
    // Update cache
    const index = cachedProjects.findIndex(p => p.id === projectId);
    if (index >= 0) {
      cachedProjects[index] = project;
    }
    
    return project;
  } catch (error) {
    console.error('Error updating project:', error);
    return null;
  }
}

/**
 * Delete a project via API
 */
export async function deleteProjectAsync(projectId: string): Promise<boolean> {
  if (!isAuthenticated()) return false;

  try {
    const response = await fetch(`${API_BASE}/projects/${projectId}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });

    if (!response.ok) {
      console.error('Failed to delete project:', response.status);
      return false;
    }

    // Update cache
    cachedProjects = cachedProjects.filter(p => p.id !== projectId);
    return true;
  } catch (error) {
    console.error('Error deleting project:', error);
    return false;
  }
}

// ============================================================================
// Sync-Compatible Functions (For Backward Compatibility)
// These use the local cache and schedule async updates
// ============================================================================

/**
 * Initialize cache from API (call on app startup)
 */
export function initProjectsCache(): Promise<void> {
  if (cacheInitPromise) return cacheInitPromise;
  cacheInitPromise = fetchProjects().then(() => {});
  return cacheInitPromise;
}

/**
 * List all projects (sync - returns cached data)
 */
export function listProjects(): Project[] {
  // Trigger background refresh if not initialized
  if (!cacheInitialized && isAuthenticated()) {
    void fetchProjects();
  }
  return [...cachedProjects];
}

/**
 * Get project by ID (sync - returns cached data)
 */
export function getProjectById(id: string): Project | null {
  const cached = cachedProjects.find(p => p.id === id);
  
  // Trigger background fetch if not found and authenticated
  if (!cached && isAuthenticated()) {
    void fetchProjectById(id);
  }
  
  return cached || null;
}

/**
 * Create a new project (sync-compatible - updates cache immediately, syncs async)
 */
export function createProject(params: {
  name: string;
  type: ProjectType;
  status?: ProjectStatus;
  data?: ProjectData;
}): Project | null {
  if (!isAuthenticated()) return null;

  // Create local project immediately
  const now = new Date().toISOString();
  const tempId = crypto.randomUUID();
  const project: Project = {
    id: tempId,
    name: params.name.trim() || "Untitled Project",
    type: params.type,
    status: params.status || "Processing",
    created: now,
    lastModified: now,
    data: params.data,
  };

  // Add to cache immediately
  cachedProjects.unshift(project);

  // Schedule async creation
  void (async () => {
    const created = await createProjectAsync({
      name: project.name,
      type: project.type,
      status: project.status,
      data: project.data,
    });
    
    if (created) {
      // Replace temp project with real one
      const index = cachedProjects.findIndex(p => p.id === tempId);
      if (index >= 0) {
        cachedProjects[index] = created;
      }
    } else {
      // Remove from cache on failure
      cachedProjects = cachedProjects.filter(p => p.id !== tempId);
    }
  })();

  return project;
}

/**
 * Update a project (sync-compatible - updates cache immediately, syncs async with debounce)
 */
export function updateProject(
  id: string,
  patch: Partial<Omit<Project, "id">>
): Project | null {
  const existing = cachedProjects.find(p => p.id === id);
  if (!existing) return null;

  // Update cache immediately
  const updated: Project = {
    ...existing,
    ...patch,
    created: patch.created || existing.created,
    lastModified: patch.lastModified || new Date().toISOString(),
  };

  const index = cachedProjects.findIndex(p => p.id === id);
  if (index >= 0) {
    cachedProjects[index] = updated;
  }

  // Debounce async update
  const pendingTimeout = pendingUpdates.get(id);
  if (pendingTimeout) {
    clearTimeout(pendingTimeout);
  }

  pendingUpdates.set(id, setTimeout(() => {
    pendingUpdates.delete(id);
    void updateProjectAsync(id, toBackendRequest(patch));
  }, DEBOUNCE_MS));

  return updated;
}

/**
 * Delete a project (sync-compatible)
 */
export function deleteProject(id: string): boolean {
  const index = cachedProjects.findIndex(p => p.id === id);
  if (index < 0) return false;

  // Remove from cache immediately
  cachedProjects.splice(index, 1);

  // Schedule async deletion
  void deleteProjectAsync(id);

  return true;
}

/**
 * Check if a project is a draft (has unsaved work in progress)
 */
export function isDraftProject(project: Project): boolean {
  if (project.status === "Completed") return false;
  const drafts = project.data?.drafts;
  if (!drafts) return false;
  return Boolean(drafts.voice || drafts.transcript || drafts.dub || drafts.speechTranslate || drafts.scriptStudio);
}

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Get projects filtered by type
 */
export function getProjectsByType(type: ProjectType): Project[] {
  return cachedProjects.filter(p => p.type === type);
}

/**
 * Get projects filtered by type (async version)
 */
export async function getProjectsByTypeAsync(type: ProjectType): Promise<Project[]> {
  const projects = await fetchProjects();
  return projects.filter(p => p.type === type);
}

/**
 * Force refresh the cache from API
 */
export async function refreshProjectsCache(): Promise<Project[]> {
  return fetchProjects();
}

/**
 * Clear the local cache (e.g., on logout)
 */
export function clearProjectsCache(): void {
  cachedProjects = [];
  cacheInitialized = false;
  cacheInitPromise = null;
  pendingUpdates.forEach(timeout => clearTimeout(timeout));
  pendingUpdates.clear();
}
