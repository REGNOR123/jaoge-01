import { API_BASE } from "./apiBase";
import { isMp3File, isWavFile } from "../utils/audioTranscode";
import { parseBody } from "./apiUtils";

export type SpeechTranslateOutputFormat = "mp3" | "wav";

export type SpeechTranslateAudioItem = {
  fileId?: string;
  voice?: string;
  contentType?: string;
  fileName?: string;
  expiresAt?: string;
  base64?: string;
  dataUrl?: string;
};

export type SpeechTranslateResponseData = {
  detectedLanguage?: string;
  text?: string;
  translations?: Record<string, string>;
  audio?: Record<string, SpeechTranslateAudioItem>;
};

export type TranslateSpeechToSpeechOptions = {
  targets: string[];
  outputFormat?: SpeechTranslateOutputFormat;
  voicesByTarget?: Record<string, string | undefined>;
  defaultVoice?: string;
  token?: string | null;
  jobId?: string;
  inputFileId?: string;
};

export type TranslateSpeechToSpeechResult =
  | { success: true; data: SpeechTranslateResponseData }
  | { success: false; status?: number; error: string; limitType?: string; insufficientCredits?: true; requiredCredits?: number; currentBalance?: number };

const getErrorMessage = (data: any, fallback: string): string => {
  return data?.error || data?.message || data?.data?.error || fallback;
};

const mapTranslateError = (status: number, data: any): string => {
  if (status === 429) {
    return getErrorMessage(data, "Usage limit reached. Please upgrade your plan.");
  }
  if (status === 401 || status === 403) {
    return getErrorMessage(data, "Session expired. Please login again.");
  }
  if (status === 415) {
    return getErrorMessage(data, "Unsupported file type. Please upload a WAV or MP3 file.");
  }
  if (status === 422) {
    return getErrorMessage(data, "Validation failed. Please review the selected audio and options.");
  }
  if (status >= 500) {
    return getErrorMessage(data, "Server error while translating speech. Please try again.");
  }
  return getErrorMessage(data, "Speech translation failed.");
};

const toDataUrl = (base64: string, contentType?: string): string => {
  const normalized = base64.replace(/^data:[^;]+;base64,/, "").trim();
  return `data:${contentType || "audio/mpeg"};base64,${normalized}`;
};

const normalizeAudioItem = (value: any): SpeechTranslateAudioItem => {
  const contentType =
    typeof (value?.contentType || value?.mimeType || value?.type) === "string"
      ? String(value?.contentType || value?.mimeType || value?.type).trim()
      : undefined;
  const base64 =
    typeof (value?.base64 || value?.audioBase64 || value?.contentBase64) === "string"
      ? String(value?.base64 || value?.audioBase64 || value?.contentBase64)
      : undefined;
  const dataUrl =
    typeof value?.dataUrl === "string"
      ? value.dataUrl
      : typeof value?.url === "string" && String(value.url).startsWith("data:")
        ? value.url
        : base64
          ? toDataUrl(base64, contentType)
          : undefined;

  return {
    fileId:
      typeof (value?.fileId || value?.storageFileId) === "string"
        ? String(value?.fileId || value?.storageFileId).trim()
        : undefined,
    voice: typeof value?.voice === "string" ? value.voice : undefined,
    contentType,
    fileName:
      typeof (value?.fileName || value?.name) === "string"
        ? String(value?.fileName || value?.name).trim()
        : undefined,
    expiresAt:
      typeof (value?.expiresAt || value?.expiresOn) === "string"
        ? String(value?.expiresAt || value?.expiresOn)
        : undefined,
    base64,
    dataUrl,
  };
};

const normalizeAudioMap = (value: any): Record<string, SpeechTranslateAudioItem> => {
  if (!value) return {};

  if (Array.isArray(value)) {
    return value.reduce<Record<string, SpeechTranslateAudioItem>>((acc, item) => {
      const target =
        item?.target || item?.language || item?.targetLanguage || item?.code || item?.locale;
      if (typeof target !== "string" || !target.trim()) return acc;
      acc[target.trim()] = normalizeAudioItem(item);
      return acc;
    }, {});
  }

  if (typeof value === "object") {
    const next: Record<string, SpeechTranslateAudioItem> = {};
    for (const [key, item] of Object.entries(value)) {
      if (!key) continue;
      next[key] = normalizeAudioItem(item);
    }
    return next;
  }

  return {};
};

const normalizePayload = (json: any): SpeechTranslateResponseData => {
  const payload =
    json?.data && typeof json.data === "object" && json.data !== null ? json.data : json;
  return {
    ...(payload || {}),
    audio: normalizeAudioMap(
      payload?.audio || payload?.audioByTarget || payload?.outputs || payload?.outputAudio,
    ),
  } as SpeechTranslateResponseData;
};

export const detectAudioLanguage = async (
  audioFile: File,
  token?: string | null,
): Promise<string | null> => {
  try {
    const headers: Record<string, string> = {};
    if (token) headers["Authorization"] = `Bearer ${token}`;
    const fd = new FormData();
    fd.append("audio", audioFile);
    const res = await fetch(`${API_BASE}/speech/detect-language`, {
      method: "POST",
      headers,
      body: fd,
    });
    if (!res.ok) return null;
    const json = await res.json().catch(() => null);
    return (json?.data?.language as string) ?? null;
  } catch {
    return null;
  }
};

export const translateSpeechToSpeech = async (
  file: File,
  options: TranslateSpeechToSpeechOptions,
): Promise<TranslateSpeechToSpeechResult> => {
  if (!file) return { success: false, error: "Please select an audio file." };
  if (!isWavFile(file) && !isMp3File(file)) {
    return { success: false, error: "Supported formats: WAV, MP3." };
  }

  const targets = Array.isArray(options.targets) ? options.targets.filter(Boolean) : [];
  if (!targets.length) {
    return { success: false, error: "Please select at least one target language." };
  }

  const fd = new FormData();
  fd.append("audio", file);
  for (const t of targets) fd.append("to", t);
  if (options.outputFormat) fd.append("outputFormat", options.outputFormat);
  if (options.defaultVoice) fd.append("defaultVoice", options.defaultVoice);
  if (options.jobId) fd.append("jobId", options.jobId);
  if (options.inputFileId) fd.append("inputFileId", options.inputFileId);

  const voicesByTarget = options.voicesByTarget || {};
  const voicesJson: Record<string, string> = {};
  for (const [target, voice] of Object.entries(voicesByTarget)) {
    if (!target || !voice) continue;
    if (!targets.includes(target)) continue;
    voicesJson[target] = voice;
  }
  if (Object.keys(voicesJson).length) {
    fd.append("voicesJson", JSON.stringify(voicesJson));
  }

  try {
    const headers: Record<string, string> = {};
    if (options.token) headers.Authorization = `Bearer ${options.token}`;
    const res = await fetch(`${API_BASE}/speech/translate-speech`, {
      method: "POST",
      headers,
      body: fd,
    });

    const json = await parseBody(res);
    if (!res.ok || json?.success === false) {
      if (res.status === 402) {
        const creds = json?.data;
        return { success: false, status: res.status, error: mapTranslateError(res.status, json),
          insufficientCredits: true, requiredCredits: creds?.requiredCredits ?? 0, currentBalance: creds?.currentBalance ?? 0 };
      }
      return {
        success: false,
        status: res.status,
        error: mapTranslateError(res.status, json),
        limitType: res.status === 429 ? json?.limitType : undefined,
      };
    }

    const data = normalizePayload(json);
    if (!data || typeof data !== "object") {
      return { success: false, error: "Speech translation failed: invalid response." };
    }

    return { success: true, data };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};
