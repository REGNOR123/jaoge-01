import { API_BASE } from './apiBase';

export interface SpeechTokenResponse {
  success: boolean;
  status?: number;
  data?: {
    token: string;
    region: string;
  };
  error?: string;
}

type CachedToken = {
  token: string;
  region: string;
  fetchedAtMs: number;
};

let cachedToken: CachedToken | null = null;

// Azure Speech auth tokens are short-lived. Cache briefly to avoid repeated calls
// when creating multiple Speech SDK clients in the same session.
const DEFAULT_TOKEN_TTL_MS = 8 * 60 * 1000;

export const fetchSpeechToken = async (): Promise<SpeechTokenResponse> => {
  try {
    const response = await fetch(`${API_BASE}/speech/token`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    const parseBody = async (): Promise<any> => {
      try {
        const contentType = response.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          return await response.json();
        }
        const text = await response.text();
        return text ? { message: text } : {};
      } catch {
        return {};
      }
    };

    const data = await parseBody();

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error:
          data?.message ||
          data?.error ||
          'Speech service unavailable, try again.',
      };
    }

    if (!data?.success || !data?.data?.token || !data?.data?.region) {
      return {
        success: false,
        status: response.status,
        error: 'Speech service unavailable, try again.',
      };
    }

    return {
      success: true,
      status: response.status,
      data: {
        token: data.data.token,
        region: data.data.region,
      },
    };
  } catch (err) {
    console.error('Speech token fetch error:', err);
    return {
      success: false,
      error: 'Speech service unavailable, try again.',
    };
  }
};

export const getSpeechToken = async (
  options?: { forceRefresh?: boolean; ttlMs?: number },
): Promise<SpeechTokenResponse> => {
  const ttlMs = options?.ttlMs ?? DEFAULT_TOKEN_TTL_MS;
  if (!options?.forceRefresh && cachedToken) {
    const age = Date.now() - cachedToken.fetchedAtMs;
    if (age >= 0 && age < ttlMs) {
      return {
        success: true,
        status: 200,
        data: { token: cachedToken.token, region: cachedToken.region },
      };
    }
  }

  const res = await fetchSpeechToken();
  if (res.success && res.data?.token && res.data.region) {
    cachedToken = {
      token: res.data.token,
      region: res.data.region,
      fetchedAtMs: Date.now(),
    };
  }
  return res;
};
