import { API_BASE } from './apiBase';
import { getAuthHeaders, parseBody } from './apiUtils';

export interface CreditBalance {
  balance: number;
}

export interface FeatureCostItem {
  feature: string;
  displayName: string;
  creditCost: number;
  costPerNChars: number | null;
  minCost: number;
  displayUnit: string;
}

export interface PlanItem {
  name: string;
  displayName: string;
  monthlyPrice: number;
  annualPrice: number;
  inrMonthlyPrice: number;
  inrAnnualPrice: number;
  creditsPerMonth: number;
  isOneTimeGrant: boolean;
  popular: boolean;
  badge: string | null;
  ctaLabel: string | null;
  features: string[];
}

export const getCreditBalance = async (
  token: string
): Promise<{ success: boolean; data?: CreditBalance; error?: string }> => {
  try {
    const response = await fetch(`${API_BASE}/credits/balance`, {
      headers: getAuthHeaders(token),
    });
    const body = await parseBody(response);
    if (!response.ok) {
      return { success: false, error: body?.error || 'Failed to fetch balance.' };
    }
    return { success: true, data: body?.data };
  } catch {
    return { success: false, error: 'Network error fetching credit balance.' };
  }
};

export const getFeatureCosts = async (): Promise<FeatureCostItem[]> => {
  try {
    const response = await fetch(`${API_BASE}/credits/feature-costs`);
    if (!response.ok) return [];
    const body = await response.json();
    return body?.data ?? [];
  } catch {
    return [];
  }
};

export const getPlans = async (): Promise<PlanItem[]> => {
  try {
    const response = await fetch(`${API_BASE}/plans`);
    if (!response.ok) return [];
    const body = await response.json();
    return body?.data ?? [];
  } catch {
    return [];
  }
};

export const deductVoicePreviewCredit = async (
  token: string
): Promise<{ success: boolean; balance?: number; error?: string }> => {
  try {
    const response = await fetch(`${API_BASE}/credits/deduct-voice-preview`, {
      method: 'POST',
      headers: getAuthHeaders(token),
    });
    const body = await parseBody(response);
    if (!response.ok) {
      return { success: false, error: body?.error || 'Failed to deduct credit.' };
    }
    return { success: true, balance: body?.data?.balance };
  } catch {
    return { success: false, error: 'Network error.' };
  }
};
