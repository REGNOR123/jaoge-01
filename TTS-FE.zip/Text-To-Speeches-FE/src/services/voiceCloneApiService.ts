import { API_BASE } from './apiBase';
import { getAuthHeaders, parseBody } from './apiUtils';

export interface VoiceCloneKeyStatusResponse {
  success: boolean;
  data?: { hasKey: boolean };
  error?: string;
}

export interface GenerateVoiceCloningKeyPayload {
  referenceAudioBase64: string;
  consentAudioBase64: string;
  languageCode: string;
  audioEncoding: string;
}

export interface GenerateVoiceCloningKeyResponse {
  success: boolean;
  data?: { message: string };
  error?: string;
  status?: number;
}

export interface SynthesizeWithClonedVoiceResponse {
  success: boolean;
  data?: { audioContent: string };
  error?: string;
  status?: number;
}

export const getKeyStatus = async (token: string): Promise<VoiceCloneKeyStatusResponse> => {
  try {
    const response = await fetch(`${API_BASE}/voice-clone/key-status`, {
      method: 'GET',
      headers: getAuthHeaders(token),
    });
    const data = await parseBody(response);
    if (!response.ok) return { success: false, error: data?.error || 'Failed to check key status.' };
    return { success: true, data: data?.data };
  } catch {
    return { success: false, error: 'Network error. Please check your connection.' };
  }
};

export const generateVoiceCloningKey = async (
  payload: GenerateVoiceCloningKeyPayload,
  token: string,
): Promise<GenerateVoiceCloningKeyResponse> => {
  try {
    const response = await fetch(`${API_BASE}/voice-clone/generate-key`, {
      method: 'POST',
      headers: getAuthHeaders(token),
      body: JSON.stringify({
        referenceAudioBase64: payload.referenceAudioBase64,
        consentAudioBase64: payload.consentAudioBase64,
        languageCode: payload.languageCode,
        audioEncoding: payload.audioEncoding,
      }),
    });
    const data = await parseBody(response);
    if (response.status === 402) {
      return {
        success: false,
        status: 402,
        error: data?.error || 'Insufficient credits.',
        data: data?.data,
      };
    }
    if (!response.ok) return { success: false, status: response.status, error: data?.error || 'Failed to generate voice clone.' };
    return { success: true, data: data?.data };
  } catch {
    return { success: false, error: 'Network error. Please check your connection.' };
  }
};

export const synthesizeWithClonedVoice = async (
  text: string,
  languageCode: string,
  token: string,
): Promise<SynthesizeWithClonedVoiceResponse> => {
  try {
    const response = await fetch(`${API_BASE}/voice-clone/synthesize`, {
      method: 'POST',
      headers: getAuthHeaders(token),
      body: JSON.stringify({ text, languageCode }),
    });
    const data = await parseBody(response);
    if (response.status === 402) {
      return {
        success: false,
        status: 402,
        error: data?.error || 'Insufficient credits.',
        data: data?.data,
      };
    }
    if (!response.ok) return { success: false, status: response.status, error: data?.error || 'Voice synthesis failed.' };
    return { success: true, data: data?.data };
  } catch {
    return { success: false, error: 'Network error. Please check your connection.' };
  }
};
