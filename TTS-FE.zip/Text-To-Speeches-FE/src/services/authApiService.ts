/**
 * Authentication API Service
 * Handles all auth-related HTTP calls to the backend
 */

import { API_BASE } from './apiBase';
import { getHeaders } from './apiUtils';

export interface AuthUser {
  id: number;
  fullName: string;
  email: string;
  profilePicture?: string;
  currentPlan?: string;
  credits?: number;
}

export interface AuthResponse {
  success: boolean;
  status?: number;
  message?: string;
  user?: AuthUser;
  token?: string;
  error?: string;
  errors?: string[];
  verificationUrl?: string;
}

const toErrorList = (data: any): string[] => {
  if (Array.isArray(data?.errors)) {
    return data.errors
      .map((item: any) => {
        if (typeof item === "string") return item;
        if (item && typeof item.message === "string") return item.message;
        return "";
      })
      .filter(Boolean);
  }
  return [];
};

const getResponseMessage = (data: any, fallback: string): string => {
  return data?.message || data?.error || fallback;
};

/**
 * Sign up with email and password
 */
export const signupWithEmail = async (
  fullName: string,
  email: string,
  password: string,
): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${API_BASE}/auth/signup`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ fullName, email, password }),
    });

    const data = await response.json();
    const validationErrors = toErrorList(data);

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        errors: validationErrors,
        error:
          validationErrors[0] ||
          getResponseMessage(data, "Signup failed. Please try again."),
      };
    }

    return {
      success: true,
      status: response.status,
      message: data?.message || "Account created successfully.",
      user: data?.data?.user || data?.user,
      token: data?.data?.token || data?.token,
      verificationUrl: data?.data?.verificationUrl,
    };
  } catch (err: any) {
    console.error("Signup error:", err);
    return {
      success: false,
      status: 0,
      error: "Network error. Please check your connection and try again.",
    };
  }
};

/**
 * Login with email and password
 */
export const loginWithEmail = async (
  email: string,
  password: string,
): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();
    const validationErrors = toErrorList(data);

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        errors: validationErrors,
        error:
          validationErrors[0] ||
          data?.message ||
          data?.error ||
          "Login failed. Please check your credentials.",
      };
    }

    return {
      success: true,
      status: response.status,
      user: data?.data?.user || data?.user,
      token: data?.data?.token || data?.token,
    };
  } catch (err: any) {
    console.error("Login error:", err);
    return {
      success: false,
      status: 0,
      error: "Network error. Please check your connection and try again.",
    };
  }
};

/**
 * Login/Signup with Google OAuth credential
 */
export const loginWithGoogle = async (
  idToken: string,
): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${API_BASE}/auth/google`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ idToken }),
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        success: false,
        error: data.error || data.message || "Google login failed.",
      };
    }

    return {
      success: true,
      user: data.data.user,
      token: data.data.token,
    };
  } catch (err: any) {
    console.error("Google login error:", err);
    return {
      success: false,
      error: "Network error. Please check your connection and try again.",
    };
  }
};

/**
 * Verify email with 6-digit OTP code and get auth token
 */
export const verifyEmailCode = async (
  email: string,
  code: string,
): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${API_BASE}/auth/verify-code`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ email, code }),
    });

    const data = await response.json();
    const validationErrors = toErrorList(data);

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        errors: validationErrors,
        error:
          validationErrors[0] ||
          getResponseMessage(data, "Verification failed. Please try again."),
      };
    }

    return {
      success: true,
      status: response.status,
      message: data?.message || "Email verified successfully!",
      user: data?.data?.user,
      token: data?.data?.token,
    };
  } catch (err: any) {
    console.error("Verify code error:", err);
    return {
      success: false,
      status: 0,
      error: "Network error. Please try again.",
    };
  }
};

/**
 * Verify email with token
 */
export const verifyEmail = async (token: string): Promise<AuthResponse> => {
  try {
    const response = await fetch(
      `${API_BASE}/auth/verify-email?token=${encodeURIComponent(token)}`,
      {
        method: "GET",
        headers: getHeaders(),
      },
    );

    const data = await response.json();
    const validationErrors = toErrorList(data);

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        errors: validationErrors,
        error:
          validationErrors[0] ||
          getResponseMessage(data, "Email verification failed."),
      };
    }

    return {
      success: true,
      status: response.status,
      message: data?.message || "Email verified successfully!",
    };
  } catch (err: any) {
    console.error("Email verification error:", err);
    return {
      success: false,
      status: 0,
      error: "Network error. Please try again.",
    };
  }
};

/**
 * Resend verification email
 */
export const resendVerificationEmail = async (
  email: string,
): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${API_BASE}/auth/resend-verification`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ email }),
    });

    const data = await response.json();
    const validationErrors = toErrorList(data);

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        errors: validationErrors,
        error:
          validationErrors[0] ||
          getResponseMessage(data, "Failed to resend verification email."),
      };
    }

    return {
      success: true,
      status: response.status,
      message: data?.message || "Verification email sent!",
    };
  } catch (err: any) {
    console.error("Resend verification error:", err);
    return {
      success: false,
      status: 0,
      error: "Network error. Please try again.",
    };
  }
};

/**
 * Get current authenticated user
 */
export const getCurrentUser = async (token: string): Promise<AuthResponse> => {
  try {
    const response = await fetch(`${API_BASE}/auth/me`, {
      method: "GET",
      headers: getHeaders(token),
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: data.error || "Session expired.",
      };
    }

    return {
      success: true,
      user: data.data,
    };
  } catch (err: any) {
    console.error("Get user error:", err);
    return {
      success: false,
      error: "Failed to fetch user data.",
    };
  }
};
