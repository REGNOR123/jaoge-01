import { API_BASE } from "./apiBase";

export type ApiResult<T> =
  | { success: true; data: T }
  | { success: false; status?: number; error: string };

export type PlanSummary = {
  planName: string;
  minutesRemaining: number | null;
};

export type ProjectType = "Voice" | "Transcript" | "Dub" | "Script" | string;
export type ProjectStatus = "Completed" | "Processing" | string;

export type RecentProject = {
  id: string;
  name: string;
  type: ProjectType;
  lastModified: string;
  status: ProjectStatus;
};

const getResponseMessage = (data: any, fallback: string): string => {
  return data?.message || data?.error || fallback;
};

const getAuthHeaders = (token: string): Record<string, string> => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${token}`,
});

const readEnvEndpoint = (key: string): string => {
  const raw = (import.meta as any)?.env?.[key];
  return typeof raw === "string" ? raw.trim() : "";
};

const withLimit = (url: string, limit: number): string => {
  try {
    const u = new URL(url);
    u.searchParams.set("limit", String(limit));
    return u.toString();
  } catch {
    const separator = url.includes("?") ? "&" : "?";
    return `${url}${separator}limit=${encodeURIComponent(String(limit))}`;
  }
};

export const fetchPlanSummary = async (token: string): Promise<ApiResult<PlanSummary>> => {
  const endpoint =
    readEnvEndpoint("VITE_PLAN_SUMMARY_ENDPOINT") || `${API_BASE}/subscription/summary`;

  try {
    const response = await fetch(endpoint, {
      method: "GET",
      headers: getAuthHeaders(token),
    });

    const data = await response.json().catch(() => null);
    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Failed to load plan summary."),
      };
    }

    const payload = data?.data ?? data;
    const planName = payload?.planName ?? payload?.plan ?? payload?.name;
    const minutesRaw =
      payload?.minutesRemaining ?? payload?.remainingMinutes ?? payload?.minutes ?? null;

    const minutesRemaining =
      typeof minutesRaw === "number"
        ? minutesRaw
        : typeof minutesRaw === "string"
          ? Number(minutesRaw)
          : null;

    if (typeof planName !== "string" || !planName.trim()) {
      return {
        success: false,
        status: response.status,
        error: "Unexpected response from server while loading plan summary.",
      };
    }

    return {
      success: true,
      data: {
        planName: planName.trim(),
        minutesRemaining: Number.isFinite(minutesRemaining as number)
          ? (minutesRemaining as number)
          : null,
      },
    };
  } catch (err) {
    console.error("fetchPlanSummary error:", err);
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

export const fetchRecentProjects = async (
  token: string,
  limit: number,
): Promise<ApiResult<RecentProject[]>> => {
  const baseEndpoint =
    readEnvEndpoint("VITE_RECENT_PROJECTS_ENDPOINT") || `${API_BASE}/projects/recent`;
  const endpoint = withLimit(baseEndpoint, limit);

  try {
    const response = await fetch(endpoint, {
      method: "GET",
      headers: getAuthHeaders(token),
    });

    const data = await response.json().catch(() => null);
    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Failed to load projects."),
      };
    }

    const payload = data?.data ?? data;
    const items = Array.isArray(payload) ? payload : payload?.items ?? payload?.projects;
    if (!Array.isArray(items)) {
      return {
        success: false,
        status: response.status,
        error: "Unexpected response from server while loading projects.",
      };
    }

    const normalized: RecentProject[] = items
      .map((item: any) => {
        const id = item?.id ?? item?.projectId ?? item?._id;
        const name = item?.name ?? item?.projectName ?? item?.title;
        const type = item?.type ?? item?.projectType ?? item?.kind;
        const status = item?.status ?? item?.state ?? item?.processingStatus;
        const lastModified =
          item?.lastModified ??
          item?.updatedAt ??
          item?.modifiedAt ??
          item?.timestamp ??
          item?.createdAt;

        if (typeof id !== "string" || typeof name !== "string") return null;

        const last =
          typeof lastModified === "string"
            ? lastModified
            : typeof lastModified === "number"
              ? new Date(lastModified).toISOString()
              : new Date().toISOString();

        return {
          id,
          name,
          type: typeof type === "string" ? type : "Voice",
          lastModified: last,
          status: typeof status === "string" ? status : "Completed",
        } satisfies RecentProject;
      })
      .filter(Boolean) as RecentProject[];

    return { success: true, data: normalized.slice(0, limit) };
  } catch (err) {
    console.error("fetchRecentProjects error:", err);
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

