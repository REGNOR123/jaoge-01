import { API_BASE } from './apiBase';
import { getAuthHeaders } from './apiUtils';

export interface UsageSummary {
  creditLeft: number;
  currentPlan: string;
  totalCreditsAwarded: number;
}

export interface PaymentHistoryItem {
  id: string;
  razorpayOrderId: string;
  razorpayPaymentId: string | null;
  planDisplayName: string;
  amountInr: number;
  creditsGranted: number;
  status: 'created' | 'paid' | 'failed';
  currency: string;
  createdAt: string;
  paidAt: string | null;
}

export interface InvoiceData {
  invoiceId: string;
  razorpayOrderId: string;
  razorpayPaymentId: string | null;
  planDisplayName: string;
  amountInr: number;
  creditsGranted: number;
  status: string;
  currency: string;
  paidAt: string | null;
  userEmail: string;
  userName: string;
}

export const createOrder = async (
  token: string,
  planName: string,
  billingCycle: 'monthly' | 'annual',
  currency: 'INR' | 'USD' = 'INR'
): Promise<{ orderId: string; amountSmallestUnit: number; currency: string } | null> => {
  try {
    const res = await fetch(`${API_BASE}/payment/create-order`, {
      method: 'POST',
      headers: getAuthHeaders(token),
      body: JSON.stringify({ planName, billingCycle, currency }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body?.error ?? 'Order creation failed');
    return body?.data ?? null;
  } catch {
    return null;
  }
};

export const verifyPayment = async (
  token: string,
  razorpayOrderId: string,
  razorpayPaymentId: string,
  razorpaySignature: string
): Promise<{ newBalance: number; creditsGranted: number; planName: string } | null> => {
  try {
    const res = await fetch(`${API_BASE}/payment/verify`, {
      method: 'POST',
      headers: getAuthHeaders(token),
      body: JSON.stringify({ razorpayOrderId, razorpayPaymentId, razorpaySignature }),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body?.error ?? 'Verification failed');
    return body?.data ?? null;
  } catch {
    return null;
  }
};

export const getUsageSummary = async (
  token: string
): Promise<{ success: boolean; data?: UsageSummary; error?: string }> => {
  try {
    const res = await fetch(`${API_BASE}/payment/summary`, {
      headers: getAuthHeaders(token),
    });
    const body = await res.json();
    if (!res.ok) return { success: false, error: body?.error ?? 'Failed to fetch summary' };
    return { success: true, data: body?.data };
  } catch {
    return { success: false, error: 'Network error' };
  }
};

export const getPaymentHistory = async (
  token: string
): Promise<{ success: boolean; data?: PaymentHistoryItem[]; error?: string }> => {
  try {
    const res = await fetch(`${API_BASE}/payment/history`, {
      headers: getAuthHeaders(token),
    });
    const body = await res.json();
    if (!res.ok) return { success: false, error: body?.error ?? 'Failed to fetch history' };
    return { success: true, data: body?.data ?? [] };
  } catch {
    return { success: false, error: 'Network error' };
  }
};

export const getInvoice = async (
  token: string,
  orderId: string
): Promise<{ success: boolean; data?: InvoiceData; error?: string }> => {
  try {
    const res = await fetch(`${API_BASE}/payment/invoice/${orderId}`, {
      headers: getAuthHeaders(token),
    });
    const body = await res.json();
    if (!res.ok) return { success: false, error: body?.error ?? 'Failed to fetch invoice' };
    return { success: true, data: body?.data };
  } catch {
    return { success: false, error: 'Network error' };
  }
};
