import { API_BASE } from "./apiBase";

// ============================================================================
// Types for Usage Page
// ============================================================================
export type TotalUsageCard = {
  totalCharactersProcessed: number;
  totalVoiceMinutes: number;
  totalEnhancements: number;
  totalRequests: number;
};

export type QuotaCard = {
  charactersUsed: number;
  charactersRemaining: number;
  charactersLimit: number;
  charactersPercentUsed: number;
  minutesUsed: number;
  minutesRemaining: number;
  minutesLimit: number;
  minutesPercentUsed: number;
  enhancementsUsed: number;
  enhancementsRemaining: number;
  enhancementsLimit: number;
  enhancementsPercentUsed: number;
  autoGenerateUsed: number;
  autoGenerateRemaining: number;
  autoGenerateLimit: number;
  autoGeneratePercentUsed: number;
};

export type PageUsageItem = {
  pageName: string;
  displayName: string;
  charactersProcessed: number;
  minutesConsumed: number;
  requestCount: number;
  lastUsed: string;
};

export type UsageBreakdown = {
  items: PageUsageItem[];
  totalCount: number;
  currentPage: number;
  pageSize: number;
  totalPages: number;
};

export type PlanDetails = {
  planId: string;
  planName: string;
  allocatedCharacters: number;
  allocatedMinutes: number;
  allocatedEnhancements: number;
  maxFileMinutes: number;
  concurrentJobsLimit: number;
  cycleStartDate: string;
  cycleEndDate: string;
  daysRemaining: number;
};

export type UsageAlerts = {
  charactersWarning: boolean;
  charactersCritical: boolean;
  minutesWarning: boolean;
  minutesCritical: boolean;
  enhancementsWarning: boolean;
  enhancementsCritical: boolean;
  messages: string[];
};

export type DetailedUsageResponse = {
  totalUsage: TotalUsageCard;
  remainingQuota: QuotaCard;
  breakdown: UsageBreakdown;
  planDetails: PlanDetails;
  alerts: UsageAlerts;
};

export type UsageHistoryPoint = {
  date: string;
  minutes: number;
  characters: number;
  requests: number;
  enhancements: number;
};

export type UsageHistoryResponse = {
  dataPoints: UsageHistoryPoint[];
  filter: string;
  feature: string | null;
  totalDays: number;
};

export type DateFilterType = "daily" | "weekly" | "monthly" | "custom";

// ============================================================================
// Simple Usage Summary Types (without plan/quota)
// ============================================================================
export type FeatureUsageSummary = {
  feature: string;
  displayName: string;
  characters: number;
  minutes: number;
  requests: number;
  lastUsed: string | null;
};

export type SimpleUsageSummary = {
  totalCharacters: number;
  totalMinutes: number;
  totalEnhancements: number;
  totalRequests: number;
  byFeature: FeatureUsageSummary[];
};

export type SimpleUsageSummaryApiResult =
  | { success: true; status: number; data: SimpleUsageSummary }
  | { success: false; status: number; error: string };

// ============================================================================
// API Result Types
// ============================================================================
export type DetailedUsageApiResult =
  | { success: true; status: number; data: DetailedUsageResponse }
  | { success: false; status: number; error: string };

export type UsageBreakdownApiResult =
  | { success: true; status: number; data: UsageBreakdown }
  | { success: false; status: number; error: string };

export type UsageHistoryApiResult =
  | { success: true; status: number; data: UsageHistoryResponse }
  | { success: false; status: number; error: string };

export type UsageSummary = {
  minutesUsed: number;
  minutesLimit: number;
  minutesRemaining: number;
  minutesWarning: boolean;
  minutesCritical: boolean;
  characterCount: number;
  enhancementsUsed: number;
  enhancementsLimit: number;
  runningJobs: number;
  runningJobsLimit: number;
  maxFileMinutes: number | null;
  features: Array<{ feature: string } | string>;
  plan: string;
};

export type UsageSummaryApiResult =
  | { success: true; status: number; data: UsageSummary }
  | { success: false; status: number; error: string };

// ============================================================================
// Helper Functions
// ============================================================================
const parseBody = async (response: Response): Promise<any> => {
  try {
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) return await response.json();
    const text = await response.text();
    return text ? { message: text } : {};
  } catch {
    return {};
  }
};

const getMessage = (data: any, fallback: string): string => {
  return data?.error || data?.message || data?.data?.error || fallback;
};

const toNumberOrNull = (value: unknown): number | null => {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
};

const toFiniteNumber = (value: unknown): number => {
  const parsed = toNumberOrNull(value);
  return parsed == null ? 0 : parsed;
};

const getAuthHeaders = (token: string): Record<string, string> => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${token}`,
});

const handleApiError = (response: Response, data: any): { success: false; status: number; error: string } => {
  if (response.status === 401 || response.status === 403) {
    return {
      success: false,
      status: response.status,
      error: getMessage(data, "Session expired. Please login again."),
    };
  }
  if (response.status >= 500) {
    return {
      success: false,
      status: response.status,
      error: getMessage(data, "Server error. Please try again later."),
    };
  }
  return {
    success: false,
    status: response.status,
    error: getMessage(data, "Failed to load data."),
  };
};

// ============================================================================
// Normalization Functions
// ============================================================================
const normalizeDetailedUsage = (data: any): DetailedUsageResponse => {
  return {
    totalUsage: {
      totalCharactersProcessed: toFiniteNumber(data?.totalUsage?.totalCharactersProcessed),
      totalVoiceMinutes: toFiniteNumber(data?.totalUsage?.totalVoiceMinutes),
      totalEnhancements: toFiniteNumber(data?.totalUsage?.totalEnhancements),
      totalRequests: toFiniteNumber(data?.totalUsage?.totalRequests),
    },
    remainingQuota: {
      charactersUsed: toFiniteNumber(data?.remainingQuota?.charactersUsed),
      charactersRemaining: toFiniteNumber(data?.remainingQuota?.charactersRemaining),
      charactersLimit: toFiniteNumber(data?.remainingQuota?.charactersLimit),
      charactersPercentUsed: toFiniteNumber(data?.remainingQuota?.charactersPercentUsed),
      minutesUsed: toFiniteNumber(data?.remainingQuota?.minutesUsed),
      minutesRemaining: toFiniteNumber(data?.remainingQuota?.minutesRemaining),
      minutesLimit: toFiniteNumber(data?.remainingQuota?.minutesLimit),
      minutesPercentUsed: toFiniteNumber(data?.remainingQuota?.minutesPercentUsed),
      enhancementsUsed: toFiniteNumber(data?.remainingQuota?.enhancementsUsed),
      enhancementsRemaining: toFiniteNumber(data?.remainingQuota?.enhancementsRemaining),
      enhancementsLimit: toFiniteNumber(data?.remainingQuota?.enhancementsLimit),
      enhancementsPercentUsed: toFiniteNumber(data?.remainingQuota?.enhancementsPercentUsed),
    },
    breakdown: normalizeBreakdown(data?.breakdown),
    planDetails: {
      planId: data?.planDetails?.planId || "",
      planName: data?.planDetails?.planName || "",
      allocatedCharacters: toFiniteNumber(data?.planDetails?.allocatedCharacters),
      allocatedMinutes: toFiniteNumber(data?.planDetails?.allocatedMinutes),
      allocatedEnhancements: toFiniteNumber(data?.planDetails?.allocatedEnhancements),
      maxFileMinutes: toFiniteNumber(data?.planDetails?.maxFileMinutes),
      concurrentJobsLimit: toFiniteNumber(data?.planDetails?.concurrentJobsLimit),
      cycleStartDate: data?.planDetails?.cycleStartDate || "",
      cycleEndDate: data?.planDetails?.cycleEndDate || "",
      daysRemaining: toFiniteNumber(data?.planDetails?.daysRemaining),
    },
    alerts: {
      charactersWarning: Boolean(data?.alerts?.charactersWarning),
      charactersCritical: Boolean(data?.alerts?.charactersCritical),
      minutesWarning: Boolean(data?.alerts?.minutesWarning),
      minutesCritical: Boolean(data?.alerts?.minutesCritical),
      enhancementsWarning: Boolean(data?.alerts?.enhancementsWarning),
      enhancementsCritical: Boolean(data?.alerts?.enhancementsCritical),
      messages: Array.isArray(data?.alerts?.messages) ? data.alerts.messages : [],
    },
  };
};

const normalizeBreakdown = (data: any): UsageBreakdown => {
  return {
    items: Array.isArray(data?.items)
      ? data.items.map((item: any) => ({
          pageName: item?.pageName || "",
          displayName: item?.displayName || "",
          charactersProcessed: toFiniteNumber(item?.charactersProcessed),
          minutesConsumed: toFiniteNumber(item?.minutesConsumed),
          requestCount: toFiniteNumber(item?.requestCount),
          lastUsed: item?.lastUsed || "",
        }))
      : [],
    totalCount: toFiniteNumber(data?.totalCount),
    currentPage: toFiniteNumber(data?.currentPage) || 1,
    pageSize: toFiniteNumber(data?.pageSize) || 10,
    totalPages: toFiniteNumber(data?.totalPages) || 1,
  };
};

const normalizeUsageHistory = (data: any): UsageHistoryResponse => {
  return {
    dataPoints: Array.isArray(data?.dataPoints)
      ? data.dataPoints.map((point: any) => ({
          date: point?.date || "",
          minutes: toFiniteNumber(point?.minutes),
          characters: toFiniteNumber(point?.characters),
          requests: toFiniteNumber(point?.requests),
          enhancements: toFiniteNumber(point?.enhancements),
        }))
      : [],
    filter: data?.filter || "daily",
    feature: data?.feature || null,
    totalDays: toFiniteNumber(data?.totalDays),
  };
};

const normalizeSimpleUsageSummary = (data: any): SimpleUsageSummary => {
  return {
    totalCharacters: toFiniteNumber(data?.totalCharacters),
    totalMinutes: toFiniteNumber(data?.totalMinutes),
    totalEnhancements: toFiniteNumber(data?.totalEnhancements),
    totalRequests: toFiniteNumber(data?.totalRequests),
    byFeature: Array.isArray(data?.byFeature)
      ? data.byFeature.map((f: any) => ({
          feature: f?.feature || "",
          displayName: f?.displayName || "",
          characters: toFiniteNumber(f?.characters),
          minutes: toFiniteNumber(f?.minutes),
          requests: toFiniteNumber(f?.requests),
          lastUsed: f?.lastUsed || null,
        }))
      : [],
  };
};

// ============================================================================
// API Functions
// ============================================================================

/**
 * Fetch simple usage summary without plan/quota calculations
 */
export const fetchSimpleUsageSummary = async (
  token: string,
  startDate?: string,
  endDate?: string
): Promise<SimpleUsageSummaryApiResult> => {
  try {
    const params = new URLSearchParams();
    if (startDate) params.append("startDate", startDate);
    if (endDate) params.append("endDate", endDate);

    const url = params.toString()
      ? `${API_BASE}/usage/summary?${params}`
      : `${API_BASE}/usage/summary`;

    const response = await fetch(url, {
      method: "GET",
      headers: getAuthHeaders(token),
    });
    const data = await parseBody(response);

    if (!response.ok) {
      return handleApiError(response, data);
    }

    const summaryData = data?.data || data;
    return { success: true, status: response.status, data: normalizeSimpleUsageSummary(summaryData) };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

/**
 * Fetch detailed usage page data with all cards
 */
export const fetchDetailedUsage = async (
  token: string,
  filter: DateFilterType = "monthly",
  startDate?: string,
  endDate?: string
): Promise<DetailedUsageApiResult> => {
  try {
    const params = new URLSearchParams({ filter });
    if (startDate) params.append("startDate", startDate);
    if (endDate) params.append("endDate", endDate);

    const response = await fetch(`${API_BASE}/usage/detailed?${params}`, {
      method: "GET",
      headers: getAuthHeaders(token),
    });
    const data = await parseBody(response);

    if (!response.ok) {
      return handleApiError(response, data);
    }

    return { success: true, status: response.status, data: normalizeDetailedUsage(data) };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

/**
 * Fetch paginated usage breakdown
 */
export const fetchUsageBreakdown = async (
  token: string,
  options: {
    page?: number;
    pageSize?: number;
    sortBy?: string;
    descending?: boolean;
    filter?: DateFilterType;
    startDate?: string;
    endDate?: string;
  } = {}
): Promise<UsageBreakdownApiResult> => {
  try {
    const params = new URLSearchParams();
    if (options.page) params.append("page", String(options.page));
    if (options.pageSize) params.append("pageSize", String(options.pageSize));
    if (options.sortBy) params.append("sortBy", options.sortBy);
    if (options.descending !== undefined) params.append("descending", String(options.descending));
    if (options.filter) params.append("filter", options.filter);
    if (options.startDate) params.append("startDate", options.startDate);
    if (options.endDate) params.append("endDate", options.endDate);

    const response = await fetch(`${API_BASE}/usage/breakdown?${params}`, {
      method: "GET",
      headers: getAuthHeaders(token),
    });
    const data = await parseBody(response);

    if (!response.ok) {
      return handleApiError(response, data);
    }

    return { success: true, status: response.status, data: normalizeBreakdown(data) };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

/**
 * Fetch usage history for charts
 */
export const fetchUsageHistory = async (
  token: string,
  filter: DateFilterType = "daily",
  feature?: string,
  days: number = 30
): Promise<UsageHistoryApiResult> => {
  try {
    const params = new URLSearchParams({ filter, days: String(days) });
    if (feature) params.append("feature", feature);

    const response = await fetch(`${API_BASE}/usage/history?${params}`, {
      method: "GET",
      headers: getAuthHeaders(token),
    });
    const data = await parseBody(response);

    if (!response.ok) {
      return handleApiError(response, data);
    }

    return { success: true, status: response.status, data: normalizeUsageHistory(data) };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

/**
 * Fetch usage summary with key metrics
 */
export const fetchUsageSummary = async (
  token: string,
  filter: DateFilterType = "monthly"
): Promise<UsageSummaryApiResult> => {
  try {
    const response = await fetch(`${API_BASE}/usage/detailed?filter=${filter}`, {
      method: "GET",
      headers: getAuthHeaders(token),
    });
    const data = await parseBody(response);

    if (!response.ok) {
      return handleApiError(response, data);
    }

    const normalized = normalizeDetailedUsage(data);
    
    // Extract unique features from breakdown if available
    const features = Array.from(
      new Set(
        normalized.breakdown.items.map((item) => item.pageName || item.displayName)
      )
    ) as string[];

    const summary: UsageSummary = {
      minutesUsed: normalized.remainingQuota.minutesUsed,
      minutesLimit: normalized.remainingQuota.minutesLimit,
      minutesRemaining: normalized.remainingQuota.minutesRemaining,
      minutesWarning: normalized.alerts.minutesWarning,
      minutesCritical: normalized.alerts.minutesCritical,
      characterCount: normalized.totalUsage.totalCharactersProcessed,
      enhancementsUsed: normalized.remainingQuota.enhancementsUsed,
      enhancementsLimit: normalized.remainingQuota.enhancementsLimit,
      runningJobs: 0, // Not currently tracked in API response
      runningJobsLimit: normalized.planDetails.concurrentJobsLimit,
      maxFileMinutes: normalized.planDetails.maxFileMinutes,
      features: features.length > 0 ? features : [],
      plan: normalized.planDetails.planName || "Free",
    };

    return { success: true, status: response.status, data: summary };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};
