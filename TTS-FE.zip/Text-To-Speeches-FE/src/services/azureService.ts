import { VoiceName, SpeechStyle } from '../types';
import { API_BASE } from './apiBase';
import { parseBody } from './apiUtils';

type BackendSpeechResponse = {
  success: boolean;
  status?: number;
  data?: {
    audioUrl?: string;
    audioDataUrl?: string;
  };
  error?: string;
  message?: string;
};

/**
 * Generates speech by calling the backend (keys stay server-side).
 * Backend should implement: POST /api/speech/tts
 * @param token - Optional auth token for usage tracking
 * @param feature - Optional feature name for usage tracking (e.g., "translate-dub", "create-voice")
 */
export const generateAzureSpeech = async (
  text: string,
  voice: VoiceName,
  rate: number = 0,
  pitch: number = 0,
  volume: number = 100,
  style: SpeechStyle = 'general',
  degree: number = 1.0,
  token?: string | null,
  feature?: string,
): Promise<string> => {
  if (!text || !text.trim()) {
    throw new Error('Text is required.');
  }

  const headers: HeadersInit = { 'Content-Type': 'application/json' };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE}/speech/tts`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      text: text.trim(),
      voice,
      rate,
      pitch,
      volume,
      style,
      degree,
      feature,
    }),
  });

  const data = (await parseBody(response)) as BackendSpeechResponse | any;

  if (response.status === 402) {
    const creds = data?.data;
    const err = new Error(data?.error || 'Insufficient credits.');
    (err as any).insufficientCredits = true;
    (err as any).requiredCredits = creds?.requiredCredits ?? 0;
    (err as any).currentBalance = creds?.currentBalance ?? 0;
    throw err;
  }

  if (!response.ok || data?.success === false) {
    throw new Error(data?.error || data?.message || 'Speech synthesis failed.');
  }

  const audioUrl: string | undefined =
    data?.data?.audioUrl || data?.data?.audioDataUrl || data?.audioUrl || data?.audioDataUrl;

  if (!audioUrl) {
    throw new Error('Speech synthesis failed: missing audioUrl.');
  }

  return audioUrl;
};
