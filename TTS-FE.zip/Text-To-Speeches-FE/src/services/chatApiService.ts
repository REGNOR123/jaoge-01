import { API_BASE } from "./apiBase";

const getResponseMessage = (data: any, fallback: string): string => {
  return data?.error?.message || data?.message || data?.error || fallback;
};

export type ChatRequest = {
  message: string;
  systemPrompt?: string;
};

export type ChatSuccess = { success: true; reply: string };
export type ChatFailure = { success: false; status?: number; error: string; insufficientCredits?: true; requiredCredits?: number; currentBalance?: number };
export type ChatResponse = ChatSuccess | ChatFailure;

const extractReply = (data: any): string | null => {
  const direct = data?.reply ?? data?.data?.reply ?? data?.message ?? data?.data?.message;
  if (typeof direct === "string" && direct.trim()) return direct;

  const choicesContent = data?.choices?.[0]?.message?.content;
  if (typeof choicesContent === "string" && choicesContent.trim()) return choicesContent;

  const outputText = data?.output_text;
  if (typeof outputText === "string" && outputText.trim()) return outputText;

  const responsesText = data?.output?.[0]?.content?.[0]?.text;
  if (typeof responsesText === "string" && responsesText.trim()) return responsesText;

  return null;
};

export const sendChatMessage = async (
  payload: ChatRequest,
  token?: string | null,
): Promise<ChatResponse> => {
  try {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE}/chat`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        ...payload,
        // Compatibility aliases for backends that expect different field names.
        prompt: payload.message,
        system: payload.systemPrompt,
      }),
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      if (response.status === 402) {
        const creds = data?.data;
        return { success: false, status: 402, error: getResponseMessage(data, 'Insufficient credits.'),
          insufficientCredits: true, requiredCredits: creds?.requiredCredits ?? 0, currentBalance: creds?.currentBalance ?? 0 };
      }
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Chat request failed."),
      };
    }

    const replyFromAny = extractReply(data);
    if (replyFromAny) {
      return { success: true, reply: replyFromAny };
    }

    if (data?.success !== true) {
      return {
        success: false,
        status: response.status,
        error: getResponseMessage(data, "Chat request failed."),
      };
    }

    const reply = data?.reply;
    if (typeof reply !== "string" || !reply.trim()) {
      return {
        success: false,
        status: response.status,
        error:
          "Model returned empty content. If this is Azure OpenAI, check content filters, deployment/model, and max_tokens.",
      };
    }

    return {
      success: true,
      reply,
    };
  } catch (err) {
    console.error("sendChatMessage error:", err);
    return {
      success: false,
      status: 0,
      error: "Network error. Please try again.",
    };
  }
};
