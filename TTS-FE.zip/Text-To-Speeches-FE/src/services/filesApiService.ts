import { API_BASE } from "./apiBase";
import { parseBody } from "./apiUtils";

export type ApiErrorResult = {
  success: false;
  status: number;
  error: string;
};

export type StoredFileRecord = {
  fileId: string;
  fileName: string;
  contentType?: string;
  feature?: string;
  jobId?: string;
  durationMinutes?: number | null;
  isOutput?: boolean;
  uploadedAt?: string;
  expiresAt?: string;
  sizeBytes?: number | null;
};

export type ApiSuccessResult<T> = {
  success: true;
  status: number;
  data: T;
};

export type ApiResult<T> = ApiSuccessResult<T> | ApiErrorResult;

// Intentionally local: omits Content-Type so the browser sets it for FormData uploads
const getAuthHeaders = (token: string): HeadersInit => ({
  Authorization: `Bearer ${token}`,
});

const getResponseMessage = (data: any, fallback: string): string => {
  return (
    data?.error ||
    data?.message ||
    data?.data?.error ||
    data?.data?.message ||
    fallback
  );
};

const mapFileApiError = (status: number, data: any, fallback: string): string => {
  if (status === 401 || status === 403) {
    return getResponseMessage(data, "Session expired. Please login again.");
  }
  if (status === 415) {
    return getResponseMessage(data, "Unsupported file type. Please upload a WAV or MP3 file.");
  }
  if (status === 422) {
    return getResponseMessage(data, "File validation failed. Please review the file and try again.");
  }
  if (status >= 500) {
    return getResponseMessage(data, "Server error. Please try again.");
  }
  return getResponseMessage(data, fallback);
};

const toOptionalNumber = (value: unknown): number | null => {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
};

const toOptionalBoolean = (value: unknown): boolean | undefined => {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }
  return undefined;
};

const normalizeStoredFileRecord = (
  data: any,
  fallbackFile?: Pick<File, "name" | "type" | "size">,
): StoredFileRecord | null => {
  const payload =
    data?.data && typeof data.data === "object" && data.data !== null ? data.data : data;
  const fileId =
    payload?.fileId ||
    payload?.id ||
    payload?._id ||
    (typeof payload === "string" ? payload : undefined);
  const fileName =
    payload?.fileName ||
    payload?.name ||
    fallbackFile?.name;
  if (typeof fileId !== "string" || !fileId.trim()) return null;
  if (typeof fileName !== "string" || !fileName.trim()) return null;

  return {
    fileId: fileId.trim(),
    fileName: fileName.trim(),
    contentType:
      typeof (payload?.contentType || fallbackFile?.type) === "string"
        ? String(payload?.contentType || fallbackFile?.type).trim()
        : undefined,
    feature:
      typeof payload?.feature === "string" ? payload.feature.trim() : undefined,
    jobId:
      typeof payload?.jobId === "string" ? payload.jobId.trim() : undefined,
    durationMinutes: toOptionalNumber(payload?.durationMinutes),
    isOutput: toOptionalBoolean(payload?.isOutput),
    uploadedAt:
      typeof (payload?.uploadedAt || payload?.createdAt) === "string"
        ? String(payload?.uploadedAt || payload?.createdAt)
        : undefined,
    expiresAt:
      typeof payload?.expiresAt === "string" ? payload.expiresAt : undefined,
    sizeBytes: toOptionalNumber(payload?.sizeBytes ?? fallbackFile?.size),
  };
};

export const uploadManagedFile = async (
  token: string,
  file: File,
  params: {
    feature: string;
    jobId?: string;
    durationMinutes?: number | null;
    isOutput?: boolean;
    onProgress?: (percent: number) => void;
  },
): Promise<ApiResult<StoredFileRecord>> => {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("feature", params.feature);
  if (params.jobId) formData.append("jobId", params.jobId);
  if (params.durationMinutes != null && Number.isFinite(params.durationMinutes)) {
    formData.append("durationMinutes", String(params.durationMinutes));
  }
  if (typeof params.isOutput === "boolean") {
    formData.append("isOutput", params.isOutput ? "true" : "false");
  }

  // Use XMLHttpRequest for progress tracking if callback is provided
  if (params.onProgress) {
    return new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      
      // Track upload progress
      xhr.upload.addEventListener("progress", (event) => {
        if (event.lengthComputable) {
          const percent = Math.round((event.loaded / event.total) * 100);
          params.onProgress?.(Math.min(percent, 95)); // Cap at 95% until response
        }
      });

      xhr.addEventListener("load", async () => {
        try {
          // xhr.responseType = "json" means response is already parsed
          const data = xhr.response || {};
          
          if (xhr.status >= 400) {
            resolve({
              success: false,
              status: xhr.status,
              error: mapFileApiError(xhr.status, data, "Failed to upload file."),
            });
            return;
          }

          const normalized = normalizeStoredFileRecord(data, file);
          if (!normalized) {
            console.error("uploadManagedFile unexpected response", data);
            resolve({
              success: false,
              status: xhr.status,
              error: "Unexpected response from server while storing the file.",
            });
            return;
          }

          params.onProgress?.(100);
          resolve({ success: true, status: xhr.status, data: normalized });
        } catch (error) {
          resolve({
            success: false,
            status: xhr.status,
            error: "Failed to parse upload response.",
          });
        }
      });

      xhr.addEventListener("error", () => {
        resolve({ success: false, status: 0, error: "Network error. Please try again." });
      });

      xhr.addEventListener("abort", () => {
        resolve({ success: false, status: 0, error: "Upload cancelled." });
      });

      xhr.open("POST", `${API_BASE}/files/upload`);
      xhr.setRequestHeader("Authorization", `Bearer ${token}`);
      xhr.responseType = "json";
      xhr.send(formData);
    });
  }

  // Fallback to fetch without progress tracking for backward compatibility
  try {
    const response = await fetch(`${API_BASE}/files/upload`, {
      method: "POST",
      headers: getAuthHeaders(token),
      body: formData,
    });
    const data = await parseBody(response);
    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: mapFileApiError(response.status, data, "Failed to upload file."),
      };
    }

    const normalized = normalizeStoredFileRecord(data, file);
    if (!normalized) {
      console.error("uploadManagedFile unexpected response", data);
      return {
        success: false,
        status: response.status,
        error: "Unexpected response from server while storing the file.",
      };
    }

    return { success: true, status: response.status, data: normalized };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

export const uploadManagedTextFile = async (
  token: string,
  text: string,
  params: {
    fileName: string;
    feature: string;
    jobId?: string;
    durationMinutes?: number | null;
    isOutput?: boolean;
    contentType?: string;
    onProgress?: (percent: number) => void;
  },
): Promise<ApiResult<StoredFileRecord>> => {
  const file = new File([text], params.fileName, {
    type: params.contentType || "text/plain;charset=utf-8",
  });

  return uploadManagedFile(token, file, {
    feature: params.feature,
    jobId: params.jobId,
    durationMinutes: params.durationMinutes,
    isOutput: params.isOutput,
    onProgress: params.onProgress,
  });
};

const getFileNameFromDisposition = (value: string | null): string | undefined => {
  if (!value) return undefined;
  const utf8Match = value.match(/filename\*=UTF-8''([^;]+)/i);
  if (utf8Match?.[1]) {
    try {
      return decodeURIComponent(utf8Match[1]).trim();
    } catch {
      return utf8Match[1].trim();
    }
  }
  const plainMatch = value.match(/filename="?([^"]+)"?/i);
  return plainMatch?.[1]?.trim() || undefined;
};

export const downloadManagedFile = async (
  token: string,
  fileId: string,
): Promise<ApiResult<{ blob: Blob; fileName?: string; contentType?: string }>> => {
  try {
    const response = await fetch(`${API_BASE}/files/${encodeURIComponent(fileId)}`, {
      method: "GET",
      headers: getAuthHeaders(token),
    });

    if (!response.ok) {
      const data = await parseBody(response);
      return {
        success: false,
        status: response.status,
        error: mapFileApiError(response.status, data, "Failed to download file."),
      };
    }

    const blob = await response.blob();
    return {
      success: true,
      status: response.status,
      data: {
        blob,
        fileName: getFileNameFromDisposition(response.headers.get("content-disposition")),
        contentType: response.headers.get("content-type") || undefined,
      },
    };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};

export const deleteManagedFile = async (
  token: string,
  fileId: string,
): Promise<ApiResult<null>> => {
  try {
    const response = await fetch(`${API_BASE}/files/${encodeURIComponent(fileId)}`, {
      method: "DELETE",
      headers: getAuthHeaders(token),
    });
    const data = await parseBody(response);

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        error: mapFileApiError(response.status, data, "Failed to delete file."),
      };
    }

    return { success: true, status: response.status, data: null };
  } catch {
    return { success: false, status: 0, error: "Network error. Please try again." };
  }
};
