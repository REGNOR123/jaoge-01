import { API_BASE } from './apiBase';
import { LANGUAGE_MAP } from '../data/languages';

const GUEST_ID_KEY = "guest_id";

const getGuestIdParam = (): string => {
  try {
    const guestId = localStorage.getItem(GUEST_ID_KEY);
    return guestId ? `?guestId=${encodeURIComponent(guestId)}` : '';
  } catch {
    return '';
  }
};

export const detectTextLanguage = async (
  text: string,
  token?: string | null,
): Promise<string | null> => {
  if (!text || text.trim().length < 3) return null;

  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const guestParam = token ? '' : getGuestIdParam();

    const response = await fetch(`${API_BASE}/translator/detect${guestParam}`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ text: text.substring(0, 500) }),
    });

    if (response.status === 429) {
      const data = await response.json().catch(() => null);
      console.warn('Guest limit reached for language detection:', data?.error);
      return null;
    }

    if (response.status === 402) return null;

    if (!response.ok) {
      console.error('Language detect failed', await response.text());
      return null;
    }

    const data = await response.json();
    const langCode: string | undefined =
      data?.data?.language || data?.language || data?.data?.languageCode || data?.languageCode;

    if (!langCode) return 'Unknown';
    const baseLangCode = langCode.split('-')[0].toLowerCase();
    return LANGUAGE_MAP[langCode] ?? LANGUAGE_MAP[baseLangCode] ?? 'Unknown';
  } catch (err) {
    console.error('Language detection error:', err);
    return null;
  }
};

export const detectTextLanguageCode = async (
  text: string,
  token?: string | null,
): Promise<string | null> => {
  if (!text || text.trim().length < 3) return null;

  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const guestParam = token ? '' : getGuestIdParam();

    const response = await fetch(`${API_BASE}/translator/detect${guestParam}`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ text: text.substring(0, 500) }),
    });

    if (response.status === 429) {
      const data = await response.json().catch(() => null);
      console.warn('Guest limit reached for language detection:', data?.error);
      return null;
    }

    if (response.status === 402) return null;

    if (!response.ok) {
      console.error('Language detect failed', await response.text());
      return null;
    }

    const data = await response.json();
    const language = String(
      data?.data?.language || data?.language || data?.data?.languageCode || data?.languageCode || '',
    ).trim();

    return language ? language : null;
  } catch (err) {
    console.error('Language detection error:', err);
    return null;
  }
};

export const translateText = async (
  text: string,
  targetLanguage: string,
  token?: string | null,
  fromLanguage?: string | null,
): Promise<string | null> => {
  if (!text || text.trim().length === 0) return null;

  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const body: Record<string, string> = { text, to: targetLanguage };
    if (fromLanguage) body['from'] = fromLanguage;

    const response = await fetch(`${API_BASE}/translator/translate`, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      if (response.status === 402) return null;
      console.error('Translate failed', await response.text());
      return null;
    }

    const data = await response.json();
    const translated: string | undefined =
      data?.data?.text || data?.data?.translatedText || data?.translatedText || data?.text;

    return translated ?? null;
  } catch (err) {
    console.error('Translation error:', err);
    return null;
  }
};
