/**
 * Script Studio Service
 * Handles script generation for different SKUs via backend endpoints
 */

import { ScriptSKU, SCRIPT_SKU_CONFIGS } from "../config/scriptStudioConfig";
import { API_BASE } from "./apiBase";

export interface ScriptGenerationRequest {
  sku: ScriptSKU;
  inputs: Record<string, string>;
  tone: string;
  length?: string;
}

export interface ScriptGenerationResponse {
  success: boolean;
  script: string;
  metadata?: {
    estimatedReadTime?: string;
    sections?: string[];
  };
  error?: string;
  limitType?: string;
  insufficientCredits?: true;
  requiredCredits?: number;
  currentBalance?: number;
}

/**
 * Generate script based on SKU and user inputs
 * Routes to SKU-specific backend endpoint
 */
export const generateScriptBySKU = async (
  request: ScriptGenerationRequest,
  token?: string | null,
): Promise<ScriptGenerationResponse> => {
  try {
    const config = SCRIPT_SKU_CONFIGS[request.sku];
    if (!config) {
      return {
        success: false,
        script: "",
        error: "Invalid script type selected",
      };
    }

    // Call SKU-specific endpoint
    // Pattern: /api/script-generation/{sku}
    const endpoint = `${API_BASE}/script-generation/${request.sku}`;

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const response = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify({
        inputs: request.inputs,
        tone: request.tone,
        length: request.length,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      if (response.status === 402) {
        return { success: false, script: '', error: errorData.error || 'Insufficient credits.',
          insufficientCredits: true, requiredCredits: errorData.data?.requiredCredits ?? 0, currentBalance: errorData.data?.currentBalance ?? 0 };
      }
      return {
        success: false,
        script: "",
        error: errorData.message || `HTTP ${response.status}: Failed to generate script`,
      };
    }

    const data = await response.json();
    return {
      success: true,
      script: data.script || data.content || "",
      metadata: data.metadata,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error occurred";
    return {
      success: false,
      script: "",
      error: `Failed to generate script: ${message}`,
    };
  }
};

/**
 * Generate a specific field using AI based on context
 */
export const generateFieldByAI = async (
  sku: ScriptSKU,
  fieldId: string,
  context: Record<string, string>,
  token?: string | null,
): Promise<ScriptGenerationResponse> => {
  try {
    const endpoint = `${API_BASE}/script-generation/${sku}/generate-field`;

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const response = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify({
        fieldId,
        context,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const errorMsg = errorData.error || errorData.message || `HTTP ${response.status}: Failed to generate field`;
      if (response.status === 402) {
        return { success: false, script: '', error: errorMsg,
          insufficientCredits: true, requiredCredits: errorData.data?.requiredCredits ?? 0, currentBalance: errorData.data?.currentBalance ?? 0 };
      }
      return {
        success: false,
        script: "",
        error: errorMsg,
        limitType: response.status === 429 ? errorData.limitType : undefined,
      };
    }

    const data = await response.json();
    return {
      success: true,
      script: data.content || data.fieldValue || "",
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error occurred";
    return {
      success: false,
      script: "",
      error: `Failed to generate field: ${message}`,
    };
  }
};

/**
 * Transform existing script (rewrite, shorten, expand, change tone)
 * This could use a generic endpoint or SKU-specific variants
 */
export const transformScript = async (
  sku: ScriptSKU,
  script: string,
  transformation: "rewrite" | "shorten" | "expand" | "tone-change",
  tone?: string,
  token?: string,
): Promise<ScriptGenerationResponse> => {
  try {
    const endpoint = `${API_BASE}/script-generation/${sku}/transform`;

    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token && { Authorization: `Bearer ${token}` }),
      },
      body: JSON.stringify({
        script,
        transformation,
        tone,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      if (response.status === 402) {
        return { success: false, script: '', error: errorData.error || errorData.message || 'Insufficient credits.',
          insufficientCredits: true, requiredCredits: errorData.data?.requiredCredits ?? 0, currentBalance: errorData.data?.currentBalance ?? 0 };
      }
      return {
        success: false,
        script: "",
        error: errorData.message || `HTTP ${response.status}: Transformation failed`,
      };
    }

    const data = await response.json();
    return {
      success: true,
      script: data.script || data.content || "",
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error occurred";
    return {
      success: false,
      script: "",
      error: `Transformation failed: ${message}`,
    };
  }
};

/**
 * Validate script generation inputs for a given SKU
 */
export const validateInputsForSKU = (
  sku: ScriptSKU,
  inputs: Record<string, string>,
): { valid: boolean; errors: string[] } => {
  const config = SCRIPT_SKU_CONFIGS[sku];
  if (!config) {
    return { valid: false, errors: ["Invalid script type"] };
  }

  const errors: string[] = [];

  // Check all steps for required fields
  config.steps.forEach((step) => {
    step.fields.forEach((field) => {
      if (field.required && (!inputs[field.id] || inputs[field.id].trim() === "")) {
        errors.push(`${field.label} is required`);
      }

      if (field.maxLength && inputs[field.id]?.length > field.maxLength) {
        errors.push(`${field.label} exceeds maximum length of ${field.maxLength}`);
      }

      if (field.minLength && inputs[field.id]?.length < field.minLength) {
        errors.push(`${field.label} must be at least ${field.minLength} characters`);
      }
    });
  });

  return {
    valid: errors.length === 0,
    errors,
  };
};
