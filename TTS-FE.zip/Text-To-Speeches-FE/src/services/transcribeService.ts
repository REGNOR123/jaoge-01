import { API_BASE } from "./apiBase";
import { isMp3File, isWavFile } from "../utils/audioTranscode";
import { parseBody } from "./apiUtils";

export type TranscribeOptions = {
  language: string;
  autoPunctuation: boolean;
  includeTimestamps: boolean;
};

export type TranscribeResult =
  | { success: true; transcript: string }
  | { success: false; error: string; limitType?: string; used?: number; limit?: number; insufficientCredits?: true; requiredCredits?: number; currentBalance?: number };

export type TranscribeWord = { startMs: number; endMs: number; word: string };
export type TranscribeSegment = { startMs: number; endMs: number; text: string };
export type TranscribeBackendData = {
  text: string;
  segments?: TranscribeSegment[];
  words?: TranscribeWord[];
};

const formatTimestampMs = (ms: number): string => {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const mm = Math.floor(totalSeconds / 60);
  const ss = totalSeconds % 60;
  return `${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
};

const getErrorMessage = (data: any, fallback: string): string => {
  return data?.error || data?.message || data?.data?.error || fallback;
};

const toTimestampedTranscript = (data: TranscribeBackendData): string => {
  const segments = Array.isArray(data.segments) ? data.segments : [];
  if (segments.length) {
    return segments
      .map((s) => `[${formatTimestampMs(Number(s.startMs) || 0)}] ${(s.text || "").trim()}`.trim())
      .filter(Boolean)
      .join("\n")
      .trim();
  }

  const words = Array.isArray(data.words) ? data.words : [];
  if (words.length) {
    return words
      .map((w) => `[${formatTimestampMs(Number(w.startMs) || 0)}] ${(w.word || "").trim()}`.trim())
      .filter(Boolean)
      .join("\n")
      .trim();
  }

  return (data.text || "").trim();
};

const stripBasicPunctuation = (value: string): string => {
  // Best-effort "no punctuation" mode for backends that always return punctuated text.
  return value.replace(/[.,!?;…“”"()]/g, "").replace(/\s{2,}/g, " ").trim();
};

export const transcribeAudioFile = async (
  file: File,
  options: TranscribeOptions,
  token?: string | null,
): Promise<TranscribeResult> => {
  if (!file) return { success: false, error: "Please select an audio file." };

  if (!isWavFile(file) && !isMp3File(file)) {
    return { success: false, error: "Supported formats: WAV, MP3." };
  }

  const fd = new FormData();
  fd.append("audio", file);
  if (options.language) fd.append("language", options.language);
  if (options.autoPunctuation !== undefined) fd.append("autoPunctuation", String(options.autoPunctuation));
  if (options.includeTimestamps) fd.append("includeTimestamps", "true");

  const headers: Record<string, string> = {};
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  try {
    const res = await fetch(`${API_BASE}/speech/transcribe`, {
      method: "POST",
      headers,
      body: fd,
    });

    const json = await parseBody(res);
    if (!res.ok) {
      const errorMsg = getErrorMessage(json, "Transcription failed.");
      if (res.status === 402) {
        const creds = json?.data;
        return { success: false, error: errorMsg, insufficientCredits: true,
          requiredCredits: creds?.requiredCredits ?? 0, currentBalance: creds?.currentBalance ?? 0 };
      }
      if (res.status === 429 && json?.limitType) {
        return { success: false, error: errorMsg, limitType: json.limitType, used: json.used, limit: json.limit };
      }
      return { success: false, error: errorMsg };
    }

    const data: TranscribeBackendData | undefined = json?.data;
    if (!data || typeof data.text !== "string") {
      return { success: false, error: "Transcription failed: invalid response." };
    }

    const base = options.includeTimestamps ? toTimestampedTranscript(data) : data.text.trim();
    const transcript = options.autoPunctuation ? base : stripBasicPunctuation(base);
    return { success: true, transcript };
  } catch {
    return { success: false, error: "Network error. Please try again." };
  }
};
