
import { VoiceName, VoiceOption, SpeechStyle } from './types';

export const GOOGLE_CLIENT_ID =
  (import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined)?.trim() ||
  '169846995090-csmqosj6c06k0qd0oih82fu16m9qt6u9.apps.googleusercontent.com';

export const AVAILABLE_STYLES: { id: SpeechStyle; label: string; icon: string }[] = [
  { id: 'general', label: 'Neutral', icon: '⚖️' },
  { id: 'cheerful', label: 'Cheerful', icon: '✨' },
  { id: 'friendly', label: 'Friendly', icon: '🤝' },
  { id: 'empathetic', label: 'Empathetic', icon: '💗' },
  { id: 'whispering', label: 'Whisper', icon: '🤫' },
  { id: 'serious', label: 'Serious', icon: '👔' },
  { id: 'sad', label: 'Sad', icon: '💧' },
  { id: 'angry', label: 'Angry', icon: '🔥' },
  { id: 'fearful', label: 'Fearful', icon: '😨' },
  { id: 'assistant', label: 'Assistant', icon: '🤖' },
  { id: 'chat', label: 'Chatty', icon: '💬' },
  { id: 'newscast', label: 'News', icon: '📺' },
];

export const AVAILABLE_VOICES: VoiceOption[] = [
  // English
  { id: VoiceName.JENNY,    name: 'Jenny',    lang: 'English (US)', description: 'Friendly and professional neural voice',     gender: 'Female', region: 'English' },
  { id: VoiceName.GUY,      name: 'Guy',      lang: 'English (US)', description: 'Reliable and natural neural voice',          gender: 'Male',   region: 'English' },
  { id: VoiceName.ARIA,     name: 'Aria',     lang: 'English (US)', description: 'Clear and expressive neural voice',          gender: 'Female', region: 'English' },
  { id: VoiceName.DAVIS,    name: 'Davis',    lang: 'English (US)', description: 'Authoritative and warm neural voice',        gender: 'Male',   region: 'English' },
  { id: VoiceName.STEFFAN,  name: 'Steffan',  lang: 'English (US)', description: 'Dynamic and conversational neural voice',    gender: 'Male',   region: 'English' },
  { id: VoiceName.SONIA,    name: 'Sonia',    lang: 'English (UK)', description: 'Confident and clear British voice',          gender: 'Female', region: 'English' },
  { id: VoiceName.RYAN,     name: 'Ryan',     lang: 'English (UK)', description: 'Polite and articulate British voice',        gender: 'Male',   region: 'English' },
  { id: VoiceName.NATASHA,  name: 'Natasha',  lang: 'English (AU)', description: 'Natural Australian accent',                  gender: 'Female', region: 'English' },
  { id: VoiceName.WILLIAM,  name: 'William',  lang: 'English (AU)', description: 'Friendly Australian accent',                 gender: 'Male',   region: 'English' },
  { id: VoiceName.NEERJA,   name: 'Neerja',   lang: 'English (IN)', description: 'Professional Indian English voice',          gender: 'Female', region: 'English' },
  { id: VoiceName.PRABHAT,  name: 'Prabhat',  lang: 'English (IN)', description: 'Clear Indian English voice',                 gender: 'Male',   region: 'English' },
  { id: VoiceName.CLARA,    name: 'Clara',    lang: 'English (CA)', description: 'Natural Canadian English voice',             gender: 'Female', region: 'English' },
  { id: VoiceName.LIAM,     name: 'Liam',     lang: 'English (CA)', description: 'Clear Canadian English voice',               gender: 'Male',   region: 'English' },

  // European
  { id: VoiceName.DENISE,    name: 'Denise',    lang: 'French (FR)',      description: 'Natural and melodious French voice',            gender: 'Female', region: 'European' },
  { id: VoiceName.HENRI,     name: 'Henri',     lang: 'French (FR)',      description: 'Calm and steady French voice',                   gender: 'Male',   region: 'European' },
  { id: VoiceName.SYLVIE,    name: 'Sylvie',    lang: 'French (CA)',      description: 'Authentic Canadian French voice',                gender: 'Female', region: 'European' },
  { id: VoiceName.ANTOINE,   name: 'Antoine',   lang: 'French (CA)',      description: 'Professional Canadian French voice',             gender: 'Male',   region: 'European' },
  { id: VoiceName.KATJA,     name: 'Katja',     lang: 'German (DE)',      description: 'Crisp and precise German voice',                 gender: 'Female', region: 'European' },
  { id: VoiceName.CONRAD,    name: 'Conrad',    lang: 'German (DE)',      description: 'Robust and deep German voice',                   gender: 'Male',   region: 'European' },
  { id: VoiceName.ELVIRA,    name: 'Elvira',    lang: 'Spanish (ES)',     description: 'Bright and energetic Spanish voice',             gender: 'Female', region: 'European' },
  { id: VoiceName.ALVARO,    name: 'Alvaro',    lang: 'Spanish (ES)',     description: 'Smooth and friendly Spanish voice',              gender: 'Male',   region: 'European' },
  { id: VoiceName.DALIA,     name: 'Dalia',     lang: 'Spanish (MX)',     description: 'Natural Mexican Spanish voice',                  gender: 'Female', region: 'European' },
  { id: VoiceName.JORGE,     name: 'Jorge',     lang: 'Spanish (MX)',     description: 'Clear Mexican Spanish voice',                    gender: 'Male',   region: 'European' },
  { id: VoiceName.ELSA,      name: 'Elsa',      lang: 'Italian (IT)',     description: 'Elegant and clear Italian voice',                gender: 'Female', region: 'European' },
  { id: VoiceName.ISABELLA,  name: 'Isabella',  lang: 'Italian (IT)',     description: 'Warm Italian neural voice',                      gender: 'Female', region: 'European' },
  { id: VoiceName.DIEGO,     name: 'Diego',     lang: 'Italian (IT)',     description: 'Professional Italian male voice',                gender: 'Male',   region: 'European' },
  { id: VoiceName.SVETLANA,  name: 'Svetlana',  lang: 'Russian (RU)',     description: 'Clear and formal Russian voice',                 gender: 'Female', region: 'European' },
  { id: VoiceName.DMITRY,    name: 'Dmitry',    lang: 'Russian (RU)',     description: 'Professional Russian male voice',                gender: 'Male',   region: 'European' },
  { id: VoiceName.EMEL,      name: 'Emel',      lang: 'Turkish (TR)',     description: 'Friendly Turkish neural voice',                  gender: 'Female', region: 'European' },
  { id: VoiceName.AHMET,     name: 'Ahmet',     lang: 'Turkish (TR)',     description: 'Resonant Turkish male voice',                    gender: 'Male',   region: 'European' },
  { id: VoiceName.COLETTE,   name: 'Colette',   lang: 'Dutch (NL)',       description: 'Articulate Dutch voice',                         gender: 'Female', region: 'European' },
  { id: VoiceName.MAARTEN,   name: 'Maarten',   lang: 'Dutch (NL)',       description: 'Steady Dutch male voice',                        gender: 'Male',   region: 'European' },
  { id: VoiceName.ZOFIA,     name: 'Zofia',     lang: 'Polish (PL)',      description: 'Precise Polish female voice',                    gender: 'Female', region: 'European' },
  { id: VoiceName.MAREK,     name: 'Marek',     lang: 'Polish (PL)',      description: 'Deep Polish male voice',                         gender: 'Male',   region: 'European' },
  { id: VoiceName.HILLEVI,   name: 'Hillevi',   lang: 'Swedish (SE)',     description: 'Melodic Swedish voice',                          gender: 'Female', region: 'European' },
  { id: VoiceName.MATTIAS,   name: 'Mattias',   lang: 'Swedish (SE)',     description: 'Natural Swedish male voice',                     gender: 'Male',   region: 'European' },
  { id: VoiceName.FRANCISCA, name: 'Francisca', lang: 'Portuguese (BR)',  description: 'Cheerful and inviting Brazilian voice',          gender: 'Female', region: 'European' },
  { id: VoiceName.ANTONIO,   name: 'Antonio',   lang: 'Portuguese (BR)',  description: 'Deep and professional Brazilian voice',          gender: 'Male',   region: 'European' },
  { id: VoiceName.RAQUEL,    name: 'Raquel',    lang: 'Portuguese (PT)',  description: 'European Portuguese neural voice',               gender: 'Female', region: 'European' },
  { id: VoiceName.DUARTE,    name: 'Duarte',    lang: 'Portuguese (PT)',  description: 'Natural European Portuguese male voice',         gender: 'Male',   region: 'European' },
  { id: VoiceName.ATHINA,    name: 'Athina',    lang: 'Greek (GR)',       description: 'Expressive Greek female voice',                  gender: 'Female', region: 'European' },
  { id: VoiceName.NESTORAS,  name: 'Nestoras',  lang: 'Greek (GR)',       description: 'Classic Greek male voice',                       gender: 'Male',   region: 'European' },
  { id: VoiceName.HILA,      name: 'Hila',      lang: 'Hebrew (IL)',      description: 'Natural Hebrew female voice',                    gender: 'Female', region: 'European' },
  { id: VoiceName.AVRI,      name: 'Avri',      lang: 'Hebrew (IL)',      description: 'Resonant Hebrew male voice',                     gender: 'Male',   region: 'European' },
  { id: VoiceName.CHRISTEL,  name: 'Christel',  lang: 'Danish (DK)',      description: 'Clear Danish female voice',                      gender: 'Female', region: 'European' },
  { id: VoiceName.JEPPE,     name: 'Jeppe',     lang: 'Danish (DK)',      description: 'Friendly Danish male voice',                     gender: 'Male',   region: 'European' },
  { id: VoiceName.SELMA,     name: 'Selma',     lang: 'Finnish (FI)',     description: 'Soft Finnish female voice',                      gender: 'Female', region: 'European' },
  { id: VoiceName.HARRI,     name: 'Harri',     lang: 'Finnish (FI)',     description: 'Steady Finnish male voice',                      gender: 'Male',   region: 'European' },
  { id: VoiceName.PERNILLE,  name: 'Pernille',  lang: 'Norwegian (NO)',   description: 'Fluent Norwegian female voice',                  gender: 'Female', region: 'European' },
  { id: VoiceName.FINN,      name: 'Finn',      lang: 'Norwegian (NO)',   description: 'Solid Norwegian male voice',                     gender: 'Male',   region: 'European' },

  // East Asian
  { id: VoiceName.NANAMI,   name: 'Nanami',  lang: 'Japanese (JP)', description: 'Polite and clear Japanese voice',          gender: 'Female', region: 'East Asian' },
  { id: VoiceName.KEITA,    name: 'Keita',   lang: 'Japanese (JP)', description: 'Energetic and natural Japanese voice',     gender: 'Male',   region: 'East Asian' },
  { id: VoiceName.SUN_HI,   name: 'Sun-Hi',  lang: 'Korean (KR)',   description: 'Gentle and clear Korean voice',            gender: 'Female', region: 'East Asian' },
  { id: VoiceName.IN_JOON,  name: 'In-Joon', lang: 'Korean (KR)',   description: 'Natural Korean male voice',                gender: 'Male',   region: 'East Asian' },
  { id: VoiceName.XIAOXIAO, name: 'Xiaoxiao',lang: 'Chinese (CN)',  description: 'Lively and expressive Mandarin voice',     gender: 'Female', region: 'East Asian' },
  { id: VoiceName.YUNXI,    name: 'Yunxi',   lang: 'Chinese (CN)',  description: 'Warm and youthful Mandarin voice',         gender: 'Male',   region: 'East Asian' },

  // Middle Eastern
  { id: VoiceName.ZARIYAH, name: 'Zariyah', lang: 'Arabic (SA)', description: 'Natural Arabic female voice',      gender: 'Female', region: 'Middle Eastern' },
  { id: VoiceName.HAMED,   name: 'Hamed',   lang: 'Arabic (SA)', description: 'Deep Arabic male voice',           gender: 'Male',   region: 'Middle Eastern' },
  { id: VoiceName.FATIMA,  name: 'Fatima',  lang: 'Arabic (AE)', description: 'Fluent UAE Arabic voice',          gender: 'Female', region: 'Middle Eastern' },
  { id: VoiceName.HAMDAN,  name: 'Hamdan',  lang: 'Arabic (AE)', description: 'Clear UAE Arabic male voice',      gender: 'Male',   region: 'Middle Eastern' },

  // Indian Regional
  { id: VoiceName.SWARA,     name: 'Swara',     lang: 'Hindi (IN)',     description: 'Soft and pleasant Hindi voice',               gender: 'Female', region: 'Indian' },
  { id: VoiceName.MADHUR,    name: 'Madhur',    lang: 'Hindi (IN)',     description: 'Clear and resonant Hindi voice',              gender: 'Male',   region: 'Indian' },
  { id: VoiceName.AARAV,     name: 'Aarav',     lang: 'Hindi (IN)',     description: 'Warm conversational Hindi voice',             gender: 'Male',   region: 'Indian' },
  { id: VoiceName.KAVAYA,    name: 'Kavya',     lang: 'Hindi (IN)',     description: 'Expressive modern Hindi voice',               gender: 'Female', region: 'Indian' },
  { id: VoiceName.PALLAVI,   name: 'Pallavi',   lang: 'Tamil (IN)',     description: 'Melodious and clear Tamil voice',             gender: 'Female', region: 'Indian' },
  { id: VoiceName.VALLUVAR,  name: 'Valluvar',  lang: 'Tamil (IN)',     description: 'Deep and steady Tamil voice',                 gender: 'Male',   region: 'Indian' },
  { id: VoiceName.SHRUTI,    name: 'Shruti',    lang: 'Telugu (IN)',    description: 'Natural and expressive Telugu voice',         gender: 'Female', region: 'Indian' },
  { id: VoiceName.MOHAN,     name: 'Mohan',     lang: 'Telugu (IN)',    description: 'Clear and professional Telugu voice',         gender: 'Male',   region: 'Indian' },
  { id: VoiceName.TANISHAA,  name: 'Tanishaa',  lang: 'Bengali (IN)',   description: 'Bright and fluent Bengali voice',             gender: 'Female', region: 'Indian' },
  { id: VoiceName.BASHKAR,   name: 'Bashkar',   lang: 'Bengali (IN)',   description: 'Rich and resonant Bengali voice',             gender: 'Male',   region: 'Indian' },
  { id: VoiceName.SOBHANA,   name: 'Sobhana',   lang: 'Malayalam (IN)', description: 'Smooth and pleasant Malayalam voice',         gender: 'Female', region: 'Indian' },
  { id: VoiceName.MIDHUN,    name: 'Midhun',    lang: 'Malayalam (IN)', description: 'Clear and natural Malayalam voice',           gender: 'Male',   region: 'Indian' },
  { id: VoiceName.AAROHI,    name: 'Aarohi',    lang: 'Marathi (IN)',   description: 'Expressive and warm Marathi voice',           gender: 'Female', region: 'Indian' },
  { id: VoiceName.MANOHAR,   name: 'Manohar',   lang: 'Marathi (IN)',   description: 'Steady and professional Marathi voice',       gender: 'Male',   region: 'Indian' },
  { id: VoiceName.DHWANI,    name: 'Dhwani',    lang: 'Gujarati (IN)',  description: 'Melodic and friendly Gujarati voice',         gender: 'Female', region: 'Indian' },
  { id: VoiceName.NIRANJAN,  name: 'Niranjan',  lang: 'Gujarati (IN)',  description: 'Clear and warm Gujarati voice',               gender: 'Male',   region: 'Indian' },
  { id: VoiceName.SAPNA,     name: 'Sapna',     lang: 'Kannada (IN)',   description: 'Gentle and natural Kannada voice',            gender: 'Female', region: 'Indian' },
  { id: VoiceName.GAGAN,     name: 'Gagan',     lang: 'Kannada (IN)',   description: 'Strong and clear Kannada voice',              gender: 'Male',   region: 'Indian' },
  { id: VoiceName.VAANI,     name: 'Vaani',     lang: 'Punjabi (IN)',   description: 'Vibrant and lively Punjabi voice',            gender: 'Female', region: 'Indian' },
  { id: VoiceName.OJAS,      name: 'Ojas',      lang: 'Punjabi (IN)',   description: 'Bold and resonant Punjabi voice',             gender: 'Male',   region: 'Indian' },
  { id: VoiceName.GUL,       name: 'Gul',       lang: 'Urdu (IN)',      description: 'Graceful and expressive Urdu voice',          gender: 'Female', region: 'Indian' },
  { id: VoiceName.SALMAN,    name: 'Salman',    lang: 'Urdu (IN)',      description: 'Poetic and warm Urdu voice',                  gender: 'Male',   region: 'Indian' },
  { id: VoiceName.SUBHASINI, name: 'Subhasini', lang: 'Odia (IN)',      description: 'Clear and pleasant Odia voice',               gender: 'Female', region: 'Indian' },
  { id: VoiceName.SUKANT,    name: 'Sukant',    lang: 'Odia (IN)',      description: 'Steady and natural Odia voice',               gender: 'Male',   region: 'Indian' },
  { id: VoiceName.YASHICA,   name: 'Yashica',   lang: 'Assamese (IN)',  description: 'Soft and melodic Assamese voice',             gender: 'Female', region: 'Indian' },
  { id: VoiceName.PRIYOM,    name: 'Priyom',    lang: 'Assamese (IN)',  description: 'Natural and clear Assamese voice',            gender: 'Male',   region: 'Indian' },

  // Southeast Asian
  { id: VoiceName.HOAI_MY,  name: 'Hoai My',  lang: 'Vietnamese (VN)',  description: 'Natural and clear Vietnamese voice',    gender: 'Female', region: 'SE Asian' },
  { id: VoiceName.NAM_MINH, name: 'Nam Minh', lang: 'Vietnamese (VN)',  description: 'Warm Vietnamese male voice',            gender: 'Male',   region: 'SE Asian' },
  { id: VoiceName.PREMWADEE,name: 'Premwadee',lang: 'Thai (TH)',        description: 'Polite and smooth Thai voice',          gender: 'Female', region: 'SE Asian' },
  { id: VoiceName.NIWAT,    name: 'Niwat',    lang: 'Thai (TH)',        description: 'Clear and steady Thai voice',           gender: 'Male',   region: 'SE Asian' },
  { id: VoiceName.GADIS,    name: 'Gadis',    lang: 'Indonesian (ID)',  description: 'Friendly and natural Indonesian voice', gender: 'Female', region: 'SE Asian' },
  { id: VoiceName.ARDI,     name: 'Ardi',     lang: 'Indonesian (ID)',  description: 'Confident Indonesian male voice',       gender: 'Male',   region: 'SE Asian' },
  { id: VoiceName.BLESSICA, name: 'Blessica', lang: 'Filipino (PH)',    description: 'Warm and expressive Filipino voice',    gender: 'Female', region: 'SE Asian' },
  { id: VoiceName.ANGELO,   name: 'Angelo',   lang: 'Filipino (PH)',    description: 'Clear and friendly Filipino voice',     gender: 'Male',   region: 'SE Asian' },
  { id: VoiceName.YASMIN,   name: 'Yasmin',   lang: 'Malay (MY)',       description: 'Natural and pleasant Malay voice',      gender: 'Female', region: 'SE Asian' },
  { id: VoiceName.OSMAN,    name: 'Osman',    lang: 'Malay (MY)',       description: 'Steady and clear Malay voice',          gender: 'Male',   region: 'SE Asian' },
];

export const MAX_TEXT_LENGTH =
  Number((import.meta.env.VITE_MAX_TEXT_LENGTH as string | undefined)?.trim()) || 5000;
