/**
 * Script Studio SKU Configuration
 * Defines input fields, output formats, and metadata for each script type
 */

export type ScriptSKU = "youtube" | "short" | "podcast" | "explainer" | "custom";

export interface InputFieldConfig {
  id: string;
  label: string;
  placeholder?: string;
  type: "text" | "textarea" | "select" | "number" | "multiselect";
  required: boolean;
  description?: string;
  options?: Array<{ value: string; label: string }>;
  maxLength?: number;
  minLength?: number;
  autoGeneratable?: boolean;
}

export interface SKUConfig {
  id: ScriptSKU;
  title: string;
  description: string;
  steps: StepConfig[];
  outputFormat: OutputFormatConfig;
  systemPromptTemplate: string;
  estimatedDuration: string;
}

export interface StepConfig {
  id: string;
  title: string;
  description?: string;
  fields: InputFieldConfig[];
}

export interface OutputFormatConfig {
  sections: string[];
  guidelines: string[];
  exampleLength: string;
}

export const SCRIPT_SKU_CONFIGS: Record<ScriptSKU, SKUConfig> = {
  youtube: {
    id: "youtube",
    title: "YouTube",
    description: "Structured narration with hook, sections, and CTA",

    steps: [
      {
        id: "basics",
        title: "Content Basics",
        description: "Define what your video is about",
        fields: [
          {
            id: "topic",
            label: "Video Topic",
            placeholder: "e.g., How to start a podcast on a budget",
            type: "text",
            required: true,
            description: "The main subject of your video",
            maxLength: 150,
          },
          {
            id: "targetAudience",
            label: "Target Audience",
            placeholder: "e.g., Beginners interested in podcasting",
            type: "text",
            required: true,
            description: "Who is this video for?",
            maxLength: 100,
          },
        ],
      },
      {
        id: "structure",
        title: "Video Structure",
        description: "Plan the content sections",
        fields: [
          {
            id: "hook",
            label: "Hook/Opening",
            placeholder: "e.g., Start with a surprising stat or question",
            type: "textarea",
            required: true,
            description: "How will you grab viewers' attention in the first 5 seconds?",
            autoGeneratable: true,
          },
          {
            id: "mainPoints",
            label: "Main Points (comma-separated)",
            placeholder: "e.g., Equipment needed, Recording setup, Publishing platforms",
            type: "textarea",
            required: true,
            description: "The 2-4 key sections of your video",
            autoGeneratable: true,
          },
          {
            id: "cta",
            label: "Call-to-Action",
            placeholder: "e.g., Subscribe, check the description for resources",
            type: "text",
            required: true,
            description: "What should viewers do next?",
            autoGeneratable: true,
          },
        ],
      },
      {
        id: "delivery",
        title: "Delivery & Tone",
        description: "How should the script sound?",
        fields: [
          {
            id: "tone",
            label: "Tone",
            type: "select",
            required: true,
            options: [
              { value: "professional", label: "Professional" },
              { value: "friendly", label: "Friendly" },
              { value: "energetic", label: "Energetic" },
              { value: "casual", label: "Casual" },
              { value: "inspirational", label: "Inspirational" },
              { value: "humorous", label: "Humorous" },
            ],
          },
          {
            id: "length",
            label: "Video Length",
            type: "select",
            required: true,
            options: [
              { value: "short", label: "Short (5-8 min)" },
              { value: "medium", label: "Medium (8-12 min)" },
              { value: "long", label: "Long (15-20 min)" },
            ],
          },
          {
            id: "pace",
            label: "Pacing",
            type: "select",
            required: true,
            options: [
              { value: "fast", label: "Fast (Quick cuts, dynamic)" },
              { value: "moderate", label: "Moderate (Balanced)" },
              { value: "slow", label: "Slow (Thoughtful, detailed)" },
            ],
          },
        ],
      },
    ],
    outputFormat: {
      sections: ["Hook", "Introduction", "Sections", "Transition statements", "CTA", "Outro"],
      guidelines: [
        "Clear section transitions",
        "Conversational and engaging tone",
        "Specific time stamps for sections",
      ],
      exampleLength: "8-10 minutes",
    },
    systemPromptTemplate:
      "You are a professional YouTube scriptwriter. Create a structured, engaging script that hooks viewers, clearly presents sections, and includes a strong call-to-action.",
    estimatedDuration: "5-10 min",
  },

  short: {
    id: "short",
    title: "Reel/Short",
    description: "Fast-paced script with strong opening",

    steps: [
      {
        id: "concept",
        title: "Content Concept",
        description: "Define your short concept",
        fields: [
          {
            id: "concept",
            label: "Content Concept",
            placeholder: "e.g., Quick productivity hack, trending topic, entertainment",
            type: "text",
            required: true,
            description: "What's the core idea?",
            maxLength: 150,
          },
          {
            id: "keyMessage",
            label: "Key Message/Takeaway",
            placeholder: "e.g., The one surprising thing viewers should remember",
            type: "text",
            required: true,
            description: "The single most important message",
            maxLength: 120,
          },
        ],
      },
      {
        id: "beats",
        title: "Scene Beats",
        description: "Plan your video pacing",
        fields: [
          {
            id: "hook",
            label: "Hook (0-2 sec)",
            placeholder: "Grab attention immediately",
            type: "textarea",
            required: true,
            description: "Your most compelling opening line or visual cue",
            autoGeneratable: true,
          },
          {
            id: "body",
            label: "Body (main content)",
            placeholder: "Keep it punchy and fast-paced",
            type: "textarea",
            required: true,
            description: "The main content - Quick, snappy delivery",
            autoGeneratable: true,
          },
          {
            id: "climax",
            label: "Climax/Payoff",
            placeholder: "The satisfying moment or reveal",
            type: "textarea",
            required: true,
            description: "The rewarding moment that makes viewers want to share",
            autoGeneratable: true,
          },
        ],
      },
      {
        id: "format",
        title: "Format & Delivery",
        description: "Define the style",
        fields: [
          {
            id: "tone",
            label: "Tone",
            type: "select",
            required: true,
            options: [
              { value: "professional", label: "Professional" },
              { value: "friendly", label: "Friendly" },
              { value: "energetic", label: "Energetic" },
              { value: "casual", label: "Casual" },
              { value: "humorous", label: "Humorous" },
            ],
          },
          {
            id: "duration",
            label: "Duration",
            type: "select",
            required: true,
            options: [
              { value: "ultra-short", label: "Ultra-short (15-30 sec)" },
              { value: "short", label: "Short (30-60 sec)" },
              { value: "medium", label: "Medium (60-90 sec)" },
            ],
          },
        ],
      },
    ],
    outputFormat: {
      sections: ["Hook", "Main content", "Climax", "Outro/CTA"],
      guidelines: [
        "Starts with strongest hook",
        "Each sentence builds momentum",
        "Clear payoff at the end",
        "Designed for rapid delivery",
      ],
      exampleLength: "30-90 seconds",
    },
    systemPromptTemplate:
      "You are a TikTok/Instagram Reel expert. Write a fast-paced, punchy script that hooks viewers in 2 seconds and delivers a memorable payoff.",
    estimatedDuration: "2-5 min",
  },

  podcast: {
    id: "podcast",
    title: "Podcast",
    description: "Conversational segments with smooth transitions",

    steps: [
      {
        id: "episode",
        title: "Episode Overview",
        description: "Define your podcast episode",
        fields: [
          {
            id: "topic",
            label: "Episode Topic",
            placeholder: "e.g., The future of remote work",
            type: "text",
            required: true,
            description: "What is this episode about?",
            maxLength: 150,
          },
          {
            id: "format",
            label: "Format",
            type: "select",
            required: true,
            options: [
              { value: "solo", label: "Solo (You talking)" },
              { value: "interview", label: "Interview (You + guest)" },
              { value: "roundtable", label: "Roundtable (Multiple voices)" },
            ],
          },
        ],
      },
      {
        id: "segments",
        title: "Segments",
        description: "Structure your episode",
        fields: [
          {
            id: "opening",
            label: "Opening/Welcome",
            placeholder: "Warm greeting, episode preview",
            type: "textarea",
            required: true,
            description: "Hook listeners and preview what's coming",
            autoGeneratable: true,
          },
          {
            id: "segments",
            label: "Segment Topics (comma-separated)",
            placeholder: "e.g., Industry news, Case study, Q&A section",
            type: "textarea",
            required: true,
            description: "The main discussion segments",
            autoGeneratable: true,
          },
          {
            id: "conclusion",
            label: "Conclusion/CTA",
            placeholder: "Wrap up and guide listeners (subscribe, follow, etc.)",
            type: "textarea",
            required: true,
            description: "How will you end the episode?",
            autoGeneratable: true,
          },
        ],
      },
      {
        id: "style",
        title: "Conversational Style",
        description: "Define the vibe",
        fields: [
          {
            id: "tone",
            label: "Tone",
            type: "select",
            required: true,
            options: [
              { value: "professional", label: "Professional" },
              { value: "friendly", label: "Friendly" },
              { value: "casual", label: "Casual" },
              { value: "comedic", label: "Comedic" },
            ],
          },
          {
            id: "depth",
            label: "Depth Level",
            type: "select",
            required: true,
            options: [
              {
                value: "surface",
                label: "Surface level (News & trends overview)",
              },
              { value: "balanced", label: "Balanced (Mix of info & discussion)" },
              {
                value: "deep",
                label: "Deep dive (In-depth exploration & nuance)",
              },
            ],
          },
          {
            id: "duration",
            label: "Episode Length",
            type: "select",
            required: true,
            options: [
              { value: "short", label: "Short (20-30 min)" },
              { value: "medium", label: "Medium (30-45 min)" },
              { value: "long", label: "Long (45-60+ min)" },
            ],
          },
        ],
      },
    ],
    outputFormat: {
      sections: ["Cold open", "Intro", "Segments with transitions", "Outro", "CTA"],
      guidelines: [
        "Conversational and natural",
        "Clear transitions between segments",
        "Includes speaker cues if multiple voices",
        "Timestamps for segments",
      ],
      exampleLength: "20-60 minutes",
    },
    systemPromptTemplate:
      "You are an experienced podcast scriptwriter. Create a conversational, naturally flowing script with smooth transitions between segments and an engaging host presence.",
    estimatedDuration: "5-10 min",
  },

  explainer: {
    id: "explainer",
    title: "Explainer",
    description: "Clear, educational breakdown with examples",

    steps: [
      {
        id: "learning",
        title: "Learning Objective",
        description: "Define what you're explaining",
        fields: [
          {
            id: "topic",
            label: "Topic to Explain",
            placeholder: "e.g., How blockchain works, What is SEO",
            type: "text",
            required: true,
            description: "The concept or process you're explaining",
            maxLength: 150,
          },
          {
            id: "targetLevel",
            label: "Target Audience Knowledge Level",
            type: "select",
            required: true,
            options: [
              {
                value: "beginner",
                label: "Beginner (No prior knowledge)",
              },
              {
                value: "intermediate",
                label: "Intermediate (Some familiarity)",
              },
              { value: "advanced", label: "Advanced (Technical background)" },
            ],
          },
        ],
      },
      {
        id: "content",
        title: "Content Structure",
        description: "Organize your explanation",
        fields: [
          {
            id: "whyItMatters",
            label: "Why It Matters",
            placeholder: "e.g., Understanding this helps you manage finances better",
            type: "textarea",
            required: true,
            description: "Hook: Why should viewers care?",
            autoGeneratable: true,
          },
          {
            id: "keyPoints",
            label: "Key Concepts to Cover",
            placeholder: "e.g., Definition, Historical context, How it works, Real-world impact",
            type: "textarea",
            required: true,
            description: "The main learning points (3-5 concepts)",
            autoGeneratable: true,
          },
          {
            id: "examples",
            label: "Real-World Examples",
            placeholder: "Specific scenarios or case studies to illustrate the concept",
            type: "textarea",
            required: true,
            description: "Concrete examples viewers can relate to",
            autoGeneratable: true,
          },
        ],
      },
      {
        id: "delivery",
        title: "Delivery",
        description: "How to present it",
        fields: [
          {
            id: "tone",
            label: "Tone",
            type: "select",
            required: true,
            options: [
              { value: "formal", label: "Formal & Academic" },
              { value: "conversational", label: "Conversational" },
              { value: "storytelling", label: "Storytelling" },
            ],
          },
          {
            id: "length",
            label: "Video Length",
            type: "select",
            required: true,
            options: [
              { value: "short", label: "Short (3-5 min)" },
              { value: "medium", label: "Medium (5-10 min)" },
              { value: "long", label: "Long (10-15 min)" },
            ],
          },
        ],
      },
    ],
    outputFormat: {
      sections: [
        "Hook (why it matters)",
        "Definition",
        "Key concepts with explanations",
        "Real-world examples",
        "Takeaway",
      ],
      guidelines: [
        "Simple, clear language",
        "Logical progression from basic to complex",
        "Concrete examples for each concept",
        "Visual cues for animations/diagrams",
      ],
      exampleLength: "5-15 minutes",
    },
    systemPromptTemplate:
      "You are an expert educator and explainer. Create a clear, well-structured script that teaches a concept progressively, using concrete examples and simple language.",
    estimatedDuration: "5-10 min",
  },

  custom: {
    id: "custom",
    title: "Custom",
    description: "Flexible script style for any use case",

    steps: [
      {
        id: "basics",
        title: "Your Script",
        description: "Define your custom script",
        fields: [
          {
            id: "topic",
            label: "Topic/Purpose",
            placeholder: "e.g., Product demo, storytelling, event announcement",
            type: "text",
            required: true,
            description: "What is this script for?",
            maxLength: 200,
          },
          {
            id: "description",
            label: "Detailed Description",
            placeholder:
              "Describe what you want: target audience, message, key points, style preferences",
            type: "textarea",
            required: true,
            description: "Provide as much context as possible for best results",
          },
        ],
      },
      {
        id: "preferences",
        title: "Style Preferences",
        description: "Customize the delivery",
        fields: [
          {
            id: "tone",
            label: "Tone",
            type: "select",
            required: true,
            options: [
              { value: "professional", label: "Professional" },
              { value: "friendly", label: "Friendly" },
              { value: "energetic", label: "Energetic" },
              { value: "casual", label: "Casual" },
              { value: "inspirational", label: "Inspirational" },
              { value: "humorous", label: "Humorous" },
              { value: "serious", label: "Serious" },
            ],
          },
          {
            id: "length",
            label: "Approximate Length",
            type: "select",
            required: true,
            options: [
              { value: "short", label: "Short (1-3 min)" },
              { value: "medium", label: "Medium (3-7 min)" },
              { value: "long", label: "Long (7+ min)" },
            ],
          },
        ],
      },
    ],
    outputFormat: {
      sections: ["Complete custom script"],
      guidelines: ["Tailored to your specific needs"],
      exampleLength: "Flexible",
    },
    systemPromptTemplate:
      "You are a versatile scriptwriter. Create a custom script based on the user's specific needs and preferences.",
    estimatedDuration: "3-10 min",
  },
};
