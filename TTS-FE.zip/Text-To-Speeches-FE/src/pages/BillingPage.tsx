import React, { useEffect, useMemo, useState } from "react";
import { AlertTriangle, CreditCard, Download, FileText, RefreshCw, Wallet, CheckCircle, X } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import {
  cancelSubscription,
  fetchBillingMetrics,
  fetchBillingSummary,
  fetchInvoices,
  fetchPaymentMethod,
  type BillingMetrics,
  type BillingSummary,
  type Invoice,
  type PaymentMethod,
} from "../services/billingApiService";

const formatDate = (iso: string | null | undefined): string => {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "2-digit" });
};

const formatCurrency = (value: number | null | undefined, currency = "INR"): string => {
  if (value == null) return "—";
  try {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency,
      maximumFractionDigits: 2,
    }).format(value);
  } catch {
    return `₹${value.toLocaleString()}`;
  }
};

const toBadgeClass = (badge: string | null): string => {
  const key = (badge || "").toLowerCase();
  if (key.includes("business")) return "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300";
  if (key.includes("pro")) return "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300";
  if (key.includes("creator")) return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300";
  if (key.includes("free")) return "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300";
  return "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300";
};

const toInvoiceStatusClass = (status: string): string => {
  const key = status.toLowerCase();
  if (key === "paid") return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300";
  if (key === "pending") return "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300";
  if (key === "failed") return "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300";
  return "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300";
};

type BillingHeaderProps = {
  onUpgrade: () => void;
  onCancel: () => void;
  actionLoading: boolean;
};

const BillingHeader: React.FC<BillingHeaderProps> = ({ onUpgrade, onCancel, actionLoading }) => (
  <section className="glass studio-card !p-6">
    <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Billing Dashboard</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 font-medium">
          Manage your subscription, billing, and invoices
        </p>
      </div>
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          type="button"
          onClick={onUpgrade}
          disabled={actionLoading}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest transition-colors disabled:opacity-60"
        >
          Upgrade Plan
        </button>
        <button
          type="button"
          onClick={onCancel}
          disabled={actionLoading}
          className="px-4 py-2.5 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 text-red-700 dark:border-red-900/40 dark:bg-red-900/20 dark:hover:bg-red-900/30 dark:text-red-300 text-xs font-black uppercase tracking-widest transition-colors disabled:opacity-60"
        >
          Cancel Plan
        </button>
      </div>
    </div>
  </section>
);

const PlanSummaryCard: React.FC<{ summary: BillingSummary | null; loading: boolean }> = ({ summary, loading }) => {
  if (loading) {
    return <div className="glass studio-card !p-6 h-48 animate-pulse bg-slate-100/70 dark:bg-slate-800/30" />;
  }

  return (
    <section className="glass studio-card !p-6">
      <h2 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Current Plan Summary</h2>
      <div className="mt-4 flex items-start justify-between gap-4">
        <div>
          <p className="text-xl font-black text-slate-900 dark:text-white">{summary?.planName || "—"}</p>
          <p className="mt-1 text-sm font-semibold text-slate-600 dark:text-slate-300">
            {formatCurrency(summary?.planPrice, summary?.planCurrency || "INR")}
            {summary?.planInterval ? `/${summary.planInterval}` : ""}
          </p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${toBadgeClass(summary?.planBadge || null)}`}>
          {summary?.planBadge || "Unknown"}
        </span>
      </div>

      <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <MetricPill label="Billing Cycle" value={`${formatDate(summary?.cycleStart)} → ${formatDate(summary?.cycleEnd)}`} />
        <MetricPill label="Next Billing Date" value={formatDate(summary?.nextBillingDate)} />
        <MetricPill label="Days Remaining" value={summary?.daysRemaining == null ? "—" : `${summary.daysRemaining} days`} />
        <MetricPill label="Plan Type" value={summary?.planBadge || "—"} />
      </div>
    </section>
  );
};

const BillingMetricsCard: React.FC<{ metrics: BillingMetrics | null; loading: boolean }> = ({ metrics, loading }) => {
  const currency = metrics?.currency || "INR";
  const cards = [
    { label: "Current Plan Price", value: formatCurrency(metrics?.currentPlanPrice, currency), helper: "Your active plan amount" },
    { label: "Current Cycle Spend", value: formatCurrency(metrics?.currentCycleSpend, currency), helper: "Spend in current billing cycle" },
    { label: "Total Spend", value: formatCurrency(metrics?.totalSpend, currency), helper: "All-time billing amount" },
    { label: "Next Billing Amount", value: formatCurrency(metrics?.nextBillingAmount, currency), helper: "Amount for next renewal" },
  ];

  return (
    <section className="glass studio-card !p-6">
      <h2 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Billing Summary</h2>
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card) => (
          <div key={card.label} className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5">
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">{card.label}</p>
            <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">{loading ? "—" : card.value}</p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{card.helper}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

const PaymentMethodCard: React.FC<{ paymentMethod: PaymentMethod | null; loading: boolean }> = ({ paymentMethod, loading }) => (
  <section className="glass studio-card !p-6">
    <div className="flex items-center justify-between gap-4">
      <h2 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Payment Method</h2>
      <button
        type="button"
        className="px-4 py-2 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 border border-slate-200 dark:border-white/10 text-xs font-black uppercase tracking-widest text-slate-800 dark:text-slate-200 transition-colors"
      >
        Update Payment Method
      </button>
    </div>

    <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
      <MetricPill label="Card Brand" value={loading ? "—" : paymentMethod?.cardBrand || "—"} />
      <MetricPill label="Last 4 Digits" value={loading ? "—" : paymentMethod?.last4 ? `•••• ${paymentMethod.last4}` : "—"} />
      <MetricPill
        label="Expiry Date"
        value={
          loading
            ? "—"
            : paymentMethod?.expiryMonth && paymentMethod?.expiryYear
              ? `${String(paymentMethod.expiryMonth).padStart(2, "0")}/${paymentMethod.expiryYear}`
              : "—"
        }
      />
      <MetricPill label="Billing Email" value={loading ? "—" : paymentMethod?.billingEmail || "—"} />
    </div>
  </section>
);

const InvoiceTable: React.FC<{ invoices: Invoice[]; loading: boolean }> = ({ invoices, loading }) => (
  <section className="glass studio-card !p-6">
    <div className="flex items-center justify-between gap-4">
      <h2 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Invoice History</h2>
      <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">{loading ? "Loading..." : `${invoices.length} invoice(s)`}</p>
    </div>

    <div className="mt-4 overflow-hidden rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[740px]">
          <thead className="bg-slate-50/80 dark:bg-white/5">
            <tr className="text-left">
              {["Date", "Invoice ID", "Amount", "Status", "Download"].map((h) => (
                <th key={h} className="px-4 py-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-sm text-slate-500 dark:text-slate-400">
                  Loading invoices...
                </td>
              </tr>
            )}

            {!loading &&
              invoices.map((inv) => (
                <tr key={inv.id} className="border-t border-slate-200/70 dark:border-white/10 hover:bg-slate-50/60 dark:hover:bg-white/5 transition-colors">
                  <td className="px-4 py-3 text-sm text-slate-700 dark:text-slate-300">{formatDate(inv.date)}</td>
                  <td className="px-4 py-3 text-sm font-semibold text-slate-900 dark:text-white">{inv.number || inv.id}</td>
                  <td className="px-4 py-3 text-sm text-slate-700 dark:text-slate-300">{formatCurrency(inv.amount, inv.currency || "INR")}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${toInvoiceStatusClass(inv.status || "unknown")}`}>
                      {inv.status || "Unknown"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {inv.downloadUrl ? (
                      <a
                        href={inv.downloadUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center justify-center w-8 h-8 rounded-lg border border-slate-200 dark:border-white/10 bg-white/80 dark:bg-white/10 hover:bg-slate-100 dark:hover:bg-white/20 transition-colors"
                        aria-label="Download invoice"
                        title="Download invoice"
                      >
                        <Download className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                      </a>
                    ) : (
                      <span className="text-xs text-slate-400">—</span>
                    )}
                  </td>
                </tr>
              ))}

            {!loading && invoices.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-12">
                  <div className="flex flex-col items-center justify-center text-center">
                    <FileText className="w-8 h-8 text-slate-400 dark:text-slate-500" />
                    <p className="mt-3 text-sm font-semibold text-slate-700 dark:text-slate-200">
                      No invoices yet. Your invoices will appear after your first payment.
                    </p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  </section>
);

const PlanActions: React.FC<{ onUpgrade: () => void; onCancel: () => void; onChangePlan: () => void; loading: boolean }> = ({ onUpgrade, onCancel, onChangePlan, loading }) => (
  <section className="glass studio-card !p-6">
    <h2 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Plan Actions</h2>
    <div className="mt-4 flex flex-wrap gap-3">
      <button
        type="button"
        onClick={onUpgrade}
        disabled={loading}
        className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest transition-colors disabled:opacity-60"
      >
        Upgrade Plan
      </button>
      <button
        type="button"
        onClick={onCancel}
        disabled={loading}
        className="px-4 py-2.5 rounded-xl bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 dark:bg-red-900/20 dark:hover:bg-red-900/30 dark:border-red-900/40 dark:text-red-300 text-xs font-black uppercase tracking-widest transition-colors disabled:opacity-60"
      >
        Cancel Subscription
      </button>
      <button
        type="button"
        onClick={onChangePlan}
        className="px-4 py-2.5 rounded-xl bg-white/80 hover:bg-white border border-slate-200 text-slate-700 dark:bg-white/10 dark:hover:bg-white/20 dark:border-white/10 dark:text-slate-200 text-xs font-black uppercase tracking-widest transition-colors"
      >
        Change Plan
      </button>
    </div>
  </section>
);

const MetricPill: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-4">
    <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">{label}</p>
    <p className="mt-1 text-sm font-semibold text-slate-900 dark:text-white break-words">{value}</p>
  </div>
);

const BillingPage: React.FC = () => {
  const { token } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [summary, setSummary] = useState<BillingSummary | null>(null);
  const [metrics, setMetrics] = useState<BillingMetrics | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [paymentSuccessMessage, setPaymentSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    const state = location.state as { paymentSuccess?: boolean; planName?: string } | null;
    if (state?.paymentSuccess) {
      setPaymentSuccessMessage(
        state.planName
          ? `🎉 Successfully subscribed to ${state.planName}! Your account has been upgraded.`
          : "🎉 Payment successful! Your subscription is now active."
      );
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  const loadAll = async () => {
    if (!token) return;
    setLoading(true);
    setError(null);
    setActionMessage(null);

    const [summaryRes, metricsRes, paymentRes, invoicesRes] = await Promise.all([
      fetchBillingSummary(token),
      fetchBillingMetrics(token),
      fetchPaymentMethod(token),
      fetchInvoices(token),
    ]);

    if (summaryRes.success) setSummary(summaryRes.data); else setError(summaryRes.error);
    if (metricsRes.success) setMetrics(metricsRes.data); else setError((prev) => prev || metricsRes.error);
    if (paymentRes.success) setPaymentMethod(paymentRes.data); else setError((prev) => prev || paymentRes.error);
    if (invoicesRes.success) setInvoices(invoicesRes.data); else setError((prev) => prev || invoicesRes.error);

    setLoading(false);
  };

  useEffect(() => {
    void loadAll();
  }, [token]);

  const actionDisabled = useMemo(() => actionLoading || !token, [actionLoading, token]);

  const handleUpgrade = () => {
    navigate("/pricing");
  };

  const handleChangePlan = () => {
    navigate("/pricing");
  };

  const handleCancel = async () => {
    if (!token) return;
    setActionLoading(true);
    setActionMessage(null);
    const res = await cancelSubscription(token);
    setActionLoading(false);
    setActionMessage(res.success ? "Cancellation request submitted successfully." : res.error);
  };

  return (
    <div className="space-y-6">
      <BillingHeader onUpgrade={handleUpgrade} onCancel={handleCancel} actionLoading={actionDisabled} />

      {paymentSuccessMessage && (
        <div className="rounded-2xl border border-emerald-300/60 dark:border-emerald-800/60 bg-emerald-50 dark:bg-emerald-900/20 p-4 flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <p className="text-sm font-medium text-emerald-700 dark:text-emerald-300 flex-1">{paymentSuccessMessage}</p>
          <button
            type="button"
            onClick={() => setPaymentSuccessMessage(null)}
            className="p-1 rounded-lg hover:bg-emerald-100 dark:hover:bg-emerald-900/30 transition-colors"
            aria-label="Dismiss"
          >
            <X className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </button>
        </div>
      )}

      {error && (
        <div className="rounded-2xl border border-amber-300/40 bg-amber-50 dark:bg-amber-900/20 dark:border-amber-800/50 p-4 flex items-start gap-3">
          <AlertTriangle className="w-4 h-4 mt-0.5 text-amber-600 dark:text-amber-400" />
          <p className="text-sm font-medium text-amber-700 dark:text-amber-300">{error}</p>
          <button
            type="button"
            onClick={loadAll}
            className="ml-auto inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-amber-300 dark:border-amber-700 text-amber-700 dark:text-amber-300 text-xs font-bold hover:bg-amber-100 dark:hover:bg-amber-900/30"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Retry
          </button>
        </div>
      )}

      {actionMessage && (
        <div className="rounded-2xl border border-indigo-200/60 dark:border-indigo-800/60 bg-indigo-50 dark:bg-indigo-900/20 p-4 text-sm font-medium text-indigo-700 dark:text-indigo-300">
          {actionMessage}
        </div>
      )}

      <PlanSummaryCard summary={summary} loading={loading} />
      <BillingMetricsCard metrics={metrics} loading={loading} />
      <PaymentMethodCard paymentMethod={paymentMethod} loading={loading} />
      <InvoiceTable invoices={invoices} loading={loading} />
      <PlanActions onUpgrade={handleUpgrade} onCancel={handleCancel} onChangePlan={handleChangePlan} loading={actionDisabled} />
    </div>
  );
};

export default BillingPage;
