import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Logo from '../components/app/Logo';

const Section: React.FC<{ id: string; title: string; children: React.ReactNode }> = ({ id, title, children }) => (
  <section id={id} className="scroll-mt-24">
    <h2 className="text-xl font-black text-slate-900 dark:text-white mb-5 pb-3 border-b border-slate-200 dark:border-white/10">{title}</h2>
    {children}
  </section>
);

const Sub: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="mt-5">
    <h3 className="font-black text-slate-800 dark:text-slate-200 mb-2">{title}</h3>
    {children}
  </div>
);

const CreditBadge: React.FC<{ cost: string; variant?: 'default' | 'regional' | 'hd' }> = ({ cost, variant = 'default' }) => {
  const colors =
    variant === 'regional'
      ? 'bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300'
      : variant === 'hd'
        ? 'bg-purple-100 dark:bg-purple-500/20 text-purple-700 dark:text-purple-300'
        : 'bg-indigo-100 dark:bg-indigo-500/20 text-indigo-700 dark:text-indigo-300';
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-widest ${colors}`}>
      ⚡ {cost}
    </span>
  );
};

const NAV_ITEMS = [
  { id: 'overview',      label: 'Overview' },
  { id: 'credits',       label: 'Credit System' },
  { id: 'create-voice',  label: 'Create AI Voice' },
  { id: 'transcribe',    label: 'Transcribe Audio' },
  { id: 'speech-translate', label: 'Speech Translate' },
  { id: 'translate-dub', label: 'Translate & Dub' },
  { id: 'script-studio', label: 'AI Script Studio' },
  { id: 'voice-clone',   label: 'Voice Clone' },
  { id: 'projects',      label: 'Projects & Storage' },
  { id: 'pricing-why',   label: 'Why These Prices?' },
  { id: 'regional',      label: 'Regional Languages' },
];

const DocsPage: React.FC = () => {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <nav className="px-8 py-5 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link to="/dashboard"><Logo /></Link>
          <Link
            to="/dashboard"
            className="text-[10px] font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 transition-colors flex items-center gap-1.5"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to App
          </Link>
        </div>
      </nav>

      <div className="flex-1 max-w-6xl mx-auto w-full px-6 sm:px-8 py-12 flex gap-10">

        {/* Sidebar nav — desktop */}
        <aside className="hidden lg:block w-52 shrink-0">
          <div className="sticky top-24 space-y-1">
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">Contents</p>
            {NAV_ITEMS.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                className="block px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-white/60 dark:hover:bg-white/5 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
              >
                {item.label}
              </a>
            ))}
          </div>
        </aside>

        {/* Mobile nav toggle */}
        <div className="lg:hidden mb-6 w-full">
          <button
            onClick={() => setMobileNavOpen(!mobileNavOpen)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs font-black uppercase tracking-widest text-slate-700 dark:text-slate-300"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
            Jump to section
          </button>
          {mobileNavOpen && (
            <div className="mt-2 p-3 rounded-xl bg-white/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 flex flex-wrap gap-2">
              {NAV_ITEMS.map((item) => (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  onClick={() => setMobileNavOpen(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 bg-slate-100 dark:bg-white/5 transition-colors"
                >
                  {item.label}
                </a>
              ))}
            </div>
          )}
        </div>

        {/* Main content */}
        <main className="flex-1 min-w-0 space-y-14 text-sm leading-relaxed text-slate-600 dark:text-slate-400">

          <div className="mb-4">
            <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-2">Documentation</h1>
            <p className="text-slate-400">Complete guide to TextToSpeeches.in features, credit usage, and pricing.</p>
          </div>

          {/* ── Overview ── */}
          <Section id="overview" title="Platform Overview">
            <p className="mb-4">TextToSpeeches.in is an AI-powered voice and language platform offering six core capabilities powered by Microsoft Azure and Google Gemini:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { name: 'Create AI Voice',    desc: 'Convert text to natural speech using 80+ neural voices across 30+ languages.' },
                { name: 'Transcribe Audio',   desc: 'Convert spoken audio files into accurate written transcripts.' },
                { name: 'Speech Translate',   desc: 'Upload or record audio and receive translated dubbed speech in multiple target languages simultaneously.' },
                { name: 'Translate & Dub',    desc: 'Provide text or audio and receive a fully dubbed audio track in a target language.' },
                { name: 'AI Script Studio',   desc: 'Generate, enhance, and transform scripts using Google Gemini AI.' },
                { name: 'Voice Clone',        desc: 'Clone a custom voice from an audio sample and synthesise speech with it.' },
              ].map((f) => (
                <div key={f.name} className="rounded-xl border border-slate-200 dark:border-white/10 bg-white/60 dark:bg-white/5 p-4">
                  <p className="font-black text-slate-900 dark:text-white text-xs mb-1">{f.name}</p>
                  <p className="text-xs">{f.desc}</p>
                </div>
              ))}
            </div>
            <p className="mt-4">All features are available to Free users with limited credits. Paid plans (Starter, Basic, Standard, Pro, Ultra) unlock more credits per month and additional capabilities like Projects &amp; Storage and Priority Processing.</p>
          </Section>

          {/* ── Credit System ── */}
          <Section id="credits" title="Credit System">
            <p className="mb-4">Every action on the Platform consumes credits from your balance. Credits are the single currency for all features.</p>

            <Sub title="Credit Rates by Feature">
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-white/10">
                      <th className="text-left py-2 pr-4 font-black text-slate-700 dark:text-slate-300">Feature</th>
                      <th className="text-left py-2 pr-4 font-black text-slate-700 dark:text-slate-300">Cost</th>
                      <th className="text-left py-2 font-black text-slate-700 dark:text-slate-300">Unit</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                    {[
                      { feature: 'Create AI Voice (standard)',    cost: '1 credit',   unit: 'per 100 characters' },
                      { feature: 'Create AI Voice (regional 2×)', cost: '2 credits',  unit: 'per 100 characters', regional: true },
                      { feature: 'Create AI Voice (Neural HD 3×)',cost: '3 credits',  unit: 'per 100 characters', hd: true },
                      { feature: 'Transcribe Audio',              cost: '~10 credits',unit: 'per transcription job' },
                      { feature: 'Speech Translate (standard)',   cost: '1 credit',   unit: 'per 100 chars synthesised' },
                      { feature: 'Speech Translate (regional 2×)',cost: '2 credits',  unit: 'per 100 chars synthesised', regional: true },
                      { feature: 'Translate & Dub',               cost: '1 credit',   unit: 'per 125 characters' },
                      { feature: 'Text Translation (standard)',   cost: '3 credits',  unit: 'per 1,000 characters' },
                      { feature: 'Text Translation (regional 2×)',cost: '6 credits',  unit: 'per 1,000 characters', regional: true },
                      { feature: 'Voice Preview',                 cost: '1 credit',   unit: 'per new voice preview (replays free)' },
                      { feature: 'Script Generate',               cost: '4 credits',  unit: 'per generation' },
                      { feature: 'AI Script Enhance',             cost: '2 credits',  unit: 'per enhance' },
                      { feature: 'Script Transform',              cost: '3 credits',  unit: 'per transform' },
                      { feature: 'Voice Clone (create)',          cost: '50 credits', unit: 'per clone job' },
                      { feature: 'Voice Clone (synthesise)',      cost: '10 credits', unit: 'per synthesis' },
                      { feature: 'Language Detect',               cost: '1 credit',   unit: 'per detection' },
                    ].map((r) => (
                      <tr key={r.feature}>
                        <td className="py-2 pr-4 text-slate-700 dark:text-slate-300 font-semibold">{r.feature}</td>
                        <td className="py-2 pr-4">
                          <span className={(r as any).regional ? 'text-amber-600 dark:text-amber-400 font-black' : (r as any).hd ? 'text-purple-600 dark:text-purple-400 font-black' : 'text-indigo-600 dark:text-indigo-400 font-semibold'}>
                            {r.cost}
                          </span>
                        </td>
                        <td className="py-2 text-slate-500 dark:text-slate-500">{r.unit}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Sub>

            <Sub title="Credit Plans at a Glance">
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-white/10">
                      <th className="text-left py-2 pr-4 font-black text-slate-700 dark:text-slate-300">Plan</th>
                      <th className="text-left py-2 pr-4 font-black text-slate-700 dark:text-slate-300">Credits</th>
                      <th className="text-left py-2 pr-4 font-black text-slate-700 dark:text-slate-300">INR/mo</th>
                      <th className="text-left py-2 font-black text-slate-700 dark:text-slate-300">USD/mo</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-white/5">
                    {[
                      { plan: 'Free',     credits: '200 (one-time)', inr: '₹0',     usd: '$0' },
                      { plan: 'Starter',  credits: '500/mo',         inr: '₹199',   usd: '—' },
                      { plan: 'Basic',    credits: '1,200/mo',       inr: '₹399',   usd: '—' },
                      { plan: 'Standard', credits: '3,000/mo',       inr: '₹699',   usd: '—' },
                      { plan: 'Pro',      credits: '6,000/mo',       inr: '₹999',   usd: '$9' },
                      { plan: 'Ultra',    credits: '15,000/mo',      inr: '₹1,999', usd: '$29' },
                    ].map((r) => (
                      <tr key={r.plan}>
                        <td className="py-2 pr-4 font-black text-slate-800 dark:text-slate-200">{r.plan}</td>
                        <td className="py-2 pr-4 text-indigo-600 dark:text-indigo-400 font-semibold">{r.credits}</td>
                        <td className="py-2 pr-4">{r.inr}</td>
                        <td className="py-2">{r.usd}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="mt-3 text-xs text-slate-400">Annual billing saves ~20% on monthly rates. INR plans are billed in INR-equivalent USD.</p>
            </Sub>
          </Section>

          {/* ── Create AI Voice ── */}
          <Section id="create-voice" title="Create AI Voice">
            <p className="mb-4">Convert your script into studio-quality speech using Azure Neural Voices. Auto language detection guides you to compatible voices.</p>
            <div className="bg-slate-50 dark:bg-white/5 rounded-2xl p-5 border border-slate-200 dark:border-white/5 space-y-3 mb-5">
              {[
                ['1', 'Enter Script', 'Type or paste your script. Language is auto-detected. If regional, a 2× credit warning displays immediately.'],
                ['2', 'Select Voice', 'Browse 80+ neural voices filtered by language, region, and gender. Use the region filter to narrow to Indian, SE Asian, European, etc.'],
                ['3', 'Adjust Settings', 'Control speed (±50%), pitch (±50%), and output format (MP3/WAV).'],
                ['4', 'Generate', 'Click Generate. Credits are deducted based on character count and voice tier.'],
                ['5', 'Export', 'Download output as MP3 or WAV. Save to a project for 24-hour cloud storage.'],
              ].map(([n, title, desc]) => (
                <div key={n} className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs font-black flex items-center justify-center shrink-0 mt-0.5">{n}</span>
                  <p><strong className="text-slate-900 dark:text-white">{title}</strong> — {desc}</p>
                </div>
              ))}
            </div>
            <Sub title="Voice Library">
              <p>80+ voices across 30+ languages including English (US, UK, AU), Hindi, Tamil, Telugu, Malayalam, Kannada, Bengali, Gujarati, Punjabi, Marathi, Urdu, Odia, Assamese, Indonesian, Filipino, Malay, French, German, Spanish, Japanese, Korean, Chinese, Arabic, and more.</p>
            </Sub>
            <Sub title="Credit Rates">
              <div className="flex flex-wrap gap-2 mt-2">
                <CreditBadge cost="1 cr / 100 chars — standard voices" />
                <CreditBadge cost="2 cr / 100 chars — regional voices" variant="regional" />
                <CreditBadge cost="3 cr / 100 chars — Neural HD voices" variant="hd" />
              </div>
            </Sub>
            <Sub title="Expression Engine">
              <p className="mb-2">Apply emotional styles to supported voices:</p>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {['Neutral', 'Cheerful', 'Friendly', 'Empathetic', 'Whisper', 'Serious', 'Sad', 'Angry', 'Fearful', 'Assistant', 'Chatty', 'News'].map((s) => (
                  <div key={s} className="px-3 py-2 rounded-lg bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/5 text-xs font-bold text-slate-700 dark:text-slate-300 text-center">{s}</div>
                ))}
              </div>
              <p className="mt-2 text-xs text-slate-400">Not all voices support all styles. Unsupported styles fall back to neutral.</p>
            </Sub>
          </Section>

          {/* ── Transcribe Audio ── */}
          <Section id="transcribe" title="Transcribe Audio">
            <p className="mb-4">Convert spoken audio into accurate written text. Transcription outputs in the same language as the audio — it does not translate.</p>
            <div className="bg-slate-50 dark:bg-white/5 rounded-2xl p-5 border border-slate-200 dark:border-white/5 space-y-3 mb-5">
              {[
                ['1', 'Upload Audio', 'Drag and drop or choose a WAV or MP3 file (max 100 MB). An audio player and file metadata are shown.'],
                ['2', 'Configure', 'Select the target language (the language spoken in your audio). Enable auto-punctuation and/or timestamps as needed.'],
                ['3', 'Generate', 'A confirmation dialog shows estimated usage. Confirm to start transcription via Azure Speech-to-Text.'],
                ['4', 'Review & Export', 'Edit the transcript in the text editor. Download as .txt or .doc, copy to clipboard, or save to a project.'],
              ].map(([n, title, desc]) => (
                <div key={n} className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs font-black flex items-center justify-center shrink-0 mt-0.5">{n}</span>
                  <p><strong className="text-slate-900 dark:text-white">{title}</strong> — {desc}</p>
                </div>
              ))}
            </div>
            <Sub title="Supported Formats">
              <p>WAV, MP3. Maximum file size: 100 MB. Files are stored for 24 hours then auto-deleted.</p>
            </Sub>
            <Sub title="Credit Rate">
              <CreditBadge cost="~10 credits per transcription job" />
            </Sub>
          </Section>

          {/* ── Speech Translate ── */}
          <Section id="speech-translate" title="Speech Translate">
            <p className="mb-4">Upload or record source audio and receive synthesised speech translated into one or more target languages simultaneously.</p>
            <div className="bg-slate-50 dark:bg-white/5 rounded-2xl p-5 border border-slate-200 dark:border-white/5 space-y-3 mb-5">
              {[
                ['1', 'Upload / Record', 'Upload a WAV, MP3, OGG, M4A, FLAC, or WebM file, or record directly in-browser using your microphone.'],
                ['2', 'Configure', 'Select one or more target languages. Choose a voice per language. Toggle "Display regional languages" to filter to Indian & SE Asian languages. Select output format (MP3/WAV) and optionally show translated text.'],
                ['3', 'Generate', 'The audio is transcribed, translated, and synthesised for each target language. Progress is shown in real time.'],
                ['4', 'Review', 'Play back each language output, view the translated text, and download or save outputs.'],
              ].map(([n, title, desc]) => (
                <div key={n} className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs font-black flex items-center justify-center shrink-0 mt-0.5">{n}</span>
                  <p><strong className="text-slate-900 dark:text-white">{title}</strong> — {desc}</p>
                </div>
              ))}
            </div>
            <Sub title="Credit Rate">
              <div className="flex flex-wrap gap-2 mt-2">
                <CreditBadge cost="1 cr / 100 chars — standard target" />
                <CreditBadge cost="2 cr / 100 chars — regional target" variant="regional" />
              </div>
              <p className="mt-2 text-xs text-slate-400">Each target language is billed separately. Multi-target jobs multiply the credit cost.</p>
            </Sub>
          </Section>

          {/* ── Translate & Dub ── */}
          <Section id="translate-dub" title="Translate & Dub">
            <p className="mb-4">Provide text or audio content in any language and receive a fully dubbed audio track in a chosen target language.</p>
            <div className="bg-slate-50 dark:bg-white/5 rounded-2xl p-5 border border-slate-200 dark:border-white/5 space-y-3 mb-5">
              {[
                ['1', 'Input Content', 'Paste text or upload an audio file. The source language is auto-detected by Azure.'],
                ['2', 'Select Target Language', 'Choose from the full language list or check "Display regional languages" to filter to Indian & SE Asian languages. Credits are shown based on selection.'],
                ['3', 'Translate', 'Content is translated via Azure Translator. A credit warning appears if a regional target is selected (2×).'],
                ['4', 'Generate Dub', 'Select a voice and generate the dubbed audio. Review, edit the translation if needed, and regenerate.'],
                ['5', 'Export', 'Download the dubbed audio (MP3/WAV). Save to a named project for 24-hour storage.'],
              ].map(([n, title, desc]) => (
                <div key={n} className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs font-black flex items-center justify-center shrink-0 mt-0.5">{n}</span>
                  <p><strong className="text-slate-900 dark:text-white">{title}</strong> — {desc}</p>
                </div>
              ))}
            </div>
            <Sub title="Credit Rate">
              <div className="flex flex-wrap gap-2 mt-2">
                <CreditBadge cost="1 cr / 125 chars — TTS synthesis" />
                <CreditBadge cost="3 cr / 1,000 chars — text translation" />
                <CreditBadge cost="6 cr / 1,000 chars — regional translation" variant="regional" />
              </div>
            </Sub>
          </Section>

          {/* ── AI Script Studio ── */}
          <Section id="script-studio" title="AI Script Studio">
            <p className="mb-4">Generate and refine scripts using Google Gemini AI. Useful for voiceover copy, podcast scripts, narration, and more.</p>
            <Sub title="Features">
              <ul className="list-disc list-inside space-y-2 ml-2">
                <li><strong className="text-slate-800 dark:text-slate-200">Script Generate</strong> — Describe your topic and tone; Gemini writes a complete script ready for voice generation</li>
                <li><strong className="text-slate-800 dark:text-slate-200">AI Enhance</strong> — Paste an existing script; Gemini improves clarity, flow, and natural speech cadence</li>
                <li><strong className="text-slate-800 dark:text-slate-200">Script Transform</strong> — Change tone, formality, or target audience of an existing script</li>
              </ul>
            </Sub>
            <Sub title="Credit Rates">
              <div className="flex flex-wrap gap-2 mt-2">
                <CreditBadge cost="4 cr — Script Generate" />
                <CreditBadge cost="2 cr — AI Enhance" />
                <CreditBadge cost="3 cr — Script Transform" />
              </div>
            </Sub>
          </Section>

          {/* ── Voice Clone ── */}
          <Section id="voice-clone" title="Voice Clone">
            <p className="mb-4">Create a synthetic voice modelled on a real audio sample, then use it for text-to-speech synthesis.</p>
            <Sub title="How It Works">
              <ol className="list-decimal list-inside space-y-2 ml-2">
                <li>Upload a clear, noise-free audio sample (minimum 30 seconds recommended)</li>
                <li>Submit a clone job — Azure Custom Voice processes and trains the model</li>
                <li>Once ready, use the cloned voice in the Create AI Voice flow</li>
              </ol>
            </Sub>
            <Sub title="Important Rules">
              <ul className="list-disc list-inside space-y-2 ml-2">
                <li>You must own or have explicit written consent to clone the voice in your sample</li>
                <li>Cloning another person's voice without consent violates our Terms of Service and may result in account termination</li>
                <li>Cloned voices are private to your account and are not shared with other users</li>
              </ul>
            </Sub>
            <Sub title="Credit Rates">
              <div className="flex flex-wrap gap-2 mt-2">
                <CreditBadge cost="50 cr — create clone" />
                <CreditBadge cost="10 cr — synthesise with clone" />
              </div>
            </Sub>
          </Section>

          {/* ── Projects & Storage ── */}
          <Section id="projects" title="Projects & Storage">
            <p className="mb-4">Authenticated users on Basic plans and above can save work across all features into named projects.</p>
            <Sub title="What Gets Saved">
              <ul className="list-disc list-inside space-y-2 ml-2">
                <li>Project name, type (Voice / Transcript / Translation / Dub), and status</li>
                <li>Settings used (voice, language, output format)</li>
                <li>Generated transcripts and translated text</li>
                <li>References to uploaded and generated audio files (files auto-delete after 24 hours)</li>
              </ul>
            </Sub>
            <Sub title="24-Hour File Retention">
              <p>All audio files — uploaded source audio and generated output — are stored for exactly 24 hours and then permanently deleted from our servers. Download your files before expiry. Project metadata (text, settings) is not subject to the 24-hour limit.</p>
            </Sub>
            <Sub title="Guest Users">
              <p>Guests may use features without registering but cannot save projects. All data is lost when the browser session ends.</p>
            </Sub>
          </Section>

          {/* ── Why These Prices? ── */}
          <Section id="pricing-why" title="Why These Prices?">
            <p className="mb-5">We're transparent about what drives our pricing. Here's a breakdown of what goes into every plan and why the numbers are what they are.</p>

            <Sub title="Infrastructure Costs We Pay Per Request">
              <div className="space-y-3 mt-2">
                {[
                  {
                    label: 'Microsoft Azure Neural Voice (standard)',
                    cost: '$4 per 1M characters',
                    note: 'Powers Create AI Voice, Speech Translate output, and Translate & Dub synthesis. Azure charges per character synthesised using their neural voice models.',
                  },
                  {
                    label: 'Microsoft Azure Neural Voice (regional / HD)',
                    cost: 'Up to $16 per 1M characters',
                    note: 'Indian, Southeast Asian, and Neural HD voices use specialised Azure models with higher compute requirements — the cost to us is 2–4× higher than standard voices, which is why we charge 2–3× credits.',
                  },
                  {
                    label: 'Microsoft Azure Speech-to-Text',
                    cost: '$1 per audio hour',
                    note: 'Powers Transcribe Audio. A 5-minute file costs us ~$0.083 in API fees before infrastructure overhead.',
                  },
                  {
                    label: 'Microsoft Azure Translator',
                    cost: '$10 per 1M characters',
                    note: 'Powers the translation step in Speech Translate and Translate & Dub.',
                  },
                  {
                    label: 'Google Gemini API',
                    cost: 'Per 1M tokens',
                    note: 'Powers language detection and all AI Script Studio features (generate, enhance, transform).',
                  },
                  {
                    label: 'File Storage & Bandwidth',
                    cost: 'Per GB stored + egress',
                    note: 'Audio files average 5–15 MB each. With thousands of uploads and downloads daily, storage and bandwidth costs are significant even at 24-hour retention.',
                  },
                  {
                    label: 'Server & Compute',
                    cost: 'Fixed monthly',
                    note: 'ASP.NET Core backend, SQL Server database, load balancing, monitoring, and backup infrastructure.',
                  },
                ].map((item) => (
                  <div key={item.label} className="rounded-xl border border-slate-200 dark:border-white/10 bg-white/60 dark:bg-white/5 p-4">
                    <div className="flex items-start justify-between gap-3 mb-1">
                      <p className="font-black text-slate-800 dark:text-slate-200 text-xs">{item.label}</p>
                      <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 whitespace-nowrap shrink-0">{item.cost}</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{item.note}</p>
                  </div>
                ))}
              </div>
            </Sub>

            <Sub title="What Each Plan Covers">
              <div className="space-y-3 mt-2">
                {[
                  {
                    plan: 'Free — ₹0 / $0',
                    credits: '200 credits (one-time)',
                    explains: 'Covers roughly 20,000 characters of standard TTS, or 2 short transcriptions, or a few translation tests. Designed to let you explore every feature before committing.',
                  },
                  {
                    plan: 'Starter — ₹199/mo',
                    credits: '500 credits/mo',
                    explains: 'Enough for a solo creator doing occasional voiceovers — approximately 50,000 standard TTS characters per month.',
                  },
                  {
                    plan: 'Basic — ₹399/mo',
                    credits: '1,200 credits/mo',
                    explains: 'For regular users generating podcast episodes, narration, or regional-language content. Covers ~60,000 regional chars or ~120,000 standard chars.',
                  },
                  {
                    plan: 'Standard — ₹699/mo (Most Popular)',
                    credits: '3,000 credits/mo',
                    explains: 'The sweet spot for content creators and small agencies. Covers full-length YouTube scripts, multi-language speech translations, and project storage. Our infrastructure costs on this tier are covered with a modest margin to sustain development.',
                  },
                  {
                    plan: 'Pro — ₹999/mo / $9/mo',
                    credits: '6,000 credits/mo',
                    explains: 'For power users, educators, and small studios producing daily content in multiple languages. Enough for daily 5-minute multilingual dubs.',
                  },
                  {
                    plan: 'Ultra — ₹1,999/mo / $29/mo',
                    credits: '15,000 credits/mo',
                    explains: 'For agencies, production houses, and enterprises. Includes Priority Processing (dedicated queue), Priority Support (direct response), and API Access. At this volume, Azure compute alone costs us several hundred dollars monthly — the plan price reflects this.',
                  },
                ].map((item) => (
                  <div key={item.plan} className="rounded-xl border border-slate-200 dark:border-white/10 bg-white/60 dark:bg-white/5 p-4">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <p className="font-black text-slate-800 dark:text-slate-200 text-xs">{item.plan}</p>
                      <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-500/10 px-2 py-0.5 rounded-full shrink-0">⚡ {item.credits}</span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{item.explains}</p>
                  </div>
                ))}
              </div>
            </Sub>

            <Sub title="Why We Don't Offer Unlimited Plans">
              <p>Every TTS synthesis, transcription, and translation call carries a real compute cost. An "unlimited" plan would either be unsustainable or require us to throttle quality. Credits ensure we can invest in fast, high-quality neural voice models without compromising reliability for all users.</p>
            </Sub>
          </Section>

          {/* ── Regional Languages ── */}
          <Section id="regional" title="Regional Language Support">
            <p className="mb-4">TextToSpeeches.in natively supports Indian regional and Southeast Asian languages across Create AI Voice, Speech Translate, and Translate &amp; Dub.</p>

            <Sub title="Supported Regional Languages">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
                {[
                  'Hindi (hi-IN)', 'Tamil (ta-IN)', 'Telugu (te-IN)', 'Malayalam (ml-IN)',
                  'Bengali (bn-IN)', 'Marathi (mr-IN)', 'Gujarati (gu-IN)', 'Kannada (kn-IN)',
                  'Punjabi (pa-IN)', 'Urdu (ur-IN)', 'Odia (or-IN)', 'Assamese (as-IN)',
                  'Indonesian (id-ID)', 'Filipino (fil-PH)', 'Malay (ms-MY)', 'Burmese (my-MM)',
                  'Khmer (km-KH)', 'Lao (lo-LA)',
                ].map((lang) => (
                  <div key={lang} className="px-3 py-2 rounded-lg bg-amber-50 dark:bg-amber-500/10 border border-amber-200/60 dark:border-amber-500/20 text-xs font-semibold text-amber-800 dark:text-amber-300 text-center">
                    {lang}
                  </div>
                ))}
              </div>
            </Sub>

            <Sub title="Credit Tiers">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-2">
                {[
                  { tier: 'Standard (1×)', cost: '1 cr / 100 chars', note: 'English, European, East Asian, Arabic', color: 'border-slate-200 dark:border-white/10' },
                  { tier: 'Regional (2×)', cost: '2 cr / 100 chars', note: 'Indian & SE Asian neural voices', color: 'border-amber-500/30 bg-amber-50 dark:bg-amber-500/10' },
                  { tier: 'Neural HD (3×)', cost: '3 cr / 100 chars', note: 'DragonHDLatestNeural ultra-quality voices', color: 'border-purple-500/30 bg-purple-50 dark:bg-purple-500/10' },
                ].map((t) => (
                  <div key={t.tier} className={`rounded-xl border p-4 ${t.color}`}>
                    <p className="font-black text-slate-800 dark:text-slate-200 text-xs mb-1">{t.tier}</p>
                    <p className="text-indigo-600 dark:text-indigo-400 font-black text-xs mb-1">⚡ {t.cost}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{t.note}</p>
                  </div>
                ))}
              </div>
            </Sub>

            <Sub title="How Regional Pricing Works in Practice">
              <ul className="list-disc list-inside space-y-2 ml-2">
                <li>If you paste Hindi text in Create AI Voice and a regional voice is auto-selected, a warning banner appears immediately showing the 2× rate</li>
                <li>In Speech Translate, selecting a regional target language shows the 2× credit rate in the step 2 banner and on the Generate button label</li>
                <li>In Translate &amp; Dub, checking "Display regional languages" reveals the credit banner and filters the dropdown to regional languages only</li>
                <li>The regional surcharge reflects the actual higher Azure compute cost — we pass it through at the minimum viable margin</li>
              </ul>
            </Sub>
          </Section>

        </main>
      </div>

      <footer className="border-t border-black/5 dark:border-white/10 px-8 py-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">© {new Date().getFullYear()} TextToSpeeches.in</div>
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <Link to="/about" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">About</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/docs" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Docs</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/help" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Help</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/privacy" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Privacy</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/terms" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Terms</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default DocsPage;
