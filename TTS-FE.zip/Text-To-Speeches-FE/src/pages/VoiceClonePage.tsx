import React from 'react';
import VoiceCloneWizard from '../components/voiceClone/VoiceCloneWizard';

const VoiceClonePage: React.FC = () => {
  return <VoiceCloneWizard />;
};

export default VoiceClonePage;
