import React from 'react';
import { Link } from 'react-router-dom';
import Logo from '../components/app/Logo';

const HelpPage: React.FC = () => {
  const whatsappUrl = 'https://wa.me/917037300542?text=Hi%20CTO%2C%20I%20need%20help%20with%20TextToSpeeches.in';
  const emailUrl = 'mailto:help@texttospeeches.in?subject=TextToSpeeches.in%20Support%20Request';

  const faqs: Array<{ question: string; answer: React.ReactNode }> = [
    {
      question: 'How do I generate speech from text?',
      answer: 'Simply enter your text in the "Vocal Canvas" section on the home page, select a voice, customize the speech parameters (rate, pitch, volume), choose an expression style, and click "Generate Neural Voice".'
    },
    {
      question: 'What languages are supported?',
      answer: 'TextToSpeeches.in supports 40+ languages including English, Spanish, French, German, Chinese, Japanese, Hindi, Arabic, and many more. You can select any available language from the Neural Voice Library.'
    },
    {
      question: 'How can I save my recordings?',
      answer: 'After generating speech, a modal will appear prompting you to name your recording. Click "Save" to add it to your Audio Library. Your recordings persist across browser sessions.'
    },
    {
      question: 'Can I translate text to other languages?',
      answer: 'Yes! Visit the "Translate Text" page from the header. Enter your text and select a target language to translate instantly.'
    },
    {
      question: 'How do I export my audio?',
      answer: 'Go to Audio Library, find your recording, and click "Export". You can download as MP3 or WAV format.'
    },
    {
      question: 'What if the audio is not playing?',
      answer: 'Make sure your browser supports audio playback and try refreshing the page. If the issue persists, contact our support team.'
    },
  ];

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">

      <nav className="px-8 py-5 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link to="/dashboard">
            <Logo />
          </Link>
          <Link
            to="/dashboard"
            className="text-[10px] font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 transition-colors flex items-center gap-1.5"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to App
          </Link>
        </div>
      </nav>

      <main className="flex-1 max-w-4xl mx-auto w-full px-8 py-16">
        <div className="mb-16">
          <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
            Help & Support
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 font-medium">
            Need assistance? Our CTO is here to help you!
          </p>
        </div>

        {/* Contact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          {/* WhatsApp Card */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="group glass studio-card !p-8 hover:border-green-500/40 hover:bg-green-50 dark:hover:bg-green-500/10 transition-all duration-300 cursor-pointer"
          >
            <div className="flex items-start gap-6">
              <div className="w-16 h-16 rounded-2xl bg-green-500/10 flex items-center justify-center text-green-600 dark:text-green-400 group-hover:bg-green-500/20 transition-all">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371 0-.57 0-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.934 1.32c-1.51.839-2.805 2.079-3.714 3.54-.909 1.461-1.293 3.113-1.293 4.796 0 1.088.19 2.154.563 3.172L2.75 21.25l3.585-.938a9.9 9.9 0 004.735 1.206h.005c5.487 0 9.997-4.51 9.997-9.997 0-2.668-.975-5.174-2.747-7.127C16.65 3.375 14.076 2.3 11.35 2.3c-.001 0-.001 0-.002 0Z"/>
                </svg>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-black text-slate-900 dark:text-white mb-2">
                  WhatsApp
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                  Chat directly with our CTO for quick support
                </p>
                <div className="mb-4 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wide text-green-700 dark:text-green-300 bg-green-100 dark:bg-green-500/20 px-3 py-2 rounded-lg w-fit">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Mon-Fri 5-10 PM
                </div>
                <div className="flex items-center gap-2 text-green-600 dark:text-green-400 font-bold text-sm">
                  +91 7037300542
                  <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </div>
          </a>

          {/* Email Card */}
          <a
            href={emailUrl}
            className="group glass studio-card !p-8 hover:border-blue-500/40 hover:bg-blue-50 dark:hover:bg-blue-500/10 transition-all duration-300 cursor-pointer"
          >
            <div className="flex items-start gap-6">
              <div className="w-16 h-16 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-600 dark:text-blue-400 group-hover:bg-blue-500/20 transition-all">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-black text-slate-900 dark:text-white mb-2">
                  Email
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                  Send detailed support requests via email
                </p>
                <div className="mb-4 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wide text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-500/20 px-3 py-2 rounded-lg w-fit">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  24/7 Available
                </div>
                <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-bold text-sm">
                  help@texttospeeches.in
                  <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </div>
          </a>
        </div>

        {/* CTO Info */}
        <div className="glass studio-card !p-8 mb-16 bg-indigo-50 dark:bg-indigo-500/10 border-indigo-200 dark:border-indigo-500/30">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-indigo-600 flex items-center justify-center text-white shrink-0">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-2">
                Meet Your CTO
              </h3>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                I'm the Chief Technology Officer at TextToSpeeches.in. I'm dedicated to providing you with exceptional support and continuously improving our platform. Feel free to reach out with any questions, feedback, or feature requests. Your experience matters to me!
              </p>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mb-12">
          <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight mb-8">
            Frequently Asked Questions
          </h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <details
                key={index}
                className="group glass studio-card !p-6 cursor-pointer hover:border-indigo-500/40 transition-all"
              >
                <summary className="flex items-center justify-between font-bold text-slate-900 dark:text-white text-sm">
                  <span className="text-base">{faq.question}</span>
                  <svg
                    className="w-5 h-5 text-slate-400 group-open:text-indigo-600 group-open:rotate-180 transition-all"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  </svg>
                </summary>
                <p className="text-slate-600 dark:text-slate-400 text-sm mt-4 leading-relaxed">
                  {faq.answer}
                </p>
              </details>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div className="glass studio-card !p-8">
          <h3 className="text-lg font-black text-slate-900 dark:text-white mb-6">
            Quick Links
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link
              to="/"
              className="p-4 rounded-xl bg-slate-100 dark:bg-white/5 hover:bg-indigo-100 dark:hover:bg-indigo-500/10 transition-colors text-slate-900 dark:text-white font-bold text-sm flex items-center gap-2 group"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12a9 9 0 1 1 18 0 9 9 0 0 1-18 0z" />
              </svg>
              Go to Home
              <svg className="w-4 h-4 ml-auto group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
            <Link
              to="/audio-library"
              className="p-4 rounded-xl bg-slate-100 dark:bg-white/5 hover:bg-indigo-100 dark:hover:bg-indigo-500/10 transition-colors text-slate-900 dark:text-white font-bold text-sm flex items-center gap-2 group"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
              </svg>
              Audio Library
              <svg className="w-4 h-4 ml-auto group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
            <Link
              to="/translate"
              className="p-4 rounded-xl bg-slate-100 dark:bg-white/5 hover:bg-indigo-100 dark:hover:bg-indigo-500/10 transition-colors text-slate-900 dark:text-white font-bold text-sm flex items-center gap-2 group"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
              </svg>
              Translate Text
              <svg className="w-4 h-4 ml-auto group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
            <Link
              to="/privacy"
              className="p-4 rounded-xl bg-slate-100 dark:bg-white/5 hover:bg-indigo-100 dark:hover:bg-indigo-500/10 transition-colors text-slate-900 dark:text-white font-bold text-sm flex items-center gap-2 group"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
              Privacy Policy
              <svg className="w-4 h-4 ml-auto group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        </div>
      </main>

      <footer className="border-t border-black/5 dark:border-white/10 px-8 py-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            © {new Date().getFullYear()} TextToSpeeches.in
          </div>
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <Link to="/about" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">About</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/docs" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Docs</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/help" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Help</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/privacy" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Privacy</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/terms" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Terms</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HelpPage;
