import React, { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  verifyEmail,
  resendVerificationEmail,
} from "../services/authApiService";
import { mapAuthErrorMessage } from "../utils/authErrorMapper";

const VerifyEmailPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  const emailParam = searchParams.get("email");

  const [isVerifying, setIsVerifying] = useState(false);
  const [verified, setVerified] = useState(false);
  const [error, setError] = useState("");
  const [resendEmail, setResendEmail] = useState(emailParam || "");
  const [resendStatus, setResendStatus] = useState("");
  const [resendLoading, setResendLoading] = useState(false);

  useEffect(() => {
    if (token) {
      handleVerify(token);
    }
  }, [token]);

  const handleVerify = async (verificationToken: string) => {
    setIsVerifying(true);
    setError("");

    const res = await verifyEmail(verificationToken);

    if (res.success) {
      setVerified(true);
    } else {
      setError(
        mapAuthErrorMessage({
          flow: "verify",
          status: res.status,
          error: res.error,
          errors: res.errors,
        }),
      );
    }
    setIsVerifying(false);
  };

  const handleResend = async () => {
    if (!resendEmail.trim()) {
      setResendStatus("Please enter your email address.");
      return;
    }
    setResendLoading(true);
    setResendStatus("");

    const res = await resendVerificationEmail(resendEmail.trim().toLowerCase());
    setResendLoading(false);

    if (res.success) {
      setResendStatus(
        res.message || "Verification email sent! Check your inbox.",
      );
    } else {
      setResendStatus(
        mapAuthErrorMessage({
          flow: "resend",
          status: res.status,
          error: res.error,
          errors: res.errors,
        }),
      );
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-gradient-to-br from-slate-50 via-white to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2.5}
                  d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"
                />
              </svg>
            </div>
            <h1 className="text-2xl font-black tracking-tighter text-slate-900 dark:text-white uppercase">
              TextTo<span className="text-indigo-500">Speeches</span>
            </h1>
          </Link>
        </div>

        {/* Card */}
        <div className="glass studio-card !p-8 sm:!p-10 text-center">
          {isVerifying ? (
            <>
              <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-indigo-100 dark:bg-indigo-500/10 flex items-center justify-center">
                <div className="w-8 h-8 border-3 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
              </div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
                Verifying Email
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Please wait while we verify your email address...
              </p>
            </>
          ) : verified ? (
            <>
              <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-emerald-100 dark:bg-emerald-500/10 flex items-center justify-center">
                <svg
                  className="w-8 h-8 text-emerald-600 dark:text-emerald-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2.5}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
                Email Verified!
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
                Your email has been verified successfully. You can login now.
              </p>
              <Link
                to="/login"
                className="inline-block px-8 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm uppercase tracking-wider transition-all shadow-lg shadow-indigo-600/20"
              >
                Go to Login
              </Link>
            </>
          ) : error ? (
            <>
              <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-red-100 dark:bg-red-500/10 flex items-center justify-center">
                <svg
                  className="w-8 h-8 text-red-600 dark:text-red-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2.5}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </div>
              <p className="text-sm text-red-500 dark:text-red-400 mb-6">
                {error}
              </p>
              <Link
                to="/home"
                className="inline-block px-8 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm uppercase tracking-wider transition-all shadow-lg shadow-indigo-600/20"
              >
                Go to Home
              </Link>
            </>
          ) : (
            <>
              {/* No token - show info page */}
              <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-indigo-100 dark:bg-indigo-500/10 flex items-center justify-center">
                <svg
                  className="w-8 h-8 text-indigo-600 dark:text-indigo-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">
                Check Your Email
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
                We've sent a verification link to your email. Click the link to
                verify your account.
              </p>

              {/* Resend Section */}
              <div className="mt-6 pt-6 border-t border-slate-200 dark:border-white/10">
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                  Didn't receive the email?
                </p>
                <input
                  type="email"
                  value={resendEmail}
                  onChange={(e) => setResendEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full px-4 py-3 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all text-sm mb-3"
                />
                <button
                  onClick={handleResend}
                  disabled={resendLoading}
                  className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm uppercase tracking-wider transition-all disabled:opacity-50"
                >
                  {resendLoading ? "Sending..." : "Resend Verification Email"}
                </button>
                {resendStatus && (
                  <p className="text-sm text-slate-500 mt-3">{resendStatus}</p>
                )}
              </div>

              <p className="text-sm text-slate-500 dark:text-slate-400 mt-6">
                <Link
                  to="/login"
                  className="font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  Go to Login
                </Link>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default VerifyEmailPage;
