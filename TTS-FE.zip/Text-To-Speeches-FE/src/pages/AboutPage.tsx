import React from "react";
import { Link } from "react-router-dom";
import Logo from "../components/app/Logo";

import amitProfilePic from "../assets/profilePic/amitProfilePic.jpg";
import sumitProfilePic from "../assets/profilePic/sumitProfilePic.jpg";
import rumaProfilePic from "../assets/profilePic/rumaProfilePic.jpg";

/* ── Types ── */
type LeadershipMember = {
  role: string;
  name: string;
  email: string;
  profilePictureUrl: string;
  summary: string;
  highlights: string[];
};

/* ── Data ── */
const leadership: LeadershipMember[] = [
  {
    role: "Founder & CEO",
    name: "Amit Kumar",
    email: "amit.kumar@texttospeeches.in",
    profilePictureUrl: amitProfilePic,
    summary: "Defines the company vision, long-term strategy, and overall growth direction. Leads product direction and business execution across strategy, partnerships, and go-to-market for voice AI solutions.",
    highlights: ["Vision", "Strategy", "Partnerships"],
  },
  {
    role: "Chief Technical Officer",
    name: "Sumit Kumar",
    email: "sumit.kumar@texttospeeches.in",
    profilePictureUrl: sumitProfilePic,
    summary: "Leads engineering architecture, platform reliability, and technical innovation. Owns platform architecture, security posture, and scalable delivery for real-time speech experiences.",
    highlights: ["Architecture", "Security", "Scalability"],
  },
  {
    role: "Head of Product Design",
    name: "Ruma",
    email: "ruma@texttospeeches.in",
    profilePictureUrl: rumaProfilePic,
    summary: "Owns product design, user experience, and design system consistency. Drives UX research, interaction design, and visual systems to keep workflows fast and accessible.",
    highlights: ["UX Research", "UI Systems", "Accessibility"],
  },
];

const values = [
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
    title: "Trust First",
    description: "Every feature we build starts with a commitment to user trust — transparent pricing, secure infrastructure, and no hidden costs.",
    color: "from-emerald-500/10 to-teal-500/10 border-emerald-200/50 dark:border-emerald-500/20",
    iconColor: "text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-500/20",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
    title: "Speed & Performance",
    description: "We obsess over response times, audio quality, and zero-lag delivery so you can create without friction.",
    color: "from-amber-500/10 to-orange-500/10 border-amber-200/50 dark:border-amber-500/20",
    iconColor: "text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-500/20",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064" />
      </svg>
    ),
    title: "Global Reach",
    description: "Supporting 40+ languages and Indian regional voices, we believe language should never be a barrier to great content.",
    color: "from-blue-500/10 to-cyan-500/10 border-blue-200/50 dark:border-blue-500/20",
    iconColor: "text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-500/20",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
      </svg>
    ),
    title: "Creator-Centric",
    description: "Built for podcasters, educators, marketers, and developers — not enterprises. Simple, powerful, affordable.",
    color: "from-violet-500/10 to-purple-500/10 border-violet-200/50 dark:border-violet-500/20",
    iconColor: "text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-500/20",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
      </svg>
    ),
    title: "AI-Powered Innovation",
    description: "Continuously integrating the latest neural voice and language models so your content always sounds cutting-edge.",
    color: "from-fuchsia-500/10 to-pink-500/10 border-fuchsia-200/50 dark:border-fuchsia-500/20",
    iconColor: "text-fuchsia-600 dark:text-fuchsia-400 bg-fuchsia-100 dark:bg-fuchsia-500/20",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
      </svg>
    ),
    title: "Made in India",
    description: "Proudly built from India, for the world — with deep support for Indian languages, INR pricing, and local payment methods.",
    color: "from-rose-500/10 to-orange-500/10 border-rose-200/50 dark:border-rose-500/20",
    iconColor: "text-rose-600 dark:text-rose-400 bg-rose-100 dark:bg-rose-500/20",
  },
];

const offerings = [
  { icon: "🎙️", title: "Create AI Voice", desc: "Convert any text to studio-quality speech using 72+ neural voices across 40+ languages." },
  { icon: "📝", title: "Transcribe Audio", desc: "Turn audio and video files into accurate, editable text transcripts in minutes." },
  { icon: "🌐", title: "Translate & Dub", desc: "Translate your content and re-voice it in any language while preserving tone and clarity." },
  { icon: "🔄", title: "Speech Translate", desc: "Real-time speech-to-speech translation that keeps your voice authentic and natural." },
  { icon: "✍️", title: "AI Script Studio", desc: "Generate scripts for videos, podcasts, ads, and more with AI-powered writing assistance." },
  { icon: "⚡", title: "AI Text Enhance", desc: "Reframe and polish your scripts for voiceover with one click using AI." },
];

const trustStats = [
  { value: "40+", label: "Languages Supported" },
  { value: "72+", label: "Neural Voices" },
  { value: "99.9%", label: "Uptime SLA" },
  { value: "256-bit", label: "AES Encryption" },
];

const whyUs = [
  {
    title: "Credit-Based Transparency",
    description: "No surprise bills. Pay only for what you use with a clear, predictable credit system. Start free with 200 credits — no card required.",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    title: "All Features, Every Plan",
    description: "Unlike competitors that gate core features, every TextToSpeeches.in plan includes every workflow — from voice cloning to script generation.",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
      </svg>
    ),
  },
  {
    title: "Indian-First Design",
    description: "Built with deep support for Hindi, Tamil, Telugu, Bengali, Marathi, and more. INR pricing. Razorpay payments. No USD conversion friction.",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
  },
  {
    title: "Enterprise-Grade Infrastructure",
    description: "Powered by Azure Neural Voices and Gemini AI, running on Microsoft's global cloud with end-to-end encryption and 99.9% uptime.",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
      </svg>
    ),
  },
];

/* ── Per-member accent themes ── */
const memberAccents = [
  {
    gradient: "from-indigo-600 via-violet-600 to-indigo-800",
    glow: "group-hover:shadow-indigo-500/30",
    badge: "bg-indigo-500/30 text-indigo-100 border-indigo-400/30",
    tag: "bg-indigo-50 dark:bg-indigo-500/15 text-indigo-700 dark:text-indigo-300",
    dot: "bg-indigo-500",
    ring: "ring-indigo-200 dark:ring-indigo-500/30",
  },
  {
    gradient: "from-cyan-600 via-blue-600 to-cyan-800",
    glow: "group-hover:shadow-cyan-500/30",
    badge: "bg-cyan-500/30 text-cyan-100 border-cyan-400/30",
    tag: "bg-cyan-50 dark:bg-cyan-500/15 text-cyan-700 dark:text-cyan-300",
    dot: "bg-cyan-500",
    ring: "ring-cyan-200 dark:ring-cyan-500/30",
  },
  {
    gradient: "from-rose-500 via-fuchsia-600 to-rose-800",
    glow: "group-hover:shadow-rose-500/30",
    badge: "bg-rose-500/30 text-rose-100 border-rose-400/30",
    tag: "bg-rose-50 dark:bg-rose-500/15 text-rose-700 dark:text-rose-300",
    dot: "bg-rose-500",
    ring: "ring-rose-200 dark:ring-rose-500/30",
  },
];

/* ── Sub-components ── */
const SectionLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <p className="text-xs font-black uppercase tracking-widest text-indigo-500 mb-3">{children}</p>
);

const LeadershipCard: React.FC<{ member: LeadershipMember; accent: typeof memberAccents[0]; imageScale?: number }> = ({ member, accent, imageScale = 1 }) => (
  <div className="group flex flex-col items-center text-center gap-4">

    {/* Circular photo */}
    <div className="w-28 h-28 rounded-full overflow-hidden shadow-lg shrink-0">
      <img
        src={member.profilePictureUrl}
        alt={member.name}
        className="w-full h-full object-cover object-top transition-transform duration-500"
        style={{ transform: `scale(${imageScale})`, transformOrigin: "top center" }}
        loading="lazy"
      />
    </div>

    {/* Name + Role */}
    <div>
      <h3 className="text-xl font-black text-slate-900 dark:text-white leading-tight">{member.name}</h3>
      <p className="text-[11px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mt-1">{member.role}</p>
    </div>

    {/* Summary */}
    <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-xs">
      {member.summary}
    </p>

    {/* Contact */}
    <a href={`mailto:${member.email}`} className="text-sm text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
      {member.email}
    </a>
  </div>
);

/* ── Page ── */
const AboutPage: React.FC = () => {

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">

      {/* Nav */}
      <nav className="px-8 py-5 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link to="/dashboard"><Logo /></Link>
          <Link to="/dashboard" className="text-[10px] font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 transition-colors flex items-center gap-1.5">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to App
          </Link>
        </div>
      </nav>

      <main className="flex-1 w-full">

        {/* ── Hero ── */}
        <section className="relative overflow-hidden py-24 px-6">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/8 via-violet-500/5 to-transparent dark:from-indigo-600/12 pointer-events-none" />
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-radial from-violet-400/10 to-transparent rounded-full blur-3xl pointer-events-none" />
          <div className="max-w-4xl mx-auto text-center relative">
            <p className="text-xs font-black uppercase tracking-widest text-indigo-500 mb-4">Our Story</p>
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black tracking-tight text-slate-900 dark:text-white mb-6 leading-[1.05]">
              Voice AI built for{" "}
              <span className="bg-gradient-to-r from-violet-600 via-fuchsia-500 to-cyan-500 bg-clip-text text-transparent">
                every creator
              </span>
            </h1>
            <p className="text-lg sm:text-xl text-slate-600 dark:text-slate-400 font-medium leading-relaxed max-w-2xl mx-auto">
              TextToSpeeches.in is an all-in-one voice AI platform built from India for the world — making professional-grade audio creation accessible, affordable, and multilingual.
            </p>
          </div>
        </section>

        {/* ── Trust Stats Bar ── */}
        <section className="border-y border-black/5 dark:border-white/8 bg-white/50 dark:bg-white/3 backdrop-blur-sm">
          <div className="max-w-6xl mx-auto px-6 py-8 grid grid-cols-2 sm:grid-cols-4 gap-6">
            {trustStats.map(stat => (
              <div key={stat.label} className="text-center">
                <p className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">{stat.value}</p>
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── Vision & Mission ── */}
        <section className="max-w-6xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-8">
          {/* Vision */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 to-violet-600 p-8 sm:p-10 text-white">
            <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl pointer-events-none" />
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center mb-6">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              </div>
              <p className="text-xs font-black uppercase tracking-widest text-white/70 mb-3">Our Vision</p>
              <h2 className="text-3xl font-black mb-4 leading-tight">A world where language is never a barrier</h2>
              <p className="text-white/80 font-medium leading-relaxed">
                We envision a future where any creator — regardless of language, location, or budget — can produce world-class audio content. Voice AI should be as accessible as writing an email.
              </p>
            </div>
          </div>

          {/* Mission */}
          <div className="relative overflow-hidden rounded-3xl bg-white/70 dark:bg-white/5 border border-slate-200/60 dark:border-white/10 backdrop-blur-xl p-8 sm:p-10">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-500/20 flex items-center justify-center mb-6">
              <svg className="w-6 h-6 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
              </svg>
            </div>
            <p className="text-xs font-black uppercase tracking-widest text-indigo-500 mb-3">Our Mission</p>
            <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-4 leading-tight">Democratize voice AI for every creator</h2>
            <p className="text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
              To deliver studio-quality voice AI tools that are simple enough for beginners, powerful enough for professionals, and affordable enough for independent creators — all under one roof.
            </p>
          </div>
        </section>

        {/* ── Our Values ── */}
        <section className="bg-white/40 dark:bg-white/2 border-y border-black/5 dark:border-white/8 py-20 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <SectionLabel>Our Values</SectionLabel>
              <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">
                What drives us every day
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {values.map(v => (
                <div key={v.title} className={`rounded-2xl border bg-gradient-to-br ${v.color} p-6 backdrop-blur-sm`}>
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${v.iconColor}`}>
                    {v.icon}
                  </div>
                  <h3 className="text-base font-black text-slate-900 dark:text-white mb-2">{v.title}</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">{v.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── What We Offer ── */}
        <section className="max-w-6xl mx-auto px-6 py-20">
          <div className="text-center mb-12">
            <SectionLabel>What We Offer</SectionLabel>
            <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-3">
              Every tool a creator needs
            </h2>
            <p className="text-slate-500 dark:text-slate-400 font-medium max-w-xl mx-auto">
              One platform. Six powerful workflows. No switching between apps.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {offerings.map(o => (
              <div key={o.title} className="group flex gap-4 bg-white/70 dark:bg-white/5 border border-slate-200/60 dark:border-white/10 rounded-2xl p-5 hover:border-indigo-200 dark:hover:border-indigo-500/30 hover:shadow-md transition-all duration-200">
                <span className="text-2xl shrink-0 mt-0.5">{o.icon}</span>
                <div>
                  <h3 className="text-sm font-black text-slate-900 dark:text-white mb-1">{o.title}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{o.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── Why Choose Us ── */}
        <section className="bg-gradient-to-br from-slate-900 to-slate-800 dark:from-slate-950 dark:to-slate-900 py-20 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <p className="text-xs font-black uppercase tracking-widest text-indigo-400 mb-3">Why Choose Us</p>
              <h2 className="text-4xl font-black text-white tracking-tight mb-3">
                Built different. Priced different.
              </h2>
              <p className="text-slate-400 font-medium max-w-xl mx-auto">
                We don't just offer features — we offer a philosophy of fairness, transparency, and creator-first design.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {whyUs.map(item => (
                <div key={item.title} className="flex gap-4 bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/8 transition-colors">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-base font-black text-white mb-1.5">{item.title}</h3>
                    <p className="text-sm text-slate-400 leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Trust & Reliability ── */}
        <section className="max-w-6xl mx-auto px-6 py-20">
          <div className="text-center mb-12">
            <SectionLabel>Trust & Reliability</SectionLabel>
            <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-3">
              Infrastructure you can rely on
            </h2>
            <p className="text-slate-500 dark:text-slate-400 font-medium max-w-xl mx-auto">
              Built on Microsoft Azure with enterprise-grade security, redundancy, and compliance baked in from day one.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="rounded-2xl border border-emerald-200 dark:border-emerald-500/20 bg-emerald-50 dark:bg-emerald-500/10 p-6 text-center">
              <svg className="w-8 h-8 text-emerald-600 dark:text-emerald-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-2">End-to-End Encrypted</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">All audio, text, and user data is encrypted with AES-256 at rest and in transit.</p>
            </div>
            <div className="rounded-2xl border border-blue-200 dark:border-blue-500/20 bg-blue-50 dark:bg-blue-500/10 p-6 text-center">
              <svg className="w-8 h-8 text-blue-600 dark:text-blue-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
              </svg>
              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-2">Azure Cloud Infrastructure</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">Deployed on Microsoft Azure's global network for low latency, high availability, and regional redundancy.</p>
            </div>
            <div className="rounded-2xl border border-violet-200 dark:border-violet-500/20 bg-violet-50 dark:bg-violet-500/10 p-6 text-center">
              <svg className="w-8 h-8 text-violet-600 dark:text-violet-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-2">Secure Payments via Razorpay</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">All transactions are processed through Razorpay with PCI-DSS compliance. We never store card details.</p>
            </div>
          </div>

          {/* Powered-by badges */}
          <div className="mt-10 flex flex-wrap justify-center items-center gap-4">
            {["Powered by Azure Neural Voices", "Gemini AI Integration", "Razorpay Payments", "99.9% Uptime SLA"].map(badge => (
              <span key={badge} className="px-4 py-2 rounded-full text-xs font-bold bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300 shadow-sm">
                ✦ {badge}
              </span>
            ))}
          </div>
        </section>

        {/* ── Leadership ── */}
        <section className="bg-white/40 dark:bg-white/2 border-t border-black/5 dark:border-white/8 py-20 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <SectionLabel>The Team</SectionLabel>
              <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-3">
                Meet the people behind the product
              </h2>
              <p className="text-slate-500 dark:text-slate-400 font-medium max-w-xl mx-auto">
                A small, focused team with deep expertise in AI, engineering, and design — united by a passion for making voice accessible to all.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {leadership.map((member, index) => (
                <LeadershipCard
                  key={member.role}
                  member={member}
                  accent={memberAccents[index % memberAccents.length]}
                  imageScale={index === 0 ? 1 : 1.25}
                />
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA ── */}
        <section className="py-20 px-6 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
              Ready to create with your voice?
            </h2>
            <p className="text-slate-500 dark:text-slate-400 font-medium mb-8">
              Start free with 200 credits. No credit card required.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                to="/dashboard"
                className="px-7 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-black uppercase tracking-widest transition-colors shadow-lg shadow-indigo-500/20"
              >
                Get Started Free
              </Link>
              <Link
                to="/pricing"
                className="px-7 py-3.5 rounded-xl bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-200 text-sm font-black uppercase tracking-widest hover:bg-white dark:hover:bg-white/10 transition-colors"
              >
                View Pricing
              </Link>
            </div>
          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="border-t border-black/5 dark:border-white/10 px-8 py-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            © {new Date().getFullYear()} TextToSpeeches.in — All rights reserved.
          </div>
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            <Link to="/about"   className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">About</Link>
            <span className="text-slate-300 dark:text-white/10">|</span>
            <Link to="/pricing" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Pricing</Link>
            <span className="text-slate-300 dark:text-white/10">|</span>
            <Link to="/privacy" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Privacy</Link>
            <span className="text-slate-300 dark:text-white/10">|</span>
            <Link to="/terms"   className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Terms</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default AboutPage;
