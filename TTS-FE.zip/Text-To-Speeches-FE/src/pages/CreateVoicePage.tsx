import React from "react";
import { useSearchParams } from "react-router-dom";
import { useSpeechSynthesis } from "../hooks/useSpeechSynthesis";
import { useAuth } from "../contexts/AuthContext";
import CreateVoiceWizard from "../components/createVoice/CreateVoiceWizard";

const CreateVoicePage: React.FC = () => {
  const { token } = useAuth();
  const synthesis = useSpeechSynthesis();
  const [searchParams] = useSearchParams();
  const projectId = searchParams.get("projectId") || undefined;

  return (
    <CreateVoiceWizard token={token} synthesis={synthesis} initialProjectId={projectId} />
  );
};

export default CreateVoicePage;
