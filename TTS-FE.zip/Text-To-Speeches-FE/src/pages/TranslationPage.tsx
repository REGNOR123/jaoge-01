import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { detectTextLanguage, translateText } from '../services/langService';
import { useAuth } from '../contexts/AuthContext';
import AuthRequiredModal from '../components/AuthRequiredModal';

const LANGUAGE_OPTIONS = [
  { code: 'en', name: 'English' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'es', name: 'Spanish' },
  { code: 'it', name: 'Italian' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ko', name: 'Korean' },
  { code: 'zh', name: 'Chinese' },
  { code: 'hi', name: 'Hindi' },
  { code: 'ar', name: 'Arabic' },
  { code: 'ru', name: 'Russian' },
  { code: 'tr', name: 'Turkish' },
  { code: 'vi', name: 'Vietnamese' },
  { code: 'nl', name: 'Dutch' },
  { code: 'pl', name: 'Polish' },
  { code: 'sv', name: 'Swedish' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'el', name: 'Greek' },
  { code: 'th', name: 'Thai' },
  { code: 'he', name: 'Hebrew' },
  { code: 'da', name: 'Danish' },
  { code: 'fi', name: 'Finnish' },
  { code: 'no', name: 'Norwegian' },
];

const TranslationPage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [sourceText, setSourceText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [sourceLang, setSourceLang] = useState('en');
  const [targetLang, setTargetLang] = useState('es');
  const [isDetecting, setIsDetecting] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [authRequiredOpen, setAuthRequiredOpen] = useState(false);

  // Auto-detect source language
  useEffect(() => {
    if (!isAuthenticated) {
      setIsDetecting(false);
      return;
    }
    if (sourceText.trim().length === 0) {
      setSourceLang('en');
      setTranslatedText('');
      return;
    }

    if (sourceText.trim().length < 5) return;

    const detectTimeout = setTimeout(async () => {
      setIsDetecting(true);
      try {
        const detected = await detectTextLanguage(sourceText);
        if (detected && detected !== 'Unknown') {
          const langCode = LANGUAGE_OPTIONS.find(l => l.name === detected)?.code;
          if (langCode) {
            setSourceLang(langCode);
          }
        }
      } catch (err) {
        console.warn('Language detection failed');
      } finally {
        setIsDetecting(false);
      }
    }, 1000);

    return () => clearTimeout(detectTimeout);
  }, [isAuthenticated, sourceText]);

  const handleTranslate = async () => {
    if (!isAuthenticated) {
      setAuthRequiredOpen(true);
      return;
    }
    if (!sourceText.trim()) {
      setError('Please enter some text to translate');
      return;
    }

    if (sourceLang === targetLang) {
      setError('Source and target languages must be different');
      return;
    }
    setIsTranslating(true);
    setError(null);
    try {
      const result = await translateText(sourceText, targetLang);
      if (result) {
        setTranslatedText(result);
      } else {
        setError('Translation failed. Please try again.');
      }
    } catch (err) {
      setError('An error occurred during translation');
      console.error('Translation error:', err);
    } finally {
      setIsTranslating(false);
    }
  };

  const handleCopyTranslation = () => {
    if (translatedText) {
      navigator.clipboard.writeText(translatedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <AuthRequiredModal
        isOpen={authRequiredOpen}
        onClose={() => setAuthRequiredOpen(false)}
        redirectTo="/translate"
      />
      <nav className="px-8 py-6 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-[1200px] mx-auto">
          <div className="flex items-center justify-between mb-4">
            <Link to="/" className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
              <h1 className="text-lg font-black tracking-tighter text-slate-900 dark:text-white uppercase leading-none">
                TextTo<span className="text-indigo-500">Speeches</span>
              </h1>
            </Link>
            <Link to="/" className="text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:text-indigo-500 transition-colors flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back
            </Link>
          </div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-slate-400 flex items-center gap-2">
            <Link to="/" className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              Home
            </Link>
            <span className="text-slate-400 dark:text-slate-600">›</span>
            <span className="text-slate-900 dark:text-white">Translate Text</span>
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-4xl mx-auto w-full px-8 py-16">
        <div className="mb-12">
          <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
            Text Translator
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-400 font-medium">
            Translate your text to any language with just one click
          </p>
          {!isAuthenticated && (
            <p className="mt-4 text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-300">
              Login required to translate.
            </p>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Source Text */}
          <div className="glass studio-card !p-6 space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-wider">
                Source Text
              </label>
              {isDetecting && (
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Detecting...</span>
                </div>
              )}
            </div>

            <textarea
              value={sourceText}
              onChange={(e) => setSourceText(e.target.value)}
              placeholder="Enter text to translate..."
              className="w-full h-48 p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10 focus:border-indigo-500 dark:focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-600 resize-none font-medium text-sm leading-relaxed"
            />

            <div className="text-[11px] text-slate-500 dark:text-slate-500">
              {sourceText.length} characters {sourceText.length > 0 && `| Detected: `}<span className={sourceText.length > 0 ? "font-bold text-slate-700 dark:text-slate-300" : "hidden"}>{LANGUAGE_OPTIONS.find(l => l.code === sourceLang)?.name || 'Unknown'}</span>
            </div>
          </div>

          {/* Target Language & Controls */}
          <div className="glass studio-card !p-6 space-y-4 flex flex-col">
            <label className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-wider">
              Translated Text
            </label>

            <textarea
              value={translatedText}
              readOnly
              placeholder="Translation will appear here..."
              className="flex-1 p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-600 resize-none font-medium text-sm leading-relaxed"
            />

            <div className="flex gap-2">
              <label className="flex-1">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                  To Language
                </span>
                <select
                  value={targetLang}
                  onChange={(e) => setTargetLang(e.target.value)}
                  className="w-full px-4 py-2 rounded-lg bg-slate-100 dark:bg-black/30 border border-slate-200 dark:border-white/10 focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white font-medium text-sm"
                >
                  {LANGUAGE_OPTIONS.map(lang => (
                    <option key={lang.code} value={lang.code}>
                      {lang.name}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {translatedText && (
              <button
                onClick={handleCopyTranslation}
                className="w-full py-2 px-4 rounded-lg bg-green-500/10 hover:bg-green-500/20 text-green-600 dark:text-green-400 font-bold text-xs uppercase tracking-wider transition-all border border-green-500/20"
              >
                {copied ? '✓ Copied!' : 'Copy Translation'}
              </button>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 mt-8">
          <button
            onClick={handleTranslate}
            disabled={isAuthenticated ? isTranslating || !sourceText.trim() : false}
            aria-disabled={isAuthenticated ? isTranslating || !sourceText.trim() : true}
            className={`flex-1 py-4 px-6 rounded-xl font-bold text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
              !isAuthenticated || isTranslating || !sourceText.trim()
                ? 'bg-slate-100 dark:bg-white/5 text-slate-300 dark:text-slate-700 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-600/20'
            }`}
          >
            {isTranslating ? (
              <>
                <svg className="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Translating...
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
                </svg>
                Translate
              </>
            )}
          </button>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mt-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 animate-in fade-in">
            <p className="text-red-600 dark:text-red-400 text-xs font-bold uppercase tracking-wide">{error}</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default TranslationPage;
