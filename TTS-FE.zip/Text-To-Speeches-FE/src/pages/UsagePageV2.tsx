import React, { useCallback, useMemo } from "react";
import { Link } from "react-router-dom";
import {
  AlertTriangle,
  TrendingUp,
  FileText,
  Clock,
  Zap,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
} from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useUsagePage } from "../hooks/useUsagePage";
import type {
  DateFilterType,
  TotalUsageCard,
  QuotaCard,
  PlanDetails,
  UsageAlerts,
  PageUsageItem,
} from "../services/usageApiService";

// ============================================================================
// Progress Bar Component
// ============================================================================
type ProgressBarProps = {
  percent: number;
  warning?: boolean;
  critical?: boolean;
  size?: "sm" | "md" | "lg";
};

const ProgressBar: React.FC<ProgressBarProps> = ({
  percent,
  warning = false,
  critical = false,
  size = "md",
}) => {
  const heightClass = size === "sm" ? "h-1.5" : size === "lg" ? "h-3" : "h-2";
  const bgColor = critical
    ? "bg-red-500"
    : warning
      ? "bg-amber-500"
      : "bg-indigo-600";

  return (
    <div className={`${heightClass} rounded-full bg-slate-200/70 dark:bg-white/10 overflow-hidden`}>
      <div
        className={`h-full ${bgColor} transition-all duration-500`}
        style={{ width: `${Math.min(100, Math.max(0, percent))}%` }}
      />
    </div>
  );
};

// ============================================================================
// Stat Card Component
// ============================================================================
type StatCardProps = {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ReactNode;
};

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon,
}) => {
  return (
    <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5 backdrop-blur-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
            {title}
          </p>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">
            {typeof value === "number" ? value.toLocaleString() : value}
          </p>
          {subtitle && (
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {subtitle}
            </p>
          )}
        </div>
        {icon && (
          <div className="rounded-xl bg-indigo-100 dark:bg-indigo-900/30 p-2.5 text-indigo-600 dark:text-indigo-400">
            {icon}
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// Total Usage Card
// ============================================================================
type TotalUsageCardProps = {
  data: TotalUsageCard;
  loading?: boolean;
};

const TotalUsageCardComponent: React.FC<TotalUsageCardProps> = ({
  data,
  loading,
}) => {
  if (loading) {
    return (
      <div className="glass studio-card !p-6 animate-pulse">
        <div className="h-4 w-24 bg-slate-200 dark:bg-slate-700 rounded mb-4" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-20 bg-slate-200 dark:bg-slate-700 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="glass studio-card !p-6">
      <h2 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-4">
        Total Usage
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          title="Characters"
          value={data.totalCharactersProcessed}
          icon={<FileText className="w-5 h-5" />}
        />
        <StatCard
          title="Voice Minutes"
          value={data.totalVoiceMinutes.toFixed(2)}
          subtitle="minutes"
          icon={<Clock className="w-5 h-5" />}
        />
        <StatCard
          title="Enhancements"
          value={data.totalEnhancements}
          icon={<Zap className="w-5 h-5" />}
        />
        <StatCard
          title="Total Requests"
          value={data.totalRequests}
          icon={<TrendingUp className="w-5 h-5" />}
        />
      </div>
    </div>
  );
};

// ============================================================================
// Quota Card Component
// ============================================================================
type QuotaCardProps = {
  data: QuotaCard;
  alerts: UsageAlerts;
  loading?: boolean;
};

type QuotaItemProps = {
  label: string;
  used: number;
  remaining: number;
  limit: number;
  percentUsed: number;
  warning: boolean;
  critical: boolean;
  unit: string;
  decimals?: number;
};

const QuotaItem: React.FC<QuotaItemProps> = ({
  label,
  used,
  remaining,
  limit,
  percentUsed,
  warning,
  critical,
  unit,
  decimals = 0,
}) => {
  const formatNumber = (n: number) =>
    decimals > 0 ? n.toFixed(decimals) : n.toLocaleString();

  const statusColor = critical
    ? "text-red-600 dark:text-red-400"
    : warning
      ? "text-amber-600 dark:text-amber-400"
      : "text-slate-700 dark:text-slate-200";

  return (
    <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5">
      <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
        {label}
      </p>
      <div className="mt-2 flex items-baseline gap-1">
        <span className={`text-xl font-bold ${statusColor}`}>
          {formatNumber(remaining)}
        </span>
        <span className="text-sm text-slate-500 dark:text-slate-400">
          / {formatNumber(limit)} {unit} remaining
        </span>
      </div>
      <div className="mt-3">
        <ProgressBar percent={percentUsed} warning={warning} critical={critical} />
      </div>
      <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
        {formatNumber(used)} {unit} used ({percentUsed.toFixed(1)}%)
      </p>
    </div>
  );
};

const QuotaCardComponent: React.FC<QuotaCardProps> = ({
  data,
  alerts,
  loading,
}) => {
  if (loading) {
    return (
      <div className="glass studio-card !p-6 animate-pulse">
        <div className="h-4 w-32 bg-slate-200 dark:bg-slate-700 rounded mb-4" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 bg-slate-200 dark:bg-slate-700 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="glass studio-card !p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
          Remaining Quota
        </h2>
        {alerts.messages.length > 0 && (
          <div className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
            <AlertTriangle className="w-4 h-4" />
            <span className="text-xs font-medium">{alerts.messages.length} Alert(s)</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Characters Quota */}
        <QuotaItem
          label="Characters"
          used={data.charactersUsed}
          remaining={data.charactersRemaining}
          limit={data.charactersLimit}
          percentUsed={data.charactersPercentUsed}
          warning={alerts.charactersWarning}
          critical={alerts.charactersCritical}
          unit=""
        />

        {/* Minutes Quota */}
        <QuotaItem
          label="Voice Minutes"
          used={data.minutesUsed}
          remaining={data.minutesRemaining}
          limit={data.minutesLimit}
          percentUsed={data.minutesPercentUsed}
          warning={alerts.minutesWarning}
          critical={alerts.minutesCritical}
          unit="mins"
          decimals={2}
        />

        {/* Enhancements Quota */}
        <QuotaItem
          label="AI Enhancements"
          used={data.enhancementsUsed}
          remaining={data.enhancementsRemaining}
          limit={data.enhancementsLimit}
          percentUsed={data.enhancementsPercentUsed}
          warning={alerts.enhancementsWarning}
          critical={alerts.enhancementsCritical}
          unit=""
        />

        {/* Auto-generate Quota */}
        <QuotaItem
          label="Auto-generate"
          used={data.autoGenerateUsed}
          remaining={data.autoGenerateRemaining}
          limit={data.autoGenerateLimit}
          percentUsed={data.autoGeneratePercentUsed}
          warning={alerts.autoGenerateWarning}
          critical={alerts.autoGenerateCritical}
          unit=""
        />
      </div>

      {/* Alert Messages */}
      {alerts.messages.length > 0 && (
        <div className="mt-4 space-y-2">
          {alerts.messages.map((message, index) => (
            <div
              key={index}
              className="flex items-start gap-2 p-3 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800"
            >
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-amber-800 dark:text-amber-200">{message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ============================================================================
// Plan Details Card
// ============================================================================
type PlanDetailsCardProps = {
  data: PlanDetails;
  loading?: boolean;
};

const PlanDetailsCardComponent: React.FC<PlanDetailsCardProps> = ({
  data,
  loading,
}) => {
  if (loading) {
    return (
      <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-5 animate-pulse">
        <div className="h-4 w-32 bg-slate-200 dark:bg-slate-700 rounded" />
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return "—";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  return (
    <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Current Plan
            </p>
            <p className="text-lg font-bold text-slate-900 dark:text-white">
              {data.planName || "—"}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-6 text-sm">
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Billing Cycle
            </p>
            <p className="font-medium text-slate-700 dark:text-slate-200">
              {formatDate(data.cycleStartDate)} — {formatDate(data.cycleEndDate)}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Days Remaining
            </p>
            <p className="font-medium text-slate-700 dark:text-slate-200">
              {data.daysRemaining} days
            </p>
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Max File Duration
            </p>
            <p className="font-medium text-slate-700 dark:text-slate-200">
              {data.maxFileMinutes} minutes
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// Date Filter Component
// ============================================================================
type DateFilterProps = {
  value: DateFilterType;
  onChange: (value: DateFilterType) => void;
  className?: string;
};

const DateFilter: React.FC<DateFilterProps> = ({
  value,
  onChange,
  className = "",
}) => {
  const options: { value: DateFilterType; label: string }[] = [
    { value: "daily", label: "Daily" },
    { value: "weekly", label: "Weekly" },
    { value: "monthly", label: "Monthly" },
  ];

  return (
    <div className={`inline-flex rounded-xl bg-slate-100 dark:bg-white/10 p-1 ${className}`}>
      {options.map((option) => (
        <button
          key={option.value}
          onClick={() => onChange(option.value)}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all ${
            value === option.value
              ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          }`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
};

// ============================================================================
// Usage Breakdown Grid
// ============================================================================
type UsageBreakdownGridProps = {
  items: PageUsageItem[];
  totalPages: number;
  currentPage: number;
  loading?: boolean;
  onPageChange: (page: number) => void;
  onSort: (sortBy: string, descending: boolean) => void;
};

const UsageBreakdownGrid: React.FC<UsageBreakdownGridProps> = ({
  items,
  totalPages,
  currentPage,
  loading,
  onPageChange,
  onSort,
}) => {
  const [sortField, setSortField] = React.useState<string>("minutesConsumed");
  const [sortDesc, setSortDesc] = React.useState<boolean>(true);

  const handleSort = (field: string) => {
    const newDesc = field === sortField ? !sortDesc : true;
    setSortField(field);
    setSortDesc(newDesc);
    onSort(field, newDesc);
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return "—";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const SortableHeader: React.FC<{ field: string; children: React.ReactNode }> = ({
    field,
    children,
  }) => (
    <th
      onClick={() => handleSort(field)}
      className="px-4 py-3 text-left text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 cursor-pointer hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
    >
      <div className="flex items-center gap-1">
        {children}
        <ArrowUpDown className={`w-3 h-3 ${sortField === field ? "opacity-100" : "opacity-40"}`} />
      </div>
    </th>
  );

  if (loading) {
    return (
      <div className="glass studio-card !p-6 animate-pulse">
        <div className="h-4 w-40 bg-slate-200 dark:bg-slate-700 rounded mb-4" />
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-12 bg-slate-200 dark:bg-slate-700 rounded" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="glass studio-card !p-6">
      <h2 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-4">
        Usage Breakdown
      </h2>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-black/5 dark:border-white/10">
              <th className="px-4 py-3 text-left text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Feature
              </th>
              <SortableHeader field="charactersProcessed">Characters</SortableHeader>
              <SortableHeader field="minutesConsumed">Minutes</SortableHeader>
              <SortableHeader field="requestCount">Requests</SortableHeader>
              <SortableHeader field="lastUsed">Last Used</SortableHeader>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-sm text-slate-500 dark:text-slate-400">
                  No usage data found for the selected period.
                </td>
              </tr>
            ) : (
              items.map((item, index) => (
                <tr
                  key={item.pageName || index}
                  className="border-b border-black/5 dark:border-white/5 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors"
                >
                  <td className="px-4 py-4">
                    <div className="font-semibold text-slate-900 dark:text-white">
                      {item.displayName}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {item.pageName}
                    </div>
                  </td>
                  <td className="px-4 py-4 font-medium text-slate-700 dark:text-slate-200">
                    {item.charactersProcessed.toLocaleString()}
                  </td>
                  <td className="px-4 py-4 font-medium text-slate-700 dark:text-slate-200">
                    {item.minutesConsumed.toFixed(2)}
                  </td>
                  <td className="px-4 py-4 font-medium text-slate-700 dark:text-slate-200">
                    {item.requestCount.toLocaleString()}
                  </td>
                  <td className="px-4 py-4 text-sm text-slate-500 dark:text-slate-400">
                    {formatDate(item.lastUsed)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-black/5 dark:border-white/10">
          <div className="text-sm text-slate-500 dark:text-slate-400">
            Page {currentPage} of {totalPages}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// Main Usage Page Component
// ============================================================================
const UsagePageV2: React.FC = () => {
  const { token } = useAuth();
  const {
    detailedUsage,
    breakdown,
    loading,
    breakdownLoading,
    error,
    dateFilter,
    setDateFilter,
    loadBreakdownPage,
    sortBreakdown,
    refresh,
  } = useUsagePage(token);

  // Default empty data for when no response yet
  const emptyTotalUsage: TotalUsageCard = {
    totalCharactersProcessed: 0,
    totalVoiceMinutes: 0,
    totalEnhancements: 0,
    totalRequests: 0,
  };

  const emptyQuota: QuotaCard = {
    charactersUsed: 0,
    charactersRemaining: 0,
    charactersLimit: 0,
    charactersPercentUsed: 0,
    minutesUsed: 0,
    minutesRemaining: 0,
    minutesLimit: 0,
    minutesPercentUsed: 0,
    enhancementsUsed: 0,
    enhancementsRemaining: 0,
    enhancementsLimit: 0,
    enhancementsPercentUsed: 0,
    autoGenerateUsed: 0,
    autoGenerateRemaining: 0,
    autoGenerateLimit: 0,
    autoGeneratePercentUsed: 0,
  };

  const emptyPlan: PlanDetails = {
    planId: "",
    planName: "—",
    allocatedCharacters: 0,
    allocatedMinutes: 0,
    allocatedEnhancements: 0,
    allocatedAutoGenerate: 0,
    maxFileMinutes: 0,
    concurrentJobsLimit: 0,
    cycleStartDate: "",
    cycleEndDate: "",
    daysRemaining: 0,
  };

  const emptyAlerts: UsageAlerts = {
    minutesWarning: false,
    minutesCritical: false,
    charactersWarning: false,
    charactersCritical: false,
    enhancementsWarning: false,
    enhancementsCritical: false,
    autoGenerateWarning: false,
    autoGenerateCritical: false,
    messages: [],
  };

  const totalUsage = detailedUsage?.totalUsage ?? emptyTotalUsage;
  const quota = detailedUsage?.remainingQuota ?? emptyQuota;
  const plan = detailedUsage?.planDetails ?? emptyPlan;
  const alerts = detailedUsage?.alerts ?? emptyAlerts;

  return (
    <div className="max-w-6xl space-y-6">
      {/* Header */}
      <section className="glass studio-card !p-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              Usage Dashboard
            </h1>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 font-medium">
              Track your character processing, voice generation, and AI enhancements.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <DateFilter value={dateFilter} onChange={setDateFilter} />
            <button
              onClick={refresh}
              className="p-3 rounded-xl bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 transition-colors"
              title="Refresh data"
            >
              <RefreshCw className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            </button>
            <Link
              to="/billing"
              className="px-4 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm"
            >
              Upgrade Plan
            </Link>
          </div>
        </div>
      </section>

      {/* Error State */}
      {error && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800">
          <p className="text-sm text-red-800 dark:text-red-200">{error}</p>
        </div>
      )}

      {/* Plan Details */}
      <PlanDetailsCardComponent data={plan} loading={loading} />

      {/* Total Usage Card */}
      <TotalUsageCardComponent data={totalUsage} loading={loading} />

      {/* Quota Card */}
      <QuotaCardComponent data={quota} alerts={alerts} loading={loading} />

      {/* Usage Breakdown Grid */}
      <UsageBreakdownGrid
        items={breakdown?.items ?? []}
        totalPages={breakdown?.totalPages ?? 1}
        currentPage={breakdown?.currentPage ?? 1}
        loading={breakdownLoading}
        onPageChange={loadBreakdownPage}
        onSort={sortBreakdown}
      />
    </div>
  );
};

export default UsagePageV2;
