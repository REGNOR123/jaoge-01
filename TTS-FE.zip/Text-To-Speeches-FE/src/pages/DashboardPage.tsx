import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { SpeechIcon, UsersIcon } from "lucide-react";

const HERO_AUTO_ROTATE_MS = 5000;

type HeroSlide = {
  id: string;
  titleGradient: string;
  titleRest: string;
  subtitleGradient: string;
  subtitleRest: string;
};

const HERO_SLIDES: HeroSlide[] = [
  {
    id: "fomo-intro",
    titleGradient: "Don't miss out",
    titleRest: "— become the creator you were meant to be",
    subtitleGradient: "All-in-one AI studio supporting 37 languages",
    subtitleRest: "— 22 global and 15 Indian & SE Asian regional — for voice, transcription, and translation.",
  },
  {
    id: "voices",
    titleGradient: "Bring your words to life",
    titleRest: "with high-quality, human-like AI voices",
    subtitleGradient: "22 global + 15 regional languages supported",
    subtitleRest: "— dedicated neural voices for every Indian & SE Asian language.",
  },
  {
    id: "transcribe",
    titleGradient: "Turn audio into clear text",
    titleRest: "for meetings, podcasts, and interviews",
    subtitleGradient: "Accurate transcripts in 8 languages",
    subtitleRest: "— including Hindi — ready for editing, sharing, and export.",
  },
  {
    id: "translate",
    titleGradient: "Scale your voice globally",
    titleRest: "with multilingual translation and dubbing",
    subtitleGradient: "Translate & dub into 22 global and 15 regional languages",
    subtitleRest: "— keeping tone, clarity, and impact across every audience.",
  },
  {
    id: "speech-translate",
    titleGradient: "Speak once, reach everyone",
    titleRest: "— convert your speech to any language",
    subtitleGradient: "Real-time speech translation into 22 global + 15 regional languages",
    subtitleRest: "— authentic voice output in every Indian & SE Asian language.",
  },
  {
    id: "global-reach",
    titleGradient: "Go viral, go global",
    titleRest: "— content that speaks every language",
    subtitleGradient: "Create once, publish in 37 languages",
    subtitleRest: "— 22 global and 15 regional Indian & SE Asian languages supported.",
  },
];

const DashboardPage: React.FC = () => {
  const { user } = useAuth();

  const [currentHeroSlide, setCurrentHeroSlide] = useState(0);
  const [showWelcomeMessage, setShowWelcomeMessage] = useState(true);

  const userName = useMemo(() => {
    const name = user?.fullName?.trim();
    if (name) return name;
    return user?.email?.split("@")?.[0] || "there";
  }, [user?.email, user?.fullName]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setCurrentHeroSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, HERO_AUTO_ROTATE_MS);

    return () => {
      window.clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    setShowWelcomeMessage(true);
    const timer = window.setTimeout(() => {
      setShowWelcomeMessage(false);
    }, 5000);

    return () => {
      window.clearTimeout(timer);
    };
  }, [userName]);

  return (
    <div className="relative space-y-6 md:space-y-7">
      {showWelcomeMessage && (
        <div className="fixed right-5 top-24 z-40">
          <div className="rounded-lg border border-slate-200 bg-white/95 px-3 py-2 shadow-sm backdrop-blur">
            <p className="text-[11px] font-semibold text-slate-700">Welcome back, {userName}</p>
          </div>
        </div>
      )}

      <section className="overflow-hidden py-2">
        <div className="relative max-w-5xl min-h-[165px] sm:min-h-[190px] lg:min-h-[210px]">
          {HERO_SLIDES.map((slide, index) => {
            const isActive = index === currentHeroSlide;

            return (
              <div
                key={slide.id}
                className={[
                  "absolute inset-0 transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]",
                  isActive
                    ? "opacity-100 translate-y-0 scale-100"
                    : "opacity-0 translate-y-4 scale-[0.98] pointer-events-none",
                ].join(" ")}
                style={{
                  transitionDelay: isActive ? "0ms" : "0ms",
                }}
              >
                <h1 className="text-[26px] font-black leading-[1.08] tracking-[-0.02em] text-slate-900 dark:text-white sm:text-[34px] lg:text-[44px]">
                  <span className="bg-gradient-to-r from-violet-600 via-fuchsia-500 to-cyan-500 bg-clip-text text-transparent">
                    {slide.titleGradient}
                  </span>{" "}
                  {slide.titleRest}
                </h1>
                <p className="mt-3 max-w-4xl text-[16px] font-semibold leading-[1.3] text-slate-600 dark:text-slate-400 sm:text-[22px] lg:text-[28px]">
                  <span className="bg-gradient-to-r from-blue-600 via-cyan-500 to-teal-500 bg-clip-text text-transparent">
                    {slide.subtitleGradient}
                  </span>{" "}
                  {slide.subtitleRest}
                </p>
              </div>
            );
          })}
        </div>

        {/* Slide indicators */}
        <div className="flex items-center gap-2 mt-6">
          {HERO_SLIDES.map((slide, index) => (
            <button
              key={slide.id}
              onClick={() => setCurrentHeroSlide(index)}
              className={[
                "h-1.5 rounded-full transition-all duration-300",
                index === currentHeroSlide
                  ? "w-8 bg-gradient-to-r from-violet-600 to-fuchsia-500"
                  : "w-1.5 bg-slate-300 dark:bg-slate-600 hover:bg-slate-400 dark:hover:bg-slate-500",
              ].join(" ")}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-black tracking-tight text-slate-900 dark:text-white">Studio Actions</h3>
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <WorkflowCard
            title="Create AI Voice"
            description="Turn text into natural, studio-quality speech."
            to="/create-voice"
            icon={<MicIcon />}
            langSupport={{ global: 22, regional: 15 }}
          />
          <WorkflowCard
            title="Transcribe Audio"
            description="Convert speech into accurate, editable text."
            to="/transcribe"
            icon={<WaveIcon />}
            langSupport={{ global: 8, regional: 1 }}
          />
          <WorkflowCard
            title="Translate & Dub"
            description="Translate content and generate voice in any language."
            to="/translate-dub"
            icon={<GlobeIcon />}
            langSupport={{ global: 22, regional: 15 }}
          />
            <WorkflowCard
            title="Speech Translation"
            description="Translate audio across languages while preserving the original voice."
            to="/speech-translate"
            icon={<SpeechIcon />}
            langSupport={{ global: 22, regional: 15 }}
          />
          <WorkflowCard
            title="AI Script Studio"
            description="Generate scripts for videos, podcasts, and more."
            to="/script-studio"
            icon={<DocIcon />}
            langSupport={{ aiPowered: true }}
          />
          <WorkflowCard
            title="Voice Clone"
            description="Clone your voice and synthesize speech that sounds like you."
            to="/voice-clone"
            icon={<CloneIcon />}
            comingSoon
          />
        </div>
      </section>

    </div>
  );
};

export default DashboardPage;

const WorkflowCard = ({
  title,
  description,
  to,
  icon,
  comingSoon,
  langSupport,
}: {
  title: string;
  description: string;
  to: string;
  icon: React.ReactNode;
  comingSoon?: boolean;
  langSupport?: { global: number; regional: number } | { aiPowered: true };
}) => {
  const cardContent = (
    <>
      {comingSoon && (
        <span className="absolute top-3 right-3 rounded-full bg-amber-100 dark:bg-amber-900/40 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
          Coming Soon
        </span>
      )}
      <div className={`flex h-10 w-10 items-center justify-center rounded-full bg-[#F1EAFF] dark:bg-indigo-500/20 text-[#6F2CFF] dark:text-indigo-400 ${comingSoon ? "opacity-50" : ""}`}>
        {icon}
      </div>
      <div className="mt-4">
        <h4 className={`text-lg font-black tracking-tight text-slate-900 dark:text-white ${comingSoon ? "opacity-50" : ""}`}>{title}</h4>
        <p className={`mt-1.5 text-xs font-medium leading-relaxed text-slate-600 dark:text-slate-400 sm:text-sm ${comingSoon ? "opacity-50" : ""}`}>{description}</p>
      </div>
      {langSupport && (
        <div className={`mt-3 flex flex-wrap items-center gap-1.5 ${comingSoon ? "opacity-50" : ""}`}>
          {"aiPowered" in langSupport ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-violet-50 dark:bg-violet-500/10 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-violet-600 dark:text-violet-400">
              ✦ AI-powered · Any language
            </span>
          ) : (
            <>
              <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 dark:bg-white/10 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                🌐 {langSupport.global} global
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 dark:bg-amber-500/10 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-amber-600 dark:text-amber-400">
                🌏 {langSupport.regional} regional
              </span>
            </>
          )}
        </div>
      )}
    </>
  );

  if (comingSoon) {
    return (
      <div
        className="group relative overflow-hidden rounded-2xl border border-[#EDECF7] dark:border-white/10 bg-white dark:bg-slate-800/60 p-5 sm:p-6 shadow-[0_4px_18px_rgba(0,0,0,0.06)] dark:shadow-none cursor-not-allowed select-none"
      >
        {cardContent}
      </div>
    );
  }

  return (
    <Link
      to={to}
      className={[
        "group relative overflow-hidden rounded-2xl border border-[#EDECF7] dark:border-white/10 bg-white dark:bg-slate-800/60 p-5 sm:p-6",
        "shadow-[0_4px_18px_rgba(0,0,0,0.06)] dark:shadow-none transition-all duration-200 hover:-translate-y-1 hover:border-[#D7C7FF] dark:hover:border-indigo-500/50 hover:shadow-[0_18px_28px_rgba(111,44,255,0.16)] dark:hover:shadow-[0_18px_28px_rgba(111,44,255,0.12)]",
      ].join(" ")}
    >
      {cardContent}
    </Link>
  );
};

const MicIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 1a4 4 0 014 4v7a4 4 0 11-8 0V5a4 4 0 014-4zm6 11a6 6 0 01-12 0M12 19v4m-4 0h8"
    />
  </svg>
);

const WaveIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M4 12h2m2 0h2m2 0h2m2 0h2m2 0h2"
    />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 8v8M10 6v12M14 8v8M18 10v4" />
  </svg>
);

const GlobeIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.6 9h16.8M3.6 15h16.8" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3a15 15 0 010 18" />
  </svg>
);

const DocIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 12h6m-6 4h6m-7 4h8a2 2 0 002-2V6a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"
    />
  </svg>
);

const CloneIcon = () => (
  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 1a4 4 0 014 4v7a4 4 0 11-8 0V5a4 4 0 014-4zm6 11a6 6 0 01-12 0" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 19h14M12 15v4" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 19c0 1.1.9 2 2 2h4a2 2 0 002-2" />
  </svg>
);
