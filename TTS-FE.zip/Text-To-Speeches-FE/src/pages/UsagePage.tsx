import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { usePlanSummary } from "../hooks/usePlanSummary";
import { summarizeUsage } from "../utils/usageEvents";

const UsagePage: React.FC = () => {
  const { token } = useAuth();
  const { planSummary, loading, tier, defaultLimits } = usePlanSummary(token);

  const usage = useMemo(() => summarizeUsage(), []);

  const voiceTotal = useMemo(() => {
    if (typeof planSummary?.minutesRemaining === "number") {
      return Math.max(0, usage.voiceMinutesUsed + planSummary.minutesRemaining);
    }
    return defaultLimits.voiceMinutesTotal;
  }, [defaultLimits.voiceMinutesTotal, planSummary?.minutesRemaining, usage.voiceMinutesUsed]);

  const sttTotal = defaultLimits.sttMinutesTotal;
  const translationTotal = defaultLimits.translationCharsTotal;

  return (
    <div className="max-w-3xl">
      <div className="glass studio-card !p-8">
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Usage
        </h1>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 font-medium">
          Voice, transcription, and translation usage for your workspace.
        </p>

        <div className="mt-8 rounded-2xl border border-black/5 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-5">
          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium">
            Usage reporting isn’t wired yet. Once backend usage data is available, this page can show minutes/characters consumed per feature.
          </p>
        </div>

        <div className="mt-8 flex gap-3">
          <Link
            to="/billing"
            className="px-4 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm"
          >
            View Billing
          </Link>
        </div>
      </div>
    </div>
  );
};

export default UsagePage;
