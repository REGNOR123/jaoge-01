import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useSpeechSynthesis } from '../hooks/useSpeechSynthesis';
import HistoryItem from '../components/HistoryItem';

const AudioLibraryPage: React.FC = () => {
  const {
    historySearch,
    setHistorySearch,
    filteredHistory,
    handleDeleteHistoryItem,
    audioRef,
  } = useSpeechSynthesis();

  const [playingId, setPlayingId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  // Setup audio event listeners
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleLoadedMetadata = () => setDuration(audio.duration);
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
    };
  }, [audioRef]);

  const handlePlayClick = (entry: any) => {
    const audio = audioRef.current;
    if (!audio) return;

    if (playingId === entry.id && isPlaying) {
      // If already playing this track, pause it
      audio.pause();
      return;
    }

    // Load new track
    audio.src = entry.audioUrl;
    audio.load();
    setPlayingId(entry.id);
    setCurrentTime(0);
    setDuration(0);

    // Play after a short delay to ensure load
    setTimeout(() => {
      audio.play().catch((err) => console.error('Play error:', err));
    }, 100);
  };

  const handleSeek = (time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const handleTogglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <audio
        ref={audioRef}
        className="hidden"
        crossOrigin="anonymous"
        onError={(e) => console.error('Audio playback error:', (e.target as HTMLAudioElement).error?.message)}
      />
      <nav className="px-8 py-6 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-[1200px] mx-auto">
          <div className="flex items-center justify-between mb-4">
            <Link to="/" className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
              <h1 className="text-lg font-black tracking-tighter text-slate-900 dark:text-white uppercase leading-none">
                TextTo<span className="text-indigo-500">Speeches</span>
              </h1>
            </Link>
            <Link to="/" className="text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:text-indigo-500 transition-colors flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back
            </Link>
          </div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-slate-400 flex items-center gap-2">
            <Link to="/" className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              Home
            </Link>
            <span className="text-slate-400 dark:text-slate-600">›</span>
            <span className="text-slate-900 dark:text-white">Audio Library</span>
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-4xl mx-auto w-full px-8 py-16">
        <div className="mb-12">
          <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
            Audio Library
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-400 font-medium">
            Manage and organize all your generated speech recordings
          </p>
        </div>

        <div className="glass studio-card !p-8 space-y-6">
          {/* Search Bar */}
          <div>
            <input
              type="text"
              placeholder="Search saved audio..."
              value={historySearch}
              onChange={(e) => setHistorySearch(e.target.value)}
              className="w-full bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10 rounded-xl py-4 px-6 text-sm font-medium placeholder-slate-400 dark:placeholder-slate-600 focus:border-indigo-500 dark:focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white"
            />
          </div>

          {/* Audio Items */}
          <div className="space-y-4">
            {filteredHistory.length > 0 ? (
              <div className="space-y-4 max-h-[70vh] overflow-y-auto">
                {filteredHistory.map((entry) => (
                  <HistoryItem
                    key={entry.id}
                    entry={entry}
                    onDelete={() => handleDeleteHistoryItem(entry.id)}
                    onPlay={() => handlePlayClick(entry)}
                    isPlaying={playingId === entry.id && isPlaying}
                    currentTime={playingId === entry.id ? currentTime : 0}
                    duration={playingId === entry.id ? duration : 0}
                    audioRef={audioRef}
                    onSeek={handleSeek}
                    onTogglePlay={handleTogglePlay}
                  />
                ))}
              </div>
            ) : (
              <div className="py-16 px-8 text-center">
                <div className="w-16 h-16 rounded-full bg-slate-200 dark:bg-white/10 flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m0 0h6m-6-6H6" />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                  No audio recordings yet
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Generate and save audio clips from the main app to see them here
                </p>
              </div>
            )}
          </div>

          {filteredHistory.length > 0 && (
            <div className="text-xs text-slate-500 dark:text-slate-500 text-center pt-4 border-t border-slate-200 dark:border-white/10">
              {filteredHistory.length} recording{filteredHistory.length !== 1 ? 's' : ''}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default AudioLibraryPage;
