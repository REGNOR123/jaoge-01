import React, { useMemo, useState, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Check, Sparkles, ArrowRight, ArrowLeft, Loader2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { createOrder, verifyPayment } from "../services/paymentApiService";

declare global {
  interface Window {
    Razorpay: any;
  }
}

type BillingCycle = "monthly" | "yearly";

type Plan = {
  id: string;
  name: string;
  priceMonthly: string;
  priceYearly: string;
  badge?: string;
  isPopular?: boolean;
  cta: string;
  features: string[];
  purchasable: boolean;
};

const plans: Plan[] = [
  {
    id: "free-starter",
    name: "Free Starter",
    priceMonthly: "Free",
    priceYearly: "Free",
    cta: "Get Started",
    purchasable: false,
    features: [
      "5,000 Characters",
      "15 Voice Minutes",
      "25 AI Enhancements",
      "25 Auto-generate",
    ],
  },
  {
    id: "creator",
    name: "Creator Plan",
    priceMonthly: "₹199/month",
    priceYearly: "₹1,990/year",
    cta: "Choose Plan",
    purchasable: true,
    features: [
      "50,000 Characters",
      "120 Voice Minutes",
      "300 AI Enhancements",
      "300 Auto-generate",
    ],
  },
  {
    id: "pro",
    name: "Pro Plan",
    priceMonthly: "₹499/month",
    priceYearly: "₹4,990/year",
    badge: "🔥 Most Popular",
    isPopular: true,
    cta: "Upgrade to Pro",
    purchasable: true,
    features: [
      "300,000 Characters",
      "600 Voice Minutes",
      "2,000 AI Enhancements",
      "2,000 Auto-generate",
    ],
  },
  {
    id: "business",
    name: "Business Plan",
    priceMonthly: "₹1,299/month",
    priceYearly: "₹12,990/year",
    cta: "Choose Plan",
    purchasable: true,
    features: [
      "1,500,000 Characters",
      "3,000 Voice Minutes",
      "12,000 AI Enhancements",
      "12,000 Auto-generate",
    ],
  },
  {
    id: "enterprise",
    name: "Enterprise Plan",
    priceMonthly: "Custom",
    priceYearly: "Custom",
    cta: "Contact Sales",
    purchasable: false,
    features: ["Custom limits", "API access", "Priority support"],
  },
];

const faq = [
  {
    q: "What happens if I exceed limits?",
    a: "You can continue by upgrading your plan. We'll notify you before you reach limits.",
  },
  {
    q: "Can I upgrade anytime?",
    a: "Yes. You can upgrade at any time from your billing dashboard without service interruption.",
  },
  {
    q: "Do unused credits roll over?",
    a: "Unused monthly credits do not roll over unless your custom enterprise contract includes rollover.",
  },
  {
    q: "Can I switch between monthly and yearly?",
    a: "Yes, you can switch billing cycle anytime. Changes apply from your next billing period.",
  },
];

const loadRazorpayScript = (): Promise<boolean> => {
  return new Promise((resolve) => {
    if (window.Razorpay) {
      resolve(true);
      return;
    }
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
};

const PricingPage: React.FC = () => {
  const [cycle, setCycle] = useState<BillingCycle>("monthly");
  const [loadingPlanId, setLoadingPlanId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { token, user } = useAuth();
  const navigate = useNavigate();

  const comparisonRows = useMemo(
    () => [
      { label: "Characters", values: ["5,000", "50,000", "300,000", "1,500,000", "Custom"] },
      { label: "Voice Minutes", values: ["15", "120", "600", "3,000", "Custom"] },
      { label: "AI Enhancements", values: ["25", "300", "2,000", "12,000", "Custom"] },
      { label: "Auto-generate", values: ["25", "300", "2,000", "12,000", "Custom"] },
    ],
    [],
  );

  const handlePlanSelect = useCallback(async (plan: Plan) => {
    setError(null);

    if (!plan.purchasable) {
      if (plan.id === "free-starter") {
        navigate("/");
        return;
      }
      if (plan.id === "enterprise") {
        window.location.href = "mailto:support@fomocreator.com?subject=Enterprise Plan Inquiry";
        return;
      }
      return;
    }

    if (!token) {
      navigate("/login", { state: { from: "/pricing", planId: plan.id } });
      return;
    }

    setLoadingPlanId(plan.id);

    try {
      const scriptLoaded = await loadRazorpayScript();
      if (!scriptLoaded) {
        setError("Failed to load payment gateway. Please refresh and try again.");
        setLoadingPlanId(null);
        return;
      }

      const orderResult = await createOrder(token, plan.id);
      if (!orderResult.success) {
        setError(orderResult.error);
        setLoadingPlanId(null);
        return;
      }

      const { orderId, amount, currency, keyId } = orderResult.data;

      const options = {
        key: keyId,
        amount: amount,
        currency: currency,
        order_id: orderId,
        name: "Text To Speeches",
        description: `${plan.name} - Monthly Subscription`,
        prefill: {
          email: user?.email || "",
          name: user?.name || "",
        },
        theme: {
          color: "#4f46e5",
        },
        handler: async (response: {
          razorpay_order_id: string;
          razorpay_payment_id: string;
          razorpay_signature: string;
        }) => {
          const verifyResult = await verifyPayment(token, {
            razorpay_order_id: response.razorpay_order_id,
            razorpay_payment_id: response.razorpay_payment_id,
            razorpay_signature: response.razorpay_signature,
          });

          if (!verifyResult.success) {
            setError(verifyResult.error);
            setLoadingPlanId(null);
            return;
          }

          setLoadingPlanId(null);
          navigate("/billing", { 
            state: { 
              paymentSuccess: true, 
              planName: plan.name 
            } 
          });
        },
        modal: {
          ondismiss: () => {
            setLoadingPlanId(null);
          },
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.on("payment.failed", (response: any) => {
        setError(response.error?.description || "Payment failed. Please try again.");
        setLoadingPlanId(null);
      });
      rzp.open();
    } catch (err) {
      console.error("Payment error:", err);
      setError("An unexpected error occurred. Please try again.");
      setLoadingPlanId(null);
    }
  }, [token, user, navigate]);

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950">
      <main className="max-w-7xl mx-auto px-6 py-12 md:py-16 space-y-10">
        <section className="glass studio-card !p-8 text-center">
          <h1 className="text-3xl md:text-4xl font-black tracking-tight text-slate-900 dark:text-white">
            Simple, Transparent Pricing
          </h1>
          <p className="mt-3 text-sm md:text-base font-medium text-slate-500 dark:text-slate-400">
            Choose a plan that fits your needs. Upgrade anytime.
          </p>

          <div className="mt-6 inline-flex rounded-2xl p-1.5 bg-slate-100 dark:bg-white/10 border border-slate-200 dark:border-white/10">
            <button
              type="button"
              onClick={() => setCycle("monthly")}
              className={[
                "px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-colors",
                cycle === "monthly"
                  ? "bg-indigo-600 text-white"
                  : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-white/10",
              ].join(" ")}
            >
              Monthly
            </button>
            <button
              type="button"
              onClick={() => setCycle("yearly")}
              className={[
                "px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-colors",
                cycle === "yearly"
                  ? "bg-indigo-600 text-white"
                  : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-white/10",
              ].join(" ")}
            >
              Yearly
            </button>
          </div>

          {error && (
            <div className="mt-4 p-3 rounded-xl bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 text-sm">
              {error}
            </div>
          )}
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-5">
          {plans.map((plan) => (
            <article
              key={plan.id}
              className={[
                "rounded-3xl border bg-white/80 dark:bg-white/5 backdrop-blur-sm p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl",
                plan.isPopular
                  ? "border-indigo-400 dark:border-indigo-500 shadow-lg shadow-indigo-500/20 scale-[1.02]"
                  : "border-black/5 dark:border-white/10",
              ].join(" ")}
            >
              <div className="flex items-start justify-between gap-2 min-h-[42px]">
                <h2 className="text-lg font-black tracking-tight text-slate-900 dark:text-white">
                  {plan.name}
                </h2>
                {plan.badge && (
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wide bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300">
                    {plan.badge}
                  </span>
                )}
              </div>

              <div className="mt-5 flex flex-wrap items-end gap-2">
                <p className="text-3xl font-black text-slate-900 dark:text-white break-words leading-tight">
                  {cycle === "monthly" ? plan.priceMonthly : plan.priceYearly}
                </p>
                {plan.id !== "free-starter" && plan.id !== "enterprise" && cycle === "yearly" && (
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 whitespace-normal break-words">
                    Save more
                  </span>
                )}
              </div>

              <ul className="mt-5 space-y-2.5">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2.5 text-sm text-slate-600 dark:text-slate-300">
                    <Check className="w-4 h-4 mt-0.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                type="button"
                onClick={() => handlePlanSelect(plan)}
                disabled={loadingPlanId !== null}
                className={[
                  "mt-6 w-full px-4 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-colors inline-flex items-center justify-center gap-2",
                  plan.isPopular
                    ? "bg-indigo-600 hover:bg-indigo-700 text-white disabled:opacity-50"
                    : "bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 dark:bg-white/10 dark:hover:bg-white/20 dark:text-slate-100 dark:border-white/10 disabled:opacity-50",
                ].join(" ")}
              >
                {loadingPlanId === plan.id ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  plan.cta
                )}
              </button>
            </article>
          ))}
        </section>

        <section className="glass studio-card !p-6">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-4">
            Feature Comparison
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px]">
              <thead>
                <tr className="border-b border-slate-200 dark:border-white/10">
                  <th className="text-left px-4 py-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    Feature
                  </th>
                  {["Free", "Creator", "Pro", "Business", "Enterprise"].map((h) => (
                    <th key={h} className="text-left px-4 py-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {comparisonRows.map((row) => (
                  <tr key={row.label} className="border-b border-slate-200/70 dark:border-white/10">
                    <td className="px-4 py-3 text-sm font-semibold text-slate-800 dark:text-slate-200">{row.label}</td>
                    {row.values.map((v, i) => (
                      <td key={`${row.label}-${i}`} className="px-4 py-3 text-sm text-slate-600 dark:text-slate-300">
                        {v}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="glass studio-card !p-6">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-4">
            FAQ
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {faq.map((item) => (
              <div key={item.q} className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5">
                <p className="text-sm font-bold text-slate-900 dark:text-white">{item.q}</p>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{item.a}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="glass studio-card !p-8 text-center">
          <div className="mx-auto inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="mt-4 text-2xl font-black tracking-tight text-slate-900 dark:text-white">
            Start for free today
          </h3>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            No credit card required. Upgrade as your usage grows.
          </p>
          <div className="mt-6 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => navigate("/")}
              className="px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest transition-colors inline-flex items-center gap-2"
            >
              Get Started <ArrowRight className="w-4 h-4" />
            </button>
            <Link
              to="/billing"
              className="px-6 py-3 rounded-2xl border border-slate-200 dark:border-white/10 bg-white/80 dark:bg-white/10 hover:bg-slate-50 dark:hover:bg-white/20 text-xs font-black uppercase tracking-widest text-slate-700 dark:text-slate-200 transition-colors"
            >
              Compare in Billing
            </Link>
          </div>
        </section>
      </main>

      {cycle === "yearly" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/35 dark:bg-black/55 backdrop-blur-md">
          <div className="glass studio-card !p-8 w-full max-w-lg text-center">
            <h2 className="text-3xl font-black tracking-tight text-slate-900 dark:text-white">
              Coming Soon
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              Yearly plans will be available soon. Please continue with monthly plans for now.
            </p>
            <button
              type="button"
              onClick={() => setCycle("monthly")}
              className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PricingPage;
