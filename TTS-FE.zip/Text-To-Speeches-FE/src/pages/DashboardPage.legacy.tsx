import React, { useEffect, useMemo, useState } from "react";

import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [accountDeletedNotice, setAccountDeletedNotice] = useState("");
  const [subscriptionNotice, setSubscriptionNotice] = useState("");

  const greeting = useMemo(() => {
    const name = user?.fullName?.trim();
    if (!name) return "Welcome back";
    const hour = new Date().getHours();
    const timeGreeting =
      hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
    return `${timeGreeting}, ${name}`;
  }, [user?.fullName]);

  useEffect(() => {
    const notice = sessionStorage.getItem("account_deleted_notice");
    if (notice) {
      setAccountDeletedNotice(notice);
      sessionStorage.removeItem("account_deleted_notice");
    }
  }, []);

  useEffect(() => {
    const notice = sessionStorage.getItem("subscription_notice");
    if (notice) {
      setSubscriptionNotice(notice);
      sessionStorage.removeItem("subscription_notice");
    }
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
            {greeting}
          </h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 font-medium">
            Pick a workflow to start creating.
          </p>
        </div>
      </div>

      {accountDeletedNotice && (
        <div className="rounded-xl border border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-500/10 px-4 py-3">
          <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
            {accountDeletedNotice}
          </p>
        </div>
      )}

      {subscriptionNotice && (
        <div className="rounded-xl border border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-500/10 px-4 py-3">
          <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
            {subscriptionNotice}
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <DashboardCard
          title="Create AI Voice"
          description="Generate voiceovers from text."
          to="/app/create-voice"
        />
        <DashboardCard
          title="Transcribe Audio"
          description="Turn speech into text."
          to="/app/transcribe"
        />
        <DashboardCard
          title="Translate & Dub"
          description="Translate and dub audio."
          to="/app/translate-dub"
        />
        <DashboardCard
          title="Projects"
          description="Manage your saved outputs."
          to="/app/projects"
        />
      </div>
    </div>
  );
};

export default DashboardPage;

const DashboardCard = ({
  title,
  description,
  to,
}: {
  title: string;
  description: string;
  to: string;
}) => (
  <Link
    to={to}
    className="glass studio-card !p-6 rounded-3xl hover:shadow-lg hover:shadow-indigo-600/10 transition-all group border border-black/5 dark:border-white/10"
  >
    <div className="text-base font-black text-slate-900 dark:text-white">
      {title}
    </div>
    <div className="mt-1 text-sm text-slate-500 dark:text-slate-400 font-medium">
      {description}
    </div>
    <div className="mt-4 text-[10px] font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-300">
      Open →
    </div>
  </Link>
);
