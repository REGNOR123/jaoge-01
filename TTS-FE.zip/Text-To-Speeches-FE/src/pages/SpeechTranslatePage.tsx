import React from "react";
import SpeechTranslateWizard from "../components/speechTranslate/SpeechTranslateWizard";

const SpeechTranslatePage: React.FC = () => {
  return <SpeechTranslateWizard />;
};

export default SpeechTranslatePage;

