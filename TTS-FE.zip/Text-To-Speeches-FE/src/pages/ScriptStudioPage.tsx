import React from "react";
import ScriptStudioWizard from "../components/scriptStudio/ScriptStudioWizard";

const ScriptStudioPage: React.FC = () => {
  return <ScriptStudioWizard />;
};

export default ScriptStudioPage;
