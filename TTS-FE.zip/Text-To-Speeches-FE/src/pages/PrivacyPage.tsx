import React from 'react';
import { Link } from 'react-router-dom';
import Logo from '../components/app/Logo';

const PrivacyPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <nav className="px-8 py-5 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link to="/dashboard"><Logo /></Link>
          <Link
            to="/dashboard"
            className="text-[10px] font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 transition-colors flex items-center gap-1.5"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to App
          </Link>
        </div>
      </nav>

      <main className="flex-1 max-w-3xl mx-auto w-full px-8 py-16">
        <div className="mb-12">
          <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-3">Privacy Policy</h1>
          <p className="text-sm text-slate-400 font-medium">Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
        </div>

        <div className="space-y-10 text-sm leading-relaxed text-slate-600 dark:text-slate-400">

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">1. Information We Collect</h2>
            <p className="mb-3">We collect the minimum data necessary to deliver our services. This includes:</p>
            <div className="space-y-4">
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Account Data</h3>
                <p>When you register, we collect your email address and a hashed password. We do not store plain-text passwords.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Text &amp; Script Input</h3>
                <p>Text you enter for Create AI Voice, Translate &amp; Dub, AI Script Studio, and Speech Translate is transmitted to our backend and forwarded to Microsoft Azure and/or Google Gemini to perform the requested operation. We do not permanently store raw script text beyond what is saved in your project drafts.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Audio Files</h3>
                <p>Audio files you upload (for Transcribe Audio, Speech Translate, Translate &amp; Dub, or Voice Clone) are stored on secure servers temporarily. All uploaded and generated audio files are automatically deleted after 24 hours.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Usage &amp; Credit Data</h3>
                <p>We record which features you use, the credit cost of each operation, and your credit balance. This data powers your dashboard, billing, and usage analytics.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Project Metadata</h3>
                <p>Project names, settings (voice selection, output format, language preferences), transcripts, and translated text saved to a project are stored in our database and associated with your account.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Technical Data</h3>
                <p>We may collect standard server logs including IP address, browser type, and request timestamps for security and debugging purposes. This data is not used for advertising.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">2. How We Use Your Data</h2>
            <ul className="list-disc list-inside space-y-2 ml-2">
              <li><strong className="text-slate-800 dark:text-slate-200">Speech synthesis</strong> — Text and voice settings are sent to Microsoft Azure Neural Voice to generate audio</li>
              <li><strong className="text-slate-800 dark:text-slate-200">Transcription</strong> — Uploaded audio is sent to Microsoft Azure Speech-to-Text to produce a written transcript</li>
              <li><strong className="text-slate-800 dark:text-slate-200">Translation</strong> — Text and audio content is sent to Microsoft Azure Translator and Azure Speech for speech translation and dubbing</li>
              <li><strong className="text-slate-800 dark:text-slate-200">Language detection</strong> — Script text is sent to Google Gemini to identify the language for voice matching</li>
              <li><strong className="text-slate-800 dark:text-slate-200">AI script features</strong> — Script enhance, generate, and transform operations are processed by Google Gemini</li>
              <li><strong className="text-slate-800 dark:text-slate-200">Credit tracking</strong> — Usage data is stored to maintain your credit balance and billing records</li>
              <li><strong className="text-slate-800 dark:text-slate-200">Service improvement</strong> — Aggregated, anonymised usage data may be used to improve features and performance</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">3. Data Storage &amp; Retention</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Audio Files (24-hour retention)</h3>
                <p>All audio files — both uploaded source files and generated output — are stored on our servers for a maximum of 24 hours and then automatically and permanently deleted. Download your outputs before the expiry time if you need to keep them.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Project Data</h3>
                <p>Project names, settings, and saved text (transcripts, translations, scripts) are retained in your account until you delete them or close your account.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Account Data</h3>
                <p>Your email, hashed password, subscription status, and credit history are retained for the lifetime of your account. You may request account deletion at any time by contacting support.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-1">Guest Sessions</h3>
                <p>Guest users (not logged in) have no data persisted to our servers beyond what is strictly necessary to process the immediate request. No account data or credit balance is retained after the session ends.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">4. Third-Party Services</h2>
            <p className="mb-3">The Platform relies on the following third-party providers to deliver its features. Your content may be transmitted to these services:</p>
            <div className="space-y-3">
              <div className="bg-slate-50 dark:bg-white/5 rounded-xl p-4 border border-slate-200 dark:border-white/5">
                <p className="font-black text-slate-800 dark:text-slate-200 mb-1">Microsoft Azure Cognitive Services</p>
                <p>Used for neural text-to-speech (Create AI Voice, Speech Translate, Translate &amp; Dub), speech-to-text transcription, and translation. Data is processed per Microsoft's Azure privacy policy. Regional (Indian &amp; SE Asian) and Neural HD voices use specialised Azure models.</p>
              </div>
              <div className="bg-slate-50 dark:bg-white/5 rounded-xl p-4 border border-slate-200 dark:border-white/5">
                <p className="font-black text-slate-800 dark:text-slate-200 mb-1">Google Gemini</p>
                <p>Used for language detection and AI script features (enhance, generate, transform). Text sent to Gemini is subject to Google's API data usage policy.</p>
              </div>
            </div>
            <p className="mt-3">We do not sell your data to any third party. We do not share your data with advertisers.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">5. Data Security</h2>
            <p>We use industry-standard security measures including HTTPS encryption in transit, hashed credential storage, and access-controlled server infrastructure. Audio files are stored in private, access-controlled cloud storage. Despite these measures, no internet transmission is 100% secure, and we cannot guarantee absolute security.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">6. Your Rights</h2>
            <p className="mb-3">You have the right to:</p>
            <ul className="list-disc list-inside space-y-2 ml-2">
              <li>Access the personal data we hold about you</li>
              <li>Request correction of inaccurate data</li>
              <li>Request deletion of your account and associated data</li>
              <li>Export your project data (transcripts, scripts) from the Projects page</li>
              <li>Opt out of non-essential communications</li>
            </ul>
            <p className="mt-3">To exercise any of these rights, contact us at <a href="mailto:help@texttospeeches.in" className="text-indigo-600 dark:text-indigo-400 hover:underline">help@texttospeeches.in</a>.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">7. Cookies</h2>
            <p>We use essential session cookies to keep you logged in. We do not use advertising cookies or third-party tracking pixels. Analytics, if any, are anonymised and aggregated.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">8. Children's Privacy</h2>
            <p>The Platform is not intended for use by individuals under 13 years of age. We do not knowingly collect personal data from children. If you believe a child has provided us with personal data, please contact us immediately.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">9. Changes to This Policy</h2>
            <p>We may update this Privacy Policy as our features evolve. We will notify registered users of material changes by email at least 7 days before they take effect. Continued use of the Platform after the effective date constitutes acceptance.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">10. Contact</h2>
            <p>Privacy questions or data requests: <a href="mailto:help@texttospeeches.in" className="text-indigo-600 dark:text-indigo-400 hover:underline">help@texttospeeches.in</a><br />
            WhatsApp: <a href="https://wa.me/917037300542" className="text-indigo-600 dark:text-indigo-400 hover:underline">+91 7037300542</a> (Mon–Fri, 5–10 PM IST)</p>
          </section>

        </div>
      </main>

      <footer className="border-t border-black/5 dark:border-white/10 px-8 py-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">© {new Date().getFullYear()} TextToSpeeches.in</div>
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <Link to="/about" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">About</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/docs" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Docs</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/help" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Help</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/privacy" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Privacy</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/terms" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Terms</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PrivacyPage;
