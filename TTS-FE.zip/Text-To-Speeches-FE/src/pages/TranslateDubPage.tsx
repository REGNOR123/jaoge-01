import React from "react";
import TranslateDubWizard from "../components/translateDub/TranslateDubWizard";

const TranslateDubPage: React.FC = () => {
  return <TranslateDubWizard />;
};

export default TranslateDubPage;
