﻿import React, { useEffect, useMemo, useRef, useState } from "react";
import { useWizardProgress } from "../hooks/useWizardProgress";
import { useNavigate, useSearchParams } from "react-router-dom";
import AuthRequiredModal from "../components/AuthRequiredModal";
import InsufficientCreditsModal from "../components/InsufficientCreditsModal";
import { useAuth } from "../contexts/AuthContext";
import { useCredits } from "../contexts/CreditContext";
import {
  downloadManagedFile,
  uploadManagedFile,
  uploadManagedTextFile,
  type StoredFileRecord,
} from "../services/filesApiService";
import { transcribeAudioFile } from "../services/transcribeService";
import { decodeAudioFileToBuffer } from "../utils/audioTranscode";
import {
  createProject,
  getProjectById,
  listProjects,
  updateProject,
} from "../utils/projectsStorage";
import ProjectNameModal from "../components/ProjectNameModal";
import { useDialog } from "../components/dialogs";
import ProgressStepBar from "../components/createVoice/ProgressStepBar";
import BottomActionBar from "../components/createVoice/BottomActionBar";
import { RECOGNITION_LANGUAGES } from "../components/speechTranslate/languages";
import { formatDuration, formatDateTime, downloadHref } from "../utils/format";

const DEFAULT_RECOGNITION_LANGUAGE =
  (import.meta.env.VITE_DEFAULT_RECOGNITION_LANGUAGE as string | undefined) ||
  "en-US";
type StepType = 1 | 2 | 3 | 4;

const stripInlineTimestamps = (value: string): string =>
  value.replace(/^\s*\[\d{2}:\d{2}\]\s*/gm, "").trim();

const RETENTION_MESSAGE = "Files are auto-deleted after 24 hours.";

const isTranscribeSourceEntry = (settings: any) =>
  settings?.feature === "transcribe" && settings?.source === "upload";

const TranscribePage: React.FC = () => {
  const { isAuthenticated, token } = useAuth();
  const { refreshBalance } = useCredits();
  const isGuest = !isAuthenticated;
  const navigate = useNavigate();
  const dialog = useDialog();
  const [searchParams] = useSearchParams();
  const projectIdFromQuery = searchParams.get("projectId") || "";

  const [authRequiredOpen, setAuthRequiredOpen] = useState(false);
  const [insuffCredits, setInsuffCredits] = useState<{ required: number; current: number } | null>(null);
  const [workflowId] = useState(() => crypto.randomUUID());

  const [file, setFile] = useState<File | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [sourceFileRecord, setSourceFileRecord] = useState<StoredFileRecord | null>(null);
  const [transcriptFileRecord, setTranscriptFileRecord] = useState<StoredFileRecord | null>(null);
  const [fileActionKey, setFileActionKey] = useState<string | null>(null);
  const [outputUploadInProgress, setOutputUploadInProgress] = useState(false);

  const [language, setLanguage] = useState("");
  const [autoPunctuation, setAutoPunctuation] = useState(true);
  const [includeTimestamps, setIncludeTimestamps] = useState(false);
  const [showTimestamps, setShowTimestamps] = useState(false);
  const [timestampedTranscript, setTimestampedTranscript] = useState("");

  const [isTranscribing, setIsTranscribing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [transcript, setTranscript] = useState("");
  const [estimatedMinutes, setEstimatedMinutes] = useState<number | null>(null);
  const [durationSeconds, setDurationSeconds] = useState<number | null>(null);
  const [activeProjectId, setActiveProjectId] = useState(projectIdFromQuery);
  const [newProjectName, setNewProjectName] = useState("");
  const [projectRefresh, setProjectRefresh] = useState(0);

  const transcribeProgress = useWizardProgress({ interval: 160 });
  const transcribeInProgress = transcribeProgress.inProgress;
  const transcribePercent = transcribeProgress.percent;

  const saveDraftProgress = useWizardProgress({ maxBump: 14, baseBump: 8, finishDelay: 450 });
  const saveDraftInProgress = saveDraftProgress.inProgress;
  const saveDraftPercent = saveDraftProgress.percent;

  const saveToProjectProgress = useWizardProgress({ maxBump: 14, baseBump: 8, finishDelay: 450 });
  const saveToProjectInProgress = saveToProjectProgress.inProgress;
  const saveToProjectPercent = saveToProjectProgress.percent;
  const [uploadPercent, setUploadPercent] = useState(0);
  const [currentStep, setCurrentStep] = useState<StepType>(1);
  const [completedSteps, setCompletedSteps] = useState<Set<StepType>>(new Set());
  const [maxStepUnlocked, setMaxStepUnlocked] = useState<number>(1);
  const [projectModalPurpose, setProjectModalPurpose] = useState<"draft" | "project" | null>(null);
  const [pendingProjectName, setPendingProjectName] = useState("");
  const [projectModalError, setProjectModalError] = useState<string | null>(null);
  const [projectModalStatus, setProjectModalStatus] = useState<"idle" | "saved">("idle");
  const [pendingNavigationTarget, setPendingNavigationTarget] = useState<StepType | null>(null);
  const [step1Loading, setStep1Loading] = useState(false);

  const isBusy =
    isTranscribing ||
    transcribeInProgress ||
    saveDraftInProgress ||
    saveToProjectInProgress ||
    outputUploadInProgress;

  const supportedFormatsLabel = "Supported formats: WAV, MP3.";

  const getDefaultProjectName = () => {
    if (newProjectName.trim()) return newProjectName.trim();
    if (file) return deriveProjectNameFromFile(file);
    return "Transcript";
  };

  const resetProjectModal = () => {
    setProjectModalPurpose(null);
    setProjectModalError(null);
    setProjectModalStatus("idle");
    setPendingNavigationTarget(null);
  };

  const openProjectModal = (purpose: "draft" | "project") => {
    setPendingProjectName(getDefaultProjectName());
    setProjectModalError(null);
    setProjectModalStatus("idle");
    setProjectModalPurpose(purpose);
  };

  const projectModalLoading =
    projectModalPurpose === "draft"
      ? saveDraftInProgress
      : projectModalPurpose === "project"
        ? saveToProjectInProgress
        : false;
  const projectModalPercent =
    projectModalPurpose === "draft" ? saveDraftPercent : projectModalPurpose === "project" ? saveToProjectPercent : 0;
  const projectModalTitle = projectModalPurpose === "project" ? "Save Project" : "Save Draft";
  const projectModalDescription =
    projectModalPurpose === "project"
      ? "Store the generated transcript under this project name."
      : "Store the current draft under this project name.";
  const projectModalStatusMessage = projectModalStatus === "saved" ? "Saved" : undefined;

  const handleProjectModalProceed = async () => {
    if (!projectModalPurpose) return;
    const candidate = pendingProjectName.trim();
    if (candidate.length <= 3) {
      setProjectModalError("Project name must be at least 4 characters.");
      return;
    }
    const validationError = validateNewProjectName(candidate, activeProjectId);
    if (validationError) {
      setProjectModalError(validationError);
      return;
    }
    setProjectModalError(null);
    setPendingProjectName(candidate);
    setNewProjectName(candidate);

    if (projectModalPurpose === "draft") {
      startSaveDraftProgress();
      const saved = await saveDraftToProject({ status: "Processing", projectName: candidate });
      if (!saved) {
        stopSaveDraftProgress();
        setError("Could not save draft. Please try again.");
        return;
      }
      await finishSaveDraftProgress();
    } else {
      startSaveToProjectProgress();
      const savedProjectId = await handleSaveTranscriptToProject(candidate);
      if (!savedProjectId) {
        stopSaveToProjectProgress();
        return;
      }
      await finishSaveToProjectProgress();
    }

    setProjectModalStatus("saved");
    if (pendingNavigationTarget != null) {
      const target = pendingNavigationTarget;
      window.setTimeout(() => {
        // Clear downstream state based on which step we're going back to
        if (target === 1) {
          setTranscript("");
          setCompletedSteps(new Set());
          setMaxStepUnlocked(1);
        } else if (target === 2) {
          setTranscript("");
          setCompletedSteps((prev) => {
            const newSet = new Set<StepType>();
            if (prev.has(1)) newSet.add(1);
            return newSet;
          });
          setMaxStepUnlocked(2);
        } else if (target === 3) {
          setTranscript("");
          setCompletedSteps((prev) => {
            const newSet = new Set<StepType>();
            if (prev.has(1)) newSet.add(1);
            if (prev.has(2)) newSet.add(2);
            return newSet;
          });
          setMaxStepUnlocked(3);
        }
        setCurrentStep(target);
        resetProjectModal();
      }, 600);
    } else {
      window.setTimeout(() => navigate("/projects"), 600);
    }
  };

  const activeProject = useMemo(() => {
    if (!activeProjectId) return null;
    return getProjectById(activeProjectId);
  }, [activeProjectId, projectRefresh]);

  const activeAudioVersions = useMemo(() => {
    return (activeProject?.data?.outputs?.audioVersions || []).filter((entry) =>
      isTranscribeSourceEntry((entry.settings as any) || {}),
    );
  }, [activeProject]);

  useEffect(() => {
    if (!projectIdFromQuery) return;
    const project = getProjectById(projectIdFromQuery);
    if (!project) return;

    setError(null);
    setActiveProjectId(project.id);
    setProjectRefresh((v) => v + 1);

    const draft = project.data?.drafts?.transcript;
    if (draft?.language && typeof draft.language === "string")
      setLanguage(draft.language);
    if (typeof draft?.autoPunctuation === "boolean")
      setAutoPunctuation(draft.autoPunctuation);
    if (typeof draft?.includeTimestamps === "boolean")
      setIncludeTimestamps(draft.includeTimestamps);

    const draftTranscript = draft?.transcript;
    const latestTranscript = project.data?.outputs?.transcripts?.[0]?.text;
    const transcriptToLoad =
      typeof draftTranscript === "string" && draftTranscript.trim()
        ? draftTranscript
        : typeof latestTranscript === "string" && latestTranscript.trim()
          ? latestTranscript
          : "";
    setTranscript(transcriptToLoad);
    if (draft?.includeTimestamps && transcriptToLoad) {
      setTimestampedTranscript(transcriptToLoad);
      setShowTimestamps(true);
    } else {
      setTimestampedTranscript("");
      setShowTimestamps(false);
    }

    if (typeof project.name === "string" && project.name.trim())
      setNewProjectName(project.name);

    setFile(null);
    setDurationSeconds(null);
    setEstimatedMinutes(null);
    const latestSource = (project.data?.outputs?.audioVersions || []).find((entry) =>
      isTranscribeSourceEntry((entry.settings as any) || {}),
    );
    if (latestSource?.fileId) {
      setSourceFileRecord({
        fileId: latestSource.fileId,
        fileName:
          latestSource.fileName ||
          (typeof (latestSource.settings as any)?.fileName === "string"
            ? String((latestSource.settings as any).fileName)
            : "uploaded-audio.wav"),
        contentType:
          latestSource.contentType ||
          (typeof (latestSource.settings as any)?.contentType === "string"
            ? String((latestSource.settings as any).contentType)
            : undefined),
        expiresAt:
          latestSource.expiresAt ||
          (typeof (latestSource.settings as any)?.expiresAt === "string"
            ? String((latestSource.settings as any).expiresAt)
            : undefined),
        uploadedAt: latestSource.createdAt,
        durationMinutes: latestSource.estimatedMinutes,
        feature: "transcribe",
        isOutput: false,
        jobId: project.id,
      });
    } else {
      setSourceFileRecord(null);
    }

    const latestTranscriptEntry = project.data?.outputs?.transcripts?.[0];
    if (latestTranscriptEntry?.fileId) {
      setTranscriptFileRecord({
        fileId: latestTranscriptEntry.fileId,
        fileName: latestTranscriptEntry.fileName || "transcript.txt",
        contentType: latestTranscriptEntry.contentType,
        expiresAt: latestTranscriptEntry.expiresAt,
        uploadedAt: latestTranscriptEntry.createdAt,
        feature: "transcribe",
        isOutput: true,
        jobId: project.id,
      });
    } else {
      setTranscriptFileRecord(null);
    }

    const nextCompleted = new Set<StepType>();
    if (transcriptToLoad.trim()) {
      nextCompleted.add(1);
      nextCompleted.add(2);
      nextCompleted.add(3);
    }
    setCompletedSteps(nextCompleted);
    setCurrentStep(transcriptToLoad.trim() ? 4 : 1);
  }, [projectIdFromQuery]);

  const applyProtectedError = (message: string, status?: number) => {
    setError(message);
    if (status === 401 || status === 403) setAuthRequiredOpen(true);
  };

  const requireProtectedAccess = () => {
    if (isAuthenticated && token) return true;
    setAuthRequiredOpen(true);
    return false;
  };

  const handleStepNavigation = async (targetStep: StepType): Promise<boolean> => {
    if (targetStep === currentStep) return true;
    if (targetStep > maxStepUnlocked) return false;

    // Check if going back to a step with subsequent completed steps
    if (targetStep < currentStep) {
      const hasSubsequentProgress =
        (targetStep === 1 && (completedSteps.has(2) || completedSteps.has(3))) ||
        (targetStep === 2 && completedSteps.has(3)) ||
        (targetStep === 3 && transcript.trim().length > 0);

      if (hasSubsequentProgress) {
        // Step 1 Confirmation: Ask if they want to edit
        const stepNames: Record<StepType, string> = {
          1: "Upload",
          2: "Settings",
          3: "Generate",
          4: "Review",
        };
        const confirmEdit = await dialog.confirm(
          `Do you want to proceed with editing the ${stepNames[targetStep]} step?`,
          {
            title: "Edit Previous Step",
            confirmText: "Yes, Proceed",
            cancelText: "Cancel",
            variant: "warning",
          }
        );

        if (!confirmEdit) return false;

        // Step 2 Confirmation: Warn about clearing progress and ask about saving
        const wantToSave = await dialog.confirm(
          "Making changes to this step will clear the progress of subsequent completed steps.\n\nWould you like to save the current project before continuing?",
          {
            title: "Warning: Progress Will Be Lost",
            confirmText: "Save Project",
            cancelText: "Continue Without Saving",
            variant: "warning",
          }
        );

        // If user chose to save
        if (wantToSave) {
          setPendingNavigationTarget(targetStep);
          // Check if we have generated transcript to save
          if (transcript.trim().length > 0) {
            openProjectModal("project");
          } else {
            // Save as draft if no generated transcript
            openProjectModal("draft");
          }
          // Don't proceed with navigation - let the modal complete first
          return false;
        }

        // User chose "Continue Without Saving"
        // Clear downstream state based on which step we're going back to
        if (targetStep === 1) {
          // Going back to Step 1: Clear all subsequent progress
          setTranscript("");
          setCompletedSteps(new Set());
          setMaxStepUnlocked(1);
        } else if (targetStep === 2) {
          // Going back to Step 2: Clear step 3 and 4 progress
          setTranscript("");
          setCompletedSteps((prev) => {
            const newSet = new Set<StepType>();
            if (prev.has(1)) newSet.add(1);
            return newSet;
          });
          setMaxStepUnlocked(2);
        } else if (targetStep === 3) {
          // Going back to Step 3: Clear step 4 progress
          setTranscript("");
          setCompletedSteps((prev) => {
            const newSet = new Set<StepType>();
            if (prev.has(1)) newSet.add(1);
            if (prev.has(2)) newSet.add(2);
            return newSet;
          });
          setMaxStepUnlocked(3);
        }
      }
    }

    setCurrentStep(targetStep);
    return true;
  };

  useEffect(() => {
    if (!file) {
      setAudioUrl(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setAudioUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const startTranscribeProgress = transcribeProgress.start;
  const stopTranscribeProgress = transcribeProgress.stop;
  const finishTranscribeProgress = transcribeProgress.finish;

  const startSaveDraftProgress = saveDraftProgress.start;
  const stopSaveDraftProgress = saveDraftProgress.stop;
  const finishSaveDraftProgress = saveDraftProgress.finish;

  const startSaveToProjectProgress = saveToProjectProgress.start;
  const stopSaveToProjectProgress = saveToProjectProgress.stop;
  const finishSaveToProjectProgress = saveToProjectProgress.finish;

  const MAX_FILE_SIZE_MB = 100;

  const onPickFile = (
    next: File | null,
    options?: { preserveTranscript?: boolean },
  ) => {
    setError(null);
    setSourceFileRecord(null);
    setTranscriptFileRecord(null);
    setFileActionKey(null);
    if (!options?.preserveTranscript) {
      setTranscript("");
      setTimestampedTranscript("");
      setShowTimestamps(false);
    }

    if (next && next.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
      setError(`File size exceeds ${MAX_FILE_SIZE_MB}MB limit. Please choose a smaller file.`);
      setFile(null);
      setDurationSeconds(null);
      setEstimatedMinutes(null);
      return;
    }

    setFile(next);
    setNewProjectName((prev) => {
      if (!next) return "";
      if (prev.trim()) return prev;
      return deriveProjectNameFromFile(next);
    });
    setDurationSeconds(null);
    setCompletedSteps((prev) => {
      const keep = new Set<StepType>();
      if (next) keep.add(1);
      if (prev.has(4) && options?.preserveTranscript) {
        keep.add(1);
        keep.add(2);
        keep.add(3);
      }
      return keep;
    });
    setCurrentStep(1);

    if (!next) {
      setEstimatedMinutes(null);
      return;
    }

    setEstimatedMinutes(null);
    decodeAudioFileToBuffer(next)
      .then((buf) => {
        const secs = Math.max(0, buf.duration || 0);
        setDurationSeconds(Number.isFinite(secs) ? secs : null);
        const mins = Math.max(0, secs / 60);
        setEstimatedMinutes(Number.isFinite(mins) ? mins : null);
      })
      .catch(() => {
        setEstimatedMinutes(null);
        setDurationSeconds(null);
        setError("Could not read audio file. The file may be corrupted or in an unsupported format.");
      });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const dropped = e.dataTransfer.files?.[0] || null;
    if (dropped) onPickFile(dropped);
  };

  const normalizeProjectName = (value: string) =>
    value.trim().replace(/\s+/g, " ").toLowerCase();

  const validateNewProjectName = (
    value: string,
    excludeId?: string,
  ): string | null => {
    const collapsed = value.trim().replace(/\s+/g, " ");
    if (collapsed.length <= 3)
      return "Project name must be at least 4 characters.";
    const normalized = normalizeProjectName(collapsed);
    const exclude = excludeId ?? activeProjectId;
    const isDuplicate = listProjects().some(
      (p) => normalizeProjectName(p.name) === normalized && p.id !== exclude,
    );
    if (isDuplicate) return "Project name must be unique.";
    return null;
  };

  const deriveProjectNameFromFile = (file: File | null): string => {
    if (!file) return "";
    const rawName = file.name.replace(/\.[^/.]+$/, "").trim();
    const base = rawName.length >= 4 ? rawName : "Transcript";
    const taken = new Set(listProjects().map((project) => normalizeProjectName(project.name)));
    let candidate = base;
    let suffix = 1;
    while (taken.has(normalizeProjectName(candidate))) {
      candidate = `${base} ${suffix}`;
      suffix += 1;
    }
    return candidate;
  };

  const ensureProject = (overrideName?: string): string | null => {
    if (activeProjectId) return activeProjectId;
    const rawName = overrideName ?? newProjectName;
    const name = rawName.trim().replace(/\s+/g, " ");
    if (!name) return null;
    const err = validateNewProjectName(name, activeProjectId);
    if (err) return null;
    const now = new Date().toISOString();
    const project = createProject({
      name,
      type: "Transcript",
      status: "Processing",
      data: {
        drafts: {
          transcript: {
            language,
            autoPunctuation,
            includeTimestamps,
            updatedAt: now,
          },
        },
        outputs: {},
      },
    });
    if (!project) return null;
    setActiveProjectId(project.id);
    setNewProjectName(name);
    setProjectRefresh((v) => v + 1);
    return project.id;
  };

  const persistProjectState = (
    projectId: string,
    options?: {
      status?: "Processing" | "Completed";
      sourceRecord?: StoredFileRecord | null;
      transcriptText?: string;
      transcriptRecord?: StoredFileRecord | null;
      persistOutput?: boolean;
      clearOutput?: boolean;
    },
  ) => {
    const project = getProjectById(projectId);
    if (!project) return null;

    const nextName = newProjectName.trim().replace(/\s+/g, " ");
    const namePatch =
      nextName && !validateNewProjectName(nextName, projectId)
        ? { name: nextName }
        : {};
    const now = new Date().toISOString();
    const sourceRecord =
      options && "sourceRecord" in options ? options.sourceRecord ?? null : sourceFileRecord;
    const transcriptText =
      options && "transcriptText" in options ? options.transcriptText ?? "" : transcript;
    const transcriptRecord =
      options && "transcriptRecord" in options ? options.transcriptRecord ?? null : transcriptFileRecord;
    const existingAudio = (project.data?.outputs?.audioVersions || []).filter(
      (entry) => !isTranscribeSourceEntry((entry.settings as any) || {}),
    );
    const existingTranscripts = project.data?.outputs?.transcripts || [];

    const nextAudioVersions = [...existingAudio];
    if (sourceRecord?.fileId) {
      nextAudioVersions.unshift({
        id: `transcribe-source-${sourceRecord.fileId}`,
        audioUrl: `managed-file:${sourceRecord.fileId}`,
        createdAt: sourceRecord.uploadedAt || now,
        fileId: sourceRecord.fileId,
        contentType: sourceRecord.contentType,
        fileName: sourceRecord.fileName,
        expiresAt: sourceRecord.expiresAt,
        estimatedMinutes: estimatedMinutes ?? undefined,
        settings: {
          feature: "transcribe",
          source: "upload",
          fileId: sourceRecord.fileId,
          fileName: sourceRecord.fileName,
          contentType: sourceRecord.contentType,
          expiresAt: sourceRecord.expiresAt,
        },
      });
    }

    let nextTranscripts = existingTranscripts;
    if (options?.clearOutput) {
      nextTranscripts = existingTranscripts.filter((entry) => entry.fileId !== transcriptFileRecord?.fileId);
    }
    if (options?.persistOutput && transcriptText.trim()) {
      nextTranscripts = [
        {
          id: transcriptRecord?.fileId ? `transcribe-output-${transcriptRecord.fileId}` : crypto.randomUUID(),
          text: transcriptText,
          createdAt: transcriptRecord?.uploadedAt || now,
          fileId: transcriptRecord?.fileId,
          contentType: transcriptRecord?.contentType,
          fileName: transcriptRecord?.fileName,
          expiresAt: transcriptRecord?.expiresAt,
          language,
          includeTimestamps,
        },
        ...existingTranscripts.filter((entry) => entry.fileId !== transcriptRecord?.fileId),
      ].slice(0, 20);
    }

    const updated = updateProject(projectId, {
      ...namePatch,
      type: "Transcript",
      status: options?.status || (project.status === "Completed" ? "Completed" : "Processing"),
      data: {
        ...(project.data || {}),
        drafts: {
          ...(project.data?.drafts || {}),
          transcript: {
            language,
            autoPunctuation,
            includeTimestamps,
            fileName: sourceRecord?.fileName || file?.name,
            durationSeconds: durationSeconds ?? undefined,
            transcript: transcriptText || undefined,
            updatedAt: now,
          },
        },
        outputs: {
          ...(project.data?.outputs || {}),
          audioVersions: nextAudioVersions.slice(0, 20),
          transcripts: nextTranscripts,
        },
      },
    });
    setProjectRefresh((v) => v + 1);
    return updated;
  };

  const ensureSourceStored = async (jobId: string) => {
    if (!file) return null;
    if (!requireProtectedAccess() || !token) return null;

    if (
      sourceFileRecord &&
      sourceFileRecord.fileName === file.name &&
      (sourceFileRecord.sizeBytes == null || sourceFileRecord.sizeBytes === file.size)
    ) {
      return sourceFileRecord;
    }

    setUploadPercent(0);
    const result = await uploadManagedFile(token, file, {
      feature: "transcribe",
      jobId,
      durationMinutes: estimatedMinutes,
      isOutput: false,
      onProgress: (percent) => setUploadPercent(percent),
    });
    setUploadPercent(0);
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return null;
    }

    setSourceFileRecord(result.data);
    return result.data;
  };

  const saveDraftToProject = async (options?: {
    status?: "Processing" | "Completed";
    uploadIfMissing?: boolean;
    projectName?: string;
  }) => {
    const projectId = ensureProject(options?.projectName);
    if (!projectId) return null;

    let nextSourceRecord = sourceFileRecord;
    if (file && options?.uploadIfMissing !== false) {
      nextSourceRecord = nextSourceRecord || (await ensureSourceStored(projectId));
      if (!nextSourceRecord) return null;
    }

    return persistProjectState(projectId, {
      status: options?.status,
      sourceRecord: nextSourceRecord,
    });
  };

  const handleSaveDraft = async (projectName?: string): Promise<boolean> => {
    setError(null);
    if (!file) {
      setError("Please upload an audio file.");
      return false;
    }
    if (!requireProtectedAccess()) return false;
    const saved = await saveDraftToProject({ status: "Processing", projectName });
    if (!saved) {
      setError("Could not save draft. Please try again.");
      return false;
    }
    return true;
  };

  const handleGenerate = async (): Promise<boolean> => {
    if (!requireProtectedAccess()) {
      return false;
    }
    if (!file) {
      setError("Please upload an audio file.");
      return false;
    }

    const ok = await dialog.confirm(
      <div className="space-y-4">
        <div className="space-y-2">
          <p className="text-sm text-slate-700 dark:text-slate-200">
            NOTE : Transcription converts spoken audio into written text in the same
            language.
          </p>
          <p className="text-[12px] text-slate-600 dark:text-slate-300">
            The language is not changed. Only speech converts to text.
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-4">
          <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
            Example
          </div>
          <div className="mt-3 space-y-2 text-sm text-slate-800 dark:text-slate-100">
            <div>
              <div className="text-[11px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Audio (English)
              </div>
              <div className="mt-1 font-semibold">
                Spoken: {'"'}Hello world, how are you?{'"'}
              </div>
            </div>
            <div>
              <div className="text-[11px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Transcription Output (English)
              </div>
              <div className="mt-1 font-semibold">{'"'}Hello world, how are you?{'"'}</div>
            </div>
            <div className="pt-2 text-[12px] text-slate-600 dark:text-slate-300">
              Transcription converts speech to text in the same language. It does not translate or change the script.
            </div>
          </div>
        </div>

        <div className="text-[12px] text-slate-600 dark:text-slate-300">
          Estimated usage:{" "}
          <span className="font-bold">
            {estimatedMinutes == null
              ? "\u2014"
              : `${estimatedMinutes.toFixed(2)} mins`}
          </span>
          .
        </div>
      </div>,
      {
        title: "Generate Transcript",
        confirmText: "Generate",
        variant: "warning",
      },
    );
    if (!ok) return false;

    // Guests skip project creation and source upload
    let projectId: string | null = null;
    let storedSource: StoredFileRecord | null = null;
    if (!isGuest) {
      const candidate = newProjectName.trim() || deriveProjectNameFromFile(file);
      projectId = ensureProject(candidate);
      if (!projectId) {
        setError("Please enter a unique project name.");
        return false;
      }

      storedSource = sourceFileRecord?.fileId ? sourceFileRecord : await ensureSourceStored(projectId);
      if (!storedSource?.fileId) {
        setError("Please complete Step 1 so the source audio is uploaded before generating.");
        return false;
      }
    }

    setIsTranscribing(true);
    setError(null);
    startTranscribeProgress();

    const res = await transcribeAudioFile(file, {
      language,
      autoPunctuation,
      includeTimestamps,
    }, token);

    setIsTranscribing(false);
    if (res.success === false) {
      stopTranscribeProgress();
      if (res.insufficientCredits) {
        setInsuffCredits({ required: res.requiredCredits ?? 0, current: res.currentBalance ?? 0 });
        return false;
      }
      setError(res.error);
      return false;
    }
    const nextTranscript = res.transcript || "";
    if (includeTimestamps) {
      setTimestampedTranscript(nextTranscript);
      setShowTimestamps(true);
      setTranscript(nextTranscript);
    } else {
      setTimestampedTranscript("");
      setShowTimestamps(false);
      setTranscript(nextTranscript);
    }
    await finishTranscribeProgress();
    void refreshBalance();

    // Only persist to server and project for authenticated users
    if (projectId && !isGuest) {
      const storedTranscriptRecord = await uploadTranscriptSample(projectId, nextTranscript);
      if (storedTranscriptRecord) {
        setTranscriptFileRecord(storedTranscriptRecord);
      }
      persistProjectState(projectId, {
        status: "Processing",
        sourceRecord: storedSource,
        transcriptText: nextTranscript,
        transcriptRecord: storedTranscriptRecord,
        persistOutput: Boolean(storedTranscriptRecord),
      });
    }

    setCompletedSteps((prev) => new Set([...prev, 1, 2, 3]));
    setCurrentStep(4);
    return true;
  };

  const uploadTranscriptSample = async (projectId: string, value: string) => {
    if (!value.trim() || !token) return null;
    const result = await uploadManagedTextFile(token, value, {
      fileName: `transcript-${workflowId}.txt`,
      feature: "transcribe",
      jobId: projectId,
      durationMinutes: estimatedMinutes,
      isOutput: true,
    });
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return null;
    }
    return result.data;
  };

  const handleSaveTranscriptToProject = async (projectName?: string): Promise<string | null> => {
    if (!transcript.trim()) {
      setError("Generate a transcript before saving.");
      return null;
    }
    if (!file) {
      setError("Please upload an audio file.");
      return null;
    }
    if (!requireProtectedAccess() || !token) return null;

    const projectId = ensureProject(projectName);
    if (!projectId) {
      setError("Please enter a unique project name.");
      return null;
    }

    const storedSource = sourceFileRecord?.fileId ? sourceFileRecord : await ensureSourceStored(projectId);
    if (!storedSource?.fileId) return null;

    setOutputUploadInProgress(true);
    setError(null);
    try {
      const storedTranscript = await uploadTranscriptSample(projectId, transcript);
      if (!storedTranscript) return null;
      setTranscriptFileRecord(storedTranscript);
      const updated = persistProjectState(projectId, {
        status: "Completed",
        sourceRecord: storedSource,
        transcriptText: transcript,
        transcriptRecord: storedTranscript,
        persistOutput: true,
      });
      if (!updated) {
        setError("Could not save transcript to project.");
        return null;
      }
      return projectId;
    } finally {
      setOutputUploadInProgress(false);
    }
  };

  const handleDownloadSource = async (record: {
    fileId?: string;
    fileName?: string;
    contentType?: string;
  }) => {
    if (!record.fileId || !token) return;
    if (!requireProtectedAccess()) return;
    setError(null);
    setFileActionKey(`download-${record.fileId}`);
    const result = await downloadManagedFile(token, record.fileId);
    setFileActionKey(null);
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return;
    }
    const url = URL.createObjectURL(result.data.blob);
    downloadHref(url, result.data.fileName || record.fileName || "audio-sample.wav");
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  };

  const handleUsePreviousUpload = async (record: {
    fileId?: string;
    fileName?: string;
    contentType?: string;
  }) => {
    if (!record.fileId || !token) return;
    if (!requireProtectedAccess()) return;
    setError(null);
    setFileActionKey(`use-${record.fileId}`);
    const result = await downloadManagedFile(token, record.fileId);
    setFileActionKey(null);
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return;
    }
    const reconstructed = new File(
      [result.data.blob],
      result.data.fileName || record.fileName || "uploaded-audio.wav",
      {
        type: record.contentType || result.data.contentType || result.data.blob.type || "audio/wav",
      },
    );
    onPickFile(reconstructed, { preserveTranscript: true });
    setSourceFileRecord({
      fileId: record.fileId as string,
      fileName: result.data.fileName || record.fileName || reconstructed.name,
      contentType: record.contentType || result.data.contentType || reconstructed.type,
      feature: "transcribe",
      isOutput: false,
    });
    setCurrentStep(1);
  };

  const downloadText = (filename: string, content: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const downloadTxt = () =>
    downloadText("transcript.txt", transcript, "text/plain;charset=utf-8");

  const downloadDoc = () => {
    const html = `<!doctype html><html><head><meta charset="utf-8" /></head><body><pre>${escapeHtml(
      transcript,
    )}</pre></body></html>`;
    downloadText("transcript.doc", html, "application/msword");
  };

  const [copySuccess, setCopySuccess] = useState(false);

  const copyText = async () => {
    try {
      await navigator.clipboard.writeText(transcript);
      setCopySuccess(true);
      window.setTimeout(() => setCopySuccess(false), 2000);
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    if (!activeProjectId) return;
    const t = window.setTimeout(() => {
      const project = getProjectById(activeProjectId);
      if (!project) return;
      const now = new Date().toISOString();
      updateProject(activeProjectId, {
        type: "Transcript",
        status: project.status || "Processing",
        data: {
          ...(project.data || {}),
          drafts: {
            ...(project.data?.drafts || {}),
            transcript: {
              language,
              autoPunctuation,
              includeTimestamps,
              updatedAt: now,
            },
          },
        },
      });
    }, 700);
    return () => window.clearTimeout(t);
  }, [activeProjectId, language, autoPunctuation, includeTimestamps]);

  useEffect(() => {
    if (!includeTimestamps) {
      setShowTimestamps(false);
      return;
    }
    if (!timestampedTranscript.trim()) return;
    setTranscript(showTimestamps ? timestampedTranscript : stripInlineTimestamps(timestampedTranscript));
  }, [includeTimestamps, showTimestamps, timestampedTranscript]);

  const step1Summary = useMemo(() => {
    if (!file) return "No file selected";
    return `${file.name} , ${formatDuration(durationSeconds)}`;
  }, [file, durationSeconds]);

  const step2Summary = useMemo(() => {
    const languageName =
      RECOGNITION_LANGUAGES.find((l) => l.code === language)?.name || language;
    const bits = [languageName, autoPunctuation ? "Auto punctuation on" : "Auto punctuation off"];
    bits.push(includeTimestamps ? "Timestamps on" : "Timestamps off");
    return bits.join(" | ");
  }, [language, autoPunctuation, includeTimestamps]);

  const transcriptWordCount = useMemo(() => {
    const t = transcript.trim();
    if (!t) return 0;
    return t.split(/\s+/).filter(Boolean).length;
  }, [transcript]);

  const handleStep1Continue = async () => {
    if (!file) {
      setError("Please upload an audio file.");
      return;
    }
    // Guests skip server upload and project creation, proceed directly
    if (isGuest) {
      setCompletedSteps((prev) => new Set([...prev, 1]));
      setMaxStepUnlocked((prev) => (prev >= 2 ? prev : 2));
      setCurrentStep(2);
      return;
    }
    if (!requireProtectedAccess()) return;
    setStep1Loading(true);
    try {
      const saved = await saveDraftToProject({ status: "Processing" });
      if (!saved) return;
      setCompletedSteps((prev) => new Set([...prev, 1]));
      setMaxStepUnlocked((prev) => (prev >= 2 ? prev : 2));
      setCurrentStep(2);
    } finally {
      setStep1Loading(false);
    }
  };

  const handleStep2Continue = () => {
    if (!file) {
      setCurrentStep(1);
      return;
    }
    setCompletedSteps((prev) => new Set([...prev, 1, 2]));
    setMaxStepUnlocked((prev) => (prev >= 3 ? prev : 3));
    setCurrentStep(3);
  };

  const handleStep3Generate = async () => {
    const ok = await handleGenerate();
    if (!ok) return;
    setMaxStepUnlocked((prev) => (prev >= 4 ? prev : 4));
  };

  const handleSaveProjectClick = () => {
    if (!transcript.trim()) {
      setError("Generate a transcript before saving.");
      return;
    } 
    if (!requireProtectedAccess() || !token) return;
    openProjectModal("project");
  };

  const handleStartNew = async () => {
    const confirmed = await dialog.confirm(
      "Are you sure you want to delete this transcription? All progress will be lost.",
      {
        title: "Delete Transcription",
        confirmText: "Delete",
        variant: "danger",
      }
    );
    
    if (!confirmed) return;
    
    setError(null);
    setFile(null);
    setSourceFileRecord(null);
    setTranscriptFileRecord(null);
    setFileActionKey(null);
    setNewProjectName("");
    setTranscript("");
    setTimestampedTranscript("");
    setShowTimestamps(false);
    setDurationSeconds(null);
    setEstimatedMinutes(null);
    setActiveProjectId("");
    setCurrentStep(1);
    setMaxStepUnlocked(1);
    setCompletedSteps(new Set());
  };

  return (
    <div className="max-w-6xl mx-auto px-5 pt-8 pb-8 space-y-6">
      <AuthRequiredModal
        isOpen={authRequiredOpen}
        onClose={() => setAuthRequiredOpen(false)}
        redirectTo="/transcribe"
      />
      <InsufficientCreditsModal
        isOpen={!!insuffCredits}
        onClose={() => setInsuffCredits(null)}
        requiredCredits={insuffCredits?.required ?? 0}
        currentBalance={insuffCredits?.current ?? 0}
      />

      <ProjectNameModal
        isOpen={Boolean(projectModalPurpose)}
        title={projectModalTitle}
        description={projectModalDescription}
        projectName={pendingProjectName}
        error={projectModalError}
        loading={projectModalLoading}
        progressPercent={projectModalPercent}
        statusMessage={projectModalStatusMessage}
        proceedDisabled={!pendingProjectName.trim()}
        onProjectNameChange={setPendingProjectName}
        onCancel={resetProjectModal}
        onProceed={handleProjectModalProceed}
      />

      <header className="flex items-start justify-between gap-6 relative">
        <div>
          <h1 className="m-0 text-3xl sm:text-4xl font-black leading-tight tracking-tight text-slate-900 dark:text-white">
            Transcribe Audio
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl">
            A guided workflow to upload, configure, generate, and export your transcript.
          </p>
        </div>
        <div className="flex items-center gap-2 relative">
          {/* Hide Save Draft button for guests */}
          {!isGuest && (
            <button
              type="button"
              disabled={isBusy || !file || Boolean(projectModalPurpose)}
              onClick={() => openProjectModal("draft")}
              className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
              title={!file ? "Upload an audio file to enable." : "Name the project after clicking Save."}
            >
              Save Draft
            </button>
          )}
        </div>
      </header>

      <ProgressStepBar
        steps={[
          { id: 1 as StepType, label: "Upload" },
          { id: 2 as StepType, label: "Settings" },
          { id: 3 as StepType, label: "Generate" },
          { id: 4 as StepType, label: "Review" },
        ].map((s) => ({
          number: s.id,
          title: s.label,
          status: completedSteps.has(s.id) ? "completed" : currentStep === s.id ? "active" : "pending",
          isClickable: maxStepUnlocked >= s.id && currentStep !== s.id,
        }))}
        onStepClick={(stepNumber) => {
          if (stepNumber >= 1 && stepNumber <= maxStepUnlocked && stepNumber !== currentStep) {
            void (async () => {
              const shouldProceed = await handleStepNavigation(stepNumber as StepType);
              if (shouldProceed) {
                setCurrentStep(stepNumber as StepType);
              }
            })();
          }
        }}
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-12 space-y-6">
          {currentStep === 1 && (
            <StepCard
              step={1}
              title="Upload Audio"
              isActive={currentStep === 1}
              isCompleted={completedSteps.has(1)}
              summary={step1Summary}
              description="Upload your audio file to begin the transcription process."
            >
            <div className="space-y-4">
              <div
                className={[
                  "rounded-3xl border-2 border-dashed p-8 transition-all cursor-pointer text-center",
                  dragOver
                    ? "border-indigo-500 bg-indigo-500/10 scale-[1.01]"
                    : "border-slate-200 dark:border-white/10 bg-white/40 dark:bg-white/5 hover:border-indigo-500/30",
                ].join(" ")}
                onClick={() => fileInputRef.current?.click()}
                onDragEnter={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={(e) => {
                  e.preventDefault();
                  setDragOver(false);
                }}
                onDrop={handleDrop}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".wav,.mp3,audio/wav,audio/mpeg"
                  className="hidden"
                  onChange={(e) => onPickFile(e.target.files?.[0] || null)}
                />
                <div className="flex flex-col items-center gap-3">
                  <div className={[
                    "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
                    dragOver ? "bg-indigo-500/20" : "bg-slate-100 dark:bg-white/10",
                  ].join(" ")}>
                    <svg className={["w-6 h-6 transition-colors", dragOver ? "text-indigo-500" : "text-slate-400 dark:text-slate-500"].join(" ")} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                  </div>
                  <div className="text-sm font-black text-slate-900 dark:text-white">
                    {dragOver ? "Drop your file here" : "Drag and drop audio"}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    {file ? (
                      <>Selected: {file.name} ({(file.size / (1024 * 1024)).toFixed(1)} MB)</>
                    ) : (
                      "Click to choose a file"
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-white/10 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">WAV</span>
                    <span className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-white/10 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">MP3</span>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">Max {MAX_FILE_SIZE_MB}MB</span>
                  </div>
                </div>
              </div>

              {file && audioUrl && (
                <div className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/40 dark:bg-white/5 p-4 space-y-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2.5 py-1.5 rounded-xl bg-white/70 dark:bg-white/10 border border-slate-200 dark:border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
                      {file.name}
                    </span>
                    <span className="px-2.5 py-1.5 rounded-xl bg-white/70 dark:bg-white/10 border border-slate-200 dark:border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
                      {formatDuration(durationSeconds)}
                    </span>
                    <span className="px-2.5 py-1.5 rounded-xl bg-white/70 dark:bg-white/10 border border-slate-200 dark:border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
                      {(file.size / (1024 * 1024)).toFixed(1)} MB
                    </span>
                    <span className="px-2.5 py-1.5 rounded-xl bg-white/70 dark:bg-white/10 border border-slate-200 dark:border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
                      {file.name.split('.').pop()?.toUpperCase() || "AUDIO"}
                    </span>
                    {estimatedMinutes != null && (
                      <span className="px-2.5 py-1.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-[10px] font-black uppercase tracking-widest text-indigo-700 dark:text-indigo-300">
                        Est. {estimatedMinutes.toFixed(2)} mins
                      </span>
                    )}
                  </div>
                  <audio
                    controls
                    src={audioUrl}
                    className={`w-full ${isGuest ? 'guest-audio' : ''}`}
                    controlsList={isGuest ? "nodownload noplaybackrate" : undefined}
                  />
                  {!isGuest && (
                    <div className="flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-500 font-medium">
                      <span>Stored until: {sourceFileRecord?.expiresAt ? formatDateTime(sourceFileRecord.expiresAt) : "Not stored yet"}</span>
                    </div>
                  )}
                  <div className="flex flex-wrap gap-2">
                    {sourceFileRecord?.fileId && (
                      <button
                        type="button"
                        onClick={() => void handleDownloadSource(sourceFileRecord)}
                        disabled={fileActionKey === `download-${sourceFileRecord.fileId}`}
                        className="px-3 py-2 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-[10px] font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 disabled:opacity-50"
                      >
                        {fileActionKey === `download-${sourceFileRecord.fileId}` ? "Downloading..." : "Download Source"}
                      </button>
                    )}
                  </div>
                </div>
              )}

              {projectIdFromQuery && !file && activeAudioVersions.length > 0 && (
                <div className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/40 dark:bg-white/5 p-4 space-y-3">
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    Previous uploads
                  </div>
                  {activeAudioVersions.slice(0, 3).map((a) => {
                    const fileName = a.fileName || ((a.settings as any)?.fileName as string | undefined);
                    const contentType = a.contentType || ((a.settings as any)?.contentType as string | undefined);
                    return (
                      <div key={a.id} className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-3">
                        <div className="flex items-center justify-between gap-3 flex-wrap">
                          <div className="text-xs font-semibold text-slate-900 dark:text-white truncate min-w-0">
                            {fileName || "Audio"}
                          </div>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              disabled={!a.fileId || isBusy || fileActionKey === `use-${a.fileId}`}
                              onClick={() =>
                                void handleUsePreviousUpload({
                                  fileId: a.fileId,
                                  fileName,
                                  contentType,
                                })
                              }
                              className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-black uppercase tracking-widest disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              {fileActionKey === `use-${a.fileId}` ? "Loading..." : "Use"}
                            </button>
                            {a.fileId && (
                              <button
                                type="button"
                                disabled={fileActionKey === `download-${a.fileId}`}
                                onClick={() =>
                                  void handleDownloadSource({
                                    fileId: a.fileId,
                                    fileName,
                                    contentType,
                                  })
                                }
                                className="px-3 py-2 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-[10px] font-black uppercase tracking-widest disabled:opacity-50 disabled:cursor-not-allowed border border-slate-200 dark:border-white/10"
                              >
                                {fileActionKey === `download-${a.fileId}` ? "Downloading..." : "Download"}
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

            </div>
            </StepCard>
          )}

          {currentStep === 2 && completedSteps.has(1) && (
            <StepCard
              step={2}
              title="Configure Settings"
              isActive={currentStep === 2}
              isCompleted={completedSteps.has(2)}
              summary={step2Summary}
              description="Configure language, punctuation, and timestamp settings for your transcription."
            >
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                    Target Language
                  </label>
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    disabled={isBusy}
                    className="w-full px-3 py-3 rounded-xl bg-slate-100/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/30 disabled:opacity-60"
                  >
                    <option value="" disabled>Select target language</option>
                    {RECOGNITION_LANGUAGES.map((l) => (
                      <option key={l.code} value={l.code}>
                        {l.name}
                      </option>
                    ))}
                  </select>
                </div>
                <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-200 font-medium select-none">
                  <input
                    type="checkbox"
                    checked={autoPunctuation}
                    onChange={(e) => setAutoPunctuation(e.target.checked)}
                    disabled={isBusy}
                    className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  Auto punctuation
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-200 font-medium select-none">
                  <input
                    type="checkbox"
                    checked={includeTimestamps}
                    onChange={(e) => setIncludeTimestamps(e.target.checked)}
                    disabled={isBusy}
                    className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  Include timestamps
                </label>
              </div>
            </StepCard>
          )}

          {currentStep === 3 && completedSteps.has(2) && (
            <StepCard
              step={3}
              title="Generate Transcript"
              isActive={currentStep === 3}
              isCompleted={completedSteps.has(3)}
              summary={transcript.trim() ? `${transcriptWordCount} words • ${transcript.length} chars` : ""}
              description="Review your settings and generate the transcript."
            >
              <div className="space-y-4">
                {/* Settings summary */}
                <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/40 dark:bg-white/5 p-4 space-y-3">
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    Settings Summary
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-200 font-medium">
                      <span className="text-slate-400 dark:text-slate-500">Language:</span>
                      <span className="font-semibold">{RECOGNITION_LANGUAGES.find((l) => l.code === language)?.name || language}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-200 font-medium">
                      <span className="text-slate-400 dark:text-slate-500">Punctuation:</span>
                      <span className="font-semibold">{autoPunctuation ? "On" : "Off"}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-200 font-medium">
                      <span className="text-slate-400 dark:text-slate-500">Timestamps:</span>
                      <span className="font-semibold">{includeTimestamps ? "On" : "Off"}</span>
                    </div>
                  </div>
                </div>

                {/* Source file info */}
                {file && (
                  <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/40 dark:bg-white/5 p-4 space-y-3">
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                      Source File
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <span className="px-2.5 py-1.5 rounded-xl bg-white/70 dark:bg-white/10 border border-slate-200 dark:border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
                        {file.name}
                      </span>
                      <span className="px-2.5 py-1.5 rounded-xl bg-white/70 dark:bg-white/10 border border-slate-200 dark:border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
                        {formatDuration(durationSeconds)}
                      </span>
                      <span className="px-2.5 py-1.5 rounded-xl bg-white/70 dark:bg-white/10 border border-slate-200 dark:border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
                        {(file.size / (1024 * 1024)).toFixed(1)} MB
                      </span>
                      <span className="px-2.5 py-1.5 rounded-xl bg-white/70 dark:bg-white/10 border border-slate-200 dark:border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
                        {file.name.split('.').pop()?.toUpperCase() || "AUDIO"}
                      </span>
                    </div>
                  </div>
                )}

                {/* Usage / quota info */}
                <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/40 dark:bg-white/5 p-4 space-y-3">
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    Usage
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {estimatedMinutes != null && (
                      <span className="px-2.5 py-1.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-[10px] font-black uppercase tracking-widest text-indigo-700 dark:text-indigo-300">
                        Est. {estimatedMinutes.toFixed(2)} mins
                      </span>
                    )}
                    {isGuest && (
                      <span className="px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[10px] font-black uppercase tracking-widest text-amber-700 dark:text-amber-300">
                        Guest Trial
                      </span>
                    )}
                  </div>
                </div>

                <div className="text-sm text-slate-600 dark:text-slate-300 font-medium">
                  Click "Generate Transcript" in the navigation below to start transcribing your audio file.
                </div>
              </div>
            </StepCard>
          )}

          {currentStep === 4 && completedSteps.has(3) && (
            <StepCard
              step={4}
              title="Review & Export"
              isActive={currentStep === 4}
              isCompleted={completedSteps.has(3)}
              summary={transcript.trim() ? `${transcriptWordCount} words • ${transcript.length} chars` : "No transcript generated"}
              description="Review your transcript, make edits, and save it to your project."
            >
              <div className="space-y-4">
                {includeTimestamps && timestampedTranscript.trim() && (
                  <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-200 font-medium select-none">
                    <input
                      type="checkbox"
                      checked={showTimestamps}
                      onChange={(e) => setShowTimestamps(e.target.checked)}
                      className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    Show timestamps
                  </label>
                )}

                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold">
                  <div>{transcriptWordCount} words</div>
                  <div>{transcript.length} characters</div>
                </div>

                 <div className="rounded-2xl border border-sky-500/20 bg-sky-500/10 p-4 text-sm font-semibold text-sky-900 dark:text-sky-100">
                  {RETENTION_MESSAGE}
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold">
                  <div>
                    Stored transcript: {transcriptFileRecord?.fileId ? "Saved" : "Not saved yet"}
                  </div>
                  <div>
                    {transcriptFileRecord?.expiresAt ? `Stored until: ${formatDateTime(transcriptFileRecord.expiresAt)}` : "Save to project to store this transcript"}
                  </div>
                </div>

                <textarea
                  value={transcript}
                  onChange={(e) => {
                    const next = e.target.value;
                    setTranscript(next);
                    if (includeTimestamps && showTimestamps) setTimestampedTranscript(next);
                  }}
                  className="w-full min-h-[240px] max-h-[370px] p-4 rounded-2xl bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white resize-y font-medium text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                />

                <div className="flex flex-col sm:flex-row gap-3">
                  {isGuest ? (
                    <>
                      <button
                        type="button"
                        onClick={downloadTxt}
                        className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center"
                      >
                        Download .txt
                      </button>
                      <button
                        type="button"
                        onClick={downloadDoc}
                        className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center"
                      >
                        Download .doc
                      </button>
                      <button
                        type="button"
                        onClick={copyText}
                        className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center"
                      >
                        {copySuccess ? "Copied!" : "Copy"}
                      </button>
                      <button
                        type="button"
                        onClick={() => setAuthRequiredOpen(true)}
                        className="px-4 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm"
                      >
                        Sign Up to Save
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={downloadTxt}
                        className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center"
                      >
                        Download .txt
                      </button>
                      <button
                        type="button"
                        onClick={downloadDoc}
                        className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center"
                      >
                        Download .doc
                      </button>
                      <button
                        type="button"
                        onClick={copyText}
                        className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center"
                      >
                        {copySuccess ? "Copied!" : "Copy"}
                      </button>
                      <button
                        type="button"
                        onClick={handleStartNew}
                        className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center"
                      >
                        Delete
                      </button>
                      <button
                        type="button"
                        onClick={handleSaveProjectClick}
                        disabled={
                          !transcript.trim() ||
                          outputUploadInProgress ||
                          isBusy ||
                          Boolean(projectModalPurpose)
                        }
                        className="px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-black uppercase tracking-widest transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Save to Project
                      </button>
                    </>
                  )}
                </div>
              </div>
            </StepCard>
          )}
          {error && (
            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
              <p className="text-red-600 dark:text-red-400 text-xs font-bold uppercase tracking-wide">{error}</p>
            </div>
          )}
        </div>
      </div>

      <BottomActionBar
        currentStep={currentStep}
        totalSteps={4}
        canGoBack={currentStep > 1}
        canGoForward={
          currentStep === 1
            ? Boolean(file && durationSeconds != null)
            : currentStep === 2
              ? Boolean(file && durationSeconds != null && language)
              : currentStep === 3
                ? true
                : false
        }
        primaryActionLabel={
          currentStep === 1
            ? "Continue"
            : currentStep === 2
              ? "Continue"
              : currentStep === 3
                ? "Generate Transcript"
                : ""
        }
        primaryActionDisabled={
          currentStep === 1
            ? !file || durationSeconds == null || isBusy
            : currentStep === 2
              ? !file || !language || isBusy
              : currentStep === 3
                ? isBusy || !file
                : false
        }
        primaryActionLoading={uploadPercent > 0 || (currentStep === 3 && isTranscribing) || (currentStep === 1 && step1Loading)}
        primaryActionProgress={uploadPercent > 0 ? uploadPercent : (currentStep === 3 ? transcribePercent : 0)}
        showPrimaryAction={currentStep !== 4}
        isGuestLocked={isGuest && currentStep === 3}
        onPrevious={() => {
          if (currentStep > 1) {
            void (async () => {
              const targetStep = (currentStep - 1) as StepType;
              const shouldProceed = await handleStepNavigation(targetStep);
              if (shouldProceed) {
                setCurrentStep(targetStep);
              }
            })();
          }
        }}
        onPrimaryAction={() => {
          if (currentStep === 1) {
            void handleStep1Continue();
          } else if (currentStep === 2) {
            handleStep2Continue();
          } else if (currentStep === 3) {
            void handleStep3Generate();
          } else if (currentStep === 4) {
            handleSaveProjectClick();
          }
        }}
      />
    </div>
  );
};

export default TranscribePage;

const StepCard = ({
  step,
  title,
  isActive,
  isCompleted,
  summary,
  description,
  children,
}: {
  step: number;
  title: string;
  isActive: boolean;
  isCompleted: boolean;
  summary?: React.ReactNode;
  description?: React.ReactNode;
  children: React.ReactNode;
}) => {
  return (
    <div
      className={[
        "glass studio-card !p-8 transition-all",
        isActive ? "ring-2 ring-indigo-500/30" : "",
      ].join(" ")}
    >
      <div>
        <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">{title}</h2>
        {description ? (
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 font-medium">{description}</p>
        ) : null}
        {summary ? <div className="mt-2 text-sm font-semibold text-slate-600 dark:text-slate-300">{summary}</div> : null}
      </div>

      {summary && isCompleted ? null : null}

      <div className="pt-6">
        {children}
      </div>
    </div>
  );
};

const escapeHtml = (value: string): string => {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
};
