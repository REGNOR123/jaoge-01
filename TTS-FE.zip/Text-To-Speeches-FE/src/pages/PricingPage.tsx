import React, { useState, useEffect, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import Logo from "../components/app/Logo";
import { getPlans, getFeatureCosts, type PlanItem, type FeatureCostItem } from "../services/creditApiService";
import { getRazorpayKey, createOrder, verifyPayment } from "../services/paymentApiService";
import { useAuth } from "../contexts/AuthContext";
import { useCredits } from "../contexts/CreditContext";

// Razorpay window type
declare global {
  interface Window {
    Razorpay: new (options: object) => { open: () => void };
  }
}

type PlanFeature = { label: string; free: boolean; pro: boolean; ultra: boolean; highlight?: boolean };
type Currency = "USD" | "INR";

/* ── USD plan feature comparison (3-column) ── */
const FEATURES: PlanFeature[] = [
  { label: "Create AI Voice",             free: true,  pro: true,  ultra: true,  highlight: true },
  { label: "Transcribe Audio",            free: true,  pro: true,  ultra: true,  highlight: true },
  { label: "Speech Translate",            free: true,  pro: true,  ultra: true,  highlight: true },
  { label: "Translate & Dub",             free: true,  pro: true,  ultra: true,  highlight: true },
  { label: "AI Script Studio",            free: true,  pro: true,  ultra: true,  highlight: true },
  { label: "Regional Language Support",   free: true,  pro: true,  ultra: true,  highlight: true },
  { label: "AI Text Enhance",             free: true,  pro: true,  ultra: true  },
  { label: "Projects & Storage",          free: false, pro: true,  ultra: true  },
  { label: "Priority Processing",         free: false, pro: false, ultra: true  },
  { label: "API Access",                  free: false, pro: false, ultra: true  },
  { label: "Priority Support",            free: false, pro: false, ultra: true  },
];

/* ── INR plans — 6 tiers starting Free (1 USD = ₹94) ── */

const ALL_INR_FEATURES = [
  "Create AI Voice",
  "Transcribe Audio",
  "Speech Translate",
  "Translate & Dub",
  "Regional Language Support",
  "AI Script Studio",
  "AI Text Enhance",
  "Projects & Storage",
  "Priority Processing",
  "Priority Support",
];

const FALLBACK_PLANS: PlanItem[] = [
  { name: "free",  displayName: "Free",  monthlyPrice: 0,  annualPrice: 0,  inrMonthlyPrice: 0,    inrAnnualPrice: 0,    creditsPerMonth: 200,   isOneTimeGrant: true,  popular: false, badge: null, ctaLabel: "Get Started Free", features: [] },
  { name: "pro",   displayName: "Pro",   monthlyPrice: 9,  annualPrice: 7,  inrMonthlyPrice: 999,  inrAnnualPrice: 799,  creditsPerMonth: 6000,  isOneTimeGrant: false, popular: false, badge: null, ctaLabel: "Get Pro",          features: [] },
  { name: "ultra", displayName: "Ultra", monthlyPrice: 29, annualPrice: 23, inrMonthlyPrice: 1999, inrAnnualPrice: 1599, creditsPerMonth: 15000, isOneTimeGrant: false, popular: false, badge: null, ctaLabel: "Get Ultra",        features: [] },
];

/* ── Static regional pricing tiers (shown in credit guide) ── */
const REGIONAL_TIERS = [
  {
    label: "Standard voices",
    features: "Create AI Voice · Speech Translate · Translate & Dub",
    cost: "1 credit / 100 chars",
    note: "English, European, East Asian, Middle Eastern",
  },
  {
    label: "Regional voices (2×)",
    features: "Create AI Voice · Speech Translate · Translate & Dub",
    cost: "2 credits / 100 chars",
    note: "Indian (hi, ta, te, ml, bn, mr, gu, kn, pa, ur, or, as) & SE Asian (id, fil, ms, my, km, lo)",
    highlight: true,
  },
  {
    label: "Neural HD voices (3×)",
    features: "Create AI Voice",
    cost: "3 credits / 100 chars",
    note: "DragonHDLatestNeural ultra-quality voices",
  },
];

const FAQ = [
  {
    q: "What happens when I run out of credits?",
    a: "Your features will pause until you upgrade your plan or purchase a credit top-up. Your data and projects are never deleted — you can resume at any time.",
  },
  {
    q: "Do unused credits roll over to the next month?",
    a: "Pro and Ultra plan credits reset monthly. Free plan credits are a one-time welcome grant and do not renew automatically.",
  },
  {
    q: "Can I switch plans at any time?",
    a: "Yes. You can upgrade, downgrade, or cancel your plan at any time from your account settings. Upgrades take effect immediately.",
  },
  {
    q: "Is there a free trial for paid plans?",
    a: "Every new account starts with free credits — enough to explore all features including Regional Language Support. No credit card required to sign up.",
  },
  {
    q: "Why do regional languages cost more credits?",
    a: "Indian and Southeast Asian neural voices use specialised Azure models that carry a higher compute cost. Regional language usage (Create AI Voice, Speech Translate, Translate & Dub) is charged at 2× the standard rate. Neural HD voices are charged at 3×.",
  },
];

const Check: React.FC = () => (
  <svg className="w-5 h-5 text-indigo-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
  </svg>
);

const Dash: React.FC = () => (
  <svg className="w-5 h-5 text-slate-300 dark:text-slate-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
  </svg>
);

const PricingPage: React.FC = () => {
  const { isAuthenticated, token, user, updateUser } = useAuth();
  const { refreshBalance } = useCredits();
  const navigate = useNavigate();
  const [annual, setAnnual] = useState(false);
  const [currency, setCurrency] = useState<Currency>("INR");
  const [plans, setPlans] = useState<PlanItem[]>(FALLBACK_PLANS);
  const [featureCosts, setFeatureCosts] = useState<FeatureCostItem[]>([]);
  const [payingPlan, setPayingPlan] = useState<string | null>(null);
  const [paymentMessage, setPaymentMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [activePlan, setActivePlan] = useState<string | null>(user?.currentPlan ?? null);

  useEffect(() => {
    setActivePlan(user?.currentPlan ?? null);
  }, [user?.currentPlan]);

  const isActivePlan = (planName: string): boolean => {
    if (!isAuthenticated) return false;
    if (planName === 'free') return activePlan === 'free' || activePlan === null;
    return activePlan === planName;
  };

  useEffect(() => {
    getPlans().then((data) => { if (data.length > 0) setPlans(data); });
    getFeatureCosts().then((data) => { if (data.length > 0) setFeatureCosts(data); });
  }, []);

  // Load Razorpay checkout script once
  useEffect(() => {
    if (document.getElementById('razorpay-script')) return;
    const script = document.createElement('script');
    script.id = 'razorpay-script';
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    document.body.appendChild(script);
  }, []);

  const handleBuyPlan = useCallback(async (planId: string) => {
    if (!isAuthenticated || !token) {
      navigate('/login');
      return;
    }

    setPayingPlan(planId);
    setPaymentMessage(null);

    const keyId = await getRazorpayKey();
    if (!keyId) {
      setPaymentMessage({ type: 'error', text: 'Payment gateway unavailable. Please try again.' });
      setPayingPlan(null);
      return;
    }

    const order = await createOrder(token, planId, annual ? 'annual' : 'monthly');
    if (!order) {
      setPaymentMessage({ type: 'error', text: 'Failed to create order. Please try again.' });
      setPayingPlan(null);
      return;
    }

    const inrPlan = plans.find(p => p.name === planId);
    const options = {
      key: keyId,
      amount: order.amountPaise,
      currency: order.currency,
      name: 'TextToSpeeches.in',
      description: `${inrPlan?.displayName ?? planId} Plan — ${inrPlan?.creditsPerMonth.toLocaleString() ?? ''} credits`,
      order_id: order.orderId,
      prefill: {
        email: user?.email ?? '',
        name: user?.fullName ?? '',
      },
      theme: { color: '#6366f1' },
      handler: async (response: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) => {
        const result = await verifyPayment(
          token,
          response.razorpay_order_id,
          response.razorpay_payment_id,
          response.razorpay_signature
        );
        if (result) {
          setActivePlan(result.planName);
          updateUser({ ...user!, currentPlan: result.planName, credits: result.newBalance });
          refreshBalance();
          setPaymentMessage({
            type: 'success',
            text: `Payment successful! ${result.creditsGranted.toLocaleString()} credits added to your account.`,
          });
        } else {
          setPaymentMessage({ type: 'error', text: 'Payment received but verification failed. Contact support.' });
        }
        setPayingPlan(null);
      },
      modal: {
        ondismiss: () => setPayingPlan(null),
      },
    };

    const rzp = new window.Razorpay(options);
    rzp.open();
  }, [isAuthenticated, token, user, updateUser, refreshBalance, annual, navigate, plans]);

  const freePlan     = plans.find((p) => p.name === "free")  ?? FALLBACK_PLANS[0];
  const proPlan      = plans.find((p) => p.name === "pro")   ?? FALLBACK_PLANS[1];
  const ultraPlan    = plans.find((p) => p.name === "ultra" || p.name === "business") ?? FALLBACK_PLANS[2];
  const inrUltraPlan = plans.find((p) => p.name === "ultra");

  const proPrice   = annual ? proPlan.annualPrice   : proPlan.monthlyPrice;
  const ultraPrice = annual ? ultraPlan.annualPrice : ultraPlan.monthlyPrice;

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Nav */}
      <nav className="px-8 py-5 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link to="/dashboard"><Logo /></Link>
          <Link
            to="/dashboard"
            className="text-[10px] font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 transition-colors flex items-center gap-1.5"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to App
          </Link>
        </div>
      </nav>

      <main className="flex-1 max-w-6xl mx-auto w-full px-6 sm:px-8 py-16 space-y-20">

        {/* Hero */}
        <section className="text-center space-y-4">
          <p className="text-xs font-black uppercase tracking-widest text-indigo-500">Pricing</p>
          <h1 className="text-5xl sm:text-6xl font-black text-slate-900 dark:text-white tracking-tight">
            Simple, transparent pricing
          </h1>
          <p className="text-lg text-slate-500 dark:text-slate-400 font-medium max-w-xl mx-auto">
            Start free with {freePlan.creditsPerMonth.toLocaleString()} credits. Scale up when you need more.
            All plans include every feature — including Regional Language Support.
          </p>
        </section>

        {/* Payment message */}
        {paymentMessage && (
          <div className={`flex items-start gap-3 rounded-2xl px-5 py-4 border ${
            paymentMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-500/10 border-emerald-200 dark:border-emerald-500/20 text-emerald-800 dark:text-emerald-300'
              : 'bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/20 text-red-800 dark:text-red-300'
          }`}>
            <svg className="w-4 h-4 mt-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {paymentMessage.type === 'success'
                ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
              }
            </svg>
            <p className="text-sm font-semibold">{paymentMessage.text}</p>
            <button onClick={() => setPaymentMessage(null)} className="ml-auto shrink-0 opacity-60 hover:opacity-100">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        )}

        {/* Billing toggle + Currency toggle */}
        <section className="flex flex-col items-center gap-4">
          <div className="flex flex-col sm:flex-row items-center gap-3">
            {/* Billing cycle */}
            <div className="flex items-center gap-3 bg-white/70 dark:bg-white/5 border border-slate-200/60 dark:border-white/10 rounded-full px-2 py-1.5">
              <button
                onClick={() => setAnnual(false)}
                className={`px-4 py-1.5 rounded-full text-sm font-bold transition-all ${
                  !annual
                    ? "bg-indigo-600 text-white shadow-sm"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setAnnual(true)}
                className={`px-4 py-1.5 rounded-full text-sm font-bold transition-all flex items-center gap-2 ${
                  annual
                    ? "bg-indigo-600 text-white shadow-sm"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                }`}
              >
                Annual
                {annual && (
                  <span className="text-[10px] font-black uppercase tracking-wide bg-emerald-500 text-white px-1.5 py-0.5 rounded-full">
                    Save 20%
                  </span>
                )}
              </button>
            </div>

            {/* Currency toggle */}
            <div className="flex items-center gap-1 bg-white/70 dark:bg-white/5 border border-slate-200/60 dark:border-white/10 rounded-full px-1.5 py-1.5">
              <button
                onClick={() => setCurrency("INR")}
                title="View prices in Indian Rupees"
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-bold transition-all ${
                  currency === "INR"
                    ? "bg-indigo-600 text-white shadow-sm"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                }`}
              >
                <span>🇮🇳</span> INR
              </button>
              <button
                onClick={() => setCurrency("USD")}
                title="View prices in US Dollars"
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-bold transition-all ${
                  currency === "USD"
                    ? "bg-indigo-600 text-white shadow-sm"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                }`}
              >
                <span>🇺🇸</span> USD
              </button>
            </div>
          </div>

          {!annual && (
            <p className="text-xs text-slate-400 dark:text-slate-500">
              Switch to annual billing and save ~20%
            </p>
          )}
          {annual && (
            <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
              You're saving with annual billing
            </p>
          )}
          {currency === "INR" && (
            <p className="text-xs text-slate-400 dark:text-slate-500">
              Prices shown in Indian Rupees (INR). Billing processed in USD equivalent.
            </p>
          )}
        </section>

        {/* Plan cards */}
        {currency === "USD" ? (
          /* ── USD: 3 plans (Free / Pro / Ultra) ── */
          <section className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">

            {/* Free */}
            <div className="bg-white/70 dark:bg-white/5 backdrop-blur-xl border border-slate-200/60 dark:border-white/10 rounded-3xl p-8 flex flex-col gap-6">
              <div>
                <p className="text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Free</p>
                <div className="flex items-end gap-1 mb-1">
                  <span className="text-4xl font-black text-slate-900 dark:text-white">$0</span>
                </div>
                <p className="text-xs text-slate-400">Forever free</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">{freePlan.creditsPerMonth.toLocaleString()} credits</p>
                <p className="text-xs text-slate-400">One-time welcome grant on signup</p>
              </div>
              {isActivePlan(freePlan.name) ? (
                <div className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200/60 dark:border-emerald-500/20">
                  <svg className="w-4 h-4 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-sm font-black text-emerald-700 dark:text-emerald-400">Currently Activated</span>
                </div>
              ) : !isAuthenticated ? (
                <Link to="/signup" className="block w-full text-center py-3 px-4 rounded-xl bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/15 text-slate-800 dark:text-white font-bold text-sm transition-colors">
                  Get Started Free
                </Link>
              ) : <div className="w-full py-3 px-4 invisible" aria-hidden="true" />}
              <ul className="space-y-3">
                {FEATURES.map((f) => (
                  <li key={f.label} className="flex items-center gap-3 text-sm">
                    {f.free ? <Check /> : <Dash />}
                    <span className={`flex items-center gap-1.5 ${f.free ? "text-slate-700 dark:text-slate-300" : "text-slate-400 dark:text-slate-600"}`}>
                      {f.label}
                      {f.highlight && f.free && <span className="text-[9px] font-black uppercase tracking-wider text-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 px-1.5 py-0.5 rounded-full leading-none">Core</span>}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Pro — highlighted */}
            <div className="relative bg-white dark:bg-white/10 backdrop-blur-xl border-2 border-indigo-500 rounded-3xl p-8 flex flex-col gap-6 shadow-xl shadow-indigo-500/10 md:scale-[1.03]">
              <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                <span className="px-3 py-1 rounded-full bg-indigo-600 text-white text-[11px] font-black uppercase tracking-widest shadow">Most Popular</span>
              </div>
              <div>
                <p className="text-xs font-black uppercase tracking-widest text-indigo-500 mb-2">Pro</p>
                <div className="flex items-end gap-1 mb-1">
                  <span className="text-4xl font-black text-slate-900 dark:text-white">${proPrice}</span>
                  <span className="text-slate-400 text-sm mb-1">/mo</span>
                </div>
                <p className="text-xs text-slate-400">{annual ? "billed annually" : "billed monthly"}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">{proPlan.creditsPerMonth.toLocaleString()} credits/month</p>
                <p className="text-xs text-slate-400">Renews every billing cycle</p>
              </div>
              {isActivePlan(proPlan.name) ? (
                <div className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200/60 dark:border-emerald-500/20">
                  <svg className="w-4 h-4 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-sm font-black text-emerald-700 dark:text-emerald-400">Currently Activated</span>
                </div>
              ) : isAuthenticated ? (
                <button
                  onClick={() => handleBuyPlan(proPlan.name)}
                  disabled={payingPlan === proPlan.name}
                  className="block w-full text-center py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm transition-colors shadow-sm disabled:opacity-70"
                >
                  {payingPlan === proPlan.name ? 'Processing…' : 'Start Pro'}
                </button>
              ) : (
                <Link to="/signup" className="block w-full text-center py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm transition-colors shadow-sm">
                  Start Pro
                </Link>
              )}
              <ul className="space-y-3">
                {FEATURES.map((f) => (
                  <li key={f.label} className="flex items-center gap-3 text-sm">
                    {f.pro ? <Check /> : <Dash />}
                    <span className={`flex items-center gap-1.5 ${f.pro ? "text-slate-700 dark:text-slate-300" : "text-slate-400 dark:text-slate-600"}`}>
                      {f.label}
                      {f.highlight && f.pro && <span className="text-[9px] font-black uppercase tracking-wider text-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 px-1.5 py-0.5 rounded-full leading-none">Core</span>}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Ultra */}
            <div className="bg-white/70 dark:bg-white/5 backdrop-blur-xl border border-slate-200/60 dark:border-white/10 rounded-3xl p-8 flex flex-col gap-6">
              <div>
                <p className="text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Ultra</p>
                <div className="flex items-end gap-1 mb-1">
                  <span className="text-4xl font-black text-slate-900 dark:text-white">${ultraPrice}</span>
                  <span className="text-slate-400 text-sm mb-1">/mo</span>
                </div>
                <p className="text-xs text-slate-400">{annual ? "billed annually" : "billed monthly"}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">{ultraPlan.creditsPerMonth.toLocaleString()} credits/month</p>
                <p className="text-xs text-slate-400">Renews every billing cycle</p>
              </div>
              {isActivePlan(ultraPlan.name) ? (
                <div className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200/60 dark:border-emerald-500/20">
                  <svg className="w-4 h-4 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-sm font-black text-emerald-700 dark:text-emerald-400">Currently Activated</span>
                </div>
              ) : isAuthenticated ? (
                <button
                  onClick={() => handleBuyPlan(ultraPlan.name)}
                  disabled={payingPlan === ultraPlan.name}
                  className="block w-full text-center py-3 px-4 rounded-xl bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-900 font-bold text-sm transition-colors disabled:opacity-70"
                >
                  {payingPlan === ultraPlan.name ? 'Processing…' : 'Start Ultra'}
                </button>
              ) : (
                <Link to="/signup" className="block w-full text-center py-3 px-4 rounded-xl bg-slate-900 dark:bg-white hover:bg-slate-800 dark:hover:bg-slate-100 text-white dark:text-slate-900 font-bold text-sm transition-colors">
                  Start Ultra
                </Link>
              )}
              <ul className="space-y-3">
                {FEATURES.map((f) => (
                  <li key={f.label} className="flex items-center gap-3 text-sm">
                    {f.ultra ? <Check /> : <Dash />}
                    <span className={`flex items-center gap-1.5 ${f.ultra ? "text-slate-700 dark:text-slate-300" : "text-slate-400 dark:text-slate-600"}`}>
                      {f.label}
                      {f.highlight && f.ultra && <span className="text-[9px] font-black uppercase tracking-wider text-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 px-1.5 py-0.5 rounded-full leading-none">Core</span>}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </section>
        ) : (
          /* ── INR: 6 plans starting Free ── */
          <section className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 items-start">
              {plans.map((plan) => {
                const price = annual ? plan.inrAnnualPrice : plan.inrMonthlyPrice;
                const isPopular = plan.popular;
                const isBest = !!plan.badge;
                const isFree = plan.isOneTimeGrant;
                const highlighted = isPopular || isBest;
                return (
                  <div
                    key={plan.name}
                    className={[
                      "relative flex flex-col gap-5 rounded-3xl p-6 backdrop-blur-xl",
                      highlighted
                        ? "bg-white dark:bg-white/10 border-2 border-indigo-500 shadow-xl shadow-indigo-500/10"
                        : "bg-white/70 dark:bg-white/5 border border-slate-200/60 dark:border-white/10",
                    ].join(" ")}
                  >
                    {/* Badge */}
                    {(isPopular || isBest) && (
                      <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                        <span className="px-3 py-1 rounded-full bg-indigo-600 text-white text-[11px] font-black uppercase tracking-widest shadow whitespace-nowrap">
                          {isPopular ? "Most Popular" : plan.badge}
                        </span>
                      </div>
                    )}

                    {/* Plan name */}
                    <div>
                      <p className={`text-xs font-black uppercase tracking-widest mb-2 ${highlighted ? "text-indigo-500" : "text-slate-400"}`}>
                        {plan.displayName}
                      </p>
                      <div className="flex items-end gap-0.5 mb-1">
                        {isFree ? (
                          <span className="text-3xl font-black text-slate-900 dark:text-white">₹0</span>
                        ) : (
                          <>
                            <span className="text-3xl font-black text-slate-900 dark:text-white">
                              ₹{price.toLocaleString("en-IN")}
                            </span>
                            <span className="text-slate-400 text-sm mb-1">/mo</span>
                          </>
                        )}
                      </div>
                      <p className="text-xs text-slate-400">
                        {isFree ? "Forever free" : annual ? "billed annually" : "billed monthly"}
                      </p>
                    </div>

                    {/* Credits */}
                    <div className="py-3 px-4 rounded-xl bg-indigo-50 dark:bg-indigo-500/10">
                      <p className="text-sm font-black text-indigo-700 dark:text-indigo-300">
                        ⚡ {plan.creditsPerMonth.toLocaleString()} credits{isFree ? " (one-time)" : "/mo"}
                      </p>
                    </div>

                    {/* CTA */}
                    {isActivePlan(plan.name) ? (
                      <div className="flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200/60 dark:border-emerald-500/20">
                        <svg className="w-4 h-4 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-sm font-black text-emerald-700 dark:text-emerald-400">Currently Activated</span>
                      </div>
                    ) : isFree ? (
                      !isAuthenticated ? (
                        <Link
                          to="/signup"
                          className="block w-full text-center py-2.5 px-4 rounded-xl font-bold text-sm transition-colors bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/15 text-slate-800 dark:text-white"
                        >
                          {plan.ctaLabel ?? 'Get Started Free'}
                        </Link>
                      ) : <div className="w-full py-2.5 px-4 invisible" aria-hidden="true" />
                    ) : (
                      <button
                        onClick={() => handleBuyPlan(plan.name)}
                        disabled={payingPlan === plan.name}
                        className={[
                          "w-full py-2.5 px-4 rounded-xl font-bold text-sm transition-colors",
                          highlighted
                            ? "bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm disabled:opacity-70"
                            : "bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/15 text-slate-800 dark:text-white disabled:opacity-70",
                        ].join(" ")}
                      >
                        {payingPlan === plan.name ? (
                          <span className="flex items-center justify-center gap-2">
                            <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                            </svg>
                            Processing…
                          </span>
                        ) : (plan.ctaLabel ?? plan.displayName)}
                      </button>
                    )}

                    {/* Features */}
                    <ul className="space-y-2.5">
                      {ALL_INR_FEATURES.map((feat) => {
                        const included = plan.features.includes(feat);
                        return (
                          <li key={feat} className="flex items-center gap-2 text-sm">
                            {included ? <Check /> : <Dash />}
                            <span className={included ? "text-slate-700 dark:text-slate-300" : "text-slate-400 dark:text-slate-600"}>
                              {feat}
                            </span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                );
              })}
            </div>

            {/* Annual savings callout */}
            {annual && inrUltraPlan && inrUltraPlan.inrMonthlyPrice > 0 && (
              <p className="text-center text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                Annual prices shown above — you save up to ₹{((inrUltraPlan.inrMonthlyPrice - inrUltraPlan.inrAnnualPrice) * 12).toLocaleString('en-IN')} per year on the Ultra plan
              </p>
            )}
          </section>
        )}

        {/* Credit usage guide */}
        <section className="space-y-8">
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              Credit usage guide
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm">
              Every action costs a fixed number of credits. Here's the full breakdown.
            </p>
          </div>

          {/* Dynamic feature cost table */}
          {featureCosts.length > 0 && (
            <div className="bg-white/70 dark:bg-white/5 backdrop-blur-xl border border-slate-200/60 dark:border-white/10 rounded-3xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200/60 dark:border-white/10">
                    <th className="text-left px-6 py-4 font-black text-slate-700 dark:text-slate-300 text-xs uppercase tracking-widest">Feature</th>
                    <th className="text-right px-6 py-4 font-black text-slate-700 dark:text-slate-300 text-xs uppercase tracking-widest">Cost</th>
                    <th className="text-right px-6 py-4 font-black text-slate-700 dark:text-slate-300 text-xs uppercase tracking-widest hidden sm:table-cell">Unit</th>
                  </tr>
                </thead>
                <tbody>
                  {featureCosts
                    .filter((r) => r.feature !== "translate-text")
                    .map((row, i) => {
                      const displayCost =
                        row.costPerNChars && row.costPerNChars > 0 && row.costPerNChars !== 1000
                          ? row.creditCost * Math.round(1000 / row.costPerNChars)
                          : row.creditCost;
                      const isCore = [
                        "create-voice",
                        "transcribe",
                        "speech-translate",
                        "translate-dub",
                        "script-generate",
                      ].includes(row.feature);
                      const isRegional = row.feature.includes("regional") || row.feature.includes("hd");
                      return (
                        <tr
                          key={row.feature}
                          className={`border-b border-slate-100 dark:border-white/5 last:border-0 ${
                            isRegional
                              ? "bg-amber-50/50 dark:bg-amber-500/[0.04]"
                              : isCore
                                ? "bg-indigo-50/40 dark:bg-indigo-500/[0.05]"
                                : i % 2 === 0
                                  ? ""
                                  : "bg-slate-50/50 dark:bg-white/[0.02]"
                          }`}
                        >
                          <td className="px-6 py-4 font-semibold text-slate-800 dark:text-slate-200">
                            <span className="flex items-center gap-2">
                              {row.displayName}
                              {isRegional && (
                                <span className="text-[9px] font-black uppercase tracking-wider text-amber-600 bg-amber-100 dark:bg-amber-500/20 px-1.5 py-0.5 rounded-full leading-none">Regional</span>
                              )}
                              {isCore && !isRegional && (
                                <span className="text-[9px] font-black uppercase tracking-wider text-indigo-500 bg-indigo-100 dark:bg-indigo-500/20 px-1.5 py-0.5 rounded-full leading-none">Core</span>
                              )}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <span className={`inline-flex items-center gap-1 font-black ${isRegional ? "text-amber-600 dark:text-amber-400" : "text-indigo-600 dark:text-indigo-400"}`}>
                              <span className="text-base leading-none">⚡</span>
                              {displayCost} {displayCost === 1 ? "credit" : "credits"}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right text-slate-400 dark:text-slate-500 hidden sm:table-cell">{row.displayUnit}</td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          )}

          {/* Regional language pricing tiers */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <h3 className="text-lg font-black text-slate-900 dark:text-white">Regional Language Pricing</h3>
              <span className="text-[10px] font-black uppercase tracking-widest text-amber-600 bg-amber-100 dark:bg-amber-500/20 px-2 py-0.5 rounded-full">New</span>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Voice synthesis rates vary by language region across Create AI Voice, Speech Translate, and Translate &amp; Dub.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {REGIONAL_TIERS.map((tier) => (
                <div
                  key={tier.label}
                  className={[
                    "rounded-2xl border p-5 space-y-3",
                    tier.highlight
                      ? "border-amber-500/30 bg-amber-50 dark:bg-amber-500/10"
                      : "border-slate-200/60 dark:border-white/10 bg-white/70 dark:bg-white/5",
                  ].join(" ")}
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className={`text-sm font-black ${tier.highlight ? "text-amber-900 dark:text-amber-200" : "text-slate-900 dark:text-white"}`}>
                      {tier.label}
                    </p>
                    <span className={`text-xs font-black whitespace-nowrap ${tier.highlight ? "text-amber-600 dark:text-amber-400" : "text-indigo-600 dark:text-indigo-400"}`}>
                      ⚡ {tier.cost}
                    </span>
                  </div>
                  <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">{tier.features}</p>
                  <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-relaxed">{tier.note}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="space-y-6 max-w-2xl mx-auto w-full">
          <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight text-center">
            Frequently asked questions
          </h2>

          <div className="space-y-3">
            {FAQ.map((item) => (
              <details
                key={item.q}
                className="group bg-white/70 dark:bg-white/5 backdrop-blur-xl border border-slate-200/60 dark:border-white/10 rounded-2xl overflow-hidden"
              >
                <summary className="flex items-center justify-between gap-4 px-6 py-5 cursor-pointer list-none font-bold text-slate-800 dark:text-slate-200 text-sm select-none">
                  {item.q}
                  <svg
                    className="w-4 h-4 text-slate-400 shrink-0 group-open:rotate-180 transition-transform"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </summary>
                <p className="px-6 pb-5 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                  {item.a}
                </p>
              </details>
            ))}
          </div>
        </section>

        {/* Bottom CTA — only shown to guests */}
        {!isAuthenticated && (
          <section className="text-center space-y-5 py-8">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              Ready to get started?
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm">
              No credit card required. {freePlan.creditsPerMonth.toLocaleString()} free credits on signup.
            </p>
            <div className="flex items-center justify-center gap-3 flex-wrap">
              <Link
                to="/signup"
                className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm transition-colors shadow-sm"
              >
                Sign Up Free
              </Link>
              <Link
                to="/dashboard"
                className="px-6 py-3 rounded-xl bg-white/70 dark:bg-white/5 border border-slate-200/60 dark:border-white/10 hover:bg-white dark:hover:bg-white/10 text-slate-700 dark:text-slate-300 font-bold text-sm transition-colors"
              >
                Explore the App
              </Link>
            </div>
          </section>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-black/5 dark:border-white/5 px-8 py-6">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400 dark:text-slate-500">
          <Logo />
          <div className="flex items-center gap-6">
            <Link to="/about" className="hover:text-slate-600 dark:hover:text-slate-300 transition-colors">About</Link>
            <Link to="/privacy" className="hover:text-slate-600 dark:hover:text-slate-300 transition-colors">Privacy</Link>
            <Link to="/terms" className="hover:text-slate-600 dark:hover:text-slate-300 transition-colors">Terms</Link>
            <Link to="/help" className="hover:text-slate-600 dark:hover:text-slate-300 transition-colors">Help</Link>
          </div>
          <p>© {new Date().getFullYear()} TextToSpeeches.in</p>
        </div>
      </footer>
    </div>
  );
};

export default PricingPage;
