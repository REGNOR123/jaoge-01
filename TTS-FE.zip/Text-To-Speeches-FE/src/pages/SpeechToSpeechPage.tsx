import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import * as SpeechSDK from 'microsoft-cognitiveservices-speech-sdk';
import { AVAILABLE_VOICES } from '../constants';
import { VoiceName } from '../types';
import { getSpeechToken } from '../services/speechTokenService';
import { detectTextLanguageCode, translateText } from '../services/langService';
import { useAuth } from '../contexts/AuthContext';
import AuthRequiredModal from '../components/AuthRequiredModal';

const RECOGNITION_LANGUAGES = [
  { code: 'en-US', name: 'English (US)' },
  { code: 'en-GB', name: 'English (UK)' },
  { code: 'hi-IN', name: 'Hindi (India)' },
  { code: 'fr-FR', name: 'French (France)' },
  { code: 'de-DE', name: 'German (Germany)' },
  { code: 'es-ES', name: 'Spanish (Spain)' },
  { code: 'ja-JP', name: 'Japanese (Japan)' },
  { code: 'ko-KR', name: 'Korean (Korea)' },
  { code: 'zh-CN', name: 'Chinese (Mandarin)' },
];

const DEFAULT_RECOGNITION_LANGUAGE =
  (import.meta.env.VITE_DEFAULT_RECOGNITION_LANGUAGE as string | undefined) || 'en-US';

const DEFAULT_OUTPUT_VOICE =
  (import.meta.env.VITE_DEFAULT_SPEECH_TO_SPEECH_VOICE as VoiceName | undefined) ||
  VoiceName.JENNY;

const getLocaleFromVoice = (voice: VoiceName): string => {
  const parts = String(voice).split('-');
  const locale = parts.length >= 2 ? `${parts[0]}-${parts[1]}` : parts[0];
  return locale || 'en-US';
};

const DEFAULT_TARGET_LANGUAGE =
  (import.meta.env.VITE_DEFAULT_SPEECH_TO_SPEECH_TARGET_LANGUAGE as string | undefined) ||
  getLocaleFromVoice(DEFAULT_OUTPUT_VOICE);

const defaultVoiceForLocale = (
  locale: string,
  gender?: 'Male' | 'Female',
): VoiceName => {
  const matches = AVAILABLE_VOICES.filter((v) => String(v.id).startsWith(`${locale}-`));
  const genderMatch = gender ? matches.find((v) => v.gender === gender) : null;
  const best = genderMatch || matches[0] || AVAILABLE_VOICES[0];
  return (best?.id as VoiceName) || VoiceName.JENNY;
};

const shouldRetryToken = (errorDetails: string): boolean => {
  return /401|403|auth|authorization|token|expired/i.test(errorDetails);
};

type ConnectionStatus = 'Connected' | 'Reconnecting' | 'Offline';
type ProcessingState =
  | 'Idle'
  | 'Starting'
  | 'Listening'
  | 'Translating'
  | 'Speaking'
  | 'Stopping'
  | 'Error';

type ConversationMode = 'single' | 'two_way' | 'auto_detect';
type SpeakerTag = 'You' | 'Person 2' | 'AI' | 'System';

type ConversationMessage = {
  id: string;
  speaker: SpeakerTag;
  text: string;
  ts: number;
  meta?: {
    fromLang?: string;
    toLang?: string;
    kind?: 'source' | 'translation' | 'status';
    isLatest?: boolean;
  };
};

type SpeakQueueItem = {
  id: string;
  text: string;
  startedAtMs: number;
  fromLang: string;
  toLang: string;
  voice: VoiceName;
};

const createId = (): string => {
  const anyCrypto = globalThis.crypto as any;
  if (anyCrypto?.randomUUID) return anyCrypto.randomUUID();
  return `${Date.now()}_${Math.random().toString(16).slice(2)}`;
};

const toTranslatorLanguage = (locale: string): string => {
  const base = String(locale).split('-')[0] || 'en';
  if (base.toLowerCase() === 'nb') return 'no';
  return base;
};

const escapeXml = (value: string): string => {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
};

const getMicrophoneStream = async (
  setError: (message: string | null) => void,
  audioConstraints?: MediaTrackConstraints,
): Promise<MediaStream | null> => {
  if (!navigator.mediaDevices?.getUserMedia) {
    setError('Microphone is not supported in this browser.');
    return null;
  }

  try {
    return await navigator.mediaDevices.getUserMedia({
      audio: audioConstraints ? audioConstraints : true,
    });
  } catch (err: any) {
    const permissionDenied =
      err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError';
    setError(
      permissionDenied
        ? 'Microphone permission denied. Please allow microphone access and try again.'
        : 'Unable to access microphone. Please check your input device and try again.',
    );
    return null;
  }
};

const SpeechToSpeechPage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [recognitionLanguage, setRecognitionLanguage] = useState(
    DEFAULT_RECOGNITION_LANGUAGE,
  );
  const [targetLanguage, setTargetLanguage] = useState(DEFAULT_TARGET_LANGUAGE);
  const [outputVoice, setOutputVoice] = useState<VoiceName>(DEFAULT_OUTPUT_VOICE);
  const [sourceVoice, setSourceVoice] = useState<VoiceName>(
    defaultVoiceForLocale(DEFAULT_RECOGNITION_LANGUAGE),
  );

  const [autoSpeak, setAutoSpeak] = useState(true);
  const [pauseWhileSpeaking, setPauseWhileSpeaking] = useState(true);
  const [translateEnabled, setTranslateEnabled] = useState(true);
  const [authRequiredOpen, setAuthRequiredOpen] = useState(false);

  const [conversationMode, setConversationMode] = useState<ConversationMode>('single');
  const [twoWayTurn, setTwoWayTurn] = useState<'source' | 'target'>('source');
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>(
    navigator.onLine ? 'Connected' : 'Offline',
  );
  const [processingState, setProcessingState] = useState<ProcessingState>('Idle');
  const [lastLatencyMs, setLastLatencyMs] = useState<number | null>(null);
  const [lastTranslationMs, setLastTranslationMs] = useState<number | null>(null);
  const [lastSynthesisMs, setLastSynthesisMs] = useState<number | null>(null);

  const [noiseSuppression, setNoiseSuppression] = useState(true);
  const [echoCancellation, setEchoCancellation] = useState(true);
  const [autoGainControl, setAutoGainControl] = useState(true);
  const [autoPunctuation, setAutoPunctuation] = useState(true);
  const [emotionTone, setEmotionTone] = useState<'neutral' | 'friendly' | 'cheerful' | 'empathetic' | 'angry'>(
    'neutral',
  );
  const [speechSpeed, setSpeechSpeed] = useState(1);
  const [voiceGenderFilter, setVoiceGenderFilter] = useState<'Any' | 'Male' | 'Female'>('Any');

  const [micLevel, setMicLevel] = useState(0);
  const [showMicPermissionDialog, setShowMicPermissionDialog] = useState(false);

  const [transcriptHistory, setTranscriptHistory] = useState<
    { id: string; text: string; ts: number; fromLang: string }[]
  >([]);
  const [translationHistory, setTranslationHistory] = useState<
    { id: string; text: string; ts: number; toLang: string }[]
  >([]);
  const [conversationHistory, setConversationHistory] = useState<ConversationMessage[]>([]);
  const [latestTranslationId, setLatestTranslationId] = useState<string | null>(null);

  const [isRunning, setIsRunning] = useState(false);
  const [isStarting, setIsStarting] = useState(false);
  const [status, setStatus] = useState('Ready');
  const [partialText, setPartialText] = useState('');
  const [finalText, setFinalText] = useState('');
  const [spokenText, setSpokenText] = useState('');
  const [spokenCount, setSpokenCount] = useState(0);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [convertedAudioUrl, setConvertedAudioUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hasRetriedToken, setHasRetriedToken] = useState(false);

  const recognizerRef = useRef<SpeechSDK.SpeechRecognizer | null>(null);
  const synthesizerRef = useRef<SpeechSDK.SpeechSynthesizer | null>(null);
  const speakerDestinationRef = useRef<any>(null);
  const queueRef = useRef<SpeakQueueItem[]>([]);
  const isSpeakingRef = useRef(false);
  const isStoppingRef = useRef(false);
  const hasRetriedTokenRef = useRef(false);
  const isRunningRef = useRef(false);
  const isStartingRef = useRef(false);
  const errorRef = useRef<string | null>(null);
  const finalTextRef = useRef('');
  const spokenTextRef = useRef('');
  const enqueueChainRef = useRef<Promise<void>>(Promise.resolve());

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioChunksRef = useRef<BlobPart[]>([]);
  const recordedAudioUrlRef = useRef<string | null>(null);
  const convertedAudioUrlRef = useRef<string | null>(null);
  const playbackAudioRef = useRef<HTMLAudioElement | null>(null);

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const micMeterRafRef = useRef<number | null>(null);

  const [isPlaybackPlaying, setIsPlaybackPlaying] = useState(false);

  useEffect(() => {
    isRunningRef.current = isRunning;
  }, [isRunning]);

  useEffect(() => {
    isStartingRef.current = isStarting;
  }, [isStarting]);

  useEffect(() => {
    errorRef.current = error;
  }, [error]);

  useEffect(() => {
    finalTextRef.current = finalText;
  }, [finalText]);

  useEffect(() => {
    spokenTextRef.current = spokenText;
  }, [spokenText]);

  useEffect(() => {
    hasRetriedTokenRef.current = hasRetriedToken;
  }, [hasRetriedToken]);

  useEffect(() => {
    const handleOnline = () => setConnectionStatus('Connected');
    const handleOffline = () => setConnectionStatus('Offline');
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    const audio = playbackAudioRef.current;
    if (!audio) return;
    audio.playbackRate = speechSpeed;
  }, [speechSpeed, convertedAudioUrl]);

  useEffect(() => {
    const audio = playbackAudioRef.current;
    if (!audio) return;

    const onPlay = () => setIsPlaybackPlaying(true);
    const onPause = () => setIsPlaybackPlaying(false);
    const onEnded = () => setIsPlaybackPlaying(false);

    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('ended', onEnded);

    return () => {
      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('ended', onEnded);
    };
  }, []);

  const outputVoiceLabel = useMemo(() => {
    const voiceInfo = AVAILABLE_VOICES.find((v) => v.id === outputVoice);
    return voiceInfo ? `${voiceInfo.name} (${voiceInfo.lang})` : outputVoice;
  }, [outputVoice]);

  const targetTranslatorCode = useMemo(() => {
    return toTranslatorLanguage(targetLanguage);
  }, [targetLanguage]);

  useEffect(() => {
    if (!String(outputVoice).startsWith(`${targetLanguage}-`)) {
      setOutputVoice(defaultVoiceForLocale(targetLanguage));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetLanguage]);

  useEffect(() => {
    if (!String(sourceVoice).startsWith(`${recognitionLanguage}-`)) {
      setSourceVoice(defaultVoiceForLocale(recognitionLanguage));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recognitionLanguage]);

  const startAudioCapture = (stream: MediaStream) => {
    if (typeof MediaRecorder === 'undefined') {
      return;
    }

    audioChunksRef.current = [];
    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorderRef.current = mediaRecorder;

    mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        audioChunksRef.current.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      const chunks = audioChunksRef.current;
      if (!chunks.length) return;

      const blob = new Blob(chunks, { type: 'audio/webm' });
      const nextUrl = URL.createObjectURL(blob);

      if (recordedAudioUrlRef.current) {
        URL.revokeObjectURL(recordedAudioUrlRef.current);
      }
      recordedAudioUrlRef.current = nextUrl;
      setRecordedAudioUrl(nextUrl);
      audioChunksRef.current = [];
    };

    mediaRecorder.start();
  };

  const stopMicMeter = () => {
    if (micMeterRafRef.current) {
      cancelAnimationFrame(micMeterRafRef.current);
      micMeterRafRef.current = null;
    }

    analyserRef.current = null;

    const ctx = audioContextRef.current;
    audioContextRef.current = null;
    if (ctx) {
      try {
        void ctx.close();
      } catch {
        // ignore
      }
    }

    setMicLevel(0);
  };

  const startMicMeter = (stream: MediaStream) => {
    stopMicMeter();

    const AudioContextCtor = (window.AudioContext || (window as any).webkitAudioContext) as
      | typeof AudioContext
      | undefined;
    if (!AudioContextCtor) return;

    const ctx = new AudioContextCtor();
    audioContextRef.current = ctx;

    const source = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 2048;
    analyserRef.current = analyser;
    source.connect(analyser);

    const data = new Float32Array(analyser.fftSize);

    const tick = () => {
      const node = analyserRef.current;
      if (!node) return;

      node.getFloatTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i += 1) {
        const v = data[i] || 0;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / data.length);
      const nextLevel = Math.max(0, Math.min(1, rms * 3.5));
      setMicLevel(nextLevel);

      micMeterRafRef.current = requestAnimationFrame(tick);
    };

    micMeterRafRef.current = requestAnimationFrame(tick);
  };

  const stopAndClearMediaStream = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
  };

  const stopAudioCapture = async () => {
    const mediaRecorder = mediaRecorderRef.current;
    if (!mediaRecorder) {
      stopAndClearMediaStream();
      return;
    }

    await new Promise<void>((resolve) => {
      if (mediaRecorder.state === 'inactive') {
        resolve();
        return;
      }

      mediaRecorder.onstop = ((originalHandler) => () => {
        if (originalHandler) originalHandler.call(mediaRecorder, new Event('stop'));
        resolve();
      })(mediaRecorder.onstop as any);

      mediaRecorder.stop();
    });

    mediaRecorderRef.current = null;
    stopAndClearMediaStream();
  };

  const closeRecognizer = () => {
    if (recognizerRef.current) {
      recognizerRef.current.close();
      recognizerRef.current = null;
    }
  };

  const closeSynthesizer = () => {
    try {
      synthesizerRef.current?.close();
    } catch {
      // ignore
    }
    synthesizerRef.current = null;

    try {
      speakerDestinationRef.current?.close?.();
    } catch {
      // ignore
    }
    speakerDestinationRef.current = null;
  };

  const stopRecognizerAsync = async () => {
    const recognizer = recognizerRef.current;
    if (!recognizer) return;
    await new Promise<void>((resolve) => {
      recognizer.stopContinuousRecognitionAsync(
        () => resolve(),
        () => resolve(),
      );
    });
  };

  const stopAllAsync = async () => {
    isStoppingRef.current = true;
    isSpeakingRef.current = false;
    queueRef.current = [];

    await stopRecognizerAsync();
    closeRecognizer();
    closeSynthesizer();
    await stopAudioCapture();
    stopMicMeter();

    isStoppingRef.current = false;
  };

  const startRecognizerAsync = async () => {
    const recognizer = recognizerRef.current;
    if (!recognizer) return;
    await new Promise<void>((resolve, reject) => {
      recognizer.startContinuousRecognitionAsync(
        () => resolve(),
        (err) => reject(err),
      );
    });
  };

  const tryRestartWithFreshToken = async () => {
    if (hasRetriedTokenRef.current) return;
    hasRetriedTokenRef.current = true;
    setHasRetriedToken(true);
    setStatus('Refreshing token...');

    await stopAllAsync();

    if (isRunningRef.current || isStartingRef.current) {
      await startSession(true);
    }
  };

  const processQueue = async () => {
    if (!autoSpeak) return;
    if (isStoppingRef.current) return;
    if (isSpeakingRef.current) return;

    const next = queueRef.current.shift();
    if (!next) return;

    const synthesizer = synthesizerRef.current;
    if (!synthesizer) return;

    isSpeakingRef.current = true;
    setProcessingState('Speaking');
    setStatus('Speaking');

    try {
      if (pauseWhileSpeaking) {
        await stopRecognizerAsync();
      }

      const speakStartMs = performance.now();
      const ratePct = Math.round((speechSpeed - 1) * 100);
      const rate = `${ratePct >= 0 ? '+' : ''}${ratePct}%`;
      const style = emotionTone === 'neutral' ? null : emotionTone;

      const ssml = `
        <speak version="1.0" xml:lang="${escapeXml(next.toLang)}"
          xmlns="http://www.w3.org/2001/10/synthesis"
          xmlns:mstts="http://www.w3.org/2001/mstts">
          <voice name="${escapeXml(String(next.voice))}">
            ${style ? `<mstts:express-as style="${escapeXml(style)}">` : ''}
              <prosody rate="${escapeXml(rate)}">${escapeXml(next.text)}</prosody>
            ${style ? `</mstts:express-as>` : ''}
          </voice>
        </speak>
      `.trim();

      await new Promise<void>((resolve, reject) => {
        synthesizer.speakSsmlAsync(
          ssml,
          (result) => {
            const audioData = (result as any)?.audioData as ArrayBuffer | undefined;
            if (audioData && audioData.byteLength > 0) {
              const blob = new Blob([audioData], { type: 'audio/wav' });
              const nextUrl = URL.createObjectURL(blob);

              if (convertedAudioUrlRef.current) {
                URL.revokeObjectURL(convertedAudioUrlRef.current);
              }
              convertedAudioUrlRef.current = nextUrl;
              setConvertedAudioUrl(nextUrl);
            }
            if (result?.reason === SpeechSDK.ResultReason.SynthesizingAudioCompleted) {
              resolve();
              return;
            }
            reject(new Error(result?.errorDetails || 'Speech synthesis failed.'));
          },
          (speakErr) => reject(speakErr),
        );
      });

      setSpokenCount((prev) => prev + 1);
      setLastSynthesisMs(Math.max(0, Math.round(performance.now() - speakStartMs)));
      setLastLatencyMs(Math.max(0, Math.round(performance.now() - next.startedAtMs)));
    } catch (err: any) {
      const message = String(err?.message || err || '');
      if (shouldRetryToken(message)) {
        setConnectionStatus('Reconnecting');
        await tryRestartWithFreshToken();
      } else if (!isStoppingRef.current) {
        setError(message || 'Speech synthesis failed.');
        setStatus('Error');
        setProcessingState('Error');
      }
    } finally {
      isSpeakingRef.current = false;
      if (pauseWhileSpeaking && (isRunningRef.current || isStartingRef.current)) {
        try {
          await startRecognizerAsync();
          setStatus('Listening');
          setProcessingState('Listening');
        } catch {
          // ignore; recognizer canceled handler will surface issues
        }
      }

      if (!isStoppingRef.current && queueRef.current.length > 0) {
        void processQueue();
      }
    }
  };

  const createClients = async (forceRefreshToken: boolean) => {
    const tokenRes = await getSpeechToken({ forceRefresh: forceRefreshToken });
    if (!tokenRes.success || !tokenRes.data) {
      throw new Error(tokenRes.error || 'Speech service unavailable, try again.');
    }

    const recognitionConfig = SpeechSDK.SpeechConfig.fromAuthorizationToken(
      tokenRes.data.token,
      tokenRes.data.region,
    );
    const effectiveRecognitionLanguage =
      conversationMode === 'two_way' && twoWayTurn === 'target'
        ? targetLanguage
        : recognitionLanguage;
    recognitionConfig.speechRecognitionLanguage = effectiveRecognitionLanguage;

    if ((recognitionConfig as any)?.setProperty && (SpeechSDK as any)?.PropertyId) {
      const propertyId = (SpeechSDK as any).PropertyId
        .SpeechServiceResponse_PostProcessingOption as any;
      if (propertyId) {
        recognitionConfig.setProperty(propertyId, autoPunctuation ? 'TrueText' : 'None');
      }
    }

    const synthesisConfig = SpeechSDK.SpeechConfig.fromAuthorizationToken(
      tokenRes.data.token,
      tokenRes.data.region,
    );
    synthesisConfig.speechSynthesisVoiceName = outputVoice;
    synthesisConfig.speechSynthesisOutputFormat =
      SpeechSDK.SpeechSynthesisOutputFormat.Riff16Khz16BitMonoPcm;

    const micConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
    const recognizer = new SpeechSDK.SpeechRecognizer(recognitionConfig, micConfig);

    let synthesizer: SpeechSDK.SpeechSynthesizer;
    let speakerDestination: any = null;

    const hasSpeakerDestination = !!(SpeechSDK as any).SpeakerAudioDestination;
    const hasFromSpeakerOutput = !!(SpeechSDK.AudioConfig as any).fromSpeakerOutput;
    const hasFromDefaultSpeakerOutput = !!(SpeechSDK.AudioConfig as any).fromDefaultSpeakerOutput;

    if (hasSpeakerDestination && hasFromSpeakerOutput) {
      speakerDestination = new (SpeechSDK as any).SpeakerAudioDestination();
      const speakerAudioConfig = (SpeechSDK.AudioConfig as any).fromSpeakerOutput(speakerDestination);
      synthesizer = new SpeechSDK.SpeechSynthesizer(synthesisConfig, speakerAudioConfig);
    } else if (hasFromDefaultSpeakerOutput) {
      const speakerAudioConfig = (SpeechSDK.AudioConfig as any).fromDefaultSpeakerOutput();
      synthesizer = new SpeechSDK.SpeechSynthesizer(synthesisConfig, speakerAudioConfig);
    } else {
      synthesizer = new SpeechSDK.SpeechSynthesizer(synthesisConfig);
    }

    recognizerRef.current = recognizer;
    synthesizerRef.current = synthesizer;
    speakerDestinationRef.current = speakerDestination;

    recognizer.recognizing = (_sender, event) => {
      setPartialText(event.result.text || '');
      if (!isSpeakingRef.current) {
        setStatus('Listening');
        setProcessingState('Listening');
      }
    };

    recognizer.recognized = (_sender, event) => {
      if (event.result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
        const text = event.result.text?.trim();
        if (!text) return;

        const utteranceId = createId();
        const utteranceTs = Date.now();
        const fromLocale = effectiveRecognitionLanguage;

        if (conversationMode === 'two_way') {
          setTwoWayTurn((prev) => (prev === 'source' ? 'target' : 'source'));
        }

        setFinalText((prev) => (prev ? `${prev} ${text}` : text));
        setTranscriptHistory((prev) => [
          ...prev,
          { id: utteranceId, text, ts: utteranceTs, fromLang: fromLocale },
        ]);
        setConversationHistory((prev) => [
          ...prev,
          {
            id: utteranceId,
            speaker:
              conversationMode === 'two_way' && fromLocale === targetLanguage ? 'Person 2' : 'You',
            text,
            ts: utteranceTs,
            meta: { fromLang: fromLocale, kind: 'source' },
          },
        ]);
        setPartialText('');
        setStatus('Listening');
        setProcessingState('Listening');

        enqueueChainRef.current = enqueueChainRef.current
          .then(async () => {
            const startedAtMs = performance.now();

            let effectiveFrom = fromLocale;
            let effectiveTo =
              conversationMode === 'two_way' && fromLocale === targetLanguage
                ? recognitionLanguage
                : targetLanguage;

            if (conversationMode === 'auto_detect') {
              const detected = await detectTextLanguageCode(text);
              const sourceCode = toTranslatorLanguage(recognitionLanguage);
              const targetCode = toTranslatorLanguage(targetLanguage);
              if (detected && detected === targetCode) {
                effectiveFrom = targetLanguage;
                effectiveTo = recognitionLanguage;
              } else if (detected && detected === sourceCode) {
                effectiveFrom = recognitionLanguage;
                effectiveTo = targetLanguage;
              }
            }

            setProcessingState('Translating');
            setStatus('Translating');

            const translated = translateEnabled
              ? await translateText(text, toTranslatorLanguage(effectiveTo))
              : null;
            setLastTranslationMs(Math.max(0, Math.round(performance.now() - startedAtMs)));

            const toSpeak = (translated || text).trim();
            if (!toSpeak) return;

            setSpokenText((prev) => (prev ? `${prev} ${toSpeak}` : toSpeak));

            const translationId = createId();
            const translatedTs = Date.now();

            setTranslationHistory((prev) => [
              ...prev,
              { id: translationId, text: toSpeak, ts: translatedTs, toLang: effectiveTo },
            ]);
            setLatestTranslationId(translationId);
            setConversationHistory((prev) => [
              ...prev.map((m) =>
                m.meta?.isLatest ? { ...m, meta: { ...m.meta, isLatest: false } } : m,
              ),
              {
                id: translationId,
                speaker: 'AI',
                text: toSpeak,
                ts: translatedTs,
                meta: {
                  fromLang: effectiveFrom,
                  toLang: effectiveTo,
                  kind: 'translation',
                  isLatest: true,
                },
              },
            ]);

            if (autoSpeak) {
              const voice = effectiveTo === targetLanguage ? outputVoice : sourceVoice;
              queueRef.current.push({
                id: translationId,
                text: toSpeak,
                startedAtMs,
                fromLang: effectiveFrom,
                toLang: effectiveTo,
                voice,
              });
              void processQueue();
            } else {
              setProcessingState('Idle');
              setStatus('Ready');
            }
          })
          .catch(() => {
            // ignore enqueue chain errors
          });
      }
    };

    recognizer.canceled = (_sender, event) => {
      const details = event.errorDetails || '';
      if (shouldRetryToken(details)) {
        void tryRestartWithFreshToken();
        return;
      }

      if (!isStoppingRef.current) {
        setError(details || 'Speech recognition was canceled.');
        setStatus('Error');
        setProcessingState('Error');
        setIsRunning(false);
        setIsStarting(false);
      }
    };

    recognizer.sessionStopped = () => {
      if (!isStoppingRef.current && !errorRef.current) {
        setStatus('Stopped');
        setProcessingState('Idle');
        setIsRunning(false);
        setIsStarting(false);
      }
    };
  };

  const startSession = async (forceRefreshToken = false) => {
    setError(null);
    setStatus('Starting...');
    setIsStarting(true);
    setProcessingState('Starting');
    setPartialText('');
    setHasRetriedToken(false);
    hasRetriedTokenRef.current = false;
    queueRef.current = [];
    isSpeakingRef.current = false;
    enqueueChainRef.current = Promise.resolve();

    await stopAllAsync();

    setRecordedAudioUrl(null);
    if (recordedAudioUrlRef.current) {
      URL.revokeObjectURL(recordedAudioUrlRef.current);
      recordedAudioUrlRef.current = null;
    }
    setConvertedAudioUrl(null);
    if (convertedAudioUrlRef.current) {
      URL.revokeObjectURL(convertedAudioUrlRef.current);
      convertedAudioUrlRef.current = null;
    }

    const stream = await getMicrophoneStream(setError, {
      noiseSuppression,
      echoCancellation,
      autoGainControl,
    });
    if (!stream) {
      setStatus('Error');
      setProcessingState('Error');
      setShowMicPermissionDialog(true);
      setIsStarting(false);
      return;
    }
    mediaStreamRef.current = stream;
    startAudioCapture(stream);
    startMicMeter(stream);

    try {
      await createClients(forceRefreshToken);
      await startRecognizerAsync();
      setIsStarting(false);
      setIsRunning(true);
      setStatus(forceRefreshToken ? 'Listening (token refreshed)' : 'Listening');
      setProcessingState('Listening');
      setConnectionStatus(navigator.onLine ? 'Connected' : 'Offline');
    } catch (err: any) {
      const message = String(err?.message || err || 'Unable to start.');
      if (shouldRetryToken(message) && !hasRetriedTokenRef.current) {
        await tryRestartWithFreshToken();
        return;
      }

      setError(message || 'Unable to start.');
      setStatus('Error');
      setProcessingState('Error');
      setIsStarting(false);
      setIsRunning(false);
      await stopAllAsync();
    }
  };

  const handleStart = async () => {
    if (!isAuthenticated) {
      setAuthRequiredOpen(true);
      return;
    }
    if (isRunning || isStarting) return;
    setFinalText('');
    setSpokenText('');
    setSpokenCount(0);
    await startSession(false);
  };

  const handleStop = async () => {
    if (!isRunning && !isStarting) return;
    setStatus('Stopping...');
    setProcessingState('Stopping');
    setIsStarting(false);
    setIsRunning(false);
    await stopAllAsync();

    if (!finalTextRef.current.trim() && !errorRef.current) {
      setError('No speech detected.');
    }
    if (!errorRef.current) {
      setStatus('Stopped');
      setProcessingState('Idle');
    }
  };

  useEffect(() => {
    return () => {
      void stopAllAsync();
      if (recordedAudioUrlRef.current) {
        URL.revokeObjectURL(recordedAudioUrlRef.current);
        recordedAudioUrlRef.current = null;
      }
      if (convertedAudioUrlRef.current) {
        URL.revokeObjectURL(convertedAudioUrlRef.current);
        convertedAudioUrlRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const isBusy = isRunning || isStarting;
  const voiceOptions = useMemo(() => AVAILABLE_VOICES, []);
  const targetVoices = useMemo(() => {
    const voices = voiceOptions.filter((v) => String(v.id).startsWith(`${targetLanguage}-`));
    const filtered =
      voiceGenderFilter === 'Any' ? voices : voices.filter((v) => v.gender === voiceGenderFilter);
    return filtered.length ? filtered : voices;
  }, [voiceOptions, targetLanguage, voiceGenderFilter]);

  const sourceVoices = useMemo(() => {
    const voices = voiceOptions.filter((v) => String(v.id).startsWith(`${recognitionLanguage}-`));
    const filtered =
      voiceGenderFilter === 'Any' ? voices : voices.filter((v) => v.gender === voiceGenderFilter);
    return filtered.length ? filtered : voices;
  }, [voiceOptions, recognitionLanguage, voiceGenderFilter]);

  const micStatus: 'Listening' | 'Muted' | 'Error' =
    error ? 'Error' : isBusy ? 'Listening' : 'Muted';

  const formatTime = (ts: number) =>
    new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const handleSwapLanguages = () => {
    if (isBusy) return;
    const nextSource = targetLanguage;
    const nextTarget = recognitionLanguage;
    const nextSourceVoice = outputVoice;
    const nextTargetVoice = sourceVoice;

    setRecognitionLanguage(nextSource);
    setTargetLanguage(nextTarget);
    setSourceVoice(nextSourceVoice);
    setOutputVoice(nextTargetVoice);
    setTwoWayTurn('source');
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setStatus('Copied');
    } catch {
      setError('Copy failed. Your browser may block clipboard access.');
    }
  };

  const exportHistoryTxt = () => {
    const lines = conversationHistory.map((m) => `[${formatTime(m.ts)}] ${m.speaker}: ${m.text}`);
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'conversation.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const exportHistoryPdf = () => {
    const html = `
      <html>
        <head>
          <title>Conversation</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 24px; }
            h1 { font-size: 18px; margin: 0 0 12px; }
            .row { margin: 10px 0; }
            .meta { color: #666; font-size: 12px; margin-bottom: 4px; }
            .text { font-size: 14px; }
          </style>
        </head>
        <body>
          <h1>Conversation History</h1>
          ${conversationHistory
            .map(
              (m) => `
                <div class="row">
                  <div class="meta">[${formatTime(m.ts)}] ${m.speaker}</div>
                  <div class="text">${String(m.text).replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
                </div>
              `,
            )
            .join('')}
        </body>
      </html>
    `.trim();

    const w = window.open('', '_blank', 'noopener,noreferrer');
    if (!w) {
      setError('Popup blocked. Allow popups to export PDF.');
      return;
    }
    w.document.open();
    w.document.write(html);
    w.document.close();
    w.focus();
    w.print();
  };

  const clearAllHistory = () => {
    setTranscriptHistory([]);
    setTranslationHistory([]);
    setConversationHistory([]);
    setLatestTranslationId(null);
    setFinalText('');
    setSpokenText('');
    setSpokenCount(0);
    setLastLatencyMs(null);
    setLastTranslationMs(null);
    setLastSynthesisMs(null);
  };

  const handleTogglePlayback = async () => {
    const audio = playbackAudioRef.current;
    if (!audio || !convertedAudioUrl) return;
    try {
      if (audio.paused) {
        audio.playbackRate = speechSpeed;
        await audio.play();
      } else {
        audio.pause();
      }
    } catch {
      setError('Audio playback failed. Try again.');
    }
  };

  const handleReplay = async () => {
    const audio = playbackAudioRef.current;
    if (!audio || !convertedAudioUrl) return;
    try {
      audio.currentTime = 0;
      audio.playbackRate = speechSpeed;
      await audio.play();
    } catch {
      setError('Replay failed. Try again.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <AuthRequiredModal
        isOpen={authRequiredOpen}
        onClose={() => setAuthRequiredOpen(false)}
        redirectTo="/speech-to-speech"
      />
      <nav className="px-8 py-6 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-[1200px] mx-auto">
          <div className="flex items-center justify-between mb-4">
            <Link to="/" className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2.5}
                    d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"
                  />
                </svg>
              </div>
              <h1 className="text-lg font-black tracking-tighter text-slate-900 dark:text-white uppercase leading-none">
                TextTo<span className="text-indigo-500">Speeches</span>
              </h1>
            </Link>
            <Link
              to="/"
              className="text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:text-indigo-500 transition-colors flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2.5}
                  d="M10 19l-7-7m0 0l7-7m-7 7h18"
                />
              </svg>
              Back
            </Link>
          </div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-slate-400 flex items-center gap-2">
            <Link to="/" className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              Home
            </Link>
            <span className="text-slate-400 dark:text-slate-600">›</span>
            <span className="text-slate-900 dark:text-white">Speech To Speech</span>
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-4xl mx-auto w-full px-8 py-16">
        <div className="mb-10">
          <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
            Real-Time Speech To Speech
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-400 font-medium">
            Speak into your microphone and hear it synthesized back in near real time.
          </p>
        </div>

        <div className="glass studio-card !p-6 space-y-6">
          {isBusy && (
            <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-600"></span>
                </span>
                <p className="text-sm font-bold text-rose-700 dark:text-rose-300 uppercase tracking-wide">
                  {isStarting ? 'Initializing microphone...' : 'Session running'}
                </p>
              </div>
              <p className="text-xs font-black text-rose-700 dark:text-rose-300 tabular-nums">
                Spoken: {spokenCount}
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <label className="w-full">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                Source Language
              </span>
              <select
                value={recognitionLanguage}
                onChange={(e) => {
                  setRecognitionLanguage(e.target.value);
                  setTwoWayTurn('source');
                }}
                disabled={isBusy}
                className="w-full px-4 py-2 rounded-lg bg-slate-100 dark:bg-black/30 border border-slate-200 dark:border-white/10 focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white font-medium text-sm disabled:opacity-60"
              >
                {RECOGNITION_LANGUAGES.map((language) => (
                  <option key={language.code} value={language.code}>
                    {language.name}
                  </option>
                ))}
              </select>
            </label>

            <div className="w-full flex items-end gap-2">
              <label className="w-full">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                  Target Language
                </span>
                <select
                  value={targetLanguage}
                  onChange={(e) => {
                    setTargetLanguage(e.target.value);
                    setTwoWayTurn('source');
                  }}
                  disabled={isBusy}
                  className="w-full px-4 py-2 rounded-lg bg-slate-100 dark:bg-black/30 border border-slate-200 dark:border-white/10 focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white font-medium text-sm disabled:opacity-60"
                >
                  {RECOGNITION_LANGUAGES.map((language) => (
                    <option key={language.code} value={language.code}>
                      {language.name}
                    </option>
                  ))}
                </select>
              </label>

              <button
                onClick={handleSwapLanguages}
                disabled={isBusy}
                className={`h-10 px-4 rounded-lg font-black text-xs uppercase tracking-wider border transition-all ${
                  isBusy
                    ? 'bg-slate-100 dark:bg-white/5 text-slate-300 dark:text-slate-700 cursor-not-allowed border-slate-200 dark:border-white/10'
                    : 'bg-white/70 dark:bg-white/5 text-slate-700 dark:text-slate-200 hover:bg-white border-slate-200 dark:border-white/10'
                }`}
                title="Swap (↔)"
              >
                ↔
              </button>
            </div>

            <label className="w-full">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                Conversation Mode
              </span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'single', label: 'Single' },
                  { id: 'two_way', label: 'Two-Way' },
                  { id: 'auto_detect', label: 'Auto' },
                ].map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      setConversationMode(opt.id as ConversationMode);
                      setTwoWayTurn('source');
                    }}
                    disabled={isBusy}
                    className={`px-3 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest border transition-colors ${
                      conversationMode === opt.id
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-white/10 hover:bg-slate-200 dark:hover:bg-white/10'
                    } ${isBusy ? 'opacity-60 cursor-not-allowed' : ''}`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              {conversationMode === 'two_way' && (
                <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-500">
                  Next turn: <span className="font-bold">{twoWayTurn === 'source' ? 'You' : 'Person 2'}</span>
                </div>
              )}
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <label className="w-full">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                Voice Gender
              </span>
              <select
                value={voiceGenderFilter}
                onChange={(e) => setVoiceGenderFilter(e.target.value as any)}
                disabled={isBusy}
                className="w-full px-4 py-2 rounded-lg bg-slate-100 dark:bg-black/30 border border-slate-200 dark:border-white/10 focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white font-medium text-sm disabled:opacity-60"
              >
                <option value="Any">Any</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </label>

            <label className="w-full">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                Target Voice
              </span>
              <select
                value={outputVoice}
                onChange={(e) => setOutputVoice(e.target.value as VoiceName)}
                disabled={isBusy}
                className="w-full px-4 py-2 rounded-lg bg-slate-100 dark:bg-black/30 border border-slate-200 dark:border-white/10 focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white font-medium text-sm disabled:opacity-60"
              >
                {(targetVoices.length ? targetVoices : voiceOptions).map((voice) => (
                  <option key={voice.id} value={voice.id}>
                    {voice.name} ({voice.lang}) - {voice.gender}
                  </option>
                ))}
              </select>
              <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-500">
                Selected: <span className="font-bold text-slate-700 dark:text-slate-300">{outputVoiceLabel}</span>
              </div>
            </label>

            <label className="w-full">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                Speed ({speechSpeed.toFixed(1)}x)
              </span>
              <input
                type="range"
                min={0.5}
                max={2}
                step={0.1}
                value={speechSpeed}
                onChange={(e) => setSpeechSpeed(parseFloat(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 px-4 py-3">
              <div>
                <div className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                  Noise suppression
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-500">
                  Helps in noisy environments
                </div>
              </div>
              <input
                type="checkbox"
                checked={noiseSuppression}
                onChange={(e) => setNoiseSuppression(e.target.checked)}
                disabled={isBusy}
                className="accent-indigo-600"
              />
            </label>

            <label className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 px-4 py-3">
              <div>
                <div className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                  Auto punctuation
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-500">
                  Cleaner transcript formatting
                </div>
              </div>
              <input
                type="checkbox"
                checked={autoPunctuation}
                onChange={(e) => setAutoPunctuation(e.target.checked)}
                disabled={isBusy}
                className="accent-indigo-600"
              />
            </label>

            <label className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 px-4 py-3">
              <div>
                <div className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                  Echo cancellation
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-500">
                  Reduces speaker feedback
                </div>
              </div>
              <input
                type="checkbox"
                checked={echoCancellation}
                onChange={(e) => setEchoCancellation(e.target.checked)}
                disabled={isBusy}
                className="accent-indigo-600"
              />
            </label>

            <label className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 px-4 py-3">
              <div>
                <div className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                  Auto gain control
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-500">
                  Stabilizes input volume
                </div>
              </div>
              <input
                type="checkbox"
                checked={autoGainControl}
                onChange={(e) => setAutoGainControl(e.target.checked)}
                disabled={isBusy}
                className="accent-indigo-600"
              />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label className="w-full">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                Emotion tone
              </span>
              <select
                value={emotionTone}
                onChange={(e) => setEmotionTone(e.target.value as any)}
                disabled={isBusy}
                className="w-full px-4 py-2 rounded-lg bg-slate-100 dark:bg-black/30 border border-slate-200 dark:border-white/10 focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white font-medium text-sm disabled:opacity-60"
              >
                <option value="neutral">Neutral</option>
                <option value="friendly">Friendly</option>
                <option value="cheerful">Cheerful</option>
                <option value="empathetic">Empathetic</option>
                <option value="angry">Angry</option>
              </select>
            </label>

            <label className="w-full">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                Source Voice (Two-Way)
              </span>
              <select
                value={sourceVoice}
                onChange={(e) => setSourceVoice(e.target.value as VoiceName)}
                disabled={isBusy}
                className="w-full px-4 py-2 rounded-lg bg-slate-100 dark:bg-black/30 border border-slate-200 dark:border-white/10 focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white font-medium text-sm disabled:opacity-60"
              >
                {(sourceVoices.length ? sourceVoices : voiceOptions).map((voice) => (
                  <option key={voice.id} value={voice.id}>
                    {voice.name} ({voice.lang}) - {voice.gender}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label className="flex items-center gap-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 px-4 py-3">
              <input
                type="checkbox"
                checked={autoSpeak}
                onChange={(e) => setAutoSpeak(e.target.checked)}
                disabled={isBusy}
                className="accent-indigo-600"
              />
              <div>
                <div className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                  Auto speak recognized text
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-500">
                  Plays back each final segment
                </div>
              </div>
            </label>

            <label className="flex items-center gap-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 px-4 py-3">
              <input
                type="checkbox"
                checked={pauseWhileSpeaking}
                onChange={(e) => setPauseWhileSpeaking(e.target.checked)}
                disabled={isBusy || !autoSpeak}
                className="accent-indigo-600"
              />
              <div>
                <div className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                  Pause listening while speaking
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-500">
                  Reduces echo/feedback loops
                </div>
              </div>
            </label>
          </div>

          <label className="flex items-center gap-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 px-4 py-3">
            <input
              type="checkbox"
              checked={translateEnabled}
              onChange={(e) => setTranslateEnabled(e.target.checked)}
              disabled={isBusy}
              className="accent-indigo-600"
            />
            <div>
              <div className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                Translate
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-500">
                Translates recognized text to <span className="font-bold">{targetTranslatorCode}</span> before speaking
              </div>
            </div>
          </label>

          <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 px-4 py-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span
                  className={`w-3 h-3 rounded-full ${
                    micStatus === 'Listening'
                      ? 'bg-emerald-500'
                      : micStatus === 'Muted'
                        ? 'bg-slate-300 dark:bg-slate-600'
                        : 'bg-rose-500'
                  }`}
                />
                <div>
                  <p className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                    Mic: {micStatus}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-500 tabular-nums">
                    Input level: {Math.round(micLevel * 100)}%
                  </p>
                </div>
              </div>

              <div className="flex items-end gap-1 h-10 w-40">
                {Array.from({ length: 14 }).map((_, i) => {
                  const threshold = (i + 1) / 14;
                  const active = micLevel >= threshold;
                  const height = 8 + i * 2;
                  return (
                    <div
                      key={i}
                      className={`w-full rounded-sm transition-colors ${
                        active ? 'bg-indigo-500' : 'bg-slate-200 dark:bg-white/10'
                      }`}
                      style={{ height }}
                    />
                  );
                })}
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={handleStart}
              disabled={isBusy}
              className={`py-3 px-5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all ${
                !isAuthenticated || isBusy
                  ? 'bg-slate-100 dark:bg-white/5 text-slate-300 dark:text-slate-700 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20'
              }`}
            >
              {isStarting ? 'Starting...' : 'Start Session'}
            </button>

            <button
              onClick={handleStop}
              disabled={!isBusy}
              className={`py-3 px-5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all ${
                !isBusy
                  ? 'bg-slate-100 dark:bg-white/5 text-slate-300 dark:text-slate-700 cursor-not-allowed'
                  : 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/20'
              }`}
            >
              Stop
            </button>
          </div>

          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 space-y-1">
            <div>
              Status: <span className="text-slate-800 dark:text-slate-200">{status}</span>
              {hasRetriedToken && (
                <span className="ml-2 text-amber-600 dark:text-amber-400">(token refreshed)</span>
              )}
            </div>
            <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 tabular-nums">
              Connection: {connectionStatus} • State: {processingState}
              {lastLatencyMs != null && <span> • Latency: {lastLatencyMs}ms</span>}
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Live Partial Text
            </label>
            <div className="min-h-20 p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-300 text-sm leading-relaxed italic">
              {partialText || 'Partial transcription appears here while speaking...'}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between gap-3 mb-2">
              <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400">
                Transcript (Final)
              </label>
              <button
                type="button"
                onClick={() => copyToClipboard(transcriptHistory.map((t) => t.text).join('\n'))}
                className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-white text-[10px] font-black uppercase tracking-widest"
              >
                Copy
              </button>
            </div>
            <div className="w-full h-56 p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10 overflow-auto space-y-3">
              {transcriptHistory.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-500">
                  Final recognized speech will appear here...
                </p>
              ) : (
                transcriptHistory.map((item) => (
                  <div key={item.id}>
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 mb-1">
                      {formatTime(item.ts)}
                    </div>
                    <p className="text-sm text-slate-900 dark:text-white leading-relaxed font-medium">
                      {item.text}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between gap-3 mb-2">
              <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400">
                Translated Output
              </label>
              <button
                type="button"
                onClick={() => copyToClipboard(translationHistory.map((t) => t.text).join('\n'))}
                className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-white text-[10px] font-black uppercase tracking-widest"
              >
                Copy
              </button>
            </div>
            <div className="w-full h-40 p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10 overflow-auto space-y-3">
              {translationHistory.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-500">
                  Translated text will appear here...
                </p>
              ) : (
                translationHistory.map((item) => (
                  <div
                    key={item.id}
                    className={`rounded-lg p-2 ${
                      item.id === latestTranslationId ? 'bg-indigo-500/10' : ''
                    }`}
                  >
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 mb-1">
                      {formatTime(item.ts)} {item.id === latestTranslationId ? '• Latest' : ''}
                    </div>
                    <p className="text-sm text-slate-900 dark:text-white leading-relaxed font-medium">
                      {item.text}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          {(recordedAudioUrl || convertedAudioUrl) && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
                  Recorder Sample
                </label>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10">
                  {recordedAudioUrl ? (
                    <audio controls src={recordedAudioUrl} className="w-full">
                      Your browser does not support audio playback.
                    </audio>
                  ) : (
                    <p className="text-[11px] text-slate-500 dark:text-slate-500">
                      No recorded sample yet.
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
                  Converted Sample
                </label>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10">
                  {convertedAudioUrl ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={handleTogglePlayback}
                          className="px-3 py-3 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-black uppercase tracking-widest"
                        >
                          {isPlaybackPlaying ? 'Pause' : 'Play'}
                        </button>
                        <button
                          type="button"
                          onClick={handleReplay}
                          className="px-3 py-3 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-white text-[10px] font-black uppercase tracking-widest"
                        >
                          Replay
                        </button>
                      </div>
                      <audio ref={playbackAudioRef} src={convertedAudioUrl} className="w-full" controls />
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-500 dark:text-slate-500">
                      No converted sample yet.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          <div>
            <div className="flex items-center justify-between gap-3 mb-2">
              <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400">
                Conversation History
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={exportHistoryTxt}
                  className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-white text-[10px] font-black uppercase tracking-widest"
                >
                  Export TXT
                </button>
                <button
                  type="button"
                  onClick={exportHistoryPdf}
                  className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-white text-[10px] font-black uppercase tracking-widest"
                >
                  Export PDF
                </button>
                <button
                  type="button"
                  onClick={clearAllHistory}
                  className="px-3 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-black uppercase tracking-widest"
                >
                  Clear
                </button>
              </div>
            </div>

            <div className="w-full h-56 p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10 overflow-auto space-y-3">
              {conversationHistory.length === 0 ? (
                <p className="text-sm text-slate-500 dark:text-slate-500">
                  Complete conversation will show up here...
                </p>
              ) : (
                conversationHistory.map((m) => (
                  <div
                    key={m.id}
                    className={`rounded-xl p-3 border ${
                      m.speaker === 'AI'
                        ? 'border-indigo-500/20 bg-indigo-500/10'
                        : m.speaker === 'Person 2'
                          ? 'border-emerald-500/20 bg-emerald-500/10'
                          : 'border-slate-200/60 dark:border-white/10 bg-white/70 dark:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3 mb-1">
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                        {m.speaker}
                      </p>
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 tabular-nums">
                        {formatTime(m.ts)}
                      </p>
                    </div>
                    <p className="text-sm text-slate-900 dark:text-white leading-relaxed">
                      {m.text}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-black/30 p-4">
            <p className="text-[11px] text-slate-500 dark:text-slate-500 leading-relaxed">
              Tip: Use headphones for best results. Speaker audio can be re-captured by the mic and cause repeated recognition.
            </p>
            {(lastTranslationMs != null || lastSynthesisMs != null) && (
              <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-500 tabular-nums">
                Translation: {lastTranslationMs ?? '—'}ms • Synthesis: {lastSynthesisMs ?? '—'}ms
              </p>
            )}
          </div>
        </div>

        {error && (
          <div className="mt-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/20">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-rose-700 dark:text-rose-300 text-xs font-black uppercase tracking-widest mb-1">
                  Error
                </p>
                <p className="text-rose-700 dark:text-rose-200 text-sm leading-relaxed">
                  {error}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setError(null)}
                  className="px-3 py-2 rounded-lg bg-white/70 dark:bg-white/10 text-rose-800 dark:text-rose-200 text-[10px] font-black uppercase tracking-widest"
                >
                  Dismiss
                </button>
                <button
                  type="button"
                  onClick={handleStart}
                  disabled={isBusy}
                  className={`px-3 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest ${
                    isBusy
                      ? 'bg-slate-100 dark:bg-white/5 text-slate-300 dark:text-slate-700 cursor-not-allowed'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  }`}
                >
                  Retry
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {showMicPermissionDialog && (
        <div className="fixed inset-0 z-[200] bg-black/40 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="w-full max-w-lg rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-950 p-6 shadow-2xl">
            <h3 className="text-lg font-black text-slate-900 dark:text-white mb-2">
              Microphone Permission Required
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              Allow microphone access in your browser, then click Retry.
            </p>
            {error && (
              <div className="mb-4 p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20">
                <p className="text-sm text-rose-700 dark:text-rose-200">{error}</p>
              </div>
            )}
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowMicPermissionDialog(false)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-bold"
              >
                Close
              </button>
              <button
                type="button"
                onClick={async () => {
                  setShowMicPermissionDialog(false);
                  await handleStart();
                }}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest"
              >
                Retry
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SpeechToSpeechPage;
