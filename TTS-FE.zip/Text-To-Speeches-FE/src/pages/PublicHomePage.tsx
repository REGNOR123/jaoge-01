import React, { useEffect, useState } from "react";
import { MAX_TEXT_LENGTH } from "../constants";
import { useSpeechSynthesis } from "../hooks/useSpeechSynthesis";
import { useAuth } from "../contexts/AuthContext";
import Header from "../components/Header";
import Footer from "../components/Footer";
import SaveSessionModal from "../components/SaveSessionModal";
import IntroSection from "../components/IntroSection";
import VocalDynamics from "../components/VocalDynamics";
import ExpressionEngine from "../components/ExpressionEngine";
import GenerateButton from "../components/GenerateButton";
import VoiceLibrarySidebar from "../components/VoiceLibrarySidebar";
import AudioPlayer from "../components/AudioPlayer";
import AuthRequiredModal from "../components/AuthRequiredModal";

const PublicHomePage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [accountDeletedNotice, setAccountDeletedNotice] = useState("");
  const [subscriptionNotice, setSubscriptionNotice] = useState("");
  const [authRequiredOpen, setAuthRequiredOpen] = useState(false);

  const {
    theme,
    toggleTheme,
    text,
    setText,
    isTextTooLong,
    isTextEmpty,
    selectedVoice,
    setSelectedVoice,
    selectedVoiceInfo,
    rate,
    setRate,
    pitch,
    setPitch,
    volume,
    setVolume,
    isVocalDynamicsOpen,
    setIsVocalDynamicsOpen,
    resetVocalDynamics,
    style,
    setStyle,
    degree,
    setDegree,
    isExpressionEngineOpen,
    setIsExpressionEngineOpen,
    isVoiceLibraryOpen,
    setIsVoiceLibraryOpen,
    isDetecting,
    detectedLang,
    isMismatched,
    isTranslating,
    handleTranslateText,
    isProcessing,
    progress,
    error,
    handleGenerate,
    pendingEntry,
    setPendingEntry,
    recordingName,
    setRecordingName,
    saveToLibrary,
    audioRef,
    currentEntry,
    handleClosePlayer,
    voiceSearch,
    setVoiceSearch,
    filteredVoices,
  } = useSpeechSynthesis();

  useEffect(() => {
    const notice = sessionStorage.getItem("account_deleted_notice");
    if (notice) {
      setAccountDeletedNotice(notice);
      sessionStorage.removeItem("account_deleted_notice");
    }
  }, []);

  useEffect(() => {
    const notice = sessionStorage.getItem("subscription_notice");
    if (notice) {
      setSubscriptionNotice(notice);
      sessionStorage.removeItem("subscription_notice");
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20">
      <audio ref={audioRef} className="hidden" />

      <AuthRequiredModal
        isOpen={authRequiredOpen}
        onClose={() => setAuthRequiredOpen(false)}
        redirectTo="/"
      />

      {pendingEntry && (
        <SaveSessionModal
          pendingEntry={pendingEntry}
          recordingName={recordingName}
          onRecordingNameChange={setRecordingName}
          onDiscard={() => setPendingEntry(null)}
          onSave={saveToLibrary}
        />
      )}

      <Header theme={theme} onToggleTheme={toggleTheme} />

      <main className="flex-1 max-w-[1800px] mx-auto w-full px-8 py-10">
        <div className="space-y-10">
          {accountDeletedNotice && (
            <div className="rounded-xl border border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-500/10 px-4 py-3">
              <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                {accountDeletedNotice}
              </p>
            </div>
          )}

          {subscriptionNotice && (
            <div className="rounded-xl border border-emerald-200 dark:border-emerald-500/30 bg-emerald-50 dark:bg-emerald-500/10 px-4 py-3">
              <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                {subscriptionNotice}
              </p>
            </div>
          )}

          <IntroSection />

          <section className="glass studio-card !p-12 relative overflow-hidden group">
            <div className="flex items-center justify-between mb-10">
              <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                Vocal Canvas
              </h2>
              {isDetecting ? (
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                    Analyzing Dialect...
                  </span>
                </div>
              ) : detectedLang && detectedLang !== "Unknown" ? (
                <div className="px-4 py-2 rounded-full border bg-emerald-500/10 text-[10px] font-black uppercase tracking-widest text-emerald-600 border-emerald-500/20">
                  {detectedLang} Mode
                </div>
              ) : null}
            </div>

            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={MAX_TEXT_LENGTH}
              placeholder="Insert your text here to generate the human like AI voices..."
              className="w-full h-56 bg-transparent text-xl font-medium text-slate-900 dark:text-slate-100 placeholder-slate-300 focus:outline-none resize-none leading-relaxed"
            />
            <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest mt-2">
              <span className="text-slate-400">Neural Buffer Capacity</span>
              <span className={isTextTooLong ? "text-red-500" : "text-slate-500"}>
                {text.length} / {MAX_TEXT_LENGTH}
              </span>
            </div>

            <GenerateButton
              isAuthenticated={isAuthenticated}
              isProcessing={isProcessing}
              isTextEmpty={isTextEmpty}
              isTextTooLong={isTextTooLong}
              isMismatched={isMismatched}
              progress={progress}
              detectedLang={detectedLang}
              selectedVoiceInfo={selectedVoiceInfo}
              error={error}
              onGenerate={handleGenerate}
              onAuthRequired={() => setAuthRequiredOpen(true)}
              isTranslating={isTranslating}
              onTranslate={handleTranslateText}
            />
          </section>

          <div className="glass studio-card !p-8">
            <VocalDynamics
              isOpen={isVocalDynamicsOpen}
              onToggle={() => setIsVocalDynamicsOpen(!isVocalDynamicsOpen)}
              rate={rate}
              pitch={pitch}
              volume={volume}
              onRateChange={setRate}
              onPitchChange={setPitch}
              onVolumeChange={setVolume}
              onReset={resetVocalDynamics}
            />
          </div>

          <div className="glass studio-card !p-8">
            <ExpressionEngine
              isOpen={isExpressionEngineOpen}
              onToggle={() => setIsExpressionEngineOpen(!isExpressionEngineOpen)}
              style={style}
              degree={degree}
              onStyleChange={setStyle}
              onDegreeChange={setDegree}
            />
          </div>

          <div className="glass studio-card !p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                Neural Voice Library
              </h3>
              <button
                onClick={() => setIsVoiceLibraryOpen(!isVoiceLibraryOpen)}
                className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 transition-all"
              >
                <svg
                  className={`w-5 h-5 text-slate-600 dark:text-slate-400 transition-transform duration-300 ${
                    isVoiceLibraryOpen ? "rotate-0" : "-rotate-90"
                  }`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
              </button>
            </div>
            {isVoiceLibraryOpen && (
              <VoiceLibrarySidebar
                voiceSearch={voiceSearch}
                onVoiceSearchChange={setVoiceSearch}
                filteredVoices={filteredVoices}
                selectedVoice={selectedVoice}
                onSelectVoice={setSelectedVoice}
              />
            )}
          </div>
        </div>
      </main>

      <Footer />

      {currentEntry && <AudioPlayer entry={currentEntry} audioRef={audioRef} onClose={handleClosePlayer} />}
    </div>
  );
};

export default PublicHomePage;

