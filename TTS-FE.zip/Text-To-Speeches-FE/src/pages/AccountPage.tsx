import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useCredits } from "../contexts/CreditContext";
import {
  getUsageSummary,
  getPaymentHistory,
  getInvoice,
  type UsageSummary,
  type PaymentHistoryItem,
  type InvoiceData,
} from "../services/paymentApiService";

const PLAN_LABELS: Record<string, string> = {
  free: "Free",
  starter: "Starter",
  basic: "Basic",
  standard: "Standard",
  pro: "Pro",
  ultra: "Ultra",
};

const PLAN_COLORS: Record<string, string> = {
  free: "bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-300",
  starter: "bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300",
  basic: "bg-cyan-50 dark:bg-cyan-500/10 text-cyan-700 dark:text-cyan-300",
  standard: "bg-indigo-50 dark:bg-indigo-500/10 text-indigo-700 dark:text-indigo-300",
  pro: "bg-violet-50 dark:bg-violet-500/10 text-violet-700 dark:text-violet-300",
  ultra: "bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300",
};

const AccountPage: React.FC = () => {
  const { user, logout, token } = useAuth();
  const { refreshBalance } = useCredits();
  const navigate = useNavigate();

  const [summary, setSummary] = useState<UsageSummary | null>(null);
  const [history, setHistory] = useState<PaymentHistoryItem[]>([]);
  const [loadingSummary, setLoadingSummary] = useState(true);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [invoiceModal, setInvoiceModal] = useState<InvoiceData | null>(null);
  const [loadingInvoice, setLoadingInvoice] = useState<string | null>(null);

  useEffect(() => {
    if (!token) return;
    void refreshBalance();
    getUsageSummary(token).then((res) => {
      if (res.success && res.data) setSummary(res.data);
      setLoadingSummary(false);
    });
    getPaymentHistory(token).then((res) => {
      if (res.success && res.data) setHistory(res.data);
      setLoadingHistory(false);
    });
  }, [token]);

  const handleViewInvoice = async (id: string) => {
    if (!token) return;
    setLoadingInvoice(id);
    const res = await getInvoice(token, id);
    setLoadingInvoice(null);
    if (res.success && res.data) setInvoiceModal(res.data);
  };

  const handlePrintInvoice = () => {
    window.print();
  };

  const planLabel = PLAN_LABELS[summary?.currentPlan ?? "free"] ?? summary?.currentPlan ?? "Free";
  const planColor = PLAN_COLORS[summary?.currentPlan ?? "free"] ?? PLAN_COLORS.free;
  const creditPct = summary
    ? Math.round((summary.creditLeft / Math.max(summary.totalCreditsAwarded, 1)) * 100)
    : 0;

  return (
    <div className="max-w-3xl space-y-6">
      {/* Top cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        {/* My Account card */}
        <div className="glass studio-card !p-8 flex flex-col">
          <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            My Account
          </h1>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-medium">
            Account details and settings.
          </p>

          <div className="mt-6 space-y-4 flex-1">
            <Field label="Name" value={user?.fullName || "-"} />
            <Field label="Email" value={user?.email || "-"} />
          </div>

          <div className="mt-6 flex flex-col gap-2">
            <button
              type="button"
              onClick={() => { logout(); navigate("/login"); }}
              className="px-4 py-2.5 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-red-600 dark:text-red-400 text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Usage card */}
        <div className="glass studio-card !p-8 flex flex-col">
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Usage
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-medium">
            Your credit balance and plan details.
          </p>

          {loadingSummary ? (
            <div className="flex-1 flex items-center justify-center mt-6">
              <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="mt-6 space-y-5 flex-1">
              {/* Current plan */}
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5">
                  Current Plan
                </p>
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-black uppercase tracking-wider ${planColor}`}>
                  {planLabel}
                </span>
              </div>

              {/* Total credits awarded */}
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1">
                  Total Credits Awarded
                </p>
                <p className="text-2xl font-black text-slate-900 dark:text-white">
                  ⚡ {(summary?.totalCreditsAwarded ?? 0).toLocaleString()}
                </p>
              </div>

              {/* Credits left with progress bar */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    Credits Left
                  </p>
                  <p className="text-[10px] font-black text-slate-500 dark:text-slate-400">
                    {creditPct}%
                  </p>
                </div>
                <p className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mb-2">
                  ⚡ {(summary?.creditLeft ?? 0).toLocaleString()}
                </p>
                <div className="h-1.5 w-full rounded-full bg-slate-100 dark:bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all duration-500"
                    style={{ width: `${Math.min(creditPct, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Payment history */}
      <div className="glass studio-card !p-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
              Payment History
            </h2>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-medium">
              All your past credit purchases.
            </p>
          </div>
        </div>

        {loadingHistory ? (
          <div className="flex items-center justify-center py-10">
            <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : history.length === 0 ? (
          <div className="text-center py-10">
            <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-white/10 flex items-center justify-center mx-auto mb-3">
              <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
            </div>
            <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">No payments yet</p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Your credit purchases will appear here.</p>
          </div>
        ) : (
          <div className="overflow-x-auto -mx-2">
            <table className="w-full text-sm min-w-[560px]">
              <thead>
                <tr className="border-b border-slate-100 dark:border-white/10">
                  <th className="text-left px-2 pb-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Date</th>
                  <th className="text-left px-2 pb-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Plan</th>
                  <th className="text-right px-2 pb-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Amount</th>
                  <th className="text-right px-2 pb-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Credits</th>
                  <th className="text-center px-2 pb-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Status</th>
                  <th className="text-right px-2 pb-3 text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Invoice</th>
                </tr>
              </thead>
              <tbody>
                {history.map((item) => (
                  <tr key={item.id} className="border-b border-slate-50 dark:border-white/5 last:border-0">
                    <td className="px-2 py-3 text-slate-600 dark:text-slate-400 text-xs">
                      {item.paidAt
                        ? new Date(item.paidAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
                        : new Date(item.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                    </td>
                    <td className="px-2 py-3 font-semibold text-slate-800 dark:text-slate-200">{item.planDisplayName}</td>
                    <td className="px-2 py-3 text-right font-bold text-slate-800 dark:text-slate-200">
                      ₹{Number(item.amountInr).toLocaleString("en-IN")}
                    </td>
                    <td className="px-2 py-3 text-right text-indigo-600 dark:text-indigo-400 font-bold">
                      ⚡ {item.creditsGranted.toLocaleString()}
                    </td>
                    <td className="px-2 py-3 text-center">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        item.status === "paid"
                          ? "bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
                          : item.status === "created"
                          ? "bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400"
                          : "bg-red-50 dark:bg-red-500/10 text-red-700 dark:text-red-400"
                      }`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="px-2 py-3 text-right">
                      {item.status === "paid" ? (
                        <button
                          onClick={() => handleViewInvoice(item.id)}
                          disabled={loadingInvoice === item.id}
                          className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 transition-colors disabled:opacity-50"
                        >
                          {loadingInvoice === item.id ? (
                            <svg className="w-3 h-3 animate-spin" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                            </svg>
                          ) : (
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                          )}
                          Invoice
                        </button>
                      ) : (
                        <span className="text-xs text-slate-400">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Invoice modal */}
      {invoiceModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={(e) => { if (e.target === e.currentTarget) setInvoiceModal(null); }}
        >
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-white/10 shadow-2xl w-full max-w-md p-8 space-y-6">
            {/* Header */}
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-indigo-500 mb-1">Invoice</p>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">TextToSpeeches.in</h3>
              </div>
              <button onClick={() => setInvoiceModal(null)} className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 text-slate-400 transition-colors">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Details */}
            <div className="space-y-3 text-sm">
              <InvoiceRow label="Invoice ID" value={invoiceModal.invoiceId.slice(0, 8).toUpperCase()} />
              <InvoiceRow label="Payment ID" value={invoiceModal.razorpayPaymentId ?? "—"} mono />
              <InvoiceRow label="Order ID" value={invoiceModal.razorpayOrderId} mono />
              <InvoiceRow label="Customer" value={invoiceModal.userName} />
              <InvoiceRow label="Email" value={invoiceModal.userEmail} />
              <InvoiceRow label="Date" value={invoiceModal.paidAt ? new Date(invoiceModal.paidAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) : "—"} />
              <div className="border-t border-slate-100 dark:border-white/10 pt-3">
                <InvoiceRow label="Plan" value={invoiceModal.planDisplayName} />
                <InvoiceRow label="Credits" value={`⚡ ${invoiceModal.creditsGranted.toLocaleString()} credits`} />
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Total Paid</span>
                  <span className="text-lg font-black text-slate-900 dark:text-white">
                    ₹{Number(invoiceModal.amountInr).toLocaleString("en-IN")}
                  </span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={handlePrintInvoice}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold transition-colors"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Download / Print
              </button>
              <button
                onClick={() => setInvoiceModal(null)}
                className="px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/15 text-slate-700 dark:text-slate-300 text-sm font-bold transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountPage;

const Field = ({ label, value }: { label: string; value: string }) => (
  <div>
    <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">{label}</div>
    <div className="mt-1 text-sm font-semibold text-slate-900 dark:text-white">{value}</div>
  </div>
);

const InvoiceRow = ({ label, value, mono }: { label: string; value: string; mono?: boolean }) => (
  <div className="flex items-center justify-between gap-4">
    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 shrink-0">{label}</span>
    <span className={`text-right text-slate-800 dark:text-slate-200 font-semibold truncate ${mono ? "font-mono text-xs" : "text-sm"}`}>{value}</span>
  </div>
);
