import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import ProjectsTable from "../components/projects-table";
import { useDialog } from "../components/dialogs";
import type { ProjectTableRow } from "../data/projects";
import { toProjectTableRows } from "../data/projects";
import {
  deleteProjects,
  duplicateProject,
  listProjects,
  updateProject,
  updateProjectsStatus,
  type ProjectStatus,
} from "../utils/projectsStorage";

const ProjectsPage: React.FC = () => {
  const navigate = useNavigate();
  const dialog = useDialog();
  const [projects, setProjects] = useState<ProjectTableRow[]>([]);
  const [loading, setLoading] = useState(true);

  const loadProjects = useCallback(() => {
    setLoading(true);
    const rows = toProjectTableRows(listProjects());
    setProjects(rows);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  const handleRefresh = useCallback(() => {
    loadProjects();
  }, [loadProjects]);

  const handleOpenProject = useCallback(
    (project: ProjectTableRow) => {
      navigate(`/projects/${project.id}`);
    },
    [navigate],
  );

  const handleDeleteProjects = useCallback(
    async (rows: ProjectTableRow[]) => {
      if (rows.length === 0) return;
      const message =
        rows.length === 1
          ? `Delete "${rows[0].projectName}"? This cannot be undone.`
          : `Delete ${rows.length} projects? This cannot be undone.\n\n${rows.map((r) => `• ${r.projectName}`).join("\n")}`;
      const ok = await dialog.confirm(message, {
        title: "Delete Projects",
        confirmText: "Delete",
        variant: "danger",
      });
      if (!ok) return;

      deleteProjects(rows.map((row) => row.id));
      loadProjects();
    },
    [dialog, loadProjects],
  );

  const handleRenameProject = useCallback(
    (id: string, newName: string) => {
      updateProject(id, { name: newName });
      loadProjects();
    },
    [loadProjects],
  );

  const handleDuplicateProject = useCallback(
    (id: string) => {
      duplicateProject(id);
      loadProjects();
    },
    [loadProjects],
  );

  const handleBulkStatusChange = useCallback(
    (rows: ProjectTableRow[], status: ProjectStatus) => {
      updateProjectsStatus(
        rows.map((r) => r.id),
        status,
      );
      loadProjects();
    },
    [loadProjects],
  );

  const totalCount = useMemo(() => projects.length, [projects.length]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <section className="space-y-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-black tracking-tight text-slate-900 dark:text-white">Projects</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            All your scripts, transcripts, and audio outputs in one place.
          </p>
          <div className="text-xs font-medium uppercase tracking-[0.18em] text-slate-400 dark:text-slate-500">
            {totalCount} active workflow projects
          </div>
        </div>

        <ProjectsTable
          data={projects}
          loading={loading}
          onRefresh={handleRefresh}
          onOpenProject={handleOpenProject}
          onDeleteProjects={handleDeleteProjects}
          onRenameProject={handleRenameProject}
          onDuplicateProject={handleDuplicateProject}
          onBulkStatusChange={handleBulkStatusChange}
        />
      </section>
    </div>
  );
};

export default ProjectsPage;
