import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link, Navigate, useNavigate, useParams } from "react-router-dom";
import { getProjectById, isDraftProject, type Project } from "../utils/projectsStorage";
import { loadAudioBlob } from "../utils/audioBlobStore";
import { useAuth } from "../contexts/AuthContext";
import { downloadManagedFile } from "../services/filesApiService";
import { formatDateTime } from "../utils/format";

type TabId = "drafts" | "scripts" | "audio" | "transcripts" | "languages";

const isIdbAudioUrl = (url?: string): boolean => typeof url === "string" && url.startsWith("idb-audio:");

const isDirectAudioUrl = (url?: string): boolean => {
  if (typeof url !== "string" || !url.trim()) return false;
  return (
    url.startsWith("data:") ||
    url.startsWith("http://") ||
    url.startsWith("https://") ||
    url.startsWith("/")
  );
};

const getManagedFileId = (audio: any): string | undefined => {
  const settings = audio?.settings && typeof audio.settings === "object" ? audio.settings : null;
  const fileId = audio?.fileId || settings?.fileId;
  if (typeof fileId !== "string" || !fileId.trim()) return undefined;
  return fileId.trim();
};

const getAudioDownloadName = (a: any): string => {
  const name = a?.fileName || a?.settings?.fileName;
  if (typeof name === "string" && name.trim()) return name.trim();
  const ct: string = a?.contentType || a?.settings?.contentType || "";
  const ext = ct.includes("mpeg") || ct.includes("mp3") ? "mp3"
    : ct.includes("wav") ? "wav"
    : ct.includes("ogg") ? "ogg"
    : "mp3";
  const label = a?.voice || a?.settings?.voice || "audio";
  return `${label}.${ext}`;
};

const getEditorRoute = (project: Project): string => {
  switch (project.type) {
    case "Voice":
      return `/create-voice?projectId=${encodeURIComponent(project.id)}`;
    case "Transcript":
      return `/transcribe?projectId=${encodeURIComponent(project.id)}`;
    case "Dub":
      return `/translate-dub?projectId=${encodeURIComponent(project.id)}`;
    case "SpeechTranslate":
      return `/speech-translate?projectId=${encodeURIComponent(project.id)}`;
    case "Script":
      return `/script-studio?projectId=${encodeURIComponent(project.id)}`;
    default:
      return `/dashboard`;
  }
};

const ProjectDetailPage: React.FC = () => {
  const { projectId } = useParams();

  const project = useMemo(() => (projectId ? getProjectById(projectId) : null), [projectId]);

  if (!projectId || !project) return <Navigate to="/projects" replace />;

  return <ProjectDetailContent project={project} />;
};

const ProjectDetailContent: React.FC<{ project: Project }> = ({ project }) => {
  const navigate = useNavigate();
  const { token } = useAuth();
  const [tab, setTab] = useState<TabId>("scripts");

  const scripts = useMemo(() => project.data?.outputs?.scripts ?? [], [project]);
  const audioVersions = useMemo(() => project.data?.outputs?.audioVersions ?? [], [project]);
  const transcripts = useMemo(() => project.data?.outputs?.transcripts ?? [], [project]);
  const languages = useMemo(() => project.data?.outputs?.languages ?? [], [project]);
  const drafts = project.data?.drafts;
  const hasDrafts = Boolean(
    drafts?.voice || drafts?.transcript || drafts?.dub || drafts?.speechTranslate || drafts?.scriptStudio,
  );
  const hasScripts = scripts.length > 0;
  const hasAudioVersions = audioVersions.length > 0;
  const hasTranscripts = transcripts.length > 0;
  const hasLanguages = languages.length > 0;

  const hasAny =
    scripts.length > 0 || audioVersions.length > 0 || transcripts.length > 0 || languages.length > 0;

  const visibleTabs = useMemo<TabId[]>(() => {
    const tabs: TabId[] = [];
    if (hasDrafts) tabs.push("drafts");
    if (hasScripts) tabs.push("scripts");
    if (hasAudioVersions) tabs.push("audio");
    if (hasTranscripts) tabs.push("transcripts");
    if (hasLanguages) tabs.push("languages");
    return tabs;
  }, [hasDrafts, hasScripts, hasAudioVersions, hasTranscripts, hasLanguages]);

  const [resolvedAudioUrls, setResolvedAudioUrls] = useState<Record<string, string>>({});
  const [unavailableAudioIds, setUnavailableAudioIds] = useState<Record<string, true>>({});
  const objectUrlsRef = useRef<Record<string, string>>({});
  const unavailableAudioRef = useRef<Record<string, true>>({});

  useEffect(() => {
    let canceled = false;

    const toIdbKey = (url: string) => url.slice("idb-audio:".length).trim();

    const sync = async () => {
      const needed = new Set<string>();
      for (const v of audioVersions) {
        const managedFileId = getManagedFileId(v);
        const needsManagedResolution = Boolean(
          managedFileId && !isDirectAudioUrl(v.audioUrl) && !isIdbAudioUrl(v.audioUrl),
        );
        if (isIdbAudioUrl(v.audioUrl) || needsManagedResolution) needed.add(v.id);
      }

      for (const id of Object.keys(objectUrlsRef.current)) {
        if (!needed.has(id)) {
          URL.revokeObjectURL(objectUrlsRef.current[id]);
          delete objectUrlsRef.current[id];
        }
      }

      for (const id of Object.keys(unavailableAudioRef.current)) {
        if (!needed.has(id)) delete unavailableAudioRef.current[id];
      }

      for (const v of audioVersions) {
        if (!v?.id) continue;
        if (objectUrlsRef.current[v.id]) continue;

        try {
          let blob: Blob | null = null;

          if (isIdbAudioUrl(v.audioUrl)) {
            const key = toIdbKey(v.audioUrl);
            if (!key) continue;
            blob = await loadAudioBlob(key);
            if (!blob) {
              unavailableAudioRef.current[v.id] = true;
              continue;
            }
          } else {
            const managedFileId = getManagedFileId(v);
            if (!managedFileId || !token) continue;
            const downloadResult = await downloadManagedFile(token, managedFileId);
            if (!downloadResult.success) {
              if (downloadResult.status === 404) unavailableAudioRef.current[v.id] = true;
              continue;
            }
            blob = downloadResult.data.blob;
          }

          if (!blob) continue;
          const url = URL.createObjectURL(blob);
          if (canceled) {
            URL.revokeObjectURL(url);
            return;
          }
          delete unavailableAudioRef.current[v.id];
          objectUrlsRef.current[v.id] = url;
        } catch {
          unavailableAudioRef.current[v.id] = true;
        }
      }

      if (!canceled) {
        setResolvedAudioUrls({ ...objectUrlsRef.current });
        setUnavailableAudioIds({ ...unavailableAudioRef.current });
      }
    };

    sync();
    return () => {
      canceled = true;
    };
  }, [audioVersions, token]);

  useEffect(() => {
    return () => {
      for (const url of Object.values(objectUrlsRef.current)) URL.revokeObjectURL(url);
      objectUrlsRef.current = {};
    };
  }, []);

  useEffect(() => {
    if (!visibleTabs.length) return;
    if (!visibleTabs.includes(tab)) setTab(visibleTabs[0]);
  }, [tab, visibleTabs]);

  return (
    <div className="space-y-6">
      <section className="glass studio-card !p-8">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
          <div className="min-w-0">
            <Link
              to="/projects"
              className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              ← Back to Projects
            </Link>

            <h1 className="mt-3 text-2xl font-black text-slate-900 dark:text-white tracking-tight truncate">
              {project.name}
            </h1>
            <div className="mt-2 flex flex-wrap gap-2 items-center">
              <span className="inline-flex items-center px-2.5 py-1 rounded-full border border-indigo-500/15 bg-indigo-500/10 text-indigo-700 dark:text-indigo-200 text-[10px] font-black uppercase tracking-widest">
                {project.type}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold">
                Created: {formatDateTime(project.created)}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold">
                Last modified: {formatDateTime(project.lastModified)}
              </span>
              {(() => {
                const status = isDraftProject(project) ? "Draft" : project.status;
                const tone =
                  status === "Draft"
                    ? "text-slate-500 dark:text-slate-400"
                    : status === "Completed"
                      ? "text-emerald-700 dark:text-emerald-300"
                      : "text-orange-700 dark:text-orange-300";
                return (
                  <span className="text-xs font-semibold">
                    <span className="text-slate-900 dark:text-white">Status:</span>{" "}
                    <span className={tone}>{status}</span>
                  </span>
                );
              })()}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={() => navigate(getEditorRoute(project))}
              className="px-4 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm"
            >
              Open in Editor
            </button>
            <Link
              to="/projects"
              className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center"
            >
              Close
            </Link>
          </div>
        </div>
      </section>

      <section className="glass studio-card !p-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="Project content tabs">
            {visibleTabs.includes("drafts") && (
              <TabButton active={tab === "drafts"} onClick={() => setTab("drafts")}>
                Drafts
              </TabButton>
            )}
            {visibleTabs.includes("scripts") && (
              <TabButton active={tab === "scripts"} onClick={() => setTab("scripts")}>
                Scripts
              </TabButton>
            )}
            {visibleTabs.includes("audio") && (
              <TabButton active={tab === "audio"} onClick={() => setTab("audio")}>
                Audio Versions
              </TabButton>
            )}
            {visibleTabs.includes("transcripts") && (
              <TabButton active={tab === "transcripts"} onClick={() => setTab("transcripts")}>
                Transcripts
              </TabButton>
            )}
            {visibleTabs.includes("languages") && (
              <TabButton active={tab === "languages"} onClick={() => setTab("languages")}>
                Languages
              </TabButton>
            )}
          </div>

          {!hasAny && (
            <div className="text-sm font-semibold text-slate-600 dark:text-slate-300">
              No outputs saved yet. Open this project in an editor to continue.
            </div>
          )}
        </div>

        <div className="mt-6" role="tabpanel" aria-label={`${tab} content`}>
          {tab === "drafts" && (
            <div className="space-y-4">
              {/* Voice Draft */}
              {drafts?.voice && (
                <DraftCard
                  label="Create Voice Draft"
                  updatedAt={drafts.voice.updatedAt}
                  route={getEditorRoute(project)}
                >
                  {drafts.voice.script && (
                    <DraftField label="Script" value={drafts.voice.script} />
                  )}
                  <div className="flex flex-wrap gap-3 text-xs text-slate-500 dark:text-slate-400 font-semibold">
                    {drafts.voice.voice && <span>Voice: {drafts.voice.voice}</span>}
                    {drafts.voice.language && <span>Language: {drafts.voice.language}</span>}
                  </div>
                </DraftCard>
              )}

              {/* Transcript Draft */}
              {drafts?.transcript && (
                <DraftCard
                  label="Transcribe Draft"
                  updatedAt={drafts.transcript.updatedAt}
                  route={getEditorRoute(project)}
                >
                  {drafts.transcript.transcript && (
                    <DraftField label="Transcript" value={drafts.transcript.transcript} />
                  )}
                  <div className="flex flex-wrap gap-3 text-xs text-slate-500 dark:text-slate-400 font-semibold">
                    {drafts.transcript.language && <span>Language: {drafts.transcript.language}</span>}
                    {drafts.transcript.fileName && <span>File: {drafts.transcript.fileName}</span>}
                  </div>
                </DraftCard>
              )}

              {/* Dub Draft */}
              {drafts?.dub && (() => {
                const dub: any = drafts.dub;
                const text: any = dub?.text || null;
                const audio: any = dub?.audio || null;

                const textSource =
                  typeof text?.sourceText === "string"
                    ? text.sourceText
                    : dub?.mode === "text" && typeof dub?.sourceText === "string"
                      ? dub.sourceText
                      : "";
                const textTranslated =
                  typeof text?.translatedText === "string"
                    ? text.translatedText
                    : dub?.mode === "text" && typeof dub?.translatedText === "string"
                      ? dub.translatedText
                      : "";

                const audioTranscript =
                  typeof audio?.transcriptText === "string"
                    ? audio.transcriptText
                    : dub?.mode === "audio" && typeof dub?.sourceText === "string"
                      ? dub.sourceText
                      : "";
                const audioTranslated =
                  typeof audio?.translatedText === "string"
                    ? audio.translatedText
                    : dub?.mode === "audio" && typeof dub?.translatedText === "string"
                      ? dub.translatedText
                      : "";

                const hasDubContent =
                  Boolean(textSource.trim()) ||
                  Boolean(textTranslated.trim()) ||
                  Boolean(audioTranscript.trim()) ||
                  Boolean(audioTranslated.trim());

                if (!hasDubContent) return null;

                return (
                  <DraftCard
                    label="Translate & Dub Draft"
                    updatedAt={dub.updatedAt}
                    route={getEditorRoute(project)}
                  >
                    {(textSource || textTranslated) && (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        <DraftField label={`Source (${textSource.length} chars)`} value={textSource} />
                        <DraftField label={`Translation (${textTranslated.length} chars)`} value={textTranslated} />
                      </div>
                    )}
                    {(audioTranscript || audioTranslated) && (
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        <DraftField label={`Transcript (${audioTranscript.length} chars)`} value={audioTranscript} />
                        <DraftField label={`Translation (${audioTranslated.length} chars)`} value={audioTranslated} />
                      </div>
                    )}
                  </DraftCard>
                );
              })()}

              {/* SpeechTranslate Draft */}
              {drafts?.speechTranslate && (
                <DraftCard
                  label="Speech Translate Draft"
                  updatedAt={drafts.speechTranslate.updatedAt}
                  route={getEditorRoute(project)}
                >
                  {drafts.speechTranslate.recognizedText && (
                    <DraftField label="Recognized Text" value={drafts.speechTranslate.recognizedText} />
                  )}
                  <div className="flex flex-wrap gap-3 text-xs text-slate-500 dark:text-slate-400 font-semibold">
                    {drafts.speechTranslate.detectedLanguage && <span>Detected: {drafts.speechTranslate.detectedLanguage}</span>}
                    {drafts.speechTranslate.targets?.length ? <span>Targets: {drafts.speechTranslate.targets.join(", ")}</span> : null}
                  </div>
                </DraftCard>
              )}

              {/* ScriptStudio Draft */}
              {drafts?.scriptStudio && (
                <DraftCard
                  label="Script Studio Draft"
                  updatedAt={drafts.scriptStudio.updatedAt}
                  route={getEditorRoute(project)}
                >
                  {drafts.scriptStudio.script && (
                    <DraftField label="Script" value={drafts.scriptStudio.script} />
                  )}
                  <div className="flex flex-wrap gap-3 text-xs text-slate-500 dark:text-slate-400 font-semibold">
                    {drafts.scriptStudio.scriptType && <span>Type: {drafts.scriptStudio.scriptType}</span>}
                    {drafts.scriptStudio.topic && <span>Topic: {drafts.scriptStudio.topic}</span>}
                    {drafts.scriptStudio.tone && <span>Tone: {drafts.scriptStudio.tone}</span>}
                  </div>
                </DraftCard>
              )}

              {!drafts?.voice && !drafts?.transcript && !drafts?.dub && !drafts?.speechTranslate && !drafts?.scriptStudio && (
                <EmptyPanel title="No drafts saved yet." />
              )}
            </div>
          )}

          {tab === "scripts" && (
            <div className="space-y-4">
              {scripts.map((s) => (
                <div
                  key={s.id}
                  className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <div className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                        Script
                      </div>
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-semibold">
                        {formatDateTime(s.createdAt)}{s.source ? ` • ${s.source}` : ""}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigator.clipboard.writeText(s.text)}
                      className="px-3 py-2 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10"
                    >
                      Copy
                    </button>
                  </div>
                  <pre className="mt-4 whitespace-pre-wrap text-sm text-slate-800 dark:text-slate-100 font-medium leading-relaxed">
                    {s.text}
                  </pre>
                </div>
              ))}
              {scripts.length === 0 && (
                <EmptyPanel title="No scripts saved yet." />
              )}
            </div>
          )}

          {tab === "audio" && (
            <div className="space-y-4">
              {audioVersions.map((a) => (
                <div
                  key={a.id}
                  className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                        Audio
                      </div>
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-semibold">
                        {formatDateTime(a.createdAt)}
                        {a.voiceLabel ? ` • ${a.voiceLabel}` : a.voice ? ` • ${a.voice}` : ""}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {(() => {
                        const hasDirectUrl = isDirectAudioUrl(a.audioUrl);
                        const url = resolvedAudioUrls[a.id] || (hasDirectUrl ? a.audioUrl : "");
                          const isUnavailable = Boolean(unavailableAudioIds[a.id]);
                          const disabled = !url || isUnavailable;
                        return (
                          <a
                            href={disabled ? undefined : url}
                            download={disabled ? undefined : getAudioDownloadName(a)}
                            aria-disabled={disabled}
                            className={[
                              "px-3 py-2 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center",
                              disabled ? "opacity-60 pointer-events-none" : "",
                            ].join(" ")}
                          >
                            {isUnavailable ? "Unavailable" : disabled ? "Loading..." : "Download"}
                          </a>
                        );
                      })()}
                    </div>
                  </div>

                  {(() => {
                    const hasDirectUrl = isDirectAudioUrl(a.audioUrl);
                    const url = resolvedAudioUrls[a.id] || (hasDirectUrl ? a.audioUrl : "");
                    const isUnavailable = Boolean(unavailableAudioIds[a.id]);
                    if (isUnavailable) {
                      return (
                        <div className="mt-4 text-xs font-semibold text-rose-600 dark:text-rose-300">
                          Audio file is no longer available in storage.
                        </div>
                      );
                    }
                    if (!url) {
                      return (
                        <div className="mt-4 text-xs font-semibold text-slate-500 dark:text-slate-400">
                          {token ? "Loading audio…" : "Audio preview unavailable. Please sign in."}
                        </div>
                      );
                    }
                    return <audio controls src={url} className="mt-4 w-full" />;
                  })()}
                </div>
              ))}
              {audioVersions.length === 0 && (
                <EmptyPanel title="No audio versions saved yet." />
              )}
            </div>
          )}

          {tab === "transcripts" && (
            <div className="space-y-4">
              {transcripts.map((t) => (
                <div
                  key={t.id}
                  className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5"
                >
                  <div className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    Transcript
                  </div>
                  <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-semibold">
                    {formatDateTime(t.createdAt)}
                    {t.language ? ` • ${t.language}` : ""}
                  </div>
                  <pre className="mt-4 whitespace-pre-wrap text-sm text-slate-800 dark:text-slate-100 font-medium leading-relaxed">
                    {t.text}
                  </pre>
                </div>
              ))}
              {transcripts.length === 0 && (
                <EmptyPanel title="No transcripts saved yet." />
              )}
            </div>
          )}

          {tab === "languages" && (
            <div className="space-y-4">
              {languages.map((l) => (
                <div
                  key={l.id}
                  className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div>
                      <div className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                        Translation
                      </div>
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-semibold">
                        {formatDateTime(l.createdAt)}
                        {l.sourceLang || l.targetLang ? ` • ${l.sourceLang || "?"} → ${l.targetLang || "?"}` : ""}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => navigator.clipboard.writeText(l.translatedText)}
                      className="px-3 py-2 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10"
                    >
                      Copy Translation
                    </button>
                  </div>

                  <div className="mt-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/70 dark:bg-white/5 p-4">
                      <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                        Source
                      </div>
                      <pre className="mt-2 whitespace-pre-wrap text-sm text-slate-800 dark:text-slate-100 font-medium leading-relaxed">
                        {l.sourceText}
                      </pre>
                    </div>
                    <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/70 dark:bg-white/5 p-4">
                      <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                        Translation
                      </div>
                      <pre className="mt-2 whitespace-pre-wrap text-sm text-slate-800 dark:text-slate-100 font-medium leading-relaxed">
                        {l.translatedText}
                      </pre>
                    </div>
                  </div>
                </div>
              ))}
              {languages.length === 0 && (
                <EmptyPanel title="No language versions saved yet." />
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default ProjectDetailPage;

// Move TabButton and EmptyPanel before they are used (kept here for minimal diff)

const TabButton = ({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) => (
  <button
    type="button"
    role="tab"
    aria-selected={active}
    onClick={onClick}
    className={[
      "px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-colors shadow-sm border",
      active
        ? "bg-indigo-600 text-white border-indigo-600"
        : "bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white border-slate-200 dark:border-white/10",
    ].join(" ")}
  >
    {children}
  </button>
);

const EmptyPanel = ({ title }: { title: string }) => (
  <div className="rounded-3xl border border-black/5 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-6">
    <div className="text-sm font-semibold text-slate-700 dark:text-slate-200">{title}</div>
    <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-medium">
      Generate outputs from the workflows and they’ll appear here automatically.
    </div>
  </div>
);

const DraftCard = ({
  label,
  updatedAt,
  route,
  children,
}: {
  label: string;
  updatedAt?: string;
  route: string;
  children: React.ReactNode;
}) => (
  <div className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-5 space-y-4">
    <div className="flex items-start justify-between gap-3">
      <div>
        <div className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
          {label}
        </div>
        <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-semibold">
          {updatedAt ? formatDateTime(updatedAt) : "\u2014"}
        </div>
      </div>
      <Link
        to={route}
        className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm"
      >
        Continue Editing
      </Link>
    </div>
    {children}
  </div>
);

const DraftField = ({ label, value }: { label: string; value: string }) => (
  <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/70 dark:bg-white/5 p-4">
    <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
      {label}
    </div>
    <pre className="mt-2 whitespace-pre-wrap text-sm text-slate-800 dark:text-slate-100 font-medium leading-relaxed max-h-40 overflow-auto">
      {value || "\u2014"}
    </pre>
  </div>
);
