import React from 'react';
import { Link } from 'react-router-dom';
import Logo from '../components/app/Logo';

const TermsPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <nav className="px-8 py-5 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link to="/dashboard"><Logo /></Link>
          <Link
            to="/dashboard"
            className="text-[10px] font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 transition-colors flex items-center gap-1.5"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to App
          </Link>
        </div>
      </nav>

      <main className="flex-1 max-w-3xl mx-auto w-full px-8 py-16">
        <div className="mb-12">
          <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight mb-3">Terms of Service</h1>
          <p className="text-sm text-slate-400 font-medium">Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
        </div>

        <div className="space-y-10 text-sm leading-relaxed text-slate-600 dark:text-slate-400">

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">1. Acceptance of Terms</h2>
            <p>By accessing or using TextToSpeeches.in ("the Platform"), you agree to be bound by these Terms of Service and all applicable laws. If you do not agree, you must not use the Platform. These terms apply to all features including Create AI Voice, Transcribe Audio, Speech Translate, Translate &amp; Dub, AI Script Studio, Voice Clone, and Projects &amp; Storage.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">2. Account Registration &amp; Security</h2>
            <p className="mb-3">To access most features you must register an account. You agree to:</p>
            <ul className="list-disc list-inside space-y-2 ml-2">
              <li>Provide accurate and complete registration information</li>
              <li>Keep your login credentials confidential</li>
              <li>Notify us immediately of any unauthorised account access</li>
              <li>Accept responsibility for all activity that occurs under your account</li>
            </ul>
            <p className="mt-3">Guest access is available for limited trial use without registration. Guest sessions do not include file storage, project saving, or credit carry-over between sessions.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">3. Credit System &amp; Billing</h2>
            <p className="mb-3">The Platform operates on a credit-based usage model. Credits are consumed when you use paid features. The following applies:</p>
            <ul className="list-disc list-inside space-y-2 ml-2">
              <li>Free accounts receive a one-time welcome grant of 200 credits on signup — these do not renew</li>
              <li>Paid plan credits reset at the start of each billing cycle (monthly or annual)</li>
              <li>Unused credits do not roll over to the following billing period</li>
              <li>Regional language features (Indian and Southeast Asian voices) consume credits at 2× the standard rate due to higher compute costs from the underlying Azure Neural Voice models</li>
              <li>Neural HD voices (DragonHDLatestNeural) consume credits at 3× the standard rate</li>
              <li>Voice preview credits are charged at 1 credit per new preview; replays of already-previewed voices within the same session are free</li>
              <li>All credit charges are final. We do not issue refunds for consumed credits unless there is a confirmed platform error on our side</li>
              <li>We reserve the right to adjust credit pricing with 30 days' notice via email or in-app notification</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">4. Feature-Specific Terms</h2>

            <div className="space-y-5">
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-2">Create AI Voice</h3>
                <p>You may generate speech from text using Azure Neural Voices. Generated audio may be exported as MP3 or WAV. You retain rights to your original text input. Azure's terms govern the neural voice models used for synthesis.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-2">Transcribe Audio</h3>
                <p>You may upload audio files (WAV, MP3, up to 100 MB) for speech-to-text transcription. Transcription converts spoken audio into written text in the same language — it does not translate. Accuracy depends on audio quality and the selected recognition language.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-2">Speech Translate</h3>
                <p>You may upload or record audio and receive translated synthesised speech in one or more target languages. Target language selection determines the voice and credit rate. Regional target languages are billed at 2× the standard synthesis rate.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-2">Translate &amp; Dub</h3>
                <p>You may provide text or audio content, select a target language, and receive a fully dubbed audio output. Source language is auto-detected by Azure. Regional target languages are billed at the regional credit rate.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-2">AI Script Studio</h3>
                <p>Script generation, transformation, and enhancement features are powered by Google Gemini. AI-generated content is provided as-is. You are responsible for reviewing and editing all AI-generated scripts before use. We do not guarantee factual accuracy of AI output.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-2">Voice Clone</h3>
                <p>Voice cloning requires you to upload an audio sample of a voice. You must have the legal right to clone the voice you upload. Cloning another person's voice without their explicit written consent is strictly prohibited and may result in immediate account termination and legal action.</p>
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-slate-200 mb-2">Projects &amp; Storage</h3>
                <p>Authenticated users on eligible plans may save projects. Uploaded audio and generated output files are stored on secure servers and automatically deleted after 24 hours. Project metadata (name, settings, transcripts) may be retained longer as part of your account data. We are not liable for data loss due to the 24-hour file expiry.</p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">5. Prohibited Uses</h2>
            <p className="mb-3">You agree not to use the Platform to:</p>
            <ul className="list-disc list-inside space-y-2 ml-2">
              <li>Generate audio, text, or translated content that is defamatory, obscene, threatening, or unlawful</li>
              <li>Produce deepfake audio or impersonate any person without explicit consent</li>
              <li>Clone voices without ownership or written consent from the voice subject</li>
              <li>Create content that constitutes misinformation, fraud, or harassment</li>
              <li>Attempt to reverse-engineer, scrape, or abuse the underlying APIs (Azure, Google Gemini)</li>
              <li>Circumvent credit limits through automated scripts or multiple accounts</li>
              <li>Resell or sublicense access to the Platform or its APIs</li>
            </ul>
            <p className="mt-3">Violation of these prohibitions may result in immediate account suspension without refund.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">6. Intellectual Property</h2>
            <p className="mb-3">You retain full ownership of text, scripts, and audio you upload to the Platform. You grant us a limited, non-exclusive licence to process your content solely for the purpose of delivering the requested service.</p>
            <p>Generated audio produced via Azure Neural Voices is subject to Microsoft's Azure Cognitive Services terms. The Platform itself — its UI, code, brand, and design — is the intellectual property of TextToSpeeches.in. Unauthorised reproduction or distribution is prohibited.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">7. Service Availability</h2>
            <p>We strive for high availability but do not guarantee uninterrupted service. Features depend on third-party providers (Microsoft Azure, Google Gemini). Outages or degraded performance by these providers may affect the Platform. We will not issue credit refunds for downtime caused by third-party infrastructure failures.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">8. Limitation of Liability</h2>
            <p>TextToSpeeches.in is provided "as is" without warranties of any kind, express or implied. To the maximum extent permitted by law, we are not liable for any indirect, incidental, or consequential damages arising from your use of the Platform, including but not limited to loss of data, inaccurate transcriptions or translations, incorrect language detection, or credit deductions resulting from user error.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">9. Changes to Terms</h2>
            <p>We may update these Terms at any time. Material changes will be communicated via email or an in-app notice at least 7 days before taking effect. Continued use of the Platform after changes constitutes your acceptance of the revised Terms.</p>
          </section>

          <section>
            <h2 className="text-lg font-black text-slate-900 dark:text-white mb-4">10. Contact</h2>
            <p>Questions about these Terms? Contact us at <a href="mailto:help@texttospeeches.in" className="text-indigo-600 dark:text-indigo-400 hover:underline">help@texttospeeches.in</a> or visit our <Link to="/help" className="text-indigo-600 dark:text-indigo-400 hover:underline">Help page</Link>.</p>
          </section>

        </div>
      </main>

      <footer className="border-t border-black/5 dark:border-white/10 px-8 py-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">© {new Date().getFullYear()} TextToSpeeches.in</div>
          <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              <Link to="/about" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">About</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/docs" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Docs</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/help" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Help</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/privacy" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Privacy</Link>
              <span className="text-slate-300 dark:text-white/10">|</span>
              <Link to="/terms" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">Terms</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default TermsPage;
