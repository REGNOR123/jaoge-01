import React from "react";

const ChatPage: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <div className="glass studio-card !p-10 max-w-lg text-center">
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Chat Bot
        </h1>
        <p className="mt-2 text-slate-600 dark:text-slate-400 font-medium">
          Use the chat icon in the bottom-right corner to open the chat bot.
        </p>
      </div>
    </div>
  );
};

export default ChatPage;
