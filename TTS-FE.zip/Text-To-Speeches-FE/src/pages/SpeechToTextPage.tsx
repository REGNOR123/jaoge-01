import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import * as SpeechSDK from 'microsoft-cognitiveservices-speech-sdk';
import { getSpeechToken } from '../services/speechTokenService';
import { useAuth } from '../contexts/AuthContext';
import AuthRequiredModal from '../components/AuthRequiredModal';

const RECOGNITION_LANGUAGES = [
  { code: 'en-US', name: 'English (US)' },
  { code: 'en-GB', name: 'English (UK)' },
  { code: 'hi-IN', name: 'Hindi (India)' },
  { code: 'fr-FR', name: 'French (France)' },
  { code: 'de-DE', name: 'German (Germany)' },
  { code: 'es-ES', name: 'Spanish (Spain)' },
  { code: 'ja-JP', name: 'Japanese (Japan)' },
  { code: 'ko-KR', name: 'Korean (Korea)' },
  { code: 'zh-CN', name: 'Chinese (Mandarin)' },
];

const DEFAULT_RECOGNITION_LANGUAGE =
  (import.meta.env.VITE_DEFAULT_RECOGNITION_LANGUAGE as string | undefined) || 'en-US';

const SpeechToTextPage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [recognitionLanguage, setRecognitionLanguage] = useState(
    DEFAULT_RECOGNITION_LANGUAGE,
  );
  const [isRecording, setIsRecording] = useState(false);
  const [isStarting, setIsStarting] = useState(false);
  const [partialText, setPartialText] = useState('');
  const [finalText, setFinalText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState('Ready');
  const [hasRetriedToken, setHasRetriedToken] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [authRequiredOpen, setAuthRequiredOpen] = useState(false);

  const recognizerRef = useRef<SpeechSDK.SpeechRecognizer | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioChunksRef = useRef<BlobPart[]>([]);
  const recordedAudioUrlRef = useRef<string | null>(null);
  const isStoppingRef = useRef(false);
  const isRecordingRef = useRef(false);
  const finalTextRef = useRef('');
  const hasRetriedTokenRef = useRef(false);
  const errorRef = useRef<string | null>(null);

  useEffect(() => {
    isRecordingRef.current = isRecording;
  }, [isRecording]);

  useEffect(() => {
    finalTextRef.current = finalText;
  }, [finalText]);

  useEffect(() => {
    hasRetriedTokenRef.current = hasRetriedToken;
  }, [hasRetriedToken]);

  useEffect(() => {
    errorRef.current = error;
  }, [error]);

  useEffect(() => {
    return () => {
      if (recognizerRef.current) {
        recognizerRef.current.close();
        recognizerRef.current = null;
      }
      if (recordedAudioUrlRef.current) {
        URL.revokeObjectURL(recordedAudioUrlRef.current);
        recordedAudioUrlRef.current = null;
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
        mediaStreamRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!isRecording) {
      setRecordingSeconds(0);
      return;
    }

    const timer = window.setInterval(() => {
      setRecordingSeconds((prev) => prev + 1);
    }, 1000);

    return () => {
      window.clearInterval(timer);
    };
  }, [isRecording]);

  const setUiError = (message: string | null) => {
    errorRef.current = message;
    setError(message);
  };

  const formatRecordingTime = (totalSeconds: number): string => {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  const ensureMicrophonePermission = async (): Promise<MediaStream | null> => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setUiError('Microphone is not supported in this browser.');
      return null;
    }

    try {
      return await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err: any) {
      const permissionDenied =
        err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError';

      if (permissionDenied) {
        setUiError('Microphone permission denied. Please allow microphone access and try again.');
      } else {
        setUiError('Unable to access microphone. Please check your input device and try again.');
      }
      return null;
    }
  };

  const stopAndClearMediaStream = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
  };

  const startAudioCapture = (stream: MediaStream) => {
    if (typeof MediaRecorder === 'undefined') {
      return;
    }

    audioChunksRef.current = [];
    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorderRef.current = mediaRecorder;

    mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        audioChunksRef.current.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      if (audioChunksRef.current.length === 0) return;

      const blob = new Blob(audioChunksRef.current, {
        type: mediaRecorder.mimeType || 'audio/webm',
      });
      const nextUrl = URL.createObjectURL(blob);

      if (recordedAudioUrlRef.current) {
        URL.revokeObjectURL(recordedAudioUrlRef.current);
      }
      recordedAudioUrlRef.current = nextUrl;
      setRecordedAudioUrl(nextUrl);
      audioChunksRef.current = [];
    };

    mediaRecorder.start();
  };

  const stopAudioCapture = async () => {
    const mediaRecorder = mediaRecorderRef.current;
    if (!mediaRecorder) {
      stopAndClearMediaStream();
      return;
    }

    await new Promise<void>((resolve) => {
      if (mediaRecorder.state === 'inactive') {
        resolve();
        return;
      }

      mediaRecorder.onstop = ((originalHandler) => () => {
        if (originalHandler) originalHandler.call(mediaRecorder, new Event('stop'));
        resolve();
      })(mediaRecorder.onstop as any);

      mediaRecorder.stop();
    });

    mediaRecorderRef.current = null;
    stopAndClearMediaStream();
  };

  const closeCurrentRecognizer = () => {
    if (recognizerRef.current) {
      recognizerRef.current.close();
      recognizerRef.current = null;
    }
  };

  const stopCurrentRecognizer = async () => {
    const recognizer = recognizerRef.current;
    if (!recognizer) return;

    await new Promise<void>((resolve) => {
      recognizer.stopContinuousRecognitionAsync(
        () => resolve(),
        () => resolve(),
      );
    });
    closeCurrentRecognizer();
  };

  const shouldRetryToken = (errorDetails: string): boolean => {
    return /401|403|auth|authorization|token|expired/i.test(errorDetails);
  };

  const startRecognitionSession = async (retryAfterTokenFailure = false) => {
    const tokenRes = await getSpeechToken({ forceRefresh: retryAfterTokenFailure });
    if (!tokenRes.success || !tokenRes.data) {
      setUiError(tokenRes.error || 'Speech service unavailable, try again.');
      setStatus('Error');
      setIsStarting(false);
      setIsRecording(false);
      return;
    }

    const speechConfig = SpeechSDK.SpeechConfig.fromAuthorizationToken(
      tokenRes.data.token,
      tokenRes.data.region,
    );
    speechConfig.speechRecognitionLanguage = recognitionLanguage;
    const audioConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
    const recognizer = new SpeechSDK.SpeechRecognizer(speechConfig, audioConfig);
    recognizerRef.current = recognizer;

    recognizer.recognizing = (_sender, event) => {
      setPartialText(event.result.text || '');
    };

    recognizer.recognized = (_sender, event) => {
      if (event.result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
        const nextText = event.result.text?.trim();
        if (!nextText) return;

        setFinalText((prev) => (prev ? `${prev} ${nextText}` : nextText));
        setPartialText('');
        setStatus('Listening');
      }

      if (event.result.reason === SpeechSDK.ResultReason.NoMatch && !finalTextRef.current.trim()) {
        setStatus('Listening');
      }
    };

    recognizer.canceled = (_sender, event) => {
      const errorDetails = event.errorDetails || '';

      if (shouldRetryToken(errorDetails) && !hasRetriedTokenRef.current) {
        hasRetriedTokenRef.current = true;
        setHasRetriedToken(true);
        setStatus('Refreshing token...');
        void (async () => {
          await stopCurrentRecognizer();
          if (isRecordingRef.current || isStarting) {
            await startRecognitionSession(true);
          }
        })();
        return;
      }

      if (!isStoppingRef.current) {
        setUiError(errorDetails || 'Speech recognition was canceled.');
        setStatus('Error');
        setIsRecording(false);
        void stopAudioCapture();
      }
    };

    recognizer.startContinuousRecognitionAsync(
      () => {
        setIsStarting(false);
        setIsRecording(true);
        setStatus(retryAfterTokenFailure ? 'Listening (token refreshed)' : 'Listening');
      },
      async (startErr) => {
        const errorMessage = String(startErr || '');
        if (shouldRetryToken(errorMessage) && !hasRetriedTokenRef.current) {
          hasRetriedTokenRef.current = true;
          setHasRetriedToken(true);
          setStatus('Refreshing token...');
          await stopCurrentRecognizer();
          await startRecognitionSession(true);
          return;
        }

        setUiError('Unable to start recognition. Please try again.');
        setStatus('Error');
        setIsStarting(false);
        setIsRecording(false);
        closeCurrentRecognizer();
      },
    );
  };

  const handleStartRecording = async () => {
    if (!isAuthenticated) {
      setAuthRequiredOpen(true);
      return;
    }
    if (isRecording || isStarting) return;

    setUiError(null);
    setStatus('Starting...');
    setIsStarting(true);
    setPartialText('');
    setFinalText('');
    setHasRetriedToken(false);
    hasRetriedTokenRef.current = false;
    setRecordedAudioUrl(null);
    if (recordedAudioUrlRef.current) {
      URL.revokeObjectURL(recordedAudioUrlRef.current);
      recordedAudioUrlRef.current = null;
    }

    const stream = await ensureMicrophonePermission();
    if (!stream) {
      setStatus('Error');
      setIsStarting(false);
      return;
    }
    mediaStreamRef.current = stream;
    startAudioCapture(stream);

    await startRecognitionSession(false);
  };

  const handleStopRecording = async () => {
    if (!isRecording && !isStarting) return;

    isStoppingRef.current = true;
    setStatus('Stopping...');
    await stopCurrentRecognizer();
    isStoppingRef.current = false;
    setIsStarting(false);
    setIsRecording(false);
    setPartialText('');
    setStatus('Stopped');
    await stopAudioCapture();

    if (!finalTextRef.current.trim() && !errorRef.current) {
      setUiError('No speech detected.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-indigo-500/20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <AuthRequiredModal
        isOpen={authRequiredOpen}
        onClose={() => setAuthRequiredOpen(false)}
        redirectTo="/speech-to-text"
      />
      <nav className="px-8 py-6 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5 backdrop-blur-xl">
        <div className="max-w-[1200px] mx-auto">
          <div className="flex items-center justify-between mb-4">
            <Link to="/" className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
              <h1 className="text-lg font-black tracking-tighter text-slate-900 dark:text-white uppercase leading-none">
                TextTo<span className="text-indigo-500">Speeches</span>
              </h1>
            </Link>
            <Link to="/" className="text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:text-indigo-500 transition-colors flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back
            </Link>
          </div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-slate-400 flex items-center gap-2">
            <Link to="/" className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
              Home
            </Link>
            <span className="text-slate-400 dark:text-slate-600">›</span>
            <span className="text-slate-900 dark:text-white">Speech To Text</span>
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-4xl mx-auto w-full px-8 py-16">
        <div className="mb-10">
          <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tight mb-4">
            Real-Time Speech To Text
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-400 font-medium">
            Convert live microphone input into text with partial and final transcripts.
          </p>
        </div>

        <div className="glass studio-card !p-6 space-y-6">
          {(isRecording || isStarting) && (
            <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-600"></span>
                </span>
                <p className="text-sm font-bold text-rose-700 dark:text-rose-300 uppercase tracking-wide">
                  {isStarting ? 'Initializing microphone...' : 'Recording in progress'}
                </p>
              </div>
              {isRecording && (
                <p className="text-sm font-black text-rose-700 dark:text-rose-300 tabular-nums">
                  {formatRecordingTime(recordingSeconds)}
                </p>
              )}
            </div>
          )}

          <div className="flex flex-col sm:flex-row sm:items-end gap-4">
            <label className="w-full sm:w-64">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2 block">
                Recognition Language
              </span>
              <select
                value={recognitionLanguage}
                onChange={(e) => setRecognitionLanguage(e.target.value)}
                disabled={isRecording || isStarting}
                className="w-full px-4 py-2 rounded-lg bg-slate-100 dark:bg-black/30 border border-slate-200 dark:border-white/10 focus:border-indigo-500 focus:outline-none text-slate-900 dark:text-white font-medium text-sm disabled:opacity-60"
              >
                {RECOGNITION_LANGUAGES.map((language) => (
                  <option key={language.code} value={language.code}>
                    {language.name}
                  </option>
                ))}
              </select>
            </label>

            <div className="flex gap-3">
              <button
                onClick={handleStartRecording}
                disabled={isRecording || isStarting}
                className={`py-3 px-5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all ${
                  !isAuthenticated || isRecording || isStarting
                    ? 'bg-slate-100 dark:bg-white/5 text-slate-300 dark:text-slate-700 cursor-not-allowed'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20'
                }`}
              >
                {isStarting ? 'Starting...' : 'Start Recording'}
              </button>

              <button
                onClick={handleStopRecording}
                disabled={!isRecording && !isStarting}
                className={`py-3 px-5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all ${
                  !isRecording && !isStarting
                    ? 'bg-slate-100 dark:bg-white/5 text-slate-300 dark:text-slate-700 cursor-not-allowed'
                    : 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/20'
                }`}
              >
                Stop Recording
              </button>
            </div>
          </div>

          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Status: <span className="text-slate-800 dark:text-slate-200">{status}</span>
            {hasRetriedToken && <span className="ml-2 text-amber-600 dark:text-amber-400">(token refreshed)</span>}
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Live Partial Text
            </label>
            <div className="min-h-20 p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-300 text-sm leading-relaxed italic">
              {partialText || 'Partial transcription appears here while speaking...'}
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Final Transcript
            </label>
            <textarea
              value={finalText}
              readOnly
              placeholder="Final recognized speech will appear here..."
              className="w-full h-56 p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white resize-none font-medium text-sm leading-relaxed"
            />
          </div>

          {recordedAudioUrl && (
            <div>
              <label className="block text-[10px] font-black uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
                Recorded Sample
              </label>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-black/30 border border-slate-200 dark:border-white/10">
                <audio controls src={recordedAudioUrl} className="w-full">
                  Your browser does not support audio playback.
                </audio>
              </div>
            </div>
          )}
        </div>

        {error && (
          <div className="mt-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20">
            <p className="text-red-600 dark:text-red-400 text-xs font-bold uppercase tracking-wide">
              {error}
            </p>
          </div>
        )}
      </main>
    </div>
  );
};

export default SpeechToTextPage;
