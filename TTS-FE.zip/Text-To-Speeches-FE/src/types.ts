
export enum VoiceName {
  // English (US)
  JENNY = 'en-US-JennyNeural',
  GUY = 'en-US-GuyNeural',
  ARIA = 'en-US-AriaNeural',
  DAVIS = 'en-US-DavisNeural',
  STEFFAN = 'en-US-SteffanNeural',
  // English (UK)
  SONIA = 'en-GB-SoniaNeural',
  RYAN = 'en-GB-RyanNeural',
  // English (AU)
  NATASHA = 'en-AU-NatashaNeural',
  WILLIAM = 'en-AU-WilliamNeural',
  // English (IN)
  NEERJA = 'en-IN-NeerjaNeural',
  PRABHAT = 'en-IN-PrabhatNeural',
  CLARA = 'en-CA-ClaraNeural',
  LIAM = 'en-CA-LiamNeural',
  DENISE = 'fr-FR-DeniseNeural',
  HENRI = 'fr-FR-HenriNeural',
  SYLVIE = 'fr-CA-SylvieNeural',
  ANTOINE = 'fr-CA-AntoineNeural',
  KATJA = 'de-DE-KatjaNeural',
  CONRAD = 'de-DE-ConradNeural',
  ELVIRA = 'es-ES-ElviraNeural',
  ALVARO = 'es-ES-AlvaroNeural',
  DALIA = 'es-MX-DaliaNeural',
  JORGE = 'es-MX-JorgeNeural',
  ELSA = 'it-IT-ElsaNeural',
  ISABELLA = 'it-IT-IsabellaNeural',
  DIEGO = 'it-IT-DiegoNeural',
  NANAMI = 'ja-JP-NanamiNeural',
  KEITA = 'ja-JP-KeitaNeural',
  SUN_HI = 'ko-KR-SunHiNeural',
  IN_JOON = 'ko-KR-InJoonNeural',
  XIAOXIAO = 'zh-CN-XiaoxiaoNeural',
  YUNXI = 'zh-CN-YunxiNeural',
  // Hindi
  SWARA = 'hi-IN-SwaraNeural',
  MADHUR = 'hi-IN-MadhurNeural',
  AARAV = 'hi-IN-AaravNeural',
  KAVAYA = 'hi-IN-KavyaNeural',
  // Tamil
  PALLAVI = 'ta-IN-PallaviNeural',
  VALLUVAR = 'ta-IN-ValluvarNeural',
  // Telugu
  SHRUTI = 'te-IN-ShrutiNeural',
  MOHAN = 'te-IN-MohanNeural',
  // Bengali (India)
  TANISHAA = 'bn-IN-TanishaaNeural',
  BASHKAR = 'bn-IN-BashkarNeural',
  // Malayalam
  SOBHANA = 'ml-IN-SobhanaNeural',
  MIDHUN = 'ml-IN-MidhunNeural',
  // Marathi
  AAROHI = 'mr-IN-AarohiNeural',
  MANOHAR = 'mr-IN-ManoharNeural',
  // Gujarati
  DHWANI = 'gu-IN-DhwaniNeural',
  NIRANJAN = 'gu-IN-NiranjanNeural',
  // Kannada
  SAPNA = 'kn-IN-SapnaNeural',
  GAGAN = 'kn-IN-GaganNeural',
  // Punjabi
  VAANI = 'pa-IN-VaaniNeural',
  OJAS = 'pa-IN-OjasNeural',
  // Urdu (India)
  GUL = 'ur-IN-GulNeural',
  SALMAN = 'ur-IN-SalmanNeural',
  // Odia
  SUBHASINI = 'or-IN-SubhasiniNeural',
  SUKANT = 'or-IN-SukantNeural',
  // Assamese
  YASHICA = 'as-IN-YashicaNeural',
  PRIYOM = 'as-IN-PriyomNeural',
  // Arabic
  ZARIYAH = 'ar-SA-ZariyahNeural',
  HAMED = 'ar-SA-HamedNeural',
  FATIMA = 'ar-AE-FatimaNeural',
  HAMDAN = 'ar-AE-HamdanNeural',
  SVETLANA = 'ru-RU-SvetlanaNeural',
  DMITRY = 'ru-RU-DmitryNeural',
  EMEL = 'tr-TR-EmelNeural',
  AHMET = 'tr-TR-AhmetNeural',
  // Southeast Asian
  HOAI_MY = 'vi-VN-HoaiMyNeural',
  NAM_MINH = 'vi-VN-NamMinhNeural',
  PREMWADEE = 'th-TH-PremwadeeNeural',
  NIWAT = 'th-TH-NiwatNeural',
  GADIS = 'id-ID-GadisNeural',
  ARDI = 'id-ID-ArdiNeural',
  BLESSICA = 'fil-PH-BlessicaNeural',
  ANGELO = 'fil-PH-AngeloNeural',
  YASMIN = 'ms-MY-YasminNeural',
  OSMAN = 'ms-MY-OsmanNeural',
  // European
  COLETTE = 'nl-NL-ColetteNeural',
  MAARTEN = 'nl-NL-MaartenNeural',
  ZOFIA = 'pl-PL-ZofiaNeural',
  MAREK = 'pl-PL-MarekNeural',
  HILLEVI = 'sv-SE-HilleviNeural',
  MATTIAS = 'sv-SE-MattiasNeural',
  FRANCISCA = 'pt-BR-FranciscaNeural',
  ANTONIO = 'pt-BR-AntonioNeural',
  RAQUEL = 'pt-PT-RaquelNeural',
  DUARTE = 'pt-PT-DuarteNeural',
  ATHINA = 'el-GR-AthinaNeural',
  NESTORAS = 'el-GR-NestorasNeural',
  HILA = 'he-IL-HilaNeural',
  AVRI = 'he-IL-AvriNeural',
  CHRISTEL = 'da-DK-ChristelNeural',
  JEPPE = 'da-DK-JeppeNeural',
  SELMA = 'fi-FI-SelmaNeural',
  HARRI = 'fi-FI-HarriNeural',
  PERNILLE = 'nb-NO-PernilleNeural',
  FINN = 'nb-NO-FinnNeural'
}

export type VoiceRegion = 'English' | 'Indian' | 'SE Asian' | 'East Asian' | 'European' | 'Middle Eastern';

export type SpeechStyle =
  | 'general'
  | 'cheerful'
  | 'sad'
  | 'angry'
  | 'fearful'
  | 'disgruntled'
  | 'serious'
  | 'depressed'
  | 'embarrassed'
  | 'empathetic'
  | 'whispering'
  | 'assistant'
  | 'chat'
  | 'newscast'
  | 'customer-service'
  | 'friendly';

export interface SpeechEntry {
  id: string;
  recordingName: string;
  text: string;
  timestamp: number;
  voice: VoiceName;
  voiceLabel: string;
  audioUrl?: string;
  settings?: {
    rate: number;
    pitch: number;
    volume: number;
    style: SpeechStyle;
    degree: number;
  }
}

export interface VoiceOption {
  id: VoiceName;
  name: string;
  lang: string;
  description: string;
  gender: 'Male' | 'Female';
  region: VoiceRegion;
}
