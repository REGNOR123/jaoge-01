import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Type, Clock, Sparkles, Wand2, UserPlus, LogIn, Zap, X, ChevronDown } from 'lucide-react';
import { useGuestUsage, GUEST_PLAN_LIMITS } from '@/contexts/GuestUsageContext';
import { useAuth } from '@/contexts/AuthContext';
import UsageProgressBar from './UsageProgressBar';
import { cn } from '@/lib/utils';

interface GuestTrialBannerProps {
  className?: string;
}

const GuestTrialBanner: React.FC<GuestTrialBannerProps> = ({ className }) => {
  const navigate = useNavigate();
  const { isAuthenticated, isLoading } = useAuth();
  const { usage } = useGuestUsage();
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  // Local state to track usage from events (for immediate UI updates)
  const [localUsage, setLocalUsage] = useState<{
    characters: number;
    voiceMinutes: number;
    aiEnhancements: number;
    autoGenerate: number;
  } | null>(null);
  
  // Listen for usage updates from other components
  useEffect(() => {
    const handleUsageUpdate = (event: Event) => {
      const customEvent = event as CustomEvent;
      if (customEvent.detail) {
        const u = customEvent.detail;
        setLocalUsage({
          characters: u.characters_used ?? 0,
          voiceMinutes: u.voice_minutes_used ?? 0,
          aiEnhancements: u.ai_enhancements_used ?? 0,
          autoGenerate: u.auto_generate_used ?? 0,
        });
      }
    };
    
    window.addEventListener('guest-usage-updated', handleUsageUpdate);
    return () => {
      window.removeEventListener('guest-usage-updated', handleUsageUpdate);
    };
  }, []);
  
  // Sync local usage with context usage when context changes
  useEffect(() => {
    if (usage) {
      setLocalUsage({
        characters: usage.characters_used,
        voiceMinutes: usage.voice_minutes_used,
        aiEnhancements: usage.ai_enhancements_used,
        autoGenerate: usage.auto_generate_used,
      });
    }
  }, [usage]);
  
  // Don't show for authenticated users
  if (isLoading || isAuthenticated) return null;

  // Use local usage (which gets updates from both context and events)
  const currentUsage = localUsage ?? {
    characters: usage?.characters_used ?? 0,
    voiceMinutes: usage?.voice_minutes_used ?? 0,
    aiEnhancements: usage?.ai_enhancements_used ?? 0,
    autoGenerate: usage?.auto_generate_used ?? 0,
  };

  const limits = {
    characters: GUEST_PLAN_LIMITS.characters,
    voiceMinutes: GUEST_PLAN_LIMITS.voiceMinutes,
    aiEnhancements: GUEST_PLAN_LIMITS.aiEnhancements,
    autoGenerate: GUEST_PLAN_LIMITS.autoGenerate,
  };

  const handleSignup = () => {
    navigate('/signup', { state: { redirectTo: window.location.pathname } });
  };

  const handleLogin = () => {
    navigate('/login', { state: { redirectTo: window.location.pathname } });
  };

  // Collapsed state - show simple tagline
  if (isCollapsed) {
    return (
      <div
        className={cn(
          'rounded-xl px-4 py-3',
          'bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-blue-500/10',
          'dark:from-indigo-900/20 dark:via-purple-900/20 dark:to-blue-900/20',
          'border border-indigo-200/50 dark:border-indigo-500/20',
          className
        )}
      >
        <div className="flex items-center justify-between gap-4">
          <p className="text-sm text-slate-600 dark:text-slate-300">
            <span className="font-semibold text-slate-900 dark:text-white">👤 You're using Free Trial</span>
            {' · '}
            <button
              type="button"
              onClick={() => setIsCollapsed(false)}
              className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-medium underline underline-offset-2 transition-colors"
            >
              click here to see free usage
            </button>
          </p>
          <button
            type="button"
            onClick={() => setIsCollapsed(false)}
            className="p-1.5 rounded-lg hover:bg-white/50 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
            aria-label="Expand banner"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-2xl p-6 lg:p-8',
        'bg-gradient-to-br from-indigo-500/10 via-purple-500/10 to-blue-500/10',
        'dark:from-indigo-900/30 dark:via-purple-900/30 dark:to-blue-900/30',
        'border border-indigo-200/50 dark:border-indigo-500/20',
        'shadow-lg shadow-indigo-500/5',
        className
      )}
    >
      {/* Close/Collapse button */}
      <button
        type="button"
        onClick={() => setIsCollapsed(true)}
        className="absolute top-4 right-4 z-20 p-2 rounded-xl hover:bg-white/50 dark:hover:bg-white/10 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
        aria-label="Collapse banner"
      >
        <X className="w-5 h-5" />
      </button>

      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-blue-500/10 to-indigo-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2 pointer-events-none" />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6 pr-8">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-2xl">👤</span>
              <h2 className="text-xl lg:text-2xl font-bold text-slate-900 dark:text-white">
                You're using Free Trial
              </h2>
            </div>
            <p className="text-slate-600 dark:text-slate-300 text-sm lg:text-base max-w-md">
              Try all features with limited credits. Sign up to unlock more.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 lg:flex-shrink-0">
            <button
              type="button"
              onClick={handleSignup}
              className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold transition-all duration-200 hover:scale-105 hover:shadow-lg hover:shadow-indigo-500/25 inline-flex items-center justify-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              Sign Up Free
            </button>
            <button
              type="button"
              onClick={handleLogin}
              className="px-6 py-3 rounded-xl border border-slate-200 dark:border-white/10 bg-white/80 dark:bg-white/5 hover:bg-white dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 text-sm font-bold transition-all duration-200 inline-flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              Login
            </button>
          </div>
        </div>

        {/* Usage Progress Bars */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-white/60 dark:bg-white/5 backdrop-blur-sm border border-white/50 dark:border-white/10">
            <UsageProgressBar
              label="Characters"
              used={Math.round(currentUsage.characters)}
              total={limits.characters}
              icon={<Type className="w-4 h-4" />}
            />
          </div>
          <div className="p-4 rounded-xl bg-white/60 dark:bg-white/5 backdrop-blur-sm border border-white/50 dark:border-white/10">
            <UsageProgressBar
              label="Voice Minutes"
              used={Math.round(currentUsage.voiceMinutes * 100) / 100}
              total={limits.voiceMinutes}
              icon={<Clock className="w-4 h-4" />}
            />
          </div>
          <div className="p-4 rounded-xl bg-white/60 dark:bg-white/5 backdrop-blur-sm border border-white/50 dark:border-white/10">
            <UsageProgressBar
              label="AI Enhancements"
              used={Math.round(currentUsage.aiEnhancements)}
              total={limits.aiEnhancements}
              icon={<Sparkles className="w-4 h-4" />}
            />
          </div>
          <div className="p-4 rounded-xl bg-white/60 dark:bg-white/5 backdrop-blur-sm border border-white/50 dark:border-white/10">
            <UsageProgressBar
              label="Auto-generate"
              used={Math.round(currentUsage.autoGenerate)}
              total={limits.autoGenerate}
              icon={<Wand2 className="w-4 h-4" />}
            />
          </div>
        </div>

        {/* Helper text */}
        <div className="mt-4 flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
          <Zap className="w-4 h-4 text-amber-500" />
          <span>Unlock more usage and save your work by signing up</span>
        </div>
      </div>
    </div>
  );
};

export default GuestTrialBanner;
