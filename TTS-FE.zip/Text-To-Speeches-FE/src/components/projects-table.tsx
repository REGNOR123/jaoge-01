import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Copy,
  FolderSearch,
  Mic,
  FileText,
  Globe,
  Languages,
  MoreHorizontal,
  PenTool,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";
import {
  type ColumnDef,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  type SortingState,
  useReactTable,
  type VisibilityState,
} from "@tanstack/react-table";
import type { ProjectTableRow, ProjectTableStatus, ProjectTableType } from "../data/projects";
import { formatProjectDate, formatRelativeDate, withinDateRange } from "../data/projects";
import { cn } from "../lib/utils";
import { StatusBadge, TypeBadge } from "./status-badge";
import TableFilters, { type TableFiltersValue } from "./table-filters";
import TableToolbar from "./table-toolbar";
import { Button } from "./ui/button";
import { Link } from "react-router-dom";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import type { ProjectStatus } from "../utils/projectsStorage";

type ProjectsTableProps = {
  data: ProjectTableRow[];
  loading: boolean;
  onRefresh: () => void;
  onOpenProject: (project: ProjectTableRow) => void;
  onDeleteProjects: (projects: ProjectTableRow[]) => void;
  onRenameProject: (id: string, newName: string) => void;
  onDuplicateProject: (id: string) => void;
  onBulkStatusChange: (rows: ProjectTableRow[], status: ProjectStatus) => void;
};

const PAGE_SIZE_OPTIONS = [10, 20, 50, 100];

const DEFAULT_FILTERS: TableFiltersValue = {
  projectName: "",
  type: "ALL",
  status: "ALL",
  createdAt: { from: "", to: "" },
  lastModified: { from: "", to: "" },
};

const hasActiveFilters = (filters: TableFiltersValue): boolean =>
  filters.projectName.trim() !== "" ||
  filters.type !== "ALL" ||
  filters.status !== "ALL" ||
  filters.createdAt.from !== "" ||
  filters.createdAt.to !== "" ||
  filters.lastModified.from !== "" ||
  filters.lastModified.to !== "";

const PREFS_KEY = "tts_projects_prefs";

type SavedPrefs = {
  sorting?: SortingState;
  columnVisibility?: VisibilityState;
  pageSize?: number;
};

const loadPrefs = (): SavedPrefs => {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};

const savePrefs = (prefs: SavedPrefs) => {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  } catch { /* ignore quota errors */ }
};

const ProjectsTable: React.FC<ProjectsTableProps> = ({
  data,
  loading,
  onRefresh,
  onOpenProject,
  onDeleteProjects,
  onRenameProject,
  onDuplicateProject,
  onBulkStatusChange,
}) => {
  const savedPrefs = useMemo(loadPrefs, []);
  const [editMode, setEditMode] = useState(false);
  const [filtersVisible, setFiltersVisible] = useState(true);
  const [globalSearch, setGlobalSearch] = useState("");
  const [sorting, setSorting] = useState<SortingState>(savedPrefs.sorting || [{ id: "lastModified", desc: true }]);
  const [rowSelection, setRowSelection] = useState({});
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>(savedPrefs.columnVisibility || {
    projectName: true,
    type: true,
    status: true,
    createdAt: true,
    lastModified: true,
    actions: true,
  });
  const [initialPageSize] = useState(savedPrefs.pageSize || 10);
  const [filters, setFilters] = useState<TableFiltersValue>(DEFAULT_FILTERS);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const renameInputRef = useRef<HTMLInputElement>(null);

  // Rename handlers
  const startRename = useCallback((id: string, currentName: string) => {
    setRenamingId(id);
    setRenameValue(currentName);
    requestAnimationFrame(() => renameInputRef.current?.focus());
  }, []);

  const commitRename = useCallback(() => {
    if (renamingId && renameValue.trim()) {
      onRenameProject(renamingId, renameValue.trim());
    }
    setRenamingId(null);
    setRenameValue("");
  }, [renamingId, renameValue, onRenameProject]);

  const cancelRename = useCallback(() => {
    setRenamingId(null);
    setRenameValue("");
  }, []);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.projectName.trim()) count++;
    if (filters.type !== "ALL") count++;
    if (filters.status !== "ALL") count++;
    if (filters.createdAt.from || filters.createdAt.to) count++;
    if (filters.lastModified.from || filters.lastModified.to) count++;
    return count;
  }, [filters]);

  const handleClearFilters = () => setFilters(DEFAULT_FILTERS);

  const filteredData = useMemo(() => {
    const search = globalSearch.trim().toLowerCase();
    return data.filter((project) => {
      if (search) {
        const haystack = [
          project.projectName,
          project.type,
          project.status,
          formatProjectDate(project.createdAt),
          formatProjectDate(project.lastModified),
        ]
          .join(" ")
          .toLowerCase();
        if (!haystack.includes(search)) return false;
      }

      if (filters.projectName.trim() && !project.projectName.toLowerCase().includes(filters.projectName.trim().toLowerCase())) {
        return false;
      }
      if (filters.type !== "ALL" && project.type !== filters.type) return false;
      if (filters.status !== "ALL" && project.status !== filters.status) return false;
      if ((filters.createdAt.from || filters.createdAt.to) && !withinDateRange(project.createdAt, filters.createdAt)) return false;
      if ((filters.lastModified.from || filters.lastModified.to) && !withinDateRange(project.lastModified, filters.lastModified)) return false;
      return true;
    });
  }, [data, filters, globalSearch]);

  const typeOptions = useMemo(() => {
    return Array.from(new Set(data.map((project) => project.type))) as ProjectTableType[];
  }, [data]);

  useEffect(() => {
    if (!editMode) setRowSelection({});
  }, [editMode]);

  useEffect(() => {
    setColumnVisibility((current) => ({
      ...current,
      select: editMode,
    }));
  }, [editMode]);

  const columns = useMemo<ColumnDef<ProjectTableRow>[]>(
    () => [
      {
        id: "select",
        header: ({ table }) =>
          editMode ? (
            <input
              type="checkbox"
              className="h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500/30"
              checked={table.getIsAllPageRowsSelected()}
              onChange={table.getToggleAllPageRowsSelectedHandler()}
              aria-label="Select all rows"
            />
          ) : null,
        cell: ({ row }) =>
          editMode ? (
            <input
              type="checkbox"
              className="h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500/30"
              checked={row.getIsSelected()}
              onChange={(e) => {
                e.stopPropagation();
                row.getToggleSelectedHandler()(e);
              }}
              aria-label={`Select ${row.original.projectName}`}
            />
          ) : null,
        enableSorting: false,
        enableHiding: false,
        size: 48,
      },
      {
        accessorKey: "projectName",
        header: "Project Name",
        cell: ({ row }) =>
          renamingId === row.original.id ? (
            <input
              ref={renameInputRef}
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              onBlur={commitRename}
              onKeyDown={(e) => {
                if (e.key === "Enter") commitRename();
                if (e.key === "Escape") cancelRename();
                e.stopPropagation();
              }}
              onClick={(e) => e.stopPropagation()}
              className="w-full px-2 py-1 rounded-md border border-indigo-300 bg-white dark:bg-slate-900 text-sm font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
              aria-label="Rename project"
            />
          ) : (
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-900 dark:text-white">{row.original.projectName}</span>
            </div>
          ),
      },
      {
        accessorKey: "type",
        header: "Type",
        cell: ({ row }) => <TypeBadge type={row.original.type} />,
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => <StatusBadge status={row.original.status} />,
      },
      {
        accessorKey: "createdAt",
        header: "Created Date",
        cell: ({ row }) => (
          <span className="text-sm text-slate-600 dark:text-slate-300" title={formatProjectDate(row.original.createdAt)}>
            {formatRelativeDate(row.original.createdAt)}
          </span>
        ),
      },
      {
        accessorKey: "lastModified",
        header: "Last Modified",
        cell: ({ row }) => (
          <span className="text-sm text-slate-600 dark:text-slate-300" title={formatProjectDate(row.original.lastModified)}>
            {formatRelativeDate(row.original.lastModified)}
          </span>
        ),
      },
      {
        id: "actions",
        header: "",
        enableSorting: false,
        enableHiding: false,
        size: 48,
        cell: ({ row }) => (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                onClick={(e) => e.stopPropagation()}
                className="p-1.5 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:text-slate-200 dark:hover:bg-white/10 transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                aria-label={`Actions for ${row.original.projectName}`}
              >
                <MoreHorizontal className="h-4 w-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuItem onClick={() => onOpenProject(row.original)}>
                Open
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => startRename(row.original.id, row.original.projectName)}>
                <Pencil className="h-3.5 w-3.5 mr-2" />
                Rename
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onDuplicateProject(row.original.id)}>
                <Copy className="h-3.5 w-3.5 mr-2" />
                Duplicate
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => onDeleteProjects([row.original])}
                className="text-red-600 dark:text-red-400 focus:text-red-600 dark:focus:text-red-400"
              >
                <Trash2 className="h-3.5 w-3.5 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ),
      },
    ],
    [editMode, renamingId, renameValue, startRename, commitRename, cancelRename, onOpenProject, onDeleteProjects, onDuplicateProject],
  );

  const table = useReactTable({
    data: filteredData,
    columns,
    state: {
      sorting,
      rowSelection,
      columnVisibility,
    },
    enableRowSelection: editMode,
    onSortingChange: setSorting,
    onRowSelectionChange: setRowSelection,
    onColumnVisibilityChange: setColumnVisibility,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: {
      pagination: { pageSize: initialPageSize },
    },
  });

  // Persist preferences on change
  useEffect(() => {
    savePrefs({
      sorting,
      columnVisibility,
      pageSize: table.getState().pagination.pageSize,
    });
  }, [sorting, columnVisibility, table.getState().pagination.pageSize]);

  const selectedRows = table.getSelectedRowModel().rows.map((row) => row.original);

  const exportCsv = () => {
    const headers = ["Project Name", "Status", "Type", "Created Date", "Last Modified"];
    const rows = table.getSortedRowModel().rows.map((row) => [
      row.original.projectName,
      row.original.status,
      row.original.type,
      row.original.createdAt,
      row.original.lastModified,
    ]);
    const csv = [headers, ...rows]
      .map((line) => line.map((value) => `"${String(value).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "projects.csv";
    link.click();
    URL.revokeObjectURL(url);
  };

  const sortableIcon = (sorted: false | "asc" | "desc") => {
    if (sorted === "asc") return <ArrowUp className="h-4 w-4 text-slate-500" />;
    if (sorted === "desc") return <ArrowDown className="h-4 w-4 text-slate-500" />;
    return <ArrowUpDown className="h-4 w-4 text-slate-400" />;
  };

  const columnToggles = table
    .getAllLeafColumns()
    .filter((column) => !["select"].includes(column.id))
    .map((column) => ({
      id: column.id,
      label:
        column.id === "projectName"
          ? "Project Name"
          : column.id === "createdAt"
            ? "Created Date"
            : column.id === "lastModified"
              ? "Last Modified"
              : column.id.charAt(0).toUpperCase() + column.id.slice(1),
      visible: column.getIsVisible(),
    }));

  // Pagination info
  const pageIndex = table.getState().pagination.pageIndex;
  const pageSize = table.getState().pagination.pageSize;
  const totalRows = filteredData.length;
  const startRow = totalRows === 0 ? 0 : pageIndex * pageSize + 1;
  const endRow = Math.min((pageIndex + 1) * pageSize, totalRows);

  const isEmptyNoData = data.length === 0 && !loading;
  const isEmptyFiltered = data.length > 0 && filteredData.length === 0 && !loading;

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-white/10 dark:bg-slate-950/80">
      <TableToolbar
        editMode={editMode}
        filtersVisible={filtersVisible}
        globalSearch={globalSearch}
        selectedCount={selectedRows.length}
        totalCount={totalRows}
        activeFilterCount={activeFilterCount}
        columnToggles={columnToggles}
        onEditToggle={() => setEditMode((value) => !value)}
        onFiltersToggle={() => setFiltersVisible((value) => !value)}
        onColumnToggle={(id, checked) => table.getColumn(id)?.toggleVisibility(checked)}
        onExport={exportCsv}
        onRefresh={onRefresh}
        onDeleteSelected={() => onDeleteProjects(selectedRows)}
        onGlobalSearchChange={setGlobalSearch}
        onClearFilters={handleClearFilters}
      />

      {editMode && selectedRows.length > 0 && (
        <div className="mt-3 flex items-center gap-2 text-xs">
          <span className="font-semibold text-slate-500 dark:text-slate-400">Set status:</span>
          <button
            type="button"
            onClick={() => onBulkStatusChange(selectedRows, "Completed")}
            className="px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/20 font-semibold transition-colors"
          >
            Completed
          </button>
          <button
            type="button"
            onClick={() => onBulkStatusChange(selectedRows, "Processing")}
            className="px-2.5 py-1 rounded-md bg-amber-50 text-amber-700 hover:bg-amber-100 dark:bg-amber-500/10 dark:text-amber-300 dark:hover:bg-amber-500/20 font-semibold transition-colors"
          >
            Processing
          </button>
        </div>
      )}

      {filtersVisible && (
        <div className="mt-4">
          <TableFilters
            value={filters}
            typeOptions={typeOptions}
            onChange={setFilters}
            onClearAll={handleClearFilters}
            hasActiveFilters={activeFilterCount > 0}
          />
        </div>
      )}

      <div className="mt-4 overflow-hidden rounded-xl border border-slate-200 dark:border-white/10">
        <div className="max-h-[680px] overflow-auto">
          <table className="min-w-full border-separate border-spacing-0 text-sm" role="grid" aria-label="Projects table">
            <thead className="sticky top-0 z-10 bg-white/95 backdrop-blur dark:bg-slate-950/95">
              {table.getHeaderGroups().map((headerGroup) => (
                <tr key={headerGroup.id}>
                  {headerGroup.headers.map((header) => (
                    <th
                      key={header.id}
                      className="border-b border-slate-200 bg-white px-4 py-3 text-left text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 transition-colors dark:border-white/10 dark:bg-slate-950 dark:text-slate-400"
                      style={{ width: header.getSize() }}
                      aria-sort={
                        header.column.getIsSorted() === "asc"
                          ? "ascending"
                          : header.column.getIsSorted() === "desc"
                            ? "descending"
                            : undefined
                      }
                    >
                      {header.isPlaceholder ? null : (
                        <button
                          type="button"
                          className={cn(
                            "flex items-center gap-2",
                            header.column.getCanSort() ? "transition-colors hover:text-slate-900 dark:hover:text-white" : "cursor-default",
                          )}
                          onClick={header.column.getToggleSortingHandler()}
                          disabled={!header.column.getCanSort()}
                          aria-label={header.column.getCanSort() ? `Sort by ${typeof header.column.columnDef.header === "string" ? header.column.columnDef.header : header.column.id}` : undefined}
                        >
                          {flexRender(header.column.columnDef.header, header.getContext())}
                          {header.column.getCanSort() ? sortableIcon(header.column.getIsSorted()) : null}
                        </button>
                      )}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>

            <tbody className="bg-white dark:bg-slate-950">
              {loading ? (
                Array.from({ length: pageSize }).map((_, rowIndex) => (
                  <tr key={`skeleton-${rowIndex}`} className="odd:bg-white even:bg-slate-50/70 dark:odd:bg-slate-950 dark:even:bg-white/[0.03]">
                    {table.getVisibleLeafColumns().map((column) => (
                      <td key={`${column.id}-${rowIndex}`} className="border-b border-slate-100 px-4 py-4 dark:border-white/5">
                        <div
                          className="h-4 animate-pulse rounded bg-slate-200 dark:bg-white/10"
                          style={{ animationDelay: `${rowIndex * 50}ms` }}
                        />
                      </td>
                    ))}
                  </tr>
                ))
              ) : isEmptyNoData ? (
                <tr>
                  <td colSpan={table.getVisibleLeafColumns().length} className="px-6 py-20 text-center">
                    <div className="mx-auto flex max-w-md flex-col items-center gap-4">
                      <div className="rounded-full bg-indigo-50 p-4 dark:bg-indigo-500/10">
                        <Plus className="h-6 w-6 text-indigo-600 dark:text-indigo-300" />
                      </div>
                      <div className="text-lg font-semibold text-slate-900 dark:text-white">No projects yet</div>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Projects are automatically created when you use any workflow. Get started with one below.
                      </p>
                      <div className="flex flex-wrap justify-center gap-2 mt-2">
                        <Link
                          to="/create-voice"
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white transition-colors"
                        >
                          <Mic className="h-3.5 w-3.5" /> Create Voice
                        </Link>
                        <Link
                          to="/transcribe"
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-white hover:bg-slate-50 dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white border border-slate-200 dark:border-white/10 transition-colors"
                        >
                          <FileText className="h-3.5 w-3.5" /> Transcribe
                        </Link>
                        <Link
                          to="/translate-dub"
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-white hover:bg-slate-50 dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white border border-slate-200 dark:border-white/10 transition-colors"
                        >
                          <Globe className="h-3.5 w-3.5" /> Translate & Dub
                        </Link>
                        <Link
                          to="/speech-translate"
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-white hover:bg-slate-50 dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white border border-slate-200 dark:border-white/10 transition-colors"
                        >
                          <Languages className="h-3.5 w-3.5" /> Speech Translate
                        </Link>
                        <Link
                          to="/script-studio"
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-white hover:bg-slate-50 dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white border border-slate-200 dark:border-white/10 transition-colors"
                        >
                          <PenTool className="h-3.5 w-3.5" /> Script Studio
                        </Link>
                      </div>
                    </div>
                  </td>
                </tr>
              ) : isEmptyFiltered ? (
                <tr>
                  <td colSpan={table.getVisibleLeafColumns().length} className="px-6 py-20 text-center">
                    <div className="mx-auto flex max-w-sm flex-col items-center gap-3">
                      <div className="rounded-full bg-slate-100 p-4 dark:bg-white/5">
                        <FolderSearch className="h-6 w-6 text-slate-500 dark:text-slate-300" />
                      </div>
                      <div className="text-lg font-semibold text-slate-900 dark:text-white">No matching projects</div>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Adjust your filters or search query to find a project.
                      </p>
                      {(hasActiveFilters(filters) || globalSearch.trim()) && (
                        <button
                          type="button"
                          onClick={() => {
                            setFilters(DEFAULT_FILTERS);
                            setGlobalSearch("");
                          }}
                          className="mt-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-600 hover:bg-indigo-50 dark:text-indigo-300 dark:hover:bg-indigo-500/10 transition-colors"
                        >
                          Clear Filters & Search
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                table.getRowModel().rows.map((row, index) => (
                  <tr
                    key={row.id}
                    data-state={row.getIsSelected() ? "selected" : undefined}
                    onClick={() => {
                      if (!editMode) onOpenProject(row.original);
                    }}
                    onKeyDown={(e) => {
                      if (!editMode && e.key === "Enter") onOpenProject(row.original);
                    }}
                    tabIndex={editMode ? undefined : 0}
                    role={editMode ? undefined : "link"}
                    aria-label={editMode ? undefined : `Open project ${row.original.projectName}`}
                    className={cn(
                      "group transition-colors duration-200",
                      !editMode && "cursor-pointer",
                      "hover:bg-sky-50/60 dark:hover:bg-white/[0.04]",
                      index % 2 === 0 ? "bg-white dark:bg-slate-950" : "bg-slate-50/70 dark:bg-white/[0.02]",
                      row.getIsSelected() && "bg-sky-50 dark:bg-sky-500/10",
                    )}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <td key={cell.id} className="border-b border-slate-100 px-4 py-4 align-middle dark:border-white/5">
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-4 flex flex-col gap-3 border-t border-slate-200 pt-4 dark:border-white/10 md:flex-row md:items-center md:justify-between">
        <div className="text-sm text-slate-500 dark:text-slate-400">
          {totalRows > 0 ? (
            <>Showing {startRow}–{endRow} of {totalRows} projects</>
          ) : (
            <>No projects</>
          )}
          {selectedRows.length > 0 && (
            <span className="ml-3 inline-flex items-center rounded-full bg-sky-100 px-2 py-0.5 text-xs font-semibold text-sky-700 dark:bg-sky-500/10 dark:text-sky-300">
              {selectedRows.length} selected
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-2">
            <span className="text-xs text-slate-500 dark:text-slate-400">Rows</span>
            <select
              value={table.getState().pagination.pageSize}
              onChange={(event) => table.setPageSize(Number(event.target.value))}
              aria-label="Rows per page"
              className="h-10 rounded-md border border-slate-200 bg-white px-3 text-sm text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500/30 dark:border-white/10 dark:bg-white/5 dark:text-slate-200"
            >
              {PAGE_SIZE_OPTIONS.map((size) => (
                <option key={size} value={size}>
                  {size}
                </option>
              ))}
            </select>
          </label>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="rounded-md"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
              aria-label="Previous page"
            >
              <ChevronLeft className="h-4 w-4" />
              Previous
            </Button>
            <span className="text-sm text-slate-500 dark:text-slate-400 tabular-nums">
              {pageIndex + 1} / {Math.max(1, table.getPageCount())}
            </span>
            <Button
              variant="outline"
              size="sm"
              className="rounded-md"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
              aria-label="Next page"
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectsTable;
