import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";

type DialogVariant = "info" | "success" | "warning" | "danger";
type DialogType = "alert" | "confirm";

type DialogOptions = {
  title?: string;
  confirmText?: string;
  cancelText?: string;
  variant?: DialogVariant;
};

type DialogState = {
  open: boolean;
  type: DialogType;
  title: string;
  message: React.ReactNode;
  confirmText: string;
  cancelText: string;
  variant: DialogVariant;
};

type DialogContextValue = {
  alert: (message: React.ReactNode, options?: DialogOptions) => Promise<void>;
  info: (message: React.ReactNode, options?: Omit<DialogOptions, "variant">) => Promise<void>;
  confirm: (message: React.ReactNode, options?: DialogOptions) => Promise<boolean>;
};

const DialogContext = createContext<DialogContextValue | null>(null);

const defaultState: DialogState = {
  open: false,
  type: "alert",
  title: "Notice",
  message: null,
  confirmText: "OK",
  cancelText: "Cancel",
  variant: "info",
};

const variantTone = (variant: DialogVariant) => {
  switch (variant) {
    case "success":
      return {
        ring: "focus:ring-emerald-500/30",
        accent: "bg-emerald-500/10 border-emerald-500/20 text-emerald-800 dark:text-emerald-200",
        primary: "bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm",
      };
    case "warning":
      return {
        ring: "focus:ring-amber-500/30",
        accent: "bg-amber-500/10 border-amber-500/20 text-amber-800 dark:text-amber-200",
        primary: "bg-amber-600 hover:bg-amber-700 text-white shadow-sm",
      };
    case "danger":
      return {
        ring: "focus:ring-red-500/30",
        accent: "bg-red-500/10 border-red-500/20 text-red-800 dark:text-red-200",
        primary: "bg-red-600 hover:bg-red-700 text-white shadow-sm",
      };
    case "info":
    default:
      return {
        ring: "focus:ring-indigo-500/30",
        accent: "bg-indigo-500/10 border-indigo-500/20 text-indigo-800 dark:text-indigo-200",
        primary: "bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm",
      };
  }
};

export const DialogProvider = ({ children }: { children: React.ReactNode }) => {
  const [dialog, setDialog] = useState<DialogState>(defaultState);
  const resolveRef = useRef<((value: any) => void) | null>(null);
  const cancelButtonRef = useRef<HTMLButtonElement | null>(null);
  const confirmButtonRef = useRef<HTMLButtonElement | null>(null);

  const close = useCallback((result: any) => {
    const resolve = resolveRef.current;
    resolveRef.current = null;
    setDialog((prev) => ({ ...prev, open: false }));
    if (resolve) resolve(result);
  }, []);

  const openDialog = useCallback(
    (type: DialogType, message: React.ReactNode, options?: DialogOptions) => {
      return new Promise<any>((resolve) => {
        resolveRef.current = resolve;
        setDialog({
          open: true,
          type,
          message,
          title: options?.title || (type === "confirm" ? "Confirm" : "Notice"),
          confirmText: options?.confirmText || (type === "confirm" ? "Confirm" : "OK"),
          cancelText: options?.cancelText || "Cancel",
          variant: options?.variant || "info",
        });
      });
    },
    [],
  );

  const value = useMemo<DialogContextValue>(
    () => ({
      alert: (message, options) => openDialog("alert", message, options).then(() => undefined),
      info: (message, options) => openDialog("alert", message, { ...options, variant: "info" }).then(() => undefined),
      confirm: (message, options) => openDialog("confirm", message, options).then((v) => Boolean(v)),
    }),
    [openDialog],
  );

  useEffect(() => {
    if (!dialog.open) return;
    const t = window.setTimeout(() => {
      if (dialog.type === "confirm") cancelButtonRef.current?.focus();
      else confirmButtonRef.current?.focus();
    }, 0);
    return () => window.clearTimeout(t);
  }, [dialog.open, dialog.type]);

  useEffect(() => {
    if (!dialog.open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        close(dialog.type === "confirm" ? false : undefined);
      }
      if (e.key === "Enter" && dialog.type === "confirm") {
        // Avoid accidental confirms when focused on cancel.
        if (document.activeElement === cancelButtonRef.current) return;
        e.preventDefault();
        close(true);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [close, dialog.open, dialog.type]);

  const modal = dialog.open
    ? createPortal(
        <div className="fixed inset-0 z-[1000] flex items-center justify-center px-4 py-8">
          <button
            type="button"
            aria-label="Close dialog"
            onClick={() => close(dialog.type === "confirm" ? false : undefined)}
            className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm cursor-default"
          />

          <div className="relative w-full max-w-lg rounded-3xl border border-black/5 dark:border-white/10 bg-white/90 dark:bg-slate-950/70 shadow-2xl overflow-hidden">
            <div
              className={[
                "px-6 py-4 border-b",
                "border-black/5 dark:border-white/10",
                variantTone(dialog.variant).accent,
              ].join(" ")}
            >
              <div className="text-xs font-black uppercase tracking-widest">
                {dialog.title}
              </div>
            </div>

            <div className="px-6 py-5 text-sm text-slate-700 dark:text-slate-200 font-medium">
              {typeof dialog.message === "string" ? (
                <div className="whitespace-pre-wrap">{dialog.message}</div>
              ) : (
                dialog.message
              )}
            </div>

            <div className="px-6 pb-6 flex items-center justify-end gap-3">
              {dialog.type === "confirm" && (
                <button
                  type="button"
                  ref={cancelButtonRef}
                  onClick={() => close(false)}
                  className={[
                    "px-4 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-colors shadow-sm border",
                    "bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15",
                    "text-slate-900 dark:text-white border-slate-200 dark:border-white/10",
                    variantTone(dialog.variant).ring,
                    "focus:outline-none focus:ring-2",
                  ].join(" ")}
                >
                  {dialog.cancelText}
                </button>
              )}

              <button
                type="button"
                ref={confirmButtonRef}
                onClick={() => close(dialog.type === "confirm" ? true : undefined)}
                className={[
                  "px-4 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-colors shadow-sm",
                  variantTone(dialog.variant).primary,
                  variantTone(dialog.variant).ring,
                  "focus:outline-none focus:ring-2",
                ].join(" ")}
              >
                {dialog.confirmText}
              </button>
            </div>
          </div>
        </div>,
        document.body,
      )
    : null;

  return (
    <DialogContext.Provider value={value}>
      {children}
      {modal}
    </DialogContext.Provider>
  );
};

export const useDialog = (): DialogContextValue => {
  const ctx = useContext(DialogContext);
  if (!ctx) throw new Error("useDialog must be used within <DialogProvider />");
  return ctx;
};

