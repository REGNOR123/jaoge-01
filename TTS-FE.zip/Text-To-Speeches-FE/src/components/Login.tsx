
import React, { useState, useRef, useEffect } from 'react';
import { requestOtp, verifyOtp } from '../services/authService';

interface LoginProps {
  onLogin: (email: string, token: string) => void;
  onClose: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin, onClose }) => {
  const [step, setStep] = useState<'email' | 'otp'>('email');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resendTimer, setResendTimer] = useState(0);

  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    let interval: number;
    if (resendTimer > 0) {
      interval = window.setInterval(() => setResendTimer(p => p - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [resendTimer]);

  const handleSendOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!email.includes('@')) {
      setError("Please enter a valid neural identity (email).");
      return;
    }

    setIsLoading(true);
    setError(null);
    const result = await requestOtp(email);
    setIsLoading(false);

    if (result.success) {
      setStep('otp');
      setResendTimer(60);
    } else {
      setError(result.error || "Azure dispatch error. Please try again.");
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) value = value[value.length - 1];
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = async () => {
    const code = otp.join('');
    if (code.length < 6) return;

    setIsLoading(true);
    setError(null);
    const result = await verifyOtp(email, code);
    setIsLoading(false);

    if (result.success && result.token) {
      onLogin(email, result.token);
    } else {
      setError(result.error || "Verification rejected by Azure protocol.");
      setOtp(['', '', '', '', '', '']);
      otpRefs.current[0]?.focus();
    }
  };

  useEffect(() => {
    if (otp.join('').length === 6) {
      handleVerify();
    }
  }, [otp]);

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-6 bg-black/95 backdrop-blur-3xl animate-in fade-in duration-700">
      <div className="glass-card w-full max-w-lg rounded-[4rem] p-12 relative z-10 border-white/5 shadow-2xl scale-in-center overflow-hidden">
        {/* Decorative Azure element */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2"></div>
        
        <button onClick={onClose} className="absolute top-10 right-10 text-slate-500 hover:text-white transition-colors z-20">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <div className="flex flex-col items-center mb-12 relative z-10">
          <div className="w-20 h-20 rounded-3xl bg-blue-600/10 flex items-center justify-center text-blue-400 border border-blue-500/20 mb-8 animate-float">
             <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A10.003 10.003 0 0014 11V7a4 4 0 10-8 0v4c0 1.38.339 2.682.933 3.817m3.646-1.92L14 14m-4-4l1.5 1.5M4 11a1 1 0 10-2 0c0 4.142 3.358 7.5 7.5 7.5H12" /></svg>
          </div>
          <h2 className="text-3xl font-black text-white tracking-tight uppercase italic">Azure<span className="text-blue-500">Access</span></h2>
          <p className="text-[10px] uppercase font-black tracking-[0.4em] text-slate-500 mt-3">Identity Management System</p>
        </div>

        {step === 'email' ? (
          <form onSubmit={handleSendOtp} className="space-y-8 relative z-10">
            <div className="space-y-4">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-2">Enterprise Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="identity@enterprise.com"
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-white outline-none focus:border-blue-500/50 transition-all font-bold group-hover:bg-white/[0.07]"
                required
              />
            </div>
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-5 rounded-2xl bg-white text-black font-black uppercase tracking-widest text-xs hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 shadow-xl shadow-white/5"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-black/20 border-t-black rounded-full animate-spin"></div>
              ) : (
                <>Dispatch Neural Code <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg></>
              )}
            </button>
          </form>
        ) : (
          <div className="space-y-10 relative z-10">
            <div className="text-center">
              <p className="text-slate-400 text-xs font-medium mb-2">Azure code dispatched to:</p>
              <p className="text-white font-bold text-sm truncate px-4">{email}</p>
              <button onClick={() => setStep('email')} className="text-blue-400 text-[10px] uppercase font-black tracking-widest mt-2 hover:underline">Revise Email</button>
            </div>

            <div className="flex justify-between gap-3">
              {otp.map((digit, i) => (
                <input
                  key={i}
                  // Fix: Ensure the ref callback returns void to avoid TypeScript error where returning the assigned element is disallowed.
                  ref={(el) => { otpRefs.current[i] = el; }}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(i, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(i, e)}
                  className="w-14 h-16 bg-white/5 border border-white/10 rounded-xl text-center text-2xl font-black text-white outline-none focus:border-blue-500 transition-all"
                />
              ))}
            </div>

            <div className="text-center">
              {resendTimer > 0 ? (
                <p className="text-slate-500 text-[10px] uppercase font-black tracking-widest">Protocol resend in {resendTimer}s</p>
              ) : (
                <button onClick={() => handleSendOtp()} className="text-blue-400 text-[10px] uppercase font-black tracking-widest hover:text-white transition-colors">Request New Protocol</button>
              )}
            </div>
          </div>
        )}

        {error && (
          <div className="mt-8 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-center animate-in slide-in-from-top-2">
            <p className="text-red-400 text-[10px] font-bold uppercase tracking-widest">{error}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Login;
