import React from "react";
import { Youtube, Zap, Mic, FileText, Sparkles } from "lucide-react";
import type { ScriptSKU } from "../../config/scriptStudioConfig";

/* ── SKU icon map ── */
export const SKU_ICONS: Record<ScriptSKU, React.ReactNode> = {
  youtube: React.createElement(Youtube, { className: "w-5 h-5" }),
  short: React.createElement(Zap, { className: "w-5 h-5" }),
  podcast: React.createElement(Mic, { className: "w-5 h-5" }),
  explainer: React.createElement(FileText, { className: "w-5 h-5" }),
  custom: React.createElement(Sparkles, { className: "w-5 h-5" }),
};

/* ── Shared types ── */
export type Phase = "selection" | "form" | "output";
export type TransformType = "rewrite" | "shorten" | "expand" | "tone-change";

/* ── ActionButton ── */
interface ActionButtonProps {
  children: React.ReactNode;
  onClick: () => void;
  disabled: boolean;
  variant?: "primary" | "secondary";
  title?: string;
  icon?: React.ReactNode;
}

export const ActionButton: React.FC<ActionButtonProps> = ({
  children,
  onClick,
  disabled,
  variant = "secondary",
  title,
  icon,
}) =>
  variant === "primary"
    ? React.createElement(
        "button",
        {
          type: "button",
          onClick,
          disabled,
          title,
          "aria-disabled": disabled || undefined,
          className: [
            "px-6 py-3 rounded-xl font-semibold text-sm uppercase tracking-wide",
            "transition-all flex items-center gap-2",
            disabled
              ? "opacity-50 cursor-not-allowed bg-slate-600 dark:bg-slate-700 text-white"
              : "bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 shadow-lg hover:shadow-xl",
          ].join(" "),
        },
        icon,
        children,
      )
    : React.createElement(
        "button",
        {
          type: "button",
          onClick,
          disabled,
          title,
          "aria-disabled": disabled || undefined,
          className: [
            "px-4 py-3 rounded-xl font-semibold text-sm uppercase tracking-wide",
            "transition-all border flex items-center gap-2",
            disabled
              ? "opacity-50 cursor-not-allowed bg-slate-100 dark:bg-white/5 border-slate-200 dark:border-white/10"
              : "bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white border-slate-200 dark:border-white/10 shadow-sm",
          ].join(" "),
        },
        icon,
        children,
      );
