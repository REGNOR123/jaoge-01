import React from "react";

export interface StepIndicatorProps {
  steps: Array<{ id: string; title: string }>;
  currentStepIndex: number;
  onStepClick: (index: number) => void;
  disabled?: boolean;
}

export const StepIndicator: React.FC<StepIndicatorProps> = ({
  steps,
  currentStepIndex,
  onStepClick,
  disabled = false,
}) => {
  return (
    <nav aria-label="Script form steps">
      {/* Desktop: circles + connectors */}
      <div className="hidden sm:flex items-center gap-4 overflow-x-auto">
        {steps.map((step, index) => {
          const isCompleted = index < currentStepIndex;
          const isCurrent = index === currentStepIndex;
          const isUpcoming = index > currentStepIndex;

          return (
            <React.Fragment key={step.id}>
              <button
                type="button"
                onClick={() => !disabled && onStepClick(index)}
                disabled={disabled || isUpcoming}
                aria-current={isCurrent ? "step" : undefined}
                aria-label={`Step ${index + 1}: ${step.title}${isCompleted ? " (completed)" : ""}`}
                className={[
                  "flex items-center justify-center flex-shrink-0",
                  "w-10 h-10 rounded-full font-bold text-sm transition-all",
                  "border-2 relative",
                  isCompleted
                    ? "bg-green-600 border-green-600 text-white"
                    : isCurrent
                      ? "bg-indigo-600 border-indigo-600 text-white ring-2 ring-indigo-300 dark:ring-indigo-700"
                      : "bg-slate-100 dark:bg-white/10 border-slate-300 dark:border-white/20 text-slate-600 dark:text-slate-400",
                  !disabled && !isUpcoming
                    ? "cursor-pointer hover:shadow-lg"
                    : "",
                  isUpcoming ? "opacity-50 cursor-not-allowed" : "",
                ].join(" ")}
              >
                {isCompleted ? (
                  <svg
                    className="w-5 h-5"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    aria-hidden="true"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                ) : (
                  <span>{index + 1}</span>
                )}
              </button>

              {/* Connector line */}
              {index < steps.length - 1 && (
                <div
                  aria-hidden="true"
                  className={[
                    "flex-shrink-0 h-1",
                    "transition-all",
                    isCompleted || isCurrent
                      ? "w-8 bg-indigo-600"
                      : "w-8 bg-slate-200 dark:bg-white/10",
                  ].join(" ")}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Mobile: compact text */}
      <div className="sm:hidden text-sm font-semibold text-slate-600 dark:text-slate-400">
        Step {currentStepIndex + 1} of {steps.length} &mdash;{" "}
        {steps[currentStepIndex]?.title}
      </div>
    </nav>
  );
};

interface StepNavigationProps {
  currentStepIndex: number;
  totalSteps: number;
  onNext: () => void;
  onPrevious: () => void;
  onSubmit: () => void;
  canProceed: boolean;
  isGenerating?: boolean;
  isGuestLocked?: boolean;
}

export const StepNavigation: React.FC<StepNavigationProps> = ({
  currentStepIndex,
  totalSteps,
  onNext,
  onPrevious,
  onSubmit,
  canProceed,
  isGenerating = false,
  isGuestLocked = false,
}) => {
  const isFirstStep = currentStepIndex === 0;
  const isLastStep = currentStepIndex === totalSteps - 1;

  return (
    <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 sm:items-center sm:justify-between mt-8 pt-6 border-t border-slate-200 dark:border-white/10">
      {/* Previous */}
      <button
        type="button"
        onClick={onPrevious}
        disabled={isFirstStep || isGenerating}
        aria-label="Previous step"
        aria-disabled={isFirstStep || isGenerating || undefined}
        className={[
          "px-6 py-3 rounded-xl font-semibold text-sm uppercase tracking-wide",
          "transition-all border",
          isFirstStep || isGenerating
            ? "opacity-50 cursor-not-allowed bg-slate-100 dark:bg-white/5 border-slate-200 dark:border-white/10"
            : "bg-white dark:bg-white/10 border-slate-200 dark:border-white/20 text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-white/15",
        ].join(" ")}
      >
        &larr; Previous
      </button>

      {/* Step counter */}
      <div
        className="text-sm font-semibold text-slate-600 dark:text-slate-400 text-center"
        aria-hidden="true"
      >
        Step {currentStepIndex + 1} of {totalSteps}
      </div>

      {/* Next / Generate */}
      {isLastStep ? (
        <button
          type="button"
          onClick={onSubmit}
          disabled={isGuestLocked ? false : (!canProceed || isGenerating)}
          aria-label="Generate script"
          aria-disabled={isGuestLocked ? false : (!canProceed || isGenerating) || undefined}
          className={[
            "px-6 py-3 rounded-xl font-semibold text-sm uppercase tracking-wide",
            "transition-all",
            isGuestLocked
              ? "bg-amber-500 hover:bg-amber-600 text-white shadow-sm hover:shadow-md"
              : !canProceed || isGenerating
                ? "opacity-50 cursor-not-allowed bg-slate-600 dark:bg-slate-700 text-white"
                : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg hover:shadow-xl hover:shadow-indigo-600/25",
          ].join(" ")}
        >
          {isGenerating ? (
            "Generating\u2026"
          ) : isGuestLocked ? (
            <span className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
              Sign Up to Generate
            </span>
          ) : (
            "Generate Script"
          )}
        </button>
      ) : (
        <button
          type="button"
          onClick={onNext}
          disabled={!canProceed || isGenerating}
          aria-label="Next step"
          aria-disabled={!canProceed || isGenerating || undefined}
          className={[
            "px-6 py-3 rounded-xl font-semibold text-sm uppercase tracking-wide",
            "transition-all",
            !canProceed || isGenerating
              ? "opacity-50 cursor-not-allowed bg-slate-600 dark:bg-slate-700 text-white"
              : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg hover:shadow-xl hover:shadow-indigo-600/25",
          ].join(" ")}
        >
          Next &rarr;
        </button>
      )}
    </div>
  );
};
