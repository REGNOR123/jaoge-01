import React from "react";
import type { useScriptStudioState } from "./useScriptStudioState";
import { SKU_ICONS } from "./constants";
import { SCRIPT_SKU_CONFIGS, ScriptSKU } from "../../config/scriptStudioConfig";

type Props = { state: ReturnType<typeof useScriptStudioState> };

const Phase1Selection: React.FC<Props> = ({ state }) => {
  const { handleSelectSKU, recentScriptProjects } = state;

  return (
    <div className="space-y-6">
      <section className="glass studio-card !p-8">
        <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
          AI Script Studio
        </h1>
        <p className="mt-3 text-base text-slate-600 dark:text-slate-300 font-medium max-w-2xl">
          Choose your script type to get started. Each type has tailored inputs
          and output formats designed for your specific use case.
        </p>

        {/* SKU Selection Grid */}
        <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
          {Object.entries(SCRIPT_SKU_CONFIGS).map(([key, config]) => (
            <button
              key={key}
              type="button"
              onClick={() => handleSelectSKU(config.id as ScriptSKU)}
              className={[
                "group rounded-2xl p-6 text-left border-2 transition-all duration-200",
                "hover:shadow-lg hover:shadow-indigo-600/15 hover:-translate-y-1",
                "bg-gradient-to-br from-white to-slate-50 dark:from-white/5 dark:to-white/10",
                "border-slate-200 dark:border-white/10 hover:border-indigo-400 dark:hover:border-indigo-500",
              ].join(" ")}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 group-hover:scale-110 transition-transform">
                  {SKU_ICONS[config.id]}
                </div>
              </div>

              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
                {config.title}
              </h3>

              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-3">
                {config.description}
              </p>

              {/* C4: metadata badges */}
              <div className="flex items-center gap-2 mb-3">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-widest bg-slate-100 dark:bg-white/10 text-slate-500 dark:text-slate-400">
                  {config.steps.length} steps
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-widest bg-slate-100 dark:bg-white/10 text-slate-500 dark:text-slate-400">
                  {config.estimatedDuration}
                </span>
              </div>

              <div className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 group-hover:translate-x-1 transition-transform">
                Get Started &rarr;
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* C13: Recent Scripts */}
      {recentScriptProjects.length > 0 && (
        <section className="glass studio-card !p-6">
          <h2 className="text-sm font-black uppercase tracking-widest text-slate-600 dark:text-slate-400 mb-4">
            Recent Scripts
          </h2>
          <div className="space-y-2">
            {recentScriptProjects.map((project) => {
              const draft = project.data?.drafts?.scriptStudio as any;
              const sku = draft?.scriptType as ScriptSKU | undefined;
              return (
                <a
                  key={project.id}
                  href={`/script-studio?projectId=${project.id}`}
                  className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-white/5 transition-colors group"
                >
                  {sku && SKU_ICONS[sku] ? (
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300">
                      {SKU_ICONS[sku]}
                    </div>
                  ) : (
                    <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-white/10" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {project.name}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {sku ? SCRIPT_SKU_CONFIGS[sku]?.title : "Script"} &middot;{" "}
                      {new Date(project.lastModified).toLocaleDateString()}
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    Continue &rarr;
                  </span>
                </a>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
};

export default Phase1Selection;
