import React, { useEffect, useRef } from "react";
import type { useScriptStudioState } from "./useScriptStudioState";
import { SKU_ICONS } from "./constants";
import { DynamicForm } from "./DynamicForm";
import { StepIndicator, StepNavigation } from "./StepNavigation";
import ProgressPill from "../ProgressPill";

type Props = { state: ReturnType<typeof useScriptStudioState> };

const Phase2Form: React.FC<Props> = ({ state }) => {
  const {
    selectedSKU,
    config,
    steps,
    currentStep,
    totalSteps,
    currentStepIndex,
    formInputs,
    setFormInputs,
    error,
    setError,
    canProceedToNext,
    fieldErrors,
    isGenerating,
    generatePercent,
    loadingFields,
    isGuest,
    handleNextStep,
    handlePreviousStep,
    handleGenerateScript,
    handleBackToSelection,
    handleAutoGenerateField,
  } = state;

  const firstFieldRef = useRef<HTMLDivElement>(null);

  // Focus first field on step change
  useEffect(() => {
    const el = firstFieldRef.current;
    if (!el) return;
    const input = el.querySelector("input, textarea, select") as HTMLElement;
    input?.focus();
  }, [currentStepIndex]);

  if (!selectedSKU || !config || !currentStep) return null;

  return (
    <div className="space-y-6">
      {/* Header with back button */}
      <div className="flex items-center gap-4 mb-4">
        <button
          type="button"
          onClick={handleBackToSelection}
          aria-label="Back to script type selection"
          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
        >
          <svg
            className="w-6 h-6 text-slate-600 dark:text-slate-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
        </button>
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300">
              {SKU_ICONS[selectedSKU]}
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              {config.title} Script
            </h2>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Estimated time: {config.estimatedDuration}
          </p>
        </div>
      </div>

      {/* Step Indicator */}
      <section className="glass studio-card !p-6">
        <StepIndicator
          steps={steps}
          currentStepIndex={currentStepIndex}
          onStepClick={(index) => {
            if (index < currentStepIndex) {
              state.goToStep(index);
            }
          }}
          disabled={isGenerating}
        />
      </section>

      {/* Step Content */}
      <section className="glass studio-card !p-8 space-y-6 relative" ref={firstFieldRef}>
        <div>
          <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
            {currentStep.title}
          </h3>
          {currentStep.description && (
            <p className="text-slate-600 dark:text-slate-400">
              {currentStep.description}
            </p>
          )}
        </div>

        {/* Error (top-level, kept for non-field errors) */}
        {error && !Object.keys(fieldErrors).length && (
          <div className="p-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800">
            <p className="text-sm font-medium text-red-800 dark:text-red-300">
              {error}
            </p>
          </div>
        )}

        {/* Dynamic Form — A6: auto-generate on ALL steps */}
        <DynamicForm
          fields={currentStep.fields}
          values={formInputs}
          onChange={(fieldId, value) => {
            setFormInputs((prev: Record<string, string>) => ({
              ...prev,
              [fieldId]: value,
            }));
            setError(null);
          }}
          onAutoGenerate={handleAutoGenerateField}
          loadingFields={loadingFields}
          disabled={isGenerating}
          fieldErrors={fieldErrors}
        />

        {/* Step Navigation */}
        <StepNavigation
          currentStepIndex={currentStepIndex}
          totalSteps={totalSteps}
          onNext={handleNextStep}
          onPrevious={handlePreviousStep}
          onSubmit={handleGenerateScript}
          canProceed={canProceedToNext}
          isGenerating={isGenerating}
          isGuestLocked={isGuest && currentStepIndex === totalSteps - 1}
        />

        {/* C6: Generation progress bar */}
        {isGenerating && generatePercent > 0 && (
          <div className="mt-4">
            <ProgressPill label="Generating script" percent={generatePercent} />
          </div>
        )}
      </section>
    </div>
  );
};

export default Phase2Form;
