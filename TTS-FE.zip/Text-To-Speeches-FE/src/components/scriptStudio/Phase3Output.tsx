import React, { useState } from "react";
import type { useScriptStudioState } from "./useScriptStudioState";
import { SKU_ICONS, ActionButton } from "./constants";
import type { TransformType } from "./constants";
import ScriptSkeleton from "./ScriptSkeleton";
import {
  RefreshCw,
  ArrowDownToLine,
  ArrowUpFromLine,
  Palette,
  Copy,
  Check,
  Download,
  Undo2,
  Redo2,
  RotateCcw,
  ChevronDown,
} from "lucide-react";

type Props = { state: ReturnType<typeof useScriptStudioState> };

/* ── Transform button metadata ── */
const TRANSFORMS: Array<{
  type: TransformType;
  label: string;
  icon: React.ReactNode;
  description: string;
}> = [
  {
    type: "rewrite",
    label: "Rewrite",
    icon: <RefreshCw className="w-3.5 h-3.5" />,
    description: "Generate a completely new version",
  },
  {
    type: "shorten",
    label: "Shorten",
    icon: <ArrowDownToLine className="w-3.5 h-3.5" />,
    description: "Make the script more concise",
  },
  {
    type: "expand",
    label: "Expand",
    icon: <ArrowUpFromLine className="w-3.5 h-3.5" />,
    description: "Add more detail and depth",
  },
  {
    type: "tone-change",
    label: "Tone",
    icon: <Palette className="w-3.5 h-3.5" />,
    description: "Change the tone of the script",
  },
];

const Phase3Output: React.FC<Props> = ({ state }) => {
  const {
    selectedSKU,
    config,
    script,
    handleScriptChange,
    error,
    isGenerating,
    isTransforming,
    transformingType,
    handleTransformScript,
    handleConvertToVoice,
    handleBackToForm,
    handleBackToSelection,
    // Undo/redo
    canUndo,
    canRedo,
    handleUndo,
    handleRedo,
    handleResetScript,
    // Copy / Download
    copyFeedback,
    handleCopy,
    handleDownloadScript,
    // Stats
    wordCount,
    charCount,
    readingTimeMin,
    wordDiff,
    // Versions
    scriptVersions,
    loadScriptVersion,
    // Retry
    retryCount,
    // Success
    successBanner,
  } = state;

  const [formatExpanded, setFormatExpanded] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);

  if (!selectedSKU || !config) return null;

  const isBusy = isGenerating || isTransforming;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4 justify-between mb-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleBackToForm}
            aria-label="Back to form"
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
          >
            <svg
              className="w-6 h-6 text-slate-600 dark:text-slate-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 19l-7-7 7-7"
              />
            </svg>
          </button>
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300">
                {SKU_ICONS[selectedSKU]}
              </div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Your Script
              </h2>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleBackToSelection}
          className="text-sm font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
        >
          New Script
        </button>
      </div>

      {/* C12: Success banner */}
      {successBanner && (
        <div className="p-3 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-sm font-semibold text-green-800 dark:text-green-300 animate-pulse">
          Script generated! Review and refine below.
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="p-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 flex items-center justify-between">
          <p className="text-sm font-medium text-red-800 dark:text-red-300">
            {error}
          </p>
          {/* B9: Retry button */}
          {retryCount > 0 && retryCount < 3 && (
            <button
              type="button"
              onClick={() => void state.handleGenerateScript()}
              className="ml-3 px-3 py-1.5 rounded-lg text-xs font-semibold bg-red-100 dark:bg-red-800/30 text-red-800 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-800/50 transition-colors"
            >
              Retry
            </button>
          )}
          {retryCount >= 3 && (
            <span className="ml-3 text-xs text-red-500">
              Please try again later
            </span>
          )}
        </div>
      )}

      {/* Script Output */}
      <section className="glass studio-card !p-8 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-1">
              {config.title} Script
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              {config.outputFormat.exampleLength}
            </p>
          </div>

          {/* B1: Undo / Redo / Reset toolbar */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={handleUndo}
              disabled={!canUndo}
              title="Undo (Ctrl+Z)"
              aria-label="Undo"
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <Undo2 className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            </button>
            <button
              type="button"
              onClick={handleRedo}
              disabled={!canRedo}
              title="Redo (Ctrl+Shift+Z)"
              aria-label="Redo"
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <Redo2 className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            </button>
            <button
              type="button"
              onClick={handleResetScript}
              title="Reset to generated version"
              aria-label="Reset to generated version"
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
            >
              <RotateCcw className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            </button>

            {/* B5: Script history */}
            {scriptVersions.length > 1 && (
              <div className="relative ml-2">
                <button
                  type="button"
                  onClick={() => setHistoryOpen((v) => !v)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-white/15 transition-colors flex items-center gap-1"
                >
                  History ({scriptVersions.length})
                  <ChevronDown className="w-3 h-3" />
                </button>
                {historyOpen && (
                  <div className="absolute right-0 top-full mt-1 w-64 max-h-48 overflow-auto rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900 shadow-xl z-20">
                    {scriptVersions.map((v, i) => (
                      <button
                        key={v.id || i}
                        type="button"
                        onClick={() => {
                          loadScriptVersion(v.text);
                          setHistoryOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 text-xs hover:bg-slate-50 dark:hover:bg-white/5 border-b border-slate-100 dark:border-white/5 last:border-0"
                      >
                        <div className="font-semibold text-slate-900 dark:text-white truncate">
                          {(v.text ?? '').slice(0, 60)}{v.text && v.text.length > 60 ? '...' : ''}
                        </div>
                        <div className="text-slate-500 dark:text-slate-400">
                          {new Date(v.createdAt).toLocaleString()}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Skeleton while generating */}
        {isGenerating ? (
          <div className="min-h-[520px] p-4 rounded-2xl bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10">
            <ScriptSkeleton />
          </div>
        ) : (
          <textarea
            value={script}
            onChange={(e) => handleScriptChange(e.target.value)}
            aria-label="Generated script"
            className="w-full min-h-[520px] p-4 rounded-2xl bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white resize-none font-medium text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
          />
        )}

        {/* B4: Word count / stats */}
        <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-slate-500 dark:text-slate-400">
          <span>{wordCount} words</span>
          <span>{charCount} chars</span>
          <span>~{readingTimeMin} min read</span>
          {/* C10: Word diff after transform */}
          {wordDiff !== null && (
            <span
              className={
                wordDiff > 0
                  ? "text-green-600 dark:text-green-400"
                  : "text-amber-600 dark:text-amber-400"
              }
            >
              {wordDiff > 0 ? `+${wordDiff}` : wordDiff} words
            </span>
          )}
        </div>

        {/* Quick Actions — C10: icons + tooltips on transforms */}
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 flex-wrap">
          {TRANSFORMS.map((t) => (
            <ActionButton
              key={t.type}
              disabled={isBusy}
              onClick={() => void handleTransformScript(t.type)}
              variant="secondary"
              title={t.description}
              icon={
                transformingType === t.type ? (
                  <span className="w-3.5 h-3.5 rounded-full border-2 border-current border-r-transparent animate-spin" />
                ) : (
                  t.icon
                )
              }
            >
              {transformingType === t.type ? "Processing\u2026" : t.label}
            </ActionButton>
          ))}

          {/* B3: Copy */}
          <ActionButton
            disabled={isBusy || !script.trim()}
            onClick={() => void handleCopy()}
            variant="secondary"
            title="Copy script to clipboard"
            icon={
              copyFeedback ? (
                <Check className="w-3.5 h-3.5 text-green-600" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )
            }
          >
            {copyFeedback ? "Copied!" : "Copy"}
          </ActionButton>

          {/* B6: Download */}
          <ActionButton
            disabled={isBusy || !script.trim()}
            onClick={handleDownloadScript}
            variant="secondary"
            title="Download as .txt file"
            icon={<Download className="w-3.5 h-3.5" />}
          >
            Download
          </ActionButton>

          {/* Convert to Voice */}
          <ActionButton
            disabled={isBusy || !script.trim()}
            onClick={handleConvertToVoice}
            variant="primary"
            title="Send script to Create Voice (Ctrl+Enter)"
          >
            Convert to Voice &rarr;
          </ActionButton>
        </div>

        {/* B2: Transform state indicator */}
        {isTransforming && (
          <div className="text-xs font-semibold uppercase tracking-widest text-slate-500 dark:text-slate-400 animate-pulse flex items-center gap-2">
            <span className="w-3 h-3 rounded-full border-2 border-current border-r-transparent animate-spin" />
            Transforming ({transformingType})&hellip;
          </div>
        )}
      </section>

      {/* C11: Output Format Info — collapsible */}
      <section className="glass studio-card !p-6">
        <button
          type="button"
          onClick={() => setFormatExpanded((v) => !v)}
          className="w-full flex items-center justify-between"
          aria-expanded={formatExpanded}
        >
          <h4 className="text-sm font-black uppercase tracking-widest text-slate-600 dark:text-slate-400">
            Expected Format
          </h4>
          <ChevronDown
            className={[
              "w-4 h-4 text-slate-400 transition-transform",
              formatExpanded ? "rotate-180" : "",
            ].join(" ")}
          />
        </button>

        <div
          className={[
            "grid transition-[grid-template-rows,opacity] duration-300 ease-out",
            formatExpanded
              ? "grid-rows-[1fr] opacity-100"
              : "grid-rows-[0fr] opacity-0",
          ].join(" ")}
        >
          <div className="overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div>
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
                  SECTIONS
                </p>
                <ul className="space-y-1">
                  {config.outputFormat.sections.map((section, idx) => (
                    <li
                      key={idx}
                      className="text-sm text-slate-700 dark:text-slate-300"
                    >
                      &bull; {section}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
                  GUIDELINES
                </p>
                <ul className="space-y-1">
                  {config.outputFormat.guidelines.map((guideline, idx) => (
                    <li
                      key={idx}
                      className="text-sm text-slate-700 dark:text-slate-300"
                    >
                      &bull; {guideline}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Phase3Output;
