import { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useCredits } from "../../contexts/CreditContext";
import { useWizardProgress } from "../../hooks/useWizardProgress";
import {
  ScriptSKU,
  SCRIPT_SKU_CONFIGS,
} from "../../config/scriptStudioConfig";
import {
  generateScriptBySKU,
  transformScript,
  validateInputsForSKU,
  generateFieldByAI,
} from "../../services/scriptStudioService";
import { setPrefillScript } from "../../utils/prefillScript";
import {
  createProject,
  getProjectById,
  updateProject,
  listProjects,
} from "../../utils/projectsStorage";
import type { Phase, TransformType } from "./constants";

/* ────────────────────────────────────────────────── */

export function useScriptStudioState() {
  const { isAuthenticated, token } = useAuth();
  const { refreshBalance } = useCredits();
  const isGuest = !isAuthenticated;
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const projectIdFromQuery = searchParams.get("projectId") || "";

  /* ── UI state ── */
  const [authRequiredOpen, setAuthRequiredOpen] = useState(false);
  const [insufficientCreditsInfo, setInsuffCreditsInfo] = useState<{ required: number; current: number } | null>(null);
  const [phase, setPhase] = useState<Phase>("selection");
  const [selectedSKU, setSelectedSKU] = useState<ScriptSKU | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [successBanner, setSuccessBanner] = useState(false);

  /* ── Form data ── */
  const [formInputs, setFormInputs] = useState<Record<string, string>>({});
  const [script, setScript] = useState("");
  const [activeProjectId, setActiveProjectId] = useState(projectIdFromQuery);

  /* ── Loading ── */
  const generateProgress = useWizardProgress({
    interval: 170,
    maxBump: 10,
    finishDelay: 600,
  });
  const isGenerating = generateProgress.inProgress;
  const generatePercent = generateProgress.percent;
  const [loadingFields, setLoadingFields] = useState<Set<string>>(new Set());
  const [transformingType, setTransformingType] =
    useState<TransformType | null>(null);
  const isTransforming = transformingType !== null;

  /* ── B1: Undo / Redo ── */
  const [editState, setEditState] = useState<{
    history: string[];
    index: number;
  }>({ history: [""], index: 0 });
  const editTimerRef = useRef<number>(0);
  const originalScriptRef = useRef("");

  const canUndo = editState.index > 0;
  const canRedo = editState.index < editState.history.length - 1;

  const pushHistory = useCallback((text: string) => {
    setEditState((prev) => {
      const truncated = prev.history.slice(0, prev.index + 1);
      const next = [...truncated, text].slice(-50);
      return { history: next, index: next.length - 1 };
    });
  }, []);

  /** Set script programmatically (generation / transform / load) */
  const setScriptWithHistory = useCallback(
    (text: string) => {
      setScript(text);
      originalScriptRef.current = text;
      pushHistory(text);
    },
    [pushHistory],
  );

  /** User edits in textarea — debounced history push */
  const handleScriptChange = useCallback(
    (text: string) => {
      setScript(text);
      if (editTimerRef.current) window.clearTimeout(editTimerRef.current);
      editTimerRef.current = window.setTimeout(() => {
        pushHistory(text);
      }, 500);
    },
    [pushHistory],
  );

  const handleUndo = useCallback(() => {
    if (editState.index <= 0) return;
    const idx = editState.index - 1;
    setScript(editState.history[idx]);
    setEditState((prev) => ({ ...prev, index: idx }));
  }, [editState]);

  const handleRedo = useCallback(() => {
    if (editState.index >= editState.history.length - 1) return;
    const idx = editState.index + 1;
    setScript(editState.history[idx]);
    setEditState((prev) => ({ ...prev, index: idx }));
  }, [editState]);

  const handleResetScript = useCallback(() => {
    if (!originalScriptRef.current) return;
    setScript(originalScriptRef.current);
    pushHistory(originalScriptRef.current);
  }, [pushHistory]);

  /* ── B3: Copy feedback ── */
  const [copyFeedback, setCopyFeedback] = useState(false);
  const handleCopy = useCallback(async () => {
    if (!script.trim()) return;
    await navigator.clipboard.writeText(script);
    setCopyFeedback(true);
    window.setTimeout(() => setCopyFeedback(false), 2000);
  }, [script]);

  /* ── B4: Word count / reading time ── */
  const wordCount = script.split(/\s+/).filter(Boolean).length;
  const charCount = script.length;
  const readingTimeMin = Math.max(1, Math.ceil(wordCount / 150));

  /* ── B6: Download as .txt ── */
  const handleDownloadScript = useCallback(() => {
    if (!script.trim()) return;
    const blob = new Blob([script], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${selectedSKU || "script"}-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }, [script, selectedSKU]);

  /* ── B5: Script versions from project ── */
  const activeProject = activeProjectId
    ? getProjectById(activeProjectId)
    : null;
  const scriptVersions: Array<{
    id: string;
    text: string;
    createdAt: string;
  }> = (activeProject?.data?.outputs?.scripts as any[]) || [];

  const loadScriptVersion = useCallback(
    (text: string) => {
      setScriptWithHistory(text);
    },
    [setScriptWithHistory],
  );

  /* ── B9: Retry tracking ── */
  const [retryCount, setRetryCount] = useState(0);

  /* ── C13: Recent scripts ── */
  const recentScriptProjects = listProjects()
    .filter((p) => p.type === "Script")
    .slice(0, 5);

  /* ── Derived config ── */
  const config = selectedSKU ? SCRIPT_SKU_CONFIGS[selectedSKU] : null;
  const steps = config?.steps || [];
  const currentStep = steps[currentStepIndex] || null;
  const totalSteps = steps.length;

  const canProceedToNext = currentStep
    ? currentStep.fields.every((field) => {
        if (!field.required) return true;
        const value = formInputs[field.id];
        return value && value.trim().length > 0;
      })
    : false;

  /* ──────── Auth helper ──────── */
  const requireAuth = (): boolean => {
    if (isAuthenticated && token) return true;
    setAuthRequiredOpen(true);
    return false;
  };

  /* ──────── Phase handlers ──────── */

  const handleSelectSKU = (sku: ScriptSKU) => {
    setSelectedSKU(sku);
    setFormInputs({});
    setCurrentStepIndex(0);
    setScript("");
    setEditState({ history: [""], index: 0 });
    setPhase("form");
    setError(null);
    setRetryCount(0);
  };

  /** B7: Confirmation before destructive nav */
  const handleBackToSelection = () => {
    const hasData =
      Object.values(formInputs).some((v) => v.trim()) || script.trim();
    if (hasData && !window.confirm("Go back to selection? Your progress will be cleared.")) {
      return;
    }
    setPhase("selection");
    setSelectedSKU(null);
    setCurrentStepIndex(0);
    setFormInputs({});
    setScript("");
    setEditState({ history: [""], index: 0 });
    setError(null);
    setRetryCount(0);
  };

  const handleBackToForm = () => {
    if (
      script.trim() &&
      !window.confirm("Discard generated script and go back to form?")
    ) {
      return;
    }
    setPhase("form");
    setCurrentStepIndex(0);
    setScript("");
    setEditState({ history: [""], index: 0 });
    setError(null);
    setRetryCount(0);
  };

  /* ──────── Step navigation ──────── */

  const handleNextStep = () => {
    if (!selectedSKU || !currentStep) return;

    const errors: string[] = [];
    currentStep.fields.forEach((field) => {
      if (
        field.required &&
        (!formInputs[field.id] || formInputs[field.id].trim() === "")
      ) {
        errors.push(`${field.label} is required`);
      }
    });

    if (errors.length > 0) {
      setError(errors[0]);
      return;
    }

    setError(null);
    setCurrentStepIndex((prev) => Math.min(prev + 1, steps.length - 1));
  };

  const handlePreviousStep = () => {
    setCurrentStepIndex((prev) => Math.max(prev - 1, 0));
    setError(null);
  };

  const goToStep = (index: number) => {
    setCurrentStepIndex(Math.max(0, Math.min(index, steps.length - 1)));
    setError(null);
  };

  /* ──────── Generation ──────── */

  const handleGenerateScript = async () => {
    if (!selectedSKU) return;
    if (!requireAuth() || !token) return;

    const validation = validateInputsForSKU(selectedSKU, formInputs);
    if (!validation.valid) {
      setError(validation.errors[0] || "Please fill in all required fields");
      return;
    }

    setError(null);
    generateProgress.start();

    try {
      const response = await generateScriptBySKU(
        {
          sku: selectedSKU,
          inputs: formInputs,
          tone: formInputs.tone || "professional",
          length: formInputs.length || formInputs.duration,
        },
        token,
      );

      if (!response.success) {
        if (response.insufficientCredits) {
          setInsuffCreditsInfo({ required: response.requiredCredits ?? 0, current: response.currentBalance ?? 0 });
          generateProgress.stop();
          return;
        }
        setError(response.error || "Failed to generate script");
        generateProgress.stop();
        setRetryCount((c) => c + 1);
        return;
      }

      setScriptWithHistory(response.script || "");
      setRetryCount(0);

      // Save to project
      const now = new Date().toISOString();
      const existing = activeProjectId
        ? getProjectById(activeProjectId)
        : null;
      const project =
        existing ||
        createProject({
          name: formInputs.topic || `Script - ${selectedSKU}`,
          type: "Script",
          status: "Completed",
          data: {
            drafts: { scriptStudio: { updatedAt: now } },
            outputs: {},
          },
        });

      if (!project) {
        setError("Could not create project. Please try again.");
        return;
      }

      setActiveProjectId(project.id);
      const prevScripts = project.data?.outputs?.scripts || [];

      updateProject(project.id, {
        type: "Script",
        status: "Completed",
        data: {
          ...(project.data || {}),
          drafts: {
            ...(project.data?.drafts || {}),
            scriptStudio: {
              scriptType: selectedSKU,
              formInputs,
              script: response.script,
              updatedAt: now,
            },
          },
          outputs: {
            ...(project.data?.outputs || {}),
            scripts: [
              {
                id: crypto.randomUUID(),
                text: response.script,
                createdAt: now,
                source: "Script Studio",
              },
              ...prevScripts,
            ].slice(0, 20),
          },
        },
      });

      await generateProgress.finish();
      setPhase("output");
      void refreshBalance();

      // C12: Success banner on first generation
      setSuccessBanner(true);
      window.setTimeout(() => setSuccessBanner(false), 4000);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
      generateProgress.stop();
      setRetryCount((c) => c + 1);
    }
  };

  /* ──────── Transform ──────── */

  const handleTransformScript = async (type: TransformType) => {
    if (!selectedSKU) return;
    if (!requireAuth()) return;

    setError(null);
    setTransformingType(type);
    const prevWordCount = script.split(/\s+/).filter(Boolean).length;

    try {
      const response = await transformScript(
        selectedSKU,
        script,
        type,
        formInputs.tone,
        token ?? undefined,
      );

      if (!response.success) {
        if (response.insufficientCredits) {
          setInsuffCreditsInfo({ required: response.requiredCredits ?? 0, current: response.currentBalance ?? 0 });
          setTransformingType(null);
          return;
        }
        setError(response.error || "Transformation failed");
        setRetryCount((c) => c + 1);
        return;
      }

      setScriptWithHistory(response.script || "");
      setRetryCount(0);
      void refreshBalance();

      // Compute word diff for brief display
      const newWordCount = (response.script || "")
        .split(/\s+/)
        .filter(Boolean).length;
      setWordDiff(newWordCount - prevWordCount);
      window.setTimeout(() => setWordDiff(null), 3000);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Transformation failed");
      setRetryCount((c) => c + 1);
    } finally {
      setTransformingType(null);
    }
  };

  /* ── C10: Word diff after transform ── */
  const [wordDiff, setWordDiff] = useState<number | null>(null);

  /* ──────── Convert to voice ──────── */

  const handleConvertToVoice = useCallback(() => {
    if (!script.trim()) return;
    setPrefillScript({
      script: script.trim(),
      title: formInputs.topic || (selectedSKU ? `Script - ${selectedSKU}` : undefined),
      sku: selectedSKU || undefined,
      tone: formInputs.tone || undefined,
    });
    navigate("/create-voice");
  }, [script, formInputs, selectedSKU, navigate]);

  /* ──────── Auto-generate field (A6: all steps) ──────── */

  const handleAutoGenerateField = async (fieldId: string) => {
    if (!selectedSKU) return;
    if (!requireAuth()) return;

    setLoadingFields((prev) => new Set(prev).add(fieldId));
    setError(null);

    try {
      const response = await generateFieldByAI(
        selectedSKU,
        fieldId,
        formInputs,
        token,
      );

      if (!response.success) {
        if (response.insufficientCredits) {
          setInsuffCreditsInfo({ required: response.requiredCredits ?? 0, current: response.currentBalance ?? 0 });
          return;
        }
        setError(response.error || "Failed to generate field content");
        return;
      }

      setFormInputs((prev) => ({
        ...prev,
        [fieldId]: response.script || "",
      }));
      void refreshBalance();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Field generation failed");
    } finally {
      setLoadingFields((prev) => {
        const next = new Set(prev);
        next.delete(fieldId);
        return next;
      });
    }
  };

  /* ──────── Field validation errors (C8) ──────── */
  const fieldErrors = currentStep
    ? currentStep.fields.reduce<Record<string, string>>((acc, field) => {
        if (
          error &&
          field.required &&
          (!formInputs[field.id] || formInputs[field.id].trim() === "")
        ) {
          acc[field.id] = `${field.label} is required`;
        }
        return acc;
      }, {})
    : {};

  /* ──────── Effects ──────── */

  // Load existing project on mount
  useEffect(() => {
    if (!projectIdFromQuery) return;
    const project = getProjectById(projectIdFromQuery);
    if (!project) return;

    setActiveProjectId(project.id);
    const draft = project.data?.drafts?.scriptStudio as any;

    if (draft?.scriptType && SCRIPT_SKU_CONFIGS[draft.scriptType as ScriptSKU]) {
      setSelectedSKU(draft.scriptType as ScriptSKU);
      setPhase("form");
    }

    // A7: Load saved formInputs
    if (draft?.formInputs && typeof draft.formInputs === "object") {
      setFormInputs(draft.formInputs);
    } else if (draft && typeof draft === "object" && "topic" in draft) {
      const legacyInputs: Record<string, string> = {};
      if (draft.topic) legacyInputs.topic = String(draft.topic);
      if (draft.tone) legacyInputs.tone = String(draft.tone);
      if (draft.length) legacyInputs.length = String(draft.length);
      setFormInputs(legacyInputs);
    }

    const latestScript = project.data?.outputs?.scripts?.[0]?.text;
    if (typeof latestScript === "string" && latestScript.trim()) {
      setScript(latestScript);
      originalScriptRef.current = latestScript;
      setEditState({ history: [latestScript], index: 0 });
      setPhase("output");
    } else if (draft?.script) {
      setScript(draft.script);
      originalScriptRef.current = draft.script;
      setEditState({ history: [draft.script], index: 0 });
      setPhase("output");
    }
  }, [projectIdFromQuery]);

  // A7: Auto-save form state including formInputs
  useEffect(() => {
    if (!activeProjectId || !selectedSKU) return;
    const t = window.setTimeout(() => {
      const project = getProjectById(activeProjectId);
      if (!project) return;
      const now = new Date().toISOString();

      updateProject(activeProjectId, {
        type: "Script",
        status: phase === "output" ? "Completed" : "Processing",
        data: {
          ...(project.data || {}),
          drafts: {
            ...(project.data?.drafts || {}),
            scriptStudio: {
              scriptType: selectedSKU,
              formInputs,
              script,
              updatedAt: now,
            },
          },
        },
      });
    }, 700);

    return () => window.clearTimeout(t);
  }, [activeProjectId, selectedSKU, script, formInputs, phase]);

  // Cleanup debounce timer on unmount
  useEffect(() => {
    return () => {
      if (editTimerRef.current) window.clearTimeout(editTimerRef.current);
    };
  }, []);

  /* ──────── Return ──────── */

  return {
    // Auth
    isAuthenticated,
    token,
    isGuest,
    authRequiredOpen,
    setAuthRequiredOpen,
    insufficientCreditsInfo,
    clearInsuffCreditsInfo: () => setInsuffCreditsInfo(null),

    // Phase
    phase,
    selectedSKU,

    // Config
    config,
    steps,
    currentStep,
    totalSteps,
    currentStepIndex,

    // Form
    formInputs,
    setFormInputs,
    error,
    setError,
    canProceedToNext,
    fieldErrors,

    // Script
    script,
    handleScriptChange,
    activeProjectId,

    // Loading
    isGenerating,
    generatePercent,
    loadingFields,
    transformingType,
    isTransforming,

    // Undo/Redo
    canUndo,
    canRedo,
    handleUndo,
    handleRedo,
    handleResetScript,

    // Copy / Download
    copyFeedback,
    handleCopy,
    handleDownloadScript,

    // Stats
    wordCount,
    charCount,
    readingTimeMin,
    wordDiff,

    // Versions
    scriptVersions,
    loadScriptVersion,

    // Retry
    retryCount,

    // Success
    successBanner,

    // Recent projects
    recentScriptProjects,

    // Handlers
    handleSelectSKU,
    handleBackToSelection,
    handleBackToForm,
    handleNextStep,
    handlePreviousStep,
    goToStep,
    handleGenerateScript,
    handleTransformScript,
    handleConvertToVoice,
    handleAutoGenerateField,
  };
}
