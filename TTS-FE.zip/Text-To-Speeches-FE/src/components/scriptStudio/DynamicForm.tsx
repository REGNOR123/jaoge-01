import React, { useId } from "react";
import type { InputFieldConfig } from "../../config/scriptStudioConfig";

interface DynamicFormProps {
  fields: InputFieldConfig[];
  values: Record<string, string>;
  onChange: (fieldId: string, value: string) => void;
  onAutoGenerate?: (fieldId: string) => Promise<void>;
  disabled?: boolean;
  loadingFields?: Set<string>;
  fieldErrors?: Record<string, string>;
}

export const DynamicForm: React.FC<DynamicFormProps> = ({
  fields,
  values,
  onChange,
  onAutoGenerate,
  disabled = false,
  loadingFields = new Set(),
  fieldErrors = {},
}) => {
  const formId = useId();

  return (
    <div className="space-y-4">
      {fields.map((field) => {
        const value = values[field.id] || "";
        const inlineError = fieldErrors[field.id];
        const isValid = !inlineError;
        const isFieldLoading = loadingFields.has(field.id);
        const inputId = `${formId}-${field.id}`;
        const showAutoGen =
          onAutoGenerate &&
          field.autoGeneratable === true;

        return (
          <div key={field.id}>
            <div className="flex items-center justify-between mb-1.5">
              <label
                htmlFor={inputId}
                className="block text-sm font-semibold text-slate-900 dark:text-white"
              >
                {field.label}
                {field.required && (
                  <span className="text-red-600 dark:text-red-400 ml-1">
                    *
                  </span>
                )}
              </label>
              {showAutoGen && (
                <button
                  type="button"
                  onClick={() => { void onAutoGenerate(field.id); }}
                  disabled={disabled || isFieldLoading}
                  title="AI will generate content based on your other inputs"
                  className={[
                    "text-xs font-semibold px-3 py-1 rounded-lg transition-all",
                    "flex items-center gap-1",
                    disabled || isFieldLoading
                      ? "opacity-50 cursor-not-allowed bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-slate-400"
                      : "bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/30",
                  ].join(" ")}
                >
                  {isFieldLoading ? (
                    <>
                      <span className="w-3 h-3 rounded-full border-2 border-current border-r-transparent animate-spin" />
                      Generating&hellip;
                    </>
                  ) : (
                    <>
                      <svg
                        className="w-3.5 h-3.5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M13 10V3L4 14h7v7l9-11h-7z"
                        />
                      </svg>
                      Auto-generate
                    </>
                  )}
                </button>
              )}
            </div>

            {field.description && (
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
                {field.description}
              </p>
            )}

            {field.type === "text" && (
              <input
                id={inputId}
                type="text"
                value={value}
                onChange={(e) => onChange(field.id, e.target.value)}
                placeholder={field.placeholder}
                disabled={disabled || isFieldLoading}
                maxLength={field.maxLength}
                aria-invalid={!isValid || undefined}
                className={[
                  "w-full px-4 py-3 rounded-xl border text-sm font-medium",
                  "bg-slate-100/70 dark:bg-slate-800 transition-colors",
                  "text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500",
                  "focus:outline-none focus:ring-2 focus:ring-indigo-500/30",
                  isValid
                    ? "border-slate-200 dark:border-white/10"
                    : "border-red-400 dark:border-red-600",
                  disabled || isFieldLoading
                    ? "opacity-50 cursor-not-allowed"
                    : "",
                ].join(" ")}
              />
            )}

            {field.type === "textarea" && (
              <textarea
                id={inputId}
                value={value}
                onChange={(e) => onChange(field.id, e.target.value)}
                placeholder={field.placeholder}
                disabled={disabled || isFieldLoading}
                maxLength={field.maxLength}
                rows={4}
                aria-invalid={!isValid || undefined}
                className={[
                  "w-full px-4 py-3 rounded-xl border text-sm font-medium",
                  "bg-slate-100/70 dark:bg-slate-800 transition-colors resize-none",
                  "text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500",
                  "focus:outline-none focus:ring-2 focus:ring-indigo-500/30",
                  isValid
                    ? "border-slate-200 dark:border-white/10"
                    : "border-red-400 dark:border-red-600",
                  disabled || isFieldLoading
                    ? "opacity-50 cursor-not-allowed"
                    : "",
                ].join(" ")}
              />
            )}

            {field.type === "select" && (
              <select
                id={inputId}
                value={value}
                onChange={(e) => onChange(field.id, e.target.value)}
                disabled={disabled || isFieldLoading}
                aria-invalid={!isValid || undefined}
                className={[
                  "w-full px-4 py-3 rounded-xl border text-sm font-medium",
                  "bg-slate-100/70 dark:bg-slate-800 transition-colors",
                  "text-slate-900 dark:text-white",
                  "focus:outline-none focus:ring-2 focus:ring-indigo-500/30",
                  isValid
                    ? "border-slate-200 dark:border-white/10"
                    : "border-red-400 dark:border-red-600",
                  disabled || isFieldLoading
                    ? "opacity-50 cursor-not-allowed"
                    : "",
                ].join(" ")}
              >
                <option value="">-- Select an option --</option>
                {field.options?.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            )}

            {field.type === "number" && (
              <input
                id={inputId}
                type="number"
                value={value}
                onChange={(e) => onChange(field.id, e.target.value)}
                placeholder={field.placeholder}
                disabled={disabled || isFieldLoading}
                min={field.minLength}
                max={field.maxLength}
                aria-invalid={!isValid || undefined}
                className={[
                  "w-full px-4 py-3 rounded-xl border text-sm font-medium",
                  "bg-slate-100/70 dark:bg-slate-800 transition-colors",
                  "text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500",
                  "focus:outline-none focus:ring-2 focus:ring-indigo-500/30",
                  isValid
                    ? "border-slate-200 dark:border-white/10"
                    : "border-red-400 dark:border-red-600",
                  disabled || isFieldLoading
                    ? "opacity-50 cursor-not-allowed"
                    : "",
                ].join(" ")}
              />
            )}

            {/* A5: Multiselect */}
            {field.type === "multiselect" && (
              <div
                className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100/70 dark:bg-slate-800 p-3 max-h-48 overflow-auto space-y-1"
                role="group"
                aria-labelledby={inputId}
              >
                {field.options?.map((opt) => {
                  const selected = value
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean);
                  const isChecked = selected.includes(opt.value);
                  return (
                    <label
                      key={opt.value}
                      className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-white/40 dark:hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        disabled={disabled || isFieldLoading}
                        onChange={() => {
                          const next = isChecked
                            ? selected.filter((s) => s !== opt.value)
                            : [...selected, opt.value];
                          onChange(field.id, next.join(", "));
                        }}
                        className="h-4 w-4 accent-indigo-600 flex-shrink-0"
                      />
                      <span className="text-sm font-medium text-slate-900 dark:text-white">
                        {opt.label}
                      </span>
                    </label>
                  );
                })}
              </div>
            )}

            {/* Character count for text fields with maxLength */}
            {field.maxLength && field.type === "text" && (
              <div className="mt-1 text-xs text-slate-400 dark:text-slate-500">
                {value.length}/{field.maxLength}
              </div>
            )}

            {/* C8: Inline validation error */}
            {inlineError && (
              <p className="mt-1 text-xs font-semibold text-red-600 dark:text-red-400">
                {inlineError}
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
};
