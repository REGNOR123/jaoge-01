import React from "react";

const ScriptSkeleton: React.FC = () => (
  <div className="animate-pulse space-y-3">
    {Array.from({ length: 12 }).map((_, i) => (
      <div
        key={i}
        className="h-4 rounded bg-slate-200 dark:bg-white/10"
        style={{ width: `${60 + Math.random() * 40}%` }}
      />
    ))}
  </div>
);

export default ScriptSkeleton;
