import React, { useEffect, Component } from "react";
import { useScriptStudioState } from "./useScriptStudioState";
import AuthRequiredModal from "../AuthRequiredModal";
import InsufficientCreditsModal from "../InsufficientCreditsModal";
import Phase1Selection from "./Phase1Selection";
import Phase2Form from "./Phase2Form";
import Phase3Output from "./Phase3Output";

/* ── ErrorBoundary to prevent blank screens on render errors ── */
class ScriptStudioErrorBoundary extends Component<
  { children: React.ReactNode },
  { error: Error | null }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  render() {
    if (this.state.error) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[400px] text-center p-8">
          <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/20 flex items-center justify-center mb-4">
            <svg className="w-8 h-8 text-red-600 dark:text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Something went wrong</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 max-w-md">
            {this.state.error.message || "An unexpected error occurred in the Script Studio."}
          </p>
          <button
            type="button"
            onClick={() => this.setState({ error: null })}
            className="px-6 py-3 rounded-xl font-semibold text-sm bg-indigo-600 hover:bg-indigo-700 text-white transition-colors"
          >
            Try Again
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

const ScriptStudioWizard: React.FC = () => {
  const state = useScriptStudioState();
  const { phase, authRequiredOpen, setAuthRequiredOpen, handleConvertToVoice, handleGenerateScript, script } = state;

  // B10: Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      // Ctrl+Enter: generate (form phase, last step) or convert to voice (output phase)
      if (e.ctrlKey && e.key === "Enter") {
        e.preventDefault();
        if (phase === "output" && script.trim()) {
          handleConvertToVoice();
        } else if (phase === "form") {
          void handleGenerateScript();
        }
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [phase, script, handleConvertToVoice, handleGenerateScript]);

  return (
    <ScriptStudioErrorBoundary>
      {/* A2: Single AuthRequiredModal */}
      <AuthRequiredModal
        isOpen={authRequiredOpen}
        onClose={() => setAuthRequiredOpen(false)}
        redirectTo="/script-studio"
      />
      <InsufficientCreditsModal
        isOpen={!!state.insufficientCreditsInfo}
        onClose={() => state.clearInsuffCreditsInfo()}
        requiredCredits={state.insufficientCreditsInfo?.required ?? 0}
        currentBalance={state.insufficientCreditsInfo?.current ?? 0}
      />

      {/* C1: aria-live region for status announcements */}
      <div aria-live="polite" className="sr-only">
        {phase === "form" && state.isGenerating && "Generating script..."}
        {phase === "output" && state.isTransforming && `Transforming script: ${state.transformingType}`}
        {phase === "output" && state.successBanner && "Script generated successfully"}
      </div>

      {phase === "selection" && <Phase1Selection state={state} />}
      {phase === "form" && <Phase2Form state={state} />}
      {phase === "output" && <Phase3Output state={state} />}
    </ScriptStudioErrorBoundary>
  );
};

export default ScriptStudioWizard;
