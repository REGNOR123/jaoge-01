
import React, { useState, useRef } from 'react';
import { VoiceName, VoiceOption } from '../types';
import { generateAzureSpeech } from '../services/azureService';

interface VoiceSelectorProps {
  voices: VoiceOption[];
  selectedVoice: VoiceName;
  onSelect: (voice: VoiceName) => void;
}

const VoiceSelector: React.FC<VoiceSelectorProps> = ({ voices, selectedVoice, onSelect }) => {
  const [loadingId, setLoadingId] = useState<VoiceName | null>(null);
  const [playingId, setPlayingId] = useState<VoiceName | null>(null);
  const previewRef = useRef<HTMLAudioElement | null>(null);

  const handlePreview = async (e: React.MouseEvent, voiceId: VoiceName, name: string) => {
    e.stopPropagation();
    if (playingId === voiceId) {
      previewRef.current?.pause();
      setPlayingId(null);
      return;
    }
    setLoadingId(voiceId);
    try {
      const url = await generateAzureSpeech(`Sample.`, voiceId, 0, 0);
      if (previewRef.current) {
        previewRef.current.src = url;
        previewRef.current.onplay = () => { setLoadingId(null); setPlayingId(voiceId); };
        previewRef.current.onended = () => { setPlayingId(null); };
        previewRef.current.play();
      }
    } catch { setLoadingId(null); }
  };

  return (
    <div className="space-y-3 pb-8">
      <audio ref={previewRef} className="hidden" />
      {voices.length === 0 ? (
        <div className="py-20 text-center opacity-30">
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Filter unmatched</p>
        </div>
      ) : (
        voices.map((voice) => (
          <button
            key={voice.id}
            onClick={() => onSelect(voice.id)}
            className={`w-full group relative p-4 rounded-[2rem] border transition-all duration-300 flex items-center justify-between text-left ${
              selectedVoice === voice.id
                ? 'bg-indigo-600 border-indigo-600 shadow-xl shadow-indigo-600/20'
                : 'bg-white dark:bg-white/5 border-slate-200 dark:border-white/5 hover:border-indigo-500/30'
            }`}
          >
            <div className="flex items-center gap-4 min-w-0">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 border transition-all ${
                selectedVoice === voice.id ? 'bg-white/10 border-white/20 text-white' : 'bg-slate-100 dark:bg-black/40 border-slate-200 dark:border-white/5 text-slate-400 group-hover:text-indigo-500'
              }`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-black truncate ${selectedVoice === voice.id ? 'text-white' : 'text-slate-900 dark:text-white'}`}>{voice.name}</span>
                  <span className={`text-[7px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded border ${
                    selectedVoice === voice.id ? 'bg-white/20 border-white/20 text-white' : voice.gender === 'Female' ? 'border-pink-500/20 text-pink-500' : 'border-blue-500/20 text-blue-500'
                  }`}>{voice.gender[0]}</span>
                </div>
                <p className={`text-[9px] font-bold truncate mt-0.5 ${selectedVoice === voice.id ? 'text-indigo-100' : 'text-slate-400 dark:text-slate-500'}`}>{voice.lang}</p>
              </div>
            </div>

            <button
              onClick={(e) => handlePreview(e, voice.id, voice.name)}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-all shrink-0 ml-3 ${
                selectedVoice === voice.id 
                  ? 'bg-white/20 text-white hover:bg-white/30' 
                  : playingId === voice.id ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-black/40 text-slate-500 hover:text-indigo-500'
              }`}
            >
              {loadingId === voice.id ? (
                <div className={`w-3.5 h-3.5 border-2 rounded-full animate-spin ${selectedVoice === voice.id ? 'border-white/30 border-t-white' : 'border-slate-300 border-t-indigo-500'}`}></div>
              ) : playingId === voice.id ? (
                <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
              ) : (
                <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
              )}
            </button>
          </button>
        ))
      )}
    </div>
  );
};

export default VoiceSelector;
