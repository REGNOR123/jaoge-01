
import React, { useState, useEffect, useRef } from 'react';
import { SpeechEntry } from '../types';

interface AudioPlayerProps {
  entry: SpeechEntry;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  onClose: () => void;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ entry, audioRef, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const volumeTimerRef = useRef<number | null>(null);

  // Set audio source when entry changes
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !entry.audioUrl) return;
    
    audio.src = entry.audioUrl;
    audio.load();
  }, [entry.audioUrl, audioRef]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const update = () => setCurrentTime(audio.currentTime);
    const durUpdate = () => setDuration(audio.duration);
    const setPlay = () => setIsPlaying(true);
    const setPause = () => setIsPlaying(false);
    
    audio.addEventListener('timeupdate', update);
    audio.addEventListener('loadedmetadata', durUpdate);
    audio.addEventListener('play', setPlay);
    audio.addEventListener('pause', setPause);
    
    // Set initial values
    audio.volume = isMuted ? 0 : volume;

    return () => {
      audio.removeEventListener('timeupdate', update);
      audio.removeEventListener('loadedmetadata', durUpdate);
      audio.removeEventListener('play', setPlay);
      audio.removeEventListener('pause', setPause);
    };
  }, [audioRef, entry]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted, audioRef]);

  const toggle = () => {
    if (!audioRef.current) return;
    if (isPlaying) audioRef.current.pause(); else audioRef.current.play();
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!audioRef.current) return;
    const val = parseFloat(e.target.value);
    audioRef.current.currentTime = val;
    setCurrentTime(val);
  };

  const jump = (seconds: number) => {
    if (!audioRef.current) return;
    audioRef.current.currentTime = Math.max(0, Math.min(duration, audioRef.current.currentTime + seconds));
  };

  const toggleMute = () => setIsMuted(!isMuted);

  const format = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const handleVolumeIconHover = () => {
    if (volumeTimerRef.current) window.clearTimeout(volumeTimerRef.current);
    setShowVolumeSlider(true);
  };

  const handleVolumeMouseLeave = () => {
    volumeTimerRef.current = window.setTimeout(() => {
      setShowVolumeSlider(false);
    }, 1000);
  };

  return (
    <div className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[500] w-full max-w-2xl px-6 animate-in slide-in-from-bottom-8 duration-700 cubic-bezier(0.4, 0, 0.2, 1)">
      <div className="glass !bg-slate-900 !border-white/10 rounded-[3rem] px-8 py-5 flex items-center gap-6 shadow-2xl">
        
        {/* Playback Controls Group */}
        <div className="flex items-center gap-3">
          <button onClick={() => jump(-10)} className="text-white/40 hover:text-white transition-colors p-2" title="Rewind 10s">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0019 16V8a1 1 0 00-1.6-.8l-5.334 4zM4.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0011 16V8a1 1 0 00-1.6-.8l-5.334 4z" /></svg>
          </button>

          <button onClick={toggle} className="w-14 h-14 rounded-full bg-white text-black flex items-center justify-center shrink-0 hover:scale-105 active:scale-95 transition-all shadow-xl shadow-white/10">
            {isPlaying ? (
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
            ) : (
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
            )}
          </button>

          <button onClick={() => jump(10)} className="text-white/40 hover:text-white transition-colors p-2" title="Forward 10s">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11.934 12.8a1 1 0 000-1.6l-5.334-4A1 1 0 005 8v8a1 1 0 001.6.8l5.334-4zM19.934 12.8a1 1 0 000-1.6l-5.334-4A1 1 0 0013 8v8a1 1 0 001.6.8l5.334-4z" /></svg>
          </button>
        </div>

        {/* Progress & Metadata */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest mb-3">
            <span className="text-white truncate max-w-[140px]">{entry.recordingName}</span>
            <span className="text-white/40">{format(currentTime)} / {format(duration || 0)}</span>
          </div>
          <div className="relative group/seeker">
            <input 
              type="range" 
              min="0" 
              max={duration || 0} 
              step="0.01" 
              value={currentTime} 
              onChange={handleSeek}
              className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-white"
            />
            <div className="absolute top-0 left-0 h-1.5 bg-white rounded-full pointer-events-none transition-all duration-75" style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}></div>
          </div>
        </div>

        {/* Volume & Additional Actions */}
        <div className="flex items-center gap-2 relative" onMouseLeave={handleVolumeMouseLeave}>
          <div className={`absolute bottom-full left-1/2 -translate-x-1/2 mb-4 p-3 bg-slate-800 border border-white/10 rounded-2xl shadow-2xl transition-all duration-300 origin-bottom ${showVolumeSlider ? 'opacity-100 scale-100 pointer-events-auto' : 'opacity-0 scale-90 pointer-events-none'}`}>
            <div className="h-24 flex flex-col items-center">
              <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.01" 
                value={volume} 
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-1.5 h-full bg-white/10 rounded-full appearance-none cursor-pointer accent-white vertical-range"
                style={{ WebkitAppearance: 'slider-vertical' } as any}
              />
            </div>
          </div>

          <button 
            onClick={toggleMute}
            onMouseEnter={handleVolumeIconHover}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${isMuted || volume === 0 ? 'text-red-500' : 'text-white/60 hover:text-white'}`}
          >
            {isMuted || volume === 0 ? (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5.586 15L4 13.414V10.586L5.586 9M9 14l5 5V5L9 10m0 4v-4m5 4h.01M17 14h.01M21 14h.01" /></svg>
            ) : volume < 0.5 ? (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.536 8.464a5 5 0 010 7.072M9 14l5 5V5L9 10H5v4h4z" /></svg>
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M9 14l5 5V5L9 10H5v4h4z" /></svg>
            )}
          </button>

          <button onClick={onClose} className="w-10 h-10 rounded-full flex items-center justify-center text-white/40 hover:text-white transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default AudioPlayer;
