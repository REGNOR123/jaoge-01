import React from "react";
import { AlertTriangle, Clock, Type, Sparkles, Wand2 } from "lucide-react";
import { useGuestUsage, GUEST_PLAN_LIMITS, type UsageType } from "../contexts/GuestUsageContext";

type GuestUsageBadgeProps = {
  className?: string;
  showAll?: boolean;
  showType?: UsageType;
  compact?: boolean;
};

const usageIcons: Record<UsageType, React.ReactNode> = {
  characters: <Type className="w-3.5 h-3.5" />,
  voiceMinutes: <Clock className="w-3.5 h-3.5" />,
  aiEnhancements: <Sparkles className="w-3.5 h-3.5" />,
  autoGenerate: <Wand2 className="w-3.5 h-3.5" />,
};

const usageLabels: Record<UsageType, string> = {
  characters: "Characters",
  voiceMinutes: "Voice Minutes",
  aiEnhancements: "AI Enhancements",
  autoGenerate: "Auto-Generate",
};

const GuestUsageBadge: React.FC<GuestUsageBadgeProps> = ({
  className = "",
  showAll = false,
  showType,
  compact = false,
}) => {
  const { isGuest, getUsed, getLimit, getUsagePercentage } = useGuestUsage();

  if (!isGuest) return null;

  const types: UsageType[] = showType
    ? [showType]
    : showAll
      ? ["characters", "voiceMinutes", "aiEnhancements", "autoGenerate"]
      : ["characters"];

  const renderUsageItem = (type: UsageType) => {
    const used = getUsed(type);
    const limit = getLimit(type);
    const percentage = getUsagePercentage(type);
    const isNearLimit = percentage >= 80;
    const isAtLimit = percentage >= 100;

    if (compact) {
      return (
        <div
          key={type}
          className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs font-semibold ${
            isAtLimit
              ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300"
              : isNearLimit
                ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300"
                : "bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-300"
          }`}
          title={`${usageLabels[type]}: ${used}/${limit}`}
        >
          {usageIcons[type]}
          <span>{used}/{limit}</span>
          {isAtLimit && <AlertTriangle className="w-3 h-3" />}
        </div>
      );
    }

    return (
      <div key={type} className="space-y-1.5">
        <div className="flex items-center justify-between text-xs">
          <span className="flex items-center gap-1.5 font-medium text-slate-600 dark:text-slate-400">
            {usageIcons[type]}
            {usageLabels[type]}
          </span>
          <span className={`font-bold ${
            isAtLimit
              ? "text-red-600 dark:text-red-400"
              : isNearLimit
                ? "text-amber-600 dark:text-amber-400"
                : "text-slate-700 dark:text-slate-300"
          }`}>
            {used}/{limit}
          </span>
        </div>
        <div className="h-1.5 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-300 ${
              isAtLimit
                ? "bg-red-500"
                : isNearLimit
                  ? "bg-amber-500"
                  : "bg-indigo-500"
            }`}
            style={{ width: `${Math.min(percentage, 100)}%` }}
          />
        </div>
      </div>
    );
  };

  if (compact) {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
          Trial
        </span>
        {types.map(renderUsageItem)}
      </div>
    );
  }

  return (
    <div className={`rounded-2xl border border-amber-200/60 dark:border-amber-800/40 bg-amber-50/80 dark:bg-amber-900/20 p-4 ${className}`}>
      <div className="flex items-center gap-2 mb-3">
        <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
        <span className="text-xs font-bold text-amber-700 dark:text-amber-300 uppercase tracking-wider">
          Free Trial Usage
        </span>
      </div>
      <div className="space-y-3">
        {types.map(renderUsageItem)}
      </div>
      <p className="mt-3 text-xs text-amber-600 dark:text-amber-400">
        Sign up for more usage & features
      </p>
    </div>
  );
};

export default GuestUsageBadge;

// Inline badge for showing a single usage type
export const GuestUsageInline: React.FC<{ type: UsageType; className?: string }> = ({ type, className = "" }) => {
  const { isGuest, getUsed, getLimit, getUsagePercentage } = useGuestUsage();

  if (!isGuest) return null;

  const used = getUsed(type);
  const limit = getLimit(type);
  const percentage = getUsagePercentage(type);
  const isNearLimit = percentage >= 80;
  const isAtLimit = percentage >= 100;

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-semibold ${
        isAtLimit
          ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300"
          : isNearLimit
            ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300"
            : "bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-300"
      } ${className}`}
    >
      {usageIcons[type]}
      {used}/{limit}
    </span>
  );
};
