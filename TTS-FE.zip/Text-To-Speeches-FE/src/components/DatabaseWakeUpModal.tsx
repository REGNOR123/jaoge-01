import React from 'react';
import { DbWakeUpState } from '../hooks/useDbWakeUp';

interface DatabaseWakeUpModalProps {
  isOpen: boolean;
  state: DbWakeUpState | null;
  onCancel: () => void;
}

export const DatabaseWakeUpModal: React.FC<DatabaseWakeUpModalProps> = ({
  isOpen,
  state,
  onCancel,
}) => {
  if (!isOpen || !state) return null;

  return (
    <div className="fixed inset-0 z-[700] flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="glass studio-card w-full max-w-sm p-8 rounded-2xl">
        {/* Spinner with Progress */}
        <div className="flex justify-center mb-6">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 border-4 border-indigo-200 dark:border-indigo-900 border-t-indigo-600 rounded-full animate-spin"></div>
            <div className="absolute inset-2 flex items-center justify-center text-sm font-bold text-slate-700 dark:text-slate-300">
              {state.progress}%
            </div>
          </div>
        </div>

        {/* Message */}
        <p className="text-center text-slate-600 dark:text-slate-300 font-medium mb-2 text-sm">
          {state.message}
        </p>

        {/* Time info */}
        <p className="text-center text-xs text-slate-500 dark:text-slate-400 mb-6">
          {state.elapsedSeconds}s elapsed • Next retry in {state.nextRetryIn}s
        </p>

        {/* Progress bar */}
        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 mb-6 overflow-hidden">
          <div
            className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${state.progress}%` }}
          ></div>
        </div>

        {/* Cancel button */}
        <button
          onClick={onCancel}
          className="w-full py-2 text-sm text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 transition-colors font-medium"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};
