import React from "react";
import { X } from "lucide-react";
import type { DateRangeValue, ProjectTableStatus, ProjectTableType } from "../data/projects";
import { Input } from "./ui/input";

type TableFiltersValue = {
  projectName: string;
  type: "ALL" | ProjectTableType;
  status: "ALL" | ProjectTableStatus;
  createdAt: DateRangeValue;
  lastModified: DateRangeValue;
};

type TableFiltersProps = {
  value: TableFiltersValue;
  typeOptions: ProjectTableType[];
  onChange: (next: TableFiltersValue) => void;
  onClearAll: () => void;
  hasActiveFilters: boolean;
};

const selectClassName =
  "flex h-10 w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-sky-500/30 dark:border-white/10 dark:bg-white/5 dark:text-white";

const TableFilters: React.FC<TableFiltersProps> = ({ value, typeOptions, onChange, onClearAll, hasActiveFilters }) => {
  return (
    <div className="space-y-3 border-b border-slate-200/80 pb-4 dark:border-white/10">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-5">
        <div className="space-y-2">
          <label htmlFor="filter-project-name" className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Project Name
          </label>
          <Input
            id="filter-project-name"
            value={value.projectName}
            onChange={(event) => onChange({ ...value, projectName: event.target.value })}
            placeholder="Filter by project name"
            className="rounded-md"
          />
        </div>

        <div className="space-y-2">
          <label htmlFor="filter-type" className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Type
          </label>
          <select
            id="filter-type"
            value={value.type}
            onChange={(event) => onChange({ ...value, type: event.target.value as TableFiltersValue["type"] })}
            className={selectClassName}
          >
            <option value="ALL">All Types</option>
            {typeOptions.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <label htmlFor="filter-status" className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Status
          </label>
          <select
            id="filter-status"
            value={value.status}
            onChange={(event) => onChange({ ...value, status: event.target.value as TableFiltersValue["status"] })}
            className={selectClassName}
          >
            <option value="ALL">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="Processing">Processing</option>
            <option value="Draft">Draft</option>
          </select>
        </div>

        <fieldset className="space-y-2">
          <legend className="text-xs font-medium text-slate-500 dark:text-slate-400">Created Date</legend>
          <div className="grid grid-cols-2 gap-2">
            <Input
              type="date"
              value={value.createdAt.from}
              onChange={(event) =>
                onChange({
                  ...value,
                  createdAt: { ...value.createdAt, from: event.target.value },
                })
              }
              aria-label="Created date from"
              placeholder="From"
              className="rounded-md"
            />
            <Input
              type="date"
              value={value.createdAt.to}
              onChange={(event) =>
                onChange({
                  ...value,
                  createdAt: { ...value.createdAt, to: event.target.value },
                })
              }
              aria-label="Created date to"
              placeholder="To"
              className="rounded-md"
            />
          </div>
        </fieldset>

        <fieldset className="space-y-2">
          <legend className="text-xs font-medium text-slate-500 dark:text-slate-400">Last Modified</legend>
          <div className="grid grid-cols-2 gap-2">
            <Input
              type="date"
              value={value.lastModified.from}
              onChange={(event) =>
                onChange({
                  ...value,
                  lastModified: { ...value.lastModified, from: event.target.value },
                })
              }
              aria-label="Last modified from"
              placeholder="From"
              className="rounded-md"
            />
            <Input
              type="date"
              value={value.lastModified.to}
              onChange={(event) =>
                onChange({
                  ...value,
                  lastModified: { ...value.lastModified, to: event.target.value },
                })
              }
              aria-label="Last modified to"
              placeholder="To"
              className="rounded-md"
            />
          </div>
        </fieldset>
      </div>

      {hasActiveFilters && (
        <div className="flex justify-end">
          <button
            type="button"
            onClick={onClearAll}
            className="flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors"
          >
            <X className="h-3 w-3" />
            Clear All Filters
          </button>
        </div>
      )}
    </div>
  );
};

export type { TableFiltersValue };
export default TableFilters;
