
import React from 'react';

const IntroSection: React.FC = () => {
  return (
    <section className="py-12 px-0 relative overflow-hidden">
      <h2 className="text-5xl font-black tracking-tight mb-6 max-w-3xl leading-tight">
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600">
          Bring your words to life
        </span>
        <span className="text-slate-900 dark:text-white"> with high-quality, human-like AI voices</span>
      </h2>
      <p className="text-xl font-bold leading-relaxed max-w-2xl">
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-emerald-600">
          Customize every vocal nuance and mood
        </span>
        <span className="text-slate-700 dark:text-slate-300"> for truly expressive Text to Speech!</span>
      </p>
    </section>
  );
};

export default IntroSection;
