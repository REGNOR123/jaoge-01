import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, 
  UserPlus, 
  LogIn, 
  X, 
  Check,
  Mic,
  Clock,
  Zap
} from 'lucide-react';
import { GUEST_PLAN_LIMITS } from '@/contexts/GuestUsageContext';

interface GuestSignupPromptProps {
  isOpen: boolean;
  onClose: () => void;
  onContinueAsGuest?: () => void;
  featureName?: string;
  redirectTo?: string;
}

const GuestSignupPrompt: React.FC<GuestSignupPromptProps> = ({
  isOpen,
  onClose,
  onContinueAsGuest,
  featureName = 'Create Voice',
  redirectTo = '/create-voice',
}) => {
  const navigate = useNavigate();

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  // Prevent body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSignup = () => {
    onClose();
    navigate('/signup', {
      state: {
        redirectTo,
        fromGuestLimit: true,
      },
    });
  };

  const handleLogin = () => {
    onClose();
    navigate('/login', {
      state: {
        redirectTo,
        fromGuestLimit: true,
      },
    });
  };

  const handleContinueAsGuest = () => {
    onClose();
    onContinueAsGuest?.();
  };

  const benefits = [
    { icon: Mic, text: '5x more voice minutes' },
    { icon: Clock, text: 'Save projects permanently' },
    { icon: Zap, text: '25 AI enhancements' },
    { icon: Sparkles, text: 'Priority support' },
  ];

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
      {/* Blur backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/40 dark:bg-black/60 backdrop-blur-md"
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-md animate-in fade-in zoom-in-95 duration-300">
        {/* Glassmorphism card */}
        <div className="relative overflow-hidden rounded-3xl border border-white/20 dark:border-white/10 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl shadow-2xl shadow-indigo-500/10">
          {/* Gradient decoration */}
          <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-br from-indigo-500/20 via-purple-500/20 to-pink-500/20 dark:from-indigo-500/10 dark:via-purple-500/10 dark:to-pink-500/10" />
          
          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-white/50 dark:hover:bg-white/10 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="relative p-8 pt-12">
            {/* Icon */}
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
                <Sparkles className="w-10 h-10 text-white" />
              </div>
            </div>

            {/* Title */}
            <h2 className="text-2xl font-black text-center text-slate-900 dark:text-white tracking-tight">
              You've Hit Your Free Trial Limit
            </h2>

            {/* Subtitle */}
            <p className="mt-3 text-center text-slate-600 dark:text-slate-300 leading-relaxed">
              Sign up for a <span className="font-semibold text-indigo-600 dark:text-indigo-400">Free Plan</span> to continue using {featureName} and unlock more features.
            </p>

            {/* Benefits */}
            <div className="mt-6 grid grid-cols-2 gap-3">
              {benefits.map((benefit, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2.5 p-3 rounded-xl bg-white/60 dark:bg-white/5 border border-white/50 dark:border-white/10"
                >
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center">
                    <benefit.icon className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                    {benefit.text}
                  </span>
                </div>
              ))}
            </div>

            {/* Free plan highlights */}
            <div className="mt-6 p-4 rounded-2xl bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border border-green-100 dark:border-green-800/30">
              <p className="text-sm font-bold text-green-700 dark:text-green-300 flex items-center gap-2 mb-2">
                <Check className="w-4 h-4" />
                Free Plan includes:
              </p>
              <ul className="space-y-1 text-xs text-green-600 dark:text-green-400">
                <li className="flex items-center gap-2">
                  <span className="w-1 h-1 rounded-full bg-green-500"></span>
                  {(GUEST_PLAN_LIMITS.characters * 5).toLocaleString()} characters/month
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1 h-1 rounded-full bg-green-500"></span>
                  {GUEST_PLAN_LIMITS.voiceMinutes * 3} voice minutes
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1 h-1 rounded-full bg-green-500"></span>
                  Unlimited project storage
                </li>
              </ul>
            </div>

            {/* Action buttons */}
            <div className="mt-6 space-y-3">
              <button
                type="button"
                onClick={handleSignup}
                className="w-full px-6 py-4 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white text-sm font-bold transition-all duration-200 hover:scale-[1.02] hover:shadow-xl hover:shadow-indigo-500/25 inline-flex items-center justify-center gap-2"
              >
                <UserPlus className="w-5 h-5" />
                Sign Up Free
              </button>
              
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={handleLogin}
                  className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-white/10 bg-white/80 dark:bg-white/5 hover:bg-white dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 text-sm font-bold transition-colors inline-flex items-center justify-center gap-2"
                >
                  <LogIn className="w-4 h-4" />
                  Login
                </button>
                {onContinueAsGuest && (
                  <button
                    type="button"
                    onClick={handleContinueAsGuest}
                    className="flex-1 px-4 py-3 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 text-sm font-medium transition-colors"
                  >
                    Maybe Later
                  </button>
                )}
              </div>
            </div>

            {/* Footer */}
            <p className="mt-4 text-center text-[10px] text-slate-400 dark:text-slate-500">
              No credit card required • Sign up in 30 seconds
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GuestSignupPrompt;
