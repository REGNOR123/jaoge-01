import React from "react";
import { NavLink } from "react-router-dom";
import { Lock, Menu, Tag } from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";

type AppSidebarProps = {
  collapsed: boolean;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onToggleSidebar: () => void;
};

type NavItem = {
  to: string;
  label: string;
  icon: React.ReactNode;
  guestRestricted?: boolean; // If true, hide/disable for guest users
  comingSoon?: boolean;
};

const navItems: NavItem[] = [
  {
    to: "/dashboard",
    label: "Dashboard",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z" />
      </svg>
    ),
  },
  {
    to: "/create-voice",
    label: "Create AI Voice",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 1a4 4 0 014 4v7a4 4 0 11-8 0V5a4 4 0 014-4zm6 11a6 6 0 01-12 0M12 19v4m-4 0h8" />
      </svg>
    ),
  },
  {
    to: "/transcribe",
    label: "Transcribe Audio",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-2v13" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10l12-2" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18a3 3 0 100-6 3 3 0 000 6z" />
      </svg>
    ),
  },
  {
    to: "/translate-dub",
    label: "Translate & Dub",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m3 14l6 2-2-6m-2-6a5 5 0 00-9.9 1" />
      </svg>
    ),
  },
  {
    to: "/speech-translate",
    label: "Speech Translate",
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 1a4 4 0 014 4v7a4 4 0 11-8 0V5a4 4 0 014-4zm6 11a6 6 0 01-12 0" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 21h18" />
      </svg>
    ),
  },
  {
    to: "/script-studio",
    label: "AI Script Studio",
    guestRestricted: true,
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m-7 4h8a2 2 0 002-2V6a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
      </svg>
    ),
  },
  {
    to: "/voice-clone",
    label: "Voice Clone",
    guestRestricted: true,
    comingSoon: true,
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 1a4 4 0 014 4v7a4 4 0 11-8 0V5a4 4 0 014-4zm6 11a6 6 0 01-12 0" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 19h14M12 15v4" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 19c0 1.1.9 2 2 2h4a2 2 0 002-2" />
      </svg>
    ),
  },
  {
    to: "/projects",
    label: "Projects",
    guestRestricted: true,
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7h18M3 12h18M3 17h18" />
      </svg>
    ),
  },
];

const AppSidebar: React.FC<AppSidebarProps> = ({
  collapsed,
  mobileOpen,
  onCloseMobile,
  onToggleSidebar,
}) => {
  const { isAuthenticated, isLoading } = useAuth();
  const isGuest = !isLoading && !isAuthenticated;
  
  const sidebarWidthClass = collapsed ? "w-16" : "w-64";
  const visibilityClass = mobileOpen ? "block" : "hidden md:block";

  // Filter or modify nav items for guests
  const displayNavItems = navItems.map(item => ({
    ...item,
    disabled: item.comingSoon || (isGuest && item.guestRestricted),
  }));

  const sidebarContent = (
    <aside
      className={[
        "fixed top-16 left-0 bottom-0 z-[180]",
        sidebarWidthClass,
        visibilityClass,
        "glass border-r border-black/5 dark:border-white/5",
        "overflow-y-auto scrollbar-hide",
      ].join(" ")}
    >
      <div className="p-3">
        <div className="px-2 pt-2 pb-3">
          <button
            type="button"
            onClick={onToggleSidebar}
            className="h-10 w-10 rounded-xl glass flex items-center justify-center hover:bg-white dark:hover:bg-white/10 transition-colors"
            aria-label="Toggle sidebar"
          >
            <Menu className="w-5 h-5 text-slate-700 dark:text-slate-200" />
          </button>
        </div>

        <nav className="space-y-1">
          {displayNavItems.map((item) => {
            // Disabled items for guests
            if (item.disabled) {
              return (
                <div
                  key={item.to}
                  title={collapsed ? `${item.label}${item.comingSoon ? " (Coming Soon)" : " (Sign up required)"}` : undefined}
                  className="flex items-center gap-3 rounded-xl px-3 py-2.5 opacity-50 cursor-not-allowed text-slate-400 dark:text-slate-500"
                >
                  <span className="shrink-0 relative">
                    {item.icon}
                    {!item.comingSoon && (
                      <Lock className="w-3 h-3 absolute -bottom-0.5 -right-0.5 text-slate-400 dark:text-slate-500" />
                    )}
                  </span>
                  {!collapsed && (
                    <span className="flex flex-col">
                      <span className="text-sm font-semibold">{item.label}</span>
                      {item.comingSoon ? (
                        <span className="text-[9px] uppercase tracking-wider text-amber-500 dark:text-amber-400 font-bold leading-tight">
                          Coming Soon
                        </span>
                      ) : (
                        <span className="text-[9px] uppercase tracking-wider text-amber-500 dark:text-amber-400 font-bold leading-tight">
                          Pro
                        </span>
                      )}
                    </span>
                  )}
                </div>
              );
            }
            
            return (
              <NavLink
                key={item.to}
                to={item.to}
                title={collapsed ? item.label : undefined}
                onClick={onCloseMobile}
                className={({ isActive }) =>
                  [
                    "flex items-center gap-3 rounded-xl px-3 py-2.5 transition-colors",
                    isActive
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/10",
                  ].join(" ")
                }
              >
                <span className="shrink-0">{item.icon}</span>
                {!collapsed && (
                  <span className="text-sm font-semibold">{item.label}</span>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Pricing link */}
        <div className="mt-2 border-t border-black/5 dark:border-white/5 pt-2">
          <NavLink
            to="/pricing"
            title={collapsed ? "Pricing" : undefined}
            onClick={onCloseMobile}
            className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/10 transition-colors"
          >
            <span className="shrink-0"><Tag className="w-5 h-5" /></span>
            {!collapsed && <span className="text-sm font-semibold">Pricing</span>}
          </NavLink>
        </div>

        {/* Guest CTA at bottom of sidebar */}
        {isGuest && !collapsed && (
          <div className="mt-6 p-3 rounded-xl bg-gradient-to-br from-indigo-500/10 to-purple-500/10 dark:from-indigo-900/20 dark:to-purple-900/20 border border-indigo-200/50 dark:border-indigo-500/20">
            <NavLink
              to="/signup"
              className="text-xs font-bold text-indigo-600 dark:text-indigo-300 hover:underline mb-2 block"
            >
              Signup for 200 free credits
            </NavLink>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mb-3">
              No credit card required
            </p>
            <NavLink
              to="/signup"
              className="block w-full text-center text-xs font-bold py-2 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition-colors"
            >
              Sign Up Free
            </NavLink>
          </div>
        )}
      </div>
    </aside>
  );

  if (!mobileOpen) return sidebarContent;

  return (
    <div
      className="fixed inset-0 z-[190] bg-slate-900/40 backdrop-blur-sm md:hidden"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onCloseMobile();
      }}
    >
      {sidebarContent}
    </div>
  );
};

export default AppSidebar;
