import React from "react";
import { Link } from "react-router-dom";

const AppFooter: React.FC = () => {
  return (
    <footer className="mt-10 pt-6 border-t border-black/5 dark:border-white/10">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
          © 2026 TextToSpeeches.in
        </div>

        <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <Link to="/about" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">
              About
            </Link>
            <span className="text-slate-300 dark:text-white/10">|</span>
            <Link to="/docs" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">
              Docs
            </Link>
            <span className="text-slate-300 dark:text-white/10">|</span>
            <Link to="/help" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">
              Help
            </Link>
            <span className="text-slate-300 dark:text-white/10">|</span>
            <Link to="/privacy" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">
              Privacy
            </Link>
            <span className="text-slate-300 dark:text-white/10">|</span>
            <Link to="/terms" className="hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors">
              Terms
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default AppFooter;

