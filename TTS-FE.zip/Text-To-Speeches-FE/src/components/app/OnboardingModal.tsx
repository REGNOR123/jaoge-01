import React, { useEffect } from "react";

export type OnboardingChoice = "voiceover" | "transcription" | "dubbing" | "script";

type OnboardingModalProps = {
  isOpen: boolean;
  onSelect: (choice: OnboardingChoice) => void;
};

const OnboardingModal: React.FC<OnboardingModalProps> = ({ isOpen, onSelect }) => {
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen]);

  if (!isOpen) return null;

  const card = (label: string, choice: OnboardingChoice, description: string) => (
    <button
      type="button"
      onClick={() => onSelect(choice)}
      className="text-left rounded-2xl p-5 glass hover:bg-white dark:hover:bg-white/10 transition-colors border border-black/5 dark:border-white/10"
    >
      <div className="text-sm font-black text-slate-900 dark:text-white">{label}</div>
      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-medium">
        {description}
      </div>
    </button>
  );

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="w-full max-w-xl glass studio-card !p-10">
        <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          What do you want to create first?
        </h2>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 font-medium">
          Choose one to jump right in.
        </p>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {card("Voiceover", "voiceover", "Generate an AI voice from text.")}
          {card("Transcription", "transcription", "Turn speech into text.")}
          {card("Dubbing", "dubbing", "Translate and dub audio in a new voice.")}
          {card("Script", "script", "Draft and refine scripts with AI.")}
        </div>
      </div>
    </div>
  );
};

export default OnboardingModal;

