import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { User } from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import { useTheme } from "../../contexts/ThemeContext";
import { useCredits } from "../../contexts/CreditContext";
import ProfileDropdownGuest from "../ProfileDropdownGuest";
import ProfileDropdownUser from "../ProfileDropdownUser";
import Logo from "./Logo";

type AppNavbarProps = {
  onToggleSidebar: () => void;
};

/* ── component ──────────────────────────────────────────── */
const AppNavbar: React.FC<AppNavbarProps> = ({ onToggleSidebar }) => {
  const { user, logout, isAuthenticated, isLoading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { balance } = useCredits();
  const navigate = useNavigate();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [imageLoadError, setImageLoadError] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const isGuest = !isLoading && !isAuthenticated;

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const targetNode = e.target as Node;
      if (!menuRef.current?.contains(targetNode)) setIsProfileMenuOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const initial =
    user?.fullName?.trim()?.charAt(0)?.toUpperCase() ||
    user?.email?.trim()?.charAt(0)?.toUpperCase() ||
    "?";

  const hasProfilePicture = !!user?.profilePicture && !imageLoadError;

  // Reset image error state when profile picture changes
  useEffect(() => {
    setImageLoadError(false);
  }, [user?.profilePicture]);

  const handleToggleChatWidget = () => {
    window.dispatchEvent(new Event("chat-widget-toggle"));
  };

  return (
    <nav className="fixed top-0 left-0 right-0 h-16 z-[200] glass border-b border-black/5 dark:border-white/5">
      <div className="h-full px-4 sm:px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/dashboard" className="flex items-center">
            <Logo />
          </Link>
        </div>

        <div className="flex items-center gap-3">
          {isAuthenticated && !isLoading && (
            <div
              className="h-9 px-3 rounded-xl glass flex items-center gap-1.5 text-sm font-semibold text-slate-700 dark:text-slate-200"
              title="Your credit balance"
            >
              <span className="text-base leading-none">⚡</span>
              <span>{balance != null ? balance.toLocaleString() : '…'}</span>
            </div>
          )}

          <button
            type="button"
            className="h-10 w-10 rounded-xl glass flex items-center justify-center hover:bg-white dark:hover:bg-white/10 transition-colors"
            aria-label="Notifications"
          >
            <svg className="w-5 h-5 text-slate-700 dark:text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
          </button>

          <button
            type="button"
            onClick={handleToggleChatWidget}
            className="h-10 px-4 rounded-full border border-white/10 bg-slate-900 text-white flex items-center gap-2 hover:bg-slate-800 transition-colors shadow-sm"
            aria-label="Ask AI"
            title="Ask AI"
          >
            <svg className="w-4 h-4 text-cyan-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2.2}
                d="M12 3l1.4 3.2L17 7.6l-3.6 1.3L12 12l-1.4-3.1L7 7.6l3.6-1.4L12 3z"
              />
            </svg>
            <span className="hidden sm:inline text-sm font-semibold tracking-wide">Ask AI</span>
          </button>

          <button
            type="button"
            onClick={toggleTheme}
            className="h-10 w-10 rounded-xl glass flex items-center justify-center hover:bg-white dark:hover:bg-white/10 transition-colors"
            aria-label="Toggle theme"
            title={theme === "dark" ? "Switch to light" : "Switch to dark"}
          >
            {theme === "light" ? (
              <svg className="w-5 h-5 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
              </svg>
            ) : (
              <svg className="w-5 h-5 text-indigo-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h1M4 12H3m16.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            )}
          </button>

          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setIsProfileMenuOpen((prev) => !prev)}
              className={`h-10 w-10 rounded-full flex items-center justify-center font-black text-sm transition-colors shadow-sm overflow-hidden ${
                isGuest
                  ? "bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-300 dark:hover:bg-slate-600"
                  : "bg-indigo-600 text-white hover:bg-indigo-700"
              }`}
              aria-label="Open profile menu"
              title={user?.fullName || user?.email}
            >
              {hasProfilePicture ? (
                <img
                  src={user.profilePicture}
                  alt={user?.fullName || "Profile"}
                  className="w-full h-full object-cover"
                  onError={() => setImageLoadError(true)}
                />
              ) : isGuest ? (
                <User className="w-5 h-5" />
              ) : (
                initial
              )}
            </button>

            {isGuest ? (
              <ProfileDropdownGuest
                isOpen={isProfileMenuOpen}
                onClose={() => setIsProfileMenuOpen(false)}
              />
            ) : (
              <ProfileDropdownUser
                isOpen={isProfileMenuOpen}
                onClose={() => setIsProfileMenuOpen(false)}
                user={user}
                onLogout={logout}
              />
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default AppNavbar;
