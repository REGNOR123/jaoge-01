import React, { useEffect, useMemo, useState } from "react";
import { Navigate, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import AppNavbar from "./AppNavbar";
import AppSidebar from "./AppSidebar";
import OnboardingModal, { type OnboardingChoice } from "./OnboardingModal";
import AppFooter from "./AppFooter";

const SIDEBAR_COLLAPSED_KEY = "tts_app_sidebar_collapsed_v1";
const ONBOARDING_DONE_KEY_PREFIX = "tts_app_onboarding_done_v1";
const CHAT_WIDGET_STATE_EVENT = "chat-widget-state-change";

// Routes that guests can access (feature pages for trial)
const GUEST_ALLOWED_ROUTES = [
  "/dashboard",
  "/create-voice",
  "/transcribe",
  "/translate-dub",
  "/speech-translate",
  "/script-studio",
];

const AppShell: React.FC = () => {
  const { isAuthenticated, isLoading, user } = useAuth();
  const isGuest = !isLoading && !isAuthenticated;
  const navigate = useNavigate();
  const location = useLocation();

  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem(SIDEBAR_COLLAPSED_KEY) === "1";
    } catch {
      return false;
    }
  });
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [onboardingOpen, setOnboardingOpen] = useState(false);
  const [chatDrawerOpen, setChatDrawerOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(SIDEBAR_COLLAPSED_KEY, collapsed ? "1" : "0");
    } catch {
      // ignore
    }
  }, [collapsed]);

  useEffect(() => {
    if (!isAuthenticated) return;
    try {
      const onboardingKey = `${ONBOARDING_DONE_KEY_PREFIX}:${user?.id ?? user?.email ?? "unknown"}`;
      const done = localStorage.getItem(onboardingKey) === "1";
      if (!done) setOnboardingOpen(true);
    } catch {
      setOnboardingOpen(true);
    }
  }, [isAuthenticated, user?.email, user?.id]);

  useEffect(() => {
    const onChatWidgetState = (event: Event) => {
      const customEvent = event as CustomEvent<{ isOpen?: boolean }>;
      setChatDrawerOpen(!!customEvent.detail?.isOpen);
    };

    window.addEventListener(CHAT_WIDGET_STATE_EVENT, onChatWidgetState as EventListener);
    return () => {
      window.removeEventListener(CHAT_WIDGET_STATE_EVENT, onChatWidgetState as EventListener);
    };
  }, []);

  const handleOnboardingSelect = (choice: OnboardingChoice) => {
    try {
      const onboardingKey = `${ONBOARDING_DONE_KEY_PREFIX}:${user?.id ?? user?.email ?? "unknown"}`;
      localStorage.setItem(onboardingKey, "1");
    } catch {
      // ignore
    }
    setOnboardingOpen(false);

    const target = (() => {
      switch (choice) {
        case "voiceover":
          return "/create-voice";
        case "transcription":
          return "/transcribe";
        case "dubbing":
          return "/translate-dub";
        case "script":
          return "/script-studio";
        default:
          return "/dashboard";
      }
    })();
    navigate(target);
  };

  const mainOffsetClass = useMemo(() => {
    if (mobileSidebarOpen) return "ml-0";
    return collapsed ? "md:ml-16" : "md:ml-64";
  }, [collapsed, mobileSidebarOpen]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-white to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin" />
          <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">
            Loading...
          </p>
        </div>
      </div>
    );
  }

  // Check if guest is trying to access a route they can use
  const isGuestAllowedRoute = GUEST_ALLOWED_ROUTES.some(
    (route) => location.pathname === route || location.pathname.startsWith(route + "/")
  );

  // Redirect non-authenticated users to login, UNLESS they are guests on allowed routes
  if (!isAuthenticated && !isGuestAllowedRoute) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ redirectTo: location.pathname, redirectState: location.state }}
      />
    );
  }

  return (
    <div className="h-screen overflow-hidden selection:bg-indigo-500/20">
      <AppNavbar
        onToggleSidebar={() => {
          if (window.innerWidth < 768) {
            setMobileSidebarOpen((prev) => !prev);
          } else {
            setCollapsed((prev) => !prev);
          }
        }}
      />

      <AppSidebar
        collapsed={collapsed}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
        onToggleSidebar={() => {
          if (window.innerWidth < 768) {
            setMobileSidebarOpen((prev) => !prev);
          } else {
            setCollapsed((prev) => !prev);
          }
        }}
      />

      <main
        className={[
          "pt-16 h-full",
          mainOffsetClass,
          chatDrawerOpen ? "lg:mr-[420px]" : "lg:mr-0",
          "transition-[margin] duration-300 ease-out",
        ].join(" ")}
      >
        <div className="h-full overflow-y-auto thin-scrollbar">
          <div className="min-h-full max-w-[1720px] mx-auto w-full px-3 sm:px-5 lg:px-6 py-6 flex flex-col">
            <div className="flex-1">
              <Outlet />
            </div>
            <AppFooter />
          </div>
        </div>
      </main>

      {/* Only show onboarding for authenticated users */}
      {isAuthenticated && (
        <OnboardingModal isOpen={onboardingOpen} onSelect={handleOnboardingSelect} />
      )}
    </div>
  );
};

export default AppShell;
