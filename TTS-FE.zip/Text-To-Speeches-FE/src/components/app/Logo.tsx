import React from "react";

type LogoProps = {
  className?: string;
  collapsed?: boolean;
};

const Logo: React.FC<LogoProps> = ({ className = "", collapsed = false }) => {
  return (
    <span className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Microphone + waveform icon */}
      <svg
        width="34"
        height="34"
        viewBox="0 0 34 34"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        <defs>
          <linearGradient id="logo-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#6366f1" />
            <stop offset="100%" stopColor="#3b82f6" />
          </linearGradient>
        </defs>
        <rect width="34" height="34" rx="10" fill="url(#logo-grad)" />
        {/* Microphone body */}
        <rect x="14" y="7" width="6" height="11" rx="3" fill="white" opacity="0.95" />
        {/* Mic arc */}
        <path
          d="M11 17a6 6 0 0012 0"
          stroke="white"
          strokeWidth="2"
          strokeLinecap="round"
          opacity="0.85"
        />
        {/* Stem */}
        <line x1="17" y1="23" x2="17" y2="27" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.85" />
        {/* Base */}
        <line x1="13.5" y1="27" x2="20.5" y2="27" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.85" />
        {/* Sound waves */}
        <path
          d="M25 12a4 4 0 010 6"
          stroke="white"
          strokeWidth="1.5"
          strokeLinecap="round"
          opacity="0.5"
        />
        <path
          d="M27.5 10a7 7 0 010 10"
          stroke="white"
          strokeWidth="1.5"
          strokeLinecap="round"
          opacity="0.3"
        />
      </svg>

      {!collapsed && (
        <span className="flex items-baseline gap-0 text-[1.1rem] font-extrabold leading-none tracking-tight">
          <span className="text-slate-800 dark:text-white">TextTo</span>
          <span className="bg-gradient-to-r from-indigo-500 to-blue-500 bg-clip-text text-transparent">
            Speeches
          </span>
          <span className="text-slate-400 dark:text-slate-500 text-xs font-bold ml-0.5">.in</span>
        </span>
      )}
    </span>
  );
};

export default Logo;
