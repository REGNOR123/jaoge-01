import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

type AuthRequiredModalProps = {
  isOpen: boolean;
  onClose: () => void;
  redirectTo: string;
  redirectState?: unknown;
};

const AuthRequiredModal: React.FC<AuthRequiredModalProps> = ({
  isOpen,
  onClose,
  redirectTo,
  redirectState,
}) => {
  const navigate = useNavigate();

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const goLogin = () => {
    onClose();
    navigate("/login", {
      state: {
        redirectTo,
        ...(redirectState ? { redirectState } : {}),
      },
    });
  };

  const goSignup = () => {
    onClose();
    navigate("/signup", {
      state: {
        redirectTo,
        ...(redirectState ? { redirectState } : {}),
      },
    });
  };

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xl animate-in fade-in duration-300"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="glass studio-card w-full max-w-md scale-in-center !p-10 space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Sign Up to Continue
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            Sign up and get{" "}
            <span className="font-black text-indigo-600 dark:text-indigo-400">200 free credits</span>{" "}
            to use all features. Already have an account?{" "}
            <button
              type="button"
              onClick={goLogin}
              className="font-bold text-indigo-600 dark:text-indigo-400 underline underline-offset-4 hover:text-indigo-500 transition-colors"
            >
              Log in
            </button>
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <button
            type="button"
            onClick={goSignup}
            className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-black tracking-wide transition-colors shadow-sm"
          >
            Sign Up Free
          </button>
          <button
            type="button"
            onClick={goLogin}
            className="w-full py-3 rounded-xl border border-slate-200 dark:border-white/15 bg-white/70 dark:bg-white/5 hover:bg-white dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 text-sm font-bold transition-colors"
          >
            Log In
          </button>
        </div>

        <div className="text-center">
          <button
            onClick={onClose}
            className="text-xs font-semibold text-slate-400 dark:text-slate-500 underline underline-offset-4 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
          >
            I'll do it later
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthRequiredModal;

