
import React from 'react';
import { SpeechEntry } from '../types';
import HistoryItem from './HistoryItem';

interface ArchiveSidebarProps {
  historySearch: string;
  onHistorySearchChange: (value: string) => void;
  filteredHistory: SpeechEntry[];
  onDelete: (id: string) => void;
  onPlay: (entry: SpeechEntry) => void;
}

const ArchiveSidebar: React.FC<ArchiveSidebarProps> = ({
  historySearch, onHistorySearchChange, filteredHistory, onDelete, onPlay
}) => {
  return (
    <aside className="lg:col-span-3 space-y-8 h-fit lg:sticky lg:top-32">
      <div className="sidebar-title">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
        Audio Archive
      </div>
      <input 
        type="text" 
        placeholder="Search saved audio..." 
        value={historySearch} 
        onChange={(e) => onHistorySearchChange(e.target.value)} 
        className="w-full bg-slate-100/50 dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-2xl py-4 px-6 text-xs font-bold" 
      />
      <div className="space-y-4 max-h-[60vh] overflow-y-auto scrollbar-hide">
        {filteredHistory.map(entry => (
          <HistoryItem 
            key={entry.id} 
            entry={entry} 
            onDelete={() => onDelete(entry.id)} 
            onPlay={() => onPlay(entry)} 
          />
        ))}
      </div>
    </aside>
  );
};

export default ArchiveSidebar;
