import React, { useEffect, useRef, useState } from 'react';

interface DbWarmupLoaderProps {
  isVisible: boolean;
  messages: string[];
}

const CIRCUMFERENCE = 2 * Math.PI * 44;

const DbWarmupLoader: React.FC<DbWarmupLoaderProps> = ({ isVisible, messages }) => {
  const [progress, setProgress] = useState(0);
  const [messageIndex, setMessageIndex] = useState(0);
  const startTimeRef = useRef<number | null>(null);

  useEffect(() => {
    if (!isVisible) {
      setProgress(0);
      setMessageIndex(0);
      startTimeRef.current = null;
      return;
    }

    startTimeRef.current = Date.now();

    const progressInterval = setInterval(() => {
      const elapsed = Date.now() - (startTimeRef.current ?? Date.now());
      // Ease-out curve: approaches 88% over ~75s (DB max warm-up time)
      const p = 88 * (1 - Math.exp(-elapsed / 28000));
      setProgress(Math.min(Math.floor(p), 88));
    }, 200);

    const messageInterval = setInterval(() => {
      setMessageIndex(prev => (prev + 1) % messages.length);
    }, 4000);

    return () => {
      clearInterval(progressInterval);
      clearInterval(messageInterval);
    };
  }, [isVisible, messages.length]);

  if (!isVisible) return null;

  const strokeDashoffset = CIRCUMFERENCE * (1 - progress / 100);

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/97 dark:bg-slate-900/97 backdrop-blur-sm rounded-2xl z-10">
      {/* Progress Ring */}
      <div className="relative w-28 h-28">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50" cy="50" r="44"
            fill="none"
            strokeWidth="6"
            className="stroke-slate-200 dark:stroke-slate-700"
          />
          <circle
            cx="50" cy="50" r="44"
            fill="none"
            strokeWidth="6"
            strokeLinecap="round"
            className="stroke-indigo-600 transition-all duration-200"
            style={{ strokeDasharray: CIRCUMFERENCE, strokeDashoffset }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-2xl font-black text-slate-900 dark:text-white">{progress}%</span>
        </div>
      </div>

      {/* Status message */}
      <p className="mt-6 text-sm font-semibold text-slate-700 dark:text-slate-200 text-center px-6 transition-all duration-300">
        {messages[messageIndex]}
      </p>
      <p className="mt-2 text-xs text-slate-400 dark:text-slate-500 text-center px-6">
        Server is warming up — this only happens on first load
      </p>
    </div>
  );
};

export default DbWarmupLoader;
