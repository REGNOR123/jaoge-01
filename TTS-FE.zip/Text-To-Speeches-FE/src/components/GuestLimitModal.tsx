import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AlertTriangle, Sparkles, UserPlus, LogIn, X, Check } from "lucide-react";
import { useGuestUsage, getUsageTypeLabel, GUEST_PLAN_LIMITS, type UsageType } from "../contexts/GuestUsageContext";

type GuestLimitModalProps = {
  isOpen: boolean;
  onClose: () => void;
  usageType?: UsageType | null;
  redirectTo?: string;
};

const GuestLimitModal: React.FC<GuestLimitModalProps> = ({
  isOpen,
  onClose,
  usageType,
  redirectTo = "/",
}) => {
  const navigate = useNavigate();
  const { getUsed, getLimit } = useGuestUsage();

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const used = usageType ? getUsed(usageType) : 0;
  const limit = usageType ? getLimit(usageType) : 0;
  const typeLabel = usageType ? getUsageTypeLabel(usageType) : "resources";

  const handleSignup = () => {
    onClose();
    navigate("/signup", {
      state: {
        redirectTo,
        fromGuestLimit: true,
      },
    });
  };

  const handleLogin = () => {
    onClose();
    navigate("/login", {
      state: {
        redirectTo,
        fromGuestLimit: true,
      },
    });
  };

  const benefits = [
    { from: `${GUEST_PLAN_LIMITS.characters.toLocaleString()} chars`, to: "5,000 characters", label: "Characters" },
    { from: `${GUEST_PLAN_LIMITS.voiceMinutes} min`, to: "15 voice minutes", label: "Voice Minutes" },
    { from: `${GUEST_PLAN_LIMITS.aiEnhancements}`, to: "25 AI enhancements", label: "AI Enhancements" },
    { from: `${GUEST_PLAN_LIMITS.autoGenerate}`, to: "25 auto-generations", label: "Auto-Generate" },
  ];

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xl animate-in fade-in duration-300"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="glass studio-card w-full max-w-lg scale-in-center !p-0 relative overflow-hidden">
        {/* Close button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with gradient */}
        <div className="relative bg-gradient-to-br from-red-500 via-orange-500 to-amber-500 px-8 pt-8 pb-12">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <AlertTriangle className="w-8 h-8 text-white" />
            </div>
          </div>
          <h2 className="text-2xl font-black text-center text-white tracking-tight">
            Free Trial Limit Reached
          </h2>
          <p className="mt-2 text-center text-white/80 text-sm">
            You've used all your free trial {typeLabel}
          </p>
          {usageType && (
            <div className="mt-3 flex justify-center">
              <span className="px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold">
                {used} / {limit} {typeLabel} used
              </span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="px-8 pb-8 -mt-4">
          {/* Benefits card */}
          <div className="rounded-2xl bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/30 dark:to-purple-900/30 border border-indigo-100 dark:border-indigo-800/30 p-5 shadow-lg">
            <p className="text-sm font-bold text-indigo-700 dark:text-indigo-300 flex items-center gap-2 mb-4">
              <Sparkles className="w-4 h-4" />
              Sign up for free and unlock:
            </p>
            <div className="grid grid-cols-2 gap-3">
              {benefits.map((benefit) => (
                <div
                  key={benefit.label}
                  className="flex items-start gap-2 text-sm"
                >
                  <Check className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-slate-700 dark:text-slate-200">
                      {benefit.to}
                    </span>
                    <span className="block text-[10px] text-slate-400 dark:text-slate-500">
                      was {benefit.from}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={handleSignup}
              className="flex-1 px-6 py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white text-sm font-bold transition-all duration-200 hover:scale-[1.02] hover:shadow-lg hover:shadow-indigo-500/25 inline-flex items-center justify-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              Sign Up Free
            </button>
            <button
              type="button"
              onClick={handleLogin}
              className="flex-1 px-6 py-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white/80 dark:bg-white/5 hover:bg-slate-50 dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 text-sm font-bold transition-colors inline-flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              Login
            </button>
          </div>

          {/* Footer note */}
          <p className="mt-4 text-center text-xs text-slate-400 dark:text-slate-500">
            No credit card required • Instant access
          </p>
        </div>
      </div>
    </div>
  );
};

export default GuestLimitModal;
