import React, { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import logo from "../assets/logo.png";

interface HeaderProps {
  theme: "light" | "dark";
  onToggleTheme: () => void;
}

const Header: React.FC<HeaderProps> = ({ theme, onToggleTheme }) => {
  const [isMobileUserMenuOpen, setIsMobileUserMenuOpen] = useState(false);
  const [isDesktopUserMenuOpen, setIsDesktopUserMenuOpen] = useState(false);
  const mobileUserMenuRef = useRef<HTMLDivElement>(null);
  const desktopUserMenuRef = useRef<HTMLDivElement>(null);
  const { user, isAuthenticated, logout } = useAuth();

  const navLinks = [
    { to: "/", label: "Home" },
    { to: "/translate", label: "Translate Text" },
    { to: "/speech-to-text", label: "Speech To Text" },
    { to: "/speech-to-speech", label: "Speech To Speech" },
    { to: "/pricing", label: "Pricing" },
    { to: "/about", label: "About" },
    { to: "/audio-library", label: "Audio Library" },
  ];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const targetNode = e.target as Node;
      const isInsideMobileMenu = mobileUserMenuRef.current?.contains(targetNode);
      const isInsideDesktopMenu = desktopUserMenuRef.current?.contains(targetNode);

      if (
        !isInsideMobileMenu &&
        !isInsideDesktopMenu
      ) {
        setIsMobileUserMenuOpen(false);
        setIsDesktopUserMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <nav className="px-4 sm:px-6 lg:px-8 py-4 sm:py-5 lg:py-6 sticky top-0 z-[100] glass border-b border-black/5 dark:border-white/5">
      <div className="max-w-[1800px] mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Top Row */}
        <div className="flex items-center justify-between w-full md:w-auto">
          <Link to="/" className="flex items-center">
            <img src={logo} alt="FomoCreator" className="h-xxl max-h-100 w-auto object-contain" />
          </Link>

          {/* Right Section (Mobile aligned) */}
          <div className="flex items-center gap-3 md:hidden">
            <ThemeButton theme={theme} onToggleTheme={onToggleTheme} />
            <AuthSection
              user={user}
              isAuthenticated={isAuthenticated}
              logout={logout}
              isUserMenuOpen={isMobileUserMenuOpen}
              setIsUserMenuOpen={setIsMobileUserMenuOpen}
              userMenuRef={mobileUserMenuRef}
              closeOtherMenu={() => setIsDesktopUserMenuOpen(false)}
            />
          </div>
        </div>

        {/* Navigation (Always Visible) */}
        <div className="flex flex-wrap items-center gap-4 text-[10px] font-bold uppercase tracking-widest text-slate-600 dark:text-slate-400">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* Desktop Right Section */}
        <div className="hidden md:flex items-center gap-3">
          <ThemeButton theme={theme} onToggleTheme={onToggleTheme} />
          <AuthSection
            user={user}
            isAuthenticated={isAuthenticated}
            logout={logout}
            isUserMenuOpen={isDesktopUserMenuOpen}
            setIsUserMenuOpen={setIsDesktopUserMenuOpen}
            userMenuRef={desktopUserMenuRef}
            closeOtherMenu={() => setIsMobileUserMenuOpen(false)}
          />
        </div>
      </div>
    </nav>
  );
};

export default Header;

/* ---------------- Components ---------------- */

const ThemeButton = ({ theme, onToggleTheme }: any) => (
  <button
    onClick={onToggleTheme}
    className="w-9 h-9 rounded-full flex items-center justify-center glass hover:bg-white dark:hover:bg-white/10 transition-all shadow-sm"
  >
    {theme === "light" ? (
      <svg
        className="w-4 text-slate-500"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"
        />
      </svg>
    ) : (
      <svg
        className="w-4 text-indigo-400"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M12 3v1m0 16v1m9-9h1M4 12H3m16.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
        />
      </svg>
    )}
  </button>
);

const AuthSection = ({
  user,
  isAuthenticated,
  logout,
  isUserMenuOpen,
  setIsUserMenuOpen,
  userMenuRef,
  closeOtherMenu,
}: any) => {
  if (isAuthenticated && user) {
    return (
      <div className="relative" ref={userMenuRef}>
        <button
          onClick={() => {
            closeOtherMenu?.();
            setIsUserMenuOpen(!isUserMenuOpen);
          }}
          className="w-9 h-9 rounded-full flex items-center justify-center bg-indigo-600 text-white font-bold text-sm hover:bg-indigo-700 transition-all shadow-sm"
        >
          {user.fullName
            ? user.fullName.charAt(0).toUpperCase()
            : user.email.charAt(0).toUpperCase()}
        </button>

        {isUserMenuOpen && (
          <div className="absolute right-0 mt-2 w-56 rounded-xl glass border border-slate-200 dark:border-white/10 shadow-xl py-2 z-50">
            <div className="px-4 py-3 border-b border-slate-200 dark:border-white/10">
              <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                {user.fullName}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {user.email}
              </p>
            </div>
            <button
              onClick={logout}
              className="w-full px-4 py-2 text-left text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors"
            >
              Log Out
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <Link
        to="/login"
        className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold uppercase tracking-widest transition-all shadow-sm"
      >
        Log In
      </Link>
      <Link
        to="/signup"
        className="px-3 py-2 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-[10px] font-bold uppercase tracking-widest transition-all shadow-sm border border-slate-200 dark:border-white/10"
      >
        Sign Up
      </Link>
    </div>
  );
};
