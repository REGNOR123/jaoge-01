import React from "react";

const ProgressPill = ({
  label,
  percent,
}: {
  label: string;
  percent: number;
}) => {
  const pct = Math.max(0, Math.min(100, Math.round(percent)));

  return (
    <div className="w-full px-4 py-3 rounded-xl bg-white/80 dark:bg-white/10 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center gap-3">
      <div className="w-4 h-4 border-2 border-slate-300 dark:border-white/20 border-t-indigo-600 rounded-full animate-spin" />
      <span>
        {label} {pct}%
      </span>
    </div>
  );
};

export default ProgressPill;

