import React from "react";

export type WizardStepNavItem = {
  id: number;
  label: string;
  isActive: boolean;
  isComplete: boolean;
  isDisabled?: boolean;
  onClick?: () => void;
};

const BASE_CLASSES = [
  "rounded-full",
  "px-5",
  "py-2",
  "text-[11px]",
  "font-black",
  "uppercase",
  "tracking-widest",
  "transition-colors",
  "border",
  "shadow-sm",
  "flex",
  "items-center",
  "justify-center",
  "gap-1",
].join(" ");

const WizardStepNav = ({ items }: { items: WizardStepNavItem[] }) => (
  <nav className="flex items-center gap-3 overflow-x-auto">
    {items.map((item, index) => {
      const classes = [
        BASE_CLASSES,
        item.isActive
          ? "bg-indigo-600 text-white border-indigo-600 shadow-lg"
          : item.isComplete
            ? "bg-white text-indigo-700 border-indigo-200 hover:bg-indigo-50"
            : "bg-white/80 text-slate-600 border-slate-200 dark:bg-white/5 dark:border-white/10 dark:text-slate-300 hover:bg-white",
        item.isDisabled ? "opacity-60 cursor-not-allowed" : "cursor-pointer",
      ].join(" ").trim();
      return (
        <React.Fragment key={item.id}>
          <button
            type="button"
            className={classes}
            onClick={item.isDisabled ? undefined : item.onClick}
            disabled={item.isDisabled}
          >
            {item.isComplete ? "✓ " : ""}
            {item.id} {item.label}
          </button>
          {index < items.length - 1 && (
            <div className="text-slate-400 dark:text-slate-500 font-black text-sm select-none">→</div>
          )}
        </React.Fragment>
      );
    })}
  </nav>
);

export default WizardStepNav;
