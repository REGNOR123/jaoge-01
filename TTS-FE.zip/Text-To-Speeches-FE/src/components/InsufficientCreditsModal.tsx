import React, { useEffect } from 'react';

type InsufficientCreditsModalProps = {
  isOpen: boolean;
  onClose: () => void;
  requiredCredits: number;
  currentBalance: number;
};

const InsufficientCreditsModal: React.FC<InsufficientCreditsModalProps> = ({
  isOpen,
  onClose,
  requiredCredits,
  currentBalance,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const deficit = requiredCredits - currentBalance;

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xl animate-in fade-in duration-300"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="glass studio-card w-full max-w-md scale-in-center !p-10">
        <div className="text-center space-y-4">
          <div className="text-4xl">⚡</div>
          <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100">
            Not enough credits
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            This action requires{' '}
            <span className="font-bold text-indigo-600 dark:text-indigo-400">
              {requiredCredits} credits
            </span>
            {', '}but you only have{' '}
            <span className="font-bold text-slate-700 dark:text-slate-300">
              {currentBalance} credits
            </span>
            . You need{' '}
            <span className="font-bold text-red-500">{deficit} more</span>.
          </p>

          <div className="pt-2">
            <button
              onClick={onClose}
              className="mt-2 text-sm font-semibold text-slate-500 dark:text-slate-400 underline underline-offset-4 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InsufficientCreditsModal;
