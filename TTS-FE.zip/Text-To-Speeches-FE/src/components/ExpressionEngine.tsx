
import React from 'react';
import { SpeechStyle } from '../types';
import { AVAILABLE_STYLES } from '../constants';

interface ExpressionEngineProps {
  isOpen: boolean;
  onToggle: () => void;
  style: SpeechStyle;
  degree: number;
  onStyleChange: (style: SpeechStyle) => void;
  onDegreeChange: (degree: number) => void;
}

const ExpressionEngine: React.FC<ExpressionEngineProps> = ({
  isOpen, onToggle, style, degree, onStyleChange, onDegreeChange
}) => {
  return (
    <div className="rounded-4xl border border-indigo-600/10 bg-indigo-600/5 overflow-hidden transition-all duration-300">
      <button 
        onClick={onToggle}
        className="w-full px-8 py-6 flex items-center justify-between hover:bg-indigo-600/5 transition-colors"
      >
        <div className="flex items-center gap-4">
          <div className="w-1.5 h-1.5 rounded-full bg-indigo-600"></div>
          <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-indigo-600">Expression Engine</h3>
        </div>
        <svg className={`w-4 h-4 text-indigo-400 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" /></svg>
      </button>

      {isOpen && (
        <div className="px-8 pb-10 pt-2 animate-in slide-in-from-top-2 duration-300 space-y-10">
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {AVAILABLE_STYLES.map((s) => (
              <button
                key={s.id}
                onClick={() => onStyleChange(s.id)}
                className={`flex flex-col items-center justify-center p-4 rounded-2xl border transition-all ${style === s.id ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-white dark:bg-white/5 border-slate-200 dark:border-white/10 text-slate-400 hover:border-indigo-300'}`}
              >
                <span className="text-xl mb-2">{s.icon}</span>
                <span className="text-[8px] font-black uppercase tracking-widest">{s.label}</span>
              </button>
            ))}
          </div>

          <div className="space-y-4 max-w-md mx-auto">
            <div className="flex justify-between text-[10px] font-black text-indigo-600 uppercase">
              <span>Emotional Intensity</span>
              <span>{degree.toFixed(2)}</span>
            </div>
            <input type="range" min="0.01" max="2.0" step="0.01" value={degree} onChange={(e) => onDegreeChange(parseFloat(e.target.value))} className="w-full" />
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpressionEngine;
