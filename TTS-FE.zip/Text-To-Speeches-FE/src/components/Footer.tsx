import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="mt-20 border-t border-black/5 dark:border-white/5 py-12 px-8">
      <div className="max-w-[1800px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
        
        {/* Logo */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#18A84A] flex items-center justify-center text-white shadow-sm shadow-emerald-500/20">
            <span className="text-lg font-black leading-none">F</span>
          </div>
          <span className="text-base font-black tracking-tight leading-none">
            <span className="text-slate-900 dark:text-white">Fomo</span><span className="text-slate-900 dark:text-white">Creator</span>
          </span>
        </div>

        {/* Links */}
        <div className="flex items-center gap-6 text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-slate-600">
          <Link to="/privacy" className="hover:text-indigo-500 transition-colors">
            Privacy
          </Link>
          <Link to="/terms" className="hover:text-indigo-500 transition-colors">
            Terms
          </Link>
          <Link to="/docs" className="hover:text-indigo-500 transition-colors">
            Docs
          </Link>
          <Link to="/help" className="hover:text-indigo-500 transition-colors">
            Help
          </Link>
        </div>

        {/* Copyright */}
        <p className="text-[11px] font-medium text-slate-400 dark:text-slate-600 text-center sm:text-right">
          © {new Date().getFullYear()} FomoCreator.com. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
