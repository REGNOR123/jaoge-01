import React from "react";

const TranslationSkeleton = () => (
  <div className="space-y-3 animate-pulse">
    <div className="h-4 w-24 bg-slate-200 dark:bg-white/10 rounded-lg" />
    <div className="rounded-2xl bg-slate-100/60 dark:bg-white/5 border border-slate-200 dark:border-white/10 p-4 space-y-3">
      <div className="h-3 w-full bg-slate-200 dark:bg-white/10 rounded" />
      <div className="h-3 w-5/6 bg-slate-200 dark:bg-white/10 rounded" />
      <div className="h-3 w-4/6 bg-slate-200 dark:bg-white/10 rounded" />
      <div className="h-3 w-full bg-slate-200 dark:bg-white/10 rounded" />
      <div className="h-3 w-3/4 bg-slate-200 dark:bg-white/10 rounded" />
    </div>
  </div>
);

export default TranslationSkeleton;
