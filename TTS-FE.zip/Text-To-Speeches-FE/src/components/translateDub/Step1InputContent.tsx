import React, { useEffect, useState } from "react";
import StepCard from "../StepCard";
import TabButton from "../TabButton";
import { TARGET_LANGUAGES } from "../../data/languages";
import { formatDuration } from "../../utils/format";
import ProgressPill from "../ProgressPill";
import {
  ACCEPTED_AUDIO_TYPES,
  SAMPLE_TEXT,
  type Mode,
} from "./constants";
import type { useTranslateDubState } from "./useTranslateDubState";

// Must match REGIONAL_LANG_CODES in useTranslateDubState
const REGIONAL_CODES = new Set([
  "hi","ta","te","ml","bn","mr","gu","kn","pa","ur","or","as",
  "ms","id","fil","jv","my","km","lo","vi","th",
]);

type Props = {
  state: ReturnType<typeof useTranslateDubState>;
};

const Step1InputContent: React.FC<Props> = ({ state }) => {
  const {
    mode,
    setMode,
    computeProgressForMode,
    textSourceText,
    setTextSourceText,
    audioFile,
    setAudioFile,
    audioUrl,
    audioDurationSeconds,
    setAudioDurationSeconds,
    audioTranscriptText,
    setAudioTranscriptText,
    dragOver,
    setDragOver,
    fileInputRef,
    textFileInputRef,
    handleDrop,
    handleTextFileUpload,
    recorder,
    inputFileRecord,
    setInputFileRecord,
    outputFileRecord,
    setOutputFileRecord,
    error,
    setError,
    currentStep,
    maxStepUnlocked,
    setMaxStepUnlocked,
    setCurrentStep,
    step1Summary,
    activeProjectId,
    setIsDirty,
    isStep1Valid,

    // Translation config
    selectedLanguages,
    setSelectedLanguages,
    sourceLanguageName,
    sourceLanguageCode,
    sourceLanguageOverride,
    setSourceLanguageOverride,

    // Regional language support (from hook)
    isRegionalOnly,
    setIsRegionalOnly,
    isSourceRegional,
    isTargetRegional,
    translateIsRegional,
    estimatedTranslationCredits,
    estimatedTtsCredits,

    // Translation progress
    translateInProgress,
    translatePercent,
    translateLabel,
  } = state;

  const selectedLanguage = selectedLanguages[0] || "";

  const [regionalDismissed, setRegionalDismissed] = useState(false);
  const triggerKey = `${isRegionalOnly}-${isTargetRegional}-${isSourceRegional}`;
  useEffect(() => { setRegionalDismissed(false); }, [triggerKey]);

  // Filter languages when "Display regional languages" checkbox is active
  const displayLanguages = isRegionalOnly
    ? TARGET_LANGUAGES.filter((l) => REGIONAL_CODES.has(l.code))
    : TARGET_LANGUAGES;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <StepCard
        step={1}
        title="Input & Configure"
        description="Provide your content and choose a target language. We'll transcribe audio automatically."
        isActive={true}
        isCompleted={maxStepUnlocked >= 2}
        summary={step1Summary}
      >
        <div className="space-y-6">
          {/* Mode tabs */}
          <div className="flex items-center justify-between gap-3">
            <div role="tablist" className="flex items-center gap-2">
              <TabButton
                active={mode === "text"}
                onClick={() => {
                  if (mode === "text") return;
                  setMode("text");
                  setError(null);
                  setInputFileRecord(null);
                  setOutputFileRecord(null);
                  const { maxUnlocked, nextStep } = computeProgressForMode("text");
                  setMaxStepUnlocked(maxUnlocked);
                  setCurrentStep(nextStep);
                }}
              >
                Paste Text
              </TabButton>
            </div>

            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              {mode === "text"
                ? `${textSourceText.length} chars`
                : audioDurationSeconds != null
                  ? formatDuration(audioDurationSeconds)
                  : audioFile
                    ? "File selected"
                    : "-"}
            </div>
          </div>

          {/* Content area */}
          <div role="tabpanel">
            {mode === "text" ? (
              <div className="space-y-3">
                <label
                  htmlFor="td-text-input"
                  className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400"
                >
                  Paste your text
                </label>
                <textarea
                  id="td-text-input"
                  value={textSourceText}
                  onChange={(e) => {
                    const next = e.target.value;
                    setTextSourceText(next);
                    setInputFileRecord(null);
                    setOutputFileRecord(null);
                    setIsDirty(true);
                    if (maxStepUnlocked >= 2) {
                      setMaxStepUnlocked(1);
                      setCurrentStep(1);
                    }
                  }}
                  placeholder="Paste a paragraph, speech transcript, or article to translate..."
                  className="w-full min-h-[200px] p-4 rounded-2xl bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white resize-none font-medium text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                />
                <div className="flex items-center justify-between gap-3">
                  <div className="text-xs text-slate-500 dark:text-slate-400 font-semibold">
                    {textSourceText.length} characters
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => textFileInputRef.current?.click()}
                      className="text-xs font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 transition-colors"
                    >
                      Upload .txt / .srt
                    </button>
                    <input
                      ref={textFileInputRef}
                      type="file"
                      accept=".txt,.srt,text/plain"
                      className="hidden"
                      onChange={handleTextFileUpload}
                    />
                    {!textSourceText.trim() && (
                      <button
                        type="button"
                        onClick={() => { setTextSourceText(SAMPLE_TEXT); setIsDirty(true); }}
                        className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                      >
                        Try Sample
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                  Upload audio file
                </label>
                <div
                  className={[
                    "rounded-3xl border-2 border-dashed p-8 transition-colors cursor-pointer min-h-[200px] flex items-center",
                    dragOver
                      ? "border-indigo-500/60 bg-indigo-500/5 animate-pulse"
                      : "border-slate-200 dark:border-white/10 bg-white/40 dark:bg-white/5",
                  ].join(" ")}
                  onClick={() => fileInputRef.current?.click()}
                  onDragEnter={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={(e) => { e.preventDefault(); setDragOver(false); }}
                  onDrop={handleDrop}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept={ACCEPTED_AUDIO_TYPES}
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0] || null;
                      setAudioFile(f);
                      setInputFileRecord(null);
                      setOutputFileRecord(null);
                      setAudioTranscriptText("");
                      setMaxStepUnlocked(1);
                      setCurrentStep(1);
                      setError(null);
                      setIsDirty(true);
                    }}
                  />
                  <div className="flex items-center gap-4 w-full">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-600/10 text-indigo-700 dark:text-indigo-300 flex items-center justify-center border border-indigo-500/15 flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                      </svg>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-black text-slate-900 dark:text-white">Drag & drop to upload</div>
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-medium truncate">
                        {audioFile ? `Selected: ${audioFile.name}` : "WAV, MP3, OGG, M4A, FLAC, or WebM"}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Microphone recording */}
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={async () => {
                      if (recorder.isRecording) {
                        const file = await recorder.stop();
                        if (file) { setAudioFile(file); setIsDirty(true); }
                      } else {
                        await recorder.start();
                      }
                    }}
                    className={[
                      "px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-colors inline-flex items-center gap-2",
                      recorder.isRecording
                        ? "bg-red-600 text-white hover:bg-red-700"
                        : "bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white border border-slate-200 dark:border-white/10",
                    ].join(" ")}
                  >
                    {recorder.isRecording ? (
                      <><span className="w-2 h-2 rounded-full bg-white animate-pulse" />Stop Recording</>
                    ) : (
                      <><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>Record</>
                    )}
                  </button>
                  {recorder.error && (
                    <span className="text-xs font-semibold text-red-600 dark:text-red-400">{recorder.error}</span>
                  )}
                </div>

                {(audioDurationSeconds != null || audioTranscriptText.trim()) && (
                  <div className="text-xs text-slate-600 dark:text-slate-300 font-semibold">
                    {audioDurationSeconds != null ? `Duration: ${formatDuration(audioDurationSeconds)}` : null}
                    {audioDurationSeconds != null && audioTranscriptText.trim() ? " " : null}
                    {audioTranscriptText.trim() ? `Transcript: ${audioTranscriptText.length} chars` : null}
                  </div>
                )}

                {!audioFile && !recorder.isRecording && (
                  <div className="rounded-2xl border border-slate-200/50 dark:border-white/10 bg-slate-50/50 dark:bg-white/5 p-4">
                    <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                      For best results, use clear audio with minimal background noise.
                    </p>
                  </div>
                )}

                {audioFile && audioUrl && (
                  <div className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/40 dark:bg-white/5 p-4 space-y-3">
                    <div className="flex items-center justify-between gap-3 text-xs font-semibold text-slate-700 dark:text-slate-200">
                      <div className="truncate">
                        {audioFile.name}
                        {audioDurationSeconds != null && ` • ${formatDuration(audioDurationSeconds)}`}
                      </div>
                    </div>
                    <div className="rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800">
                      <audio controls src={audioUrl} className="w-full" />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Target language + source language section */}
          <div className="border-t border-slate-200/50 dark:border-white/10 pt-6 space-y-4">

            {/* Target language selector with Display regional languages checkbox */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label
                  htmlFor="td-target-lang"
                  className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400"
                >
                  Target language
                </label>
                <label className="inline-flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={isRegionalOnly}
                    onChange={(e) => {
                      const next = e.target.checked;
                      setIsRegionalOnly(next);
                      if (next && selectedLanguage && !REGIONAL_CODES.has(selectedLanguage)) {
                        setSelectedLanguages([]);
                      }
                    }}
                    className="h-3.5 w-3.5 accent-amber-500 flex-shrink-0"
                  />
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                    Display regional languages
                  </span>
                </label>
              </div>
              <select
                id="td-target-lang"
                value={selectedLanguage}
                onChange={(e) => {
                  setSelectedLanguages([e.target.value]);
                  setIsDirty(true);
                }}
                className="w-full px-3 py-3 rounded-xl bg-slate-100/70 dark:bg-slate-800 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
              >
                <option value="" disabled>Select target language</option>
                {displayLanguages.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.name}{REGIONAL_CODES.has(l.code) ? " (2×)" : ""}
                  </option>
                ))}
              </select>
              {isRegionalOnly && (
                <p className="mt-1.5 text-[10px] font-semibold text-amber-600 dark:text-amber-400">
                  Showing Indian & Southeast Asian languages only
                </p>
              )}
            </div>

            {/* Source language display + override */}
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1">
                  Source language
                </div>
                <div className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                  {sourceLanguageOverride
                    ? TARGET_LANGUAGES.find((l) => l.code === sourceLanguageOverride)?.name || sourceLanguageOverride
                    : sourceLanguageName || "—"}
                  {(sourceLanguageOverride || sourceLanguageCode) && (
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold">
                      ({sourceLanguageOverride || sourceLanguageCode})
                    </span>
                  )}
                  {isSourceRegional && (
                    <span className="px-1.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 text-[9px] font-black uppercase tracking-wider">
                      Regional
                    </span>
                  )}
                </div>
              </div>
              <div>
                <select
                  value={sourceLanguageOverride || ""}
                  onChange={(e) => setSourceLanguageOverride(e.target.value || null)}
                  className="px-2 py-1.5 rounded-lg bg-slate-100/70 dark:bg-slate-800 border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-300 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                >
                  <option value="">Auto-detect</option>
                  {TARGET_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code}>{l.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Regional credit warning banner */}
            {(isRegionalOnly || isTargetRegional || isSourceRegional) && !regionalDismissed && (
              <div className="relative rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-start gap-3">
                <svg className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                </svg>
                <div className="space-y-1 flex-1">
                  <p className="text-sm font-black text-amber-900 dark:text-amber-200">
                    {isSourceRegional && isTargetRegional
                      ? "Regional → Regional — 2× charges apply for both translation and voice"
                      : isSourceRegional
                        ? "Regional source detected — 2× translation charges apply"
                        : "Regional target language — 2× voice synthesis charges apply"}
                  </p>
                  <p className="text-xs font-medium text-amber-800 dark:text-amber-300/80">
                    {translateIsRegional
                      ? <>Translation: <span className="font-black">6 credits / 1,000 chars</span> (2× standard)</>
                      : <>Translation: <span className="font-black">3 credits / 1,000 chars</span> (standard)</>}
                    {isTargetRegional && (
                      <> · Voice synthesis: <span className="font-black">2 credits / 100 chars</span> (2× standard)</>
                    )}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setRegionalDismissed(true)}
                  className="absolute top-2 right-2 p-1 rounded-md text-amber-600 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-200 hover:bg-amber-500/15 transition-colors"
                  aria-label="Dismiss"
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            )}

            {/* Live credit cost estimate */}
            {(textSourceText.length > 10 || audioTranscriptText.length > 10) && (
              <div className="rounded-2xl border border-slate-200/60 dark:border-white/8 bg-slate-50/60 dark:bg-white/5 px-4 py-3 flex items-center justify-between gap-4 flex-wrap">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                  Estimated cost
                </span>
                <div className="flex items-center gap-3 text-xs font-semibold text-slate-700 dark:text-slate-200 flex-wrap">
                  <span>
                    Translation{" "}
                    <span className={["font-black", translateIsRegional ? "text-amber-600 dark:text-amber-400" : ""].join(" ")}>
                      ~{estimatedTranslationCredits} cr
                    </span>
                  </span>
                  <span className="text-slate-300 dark:text-slate-600">+</span>
                  <span>
                    TTS{" "}
                    <span className={["font-black", isTargetRegional ? "text-amber-600 dark:text-amber-400" : ""].join(" ")}>
                      ~{estimatedTtsCredits} cr
                    </span>
                  </span>
                  <span className="text-slate-300 dark:text-slate-600">=</span>
                  <span className="font-black text-slate-900 dark:text-white">
                    ~{estimatedTranslationCredits + estimatedTtsCredits} credits total
                  </span>
                </div>
              </div>
            )}

          </div>

          {/* Translation progress */}
          {translateInProgress && (
            <div>
              <ProgressPill label={translateLabel} percent={translatePercent} />
            </div>
          )}
        </div>
      </StepCard>
    </div>
  );
};

export default Step1InputContent;
