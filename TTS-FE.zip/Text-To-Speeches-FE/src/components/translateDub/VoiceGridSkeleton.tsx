import React from "react";

const VoiceGridSkeleton = () => (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-pulse">
    {Array.from({ length: 6 }).map((_, i) => (
      <div
        key={i}
        className="rounded-3xl border border-slate-200 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-5 space-y-3"
      >
        <div className="flex items-center justify-between">
          <div className="h-4 w-28 bg-slate-200 dark:bg-white/10 rounded" />
          <div className="h-10 w-10 bg-slate-200 dark:bg-white/10 rounded-2xl" />
        </div>
        <div className="h-3 w-16 bg-slate-200 dark:bg-white/10 rounded" />
        <div className="h-3 w-full bg-slate-200 dark:bg-white/10 rounded" />
      </div>
    ))}
  </div>
);

export default VoiceGridSkeleton;
