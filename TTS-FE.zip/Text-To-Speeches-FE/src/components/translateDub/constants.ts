export const RETENTION_MESSAGE = "Files are auto-deleted after 24 hours.";
export const TRANSLATE_DUB_INPUT_SOURCE = "Translate Dub Input";
export const TRANSLATE_DUB_TRANSCRIPT_SOURCE = "Translate Dub Transcript";
export const TRANSLATE_DUB_TRANSLATION_SOURCE = "Translate Dub Translation";

export const isTranslateDubAudioEntry = (settings: any) =>
  settings?.feature === "translate-dub";

export type Mode = "text" | "audio";
export type StepType = 1 | 2 | 3;

export const ACCEPTED_AUDIO_TYPES =
  ".wav,.mp3,.ogg,.webm,.m4a,.flac,audio/*";

export const SAMPLE_TEXT =
  "Welcome to the Translate and Dub studio. Paste any text here — an article, a speech transcript, or a product description — and we will translate it into your chosen language, then generate a natural-sounding voiceover you can download instantly.";
