import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { AVAILABLE_VOICES } from "../../constants";
import { useAuth } from "../../contexts/AuthContext";
import { useWizardProgress } from "../../hooks/useWizardProgress";

// Regional language codes used for credit-tier detection (matches backend VoiceResolver.RegionalLangCodes)
const REGIONAL_LANG_CODES = new Set([
  "hi","ta","te","ml","bn","mr","gu","kn","pa","ur","or","as",   // Indian
  "ms","id","fil","jv","my","km","lo","vi","th",                  // SE Asian
]);
import { useCredits } from "../../contexts/CreditContext";
import { generateAzureSpeech } from "../../services/azureService";
import {
  deleteManagedFile,
  downloadManagedFile,
  uploadManagedFile,
  uploadManagedTextFile,
  type StoredFileRecord,
} from "../../services/filesApiService";
import {
  detectTextLanguage,
  detectTextLanguageCode,
  translateText,
} from "../../services/langService";
import { transcribeAudioFile } from "../../services/transcribeService";
import { VoiceName, type VoiceOption } from "../../types";
import { estimateVoiceMinutes, getPreviewTextForVoice } from "../createVoice/utils";
import { useDialog } from "../dialogs";
import {
  createProject,
  getProjectById,
  listProjects,
  updateProject,
} from "../../utils/projectsStorage";
import { formatDuration } from "../../utils/format";
import { TARGET_LANGUAGES } from "../../data/languages";
import {
  type Mode,
  type StepType,
  TRANSLATE_DUB_INPUT_SOURCE,
  TRANSLATE_DUB_TRANSCRIPT_SOURCE,
  TRANSLATE_DUB_TRANSLATION_SOURCE,
  isTranslateDubAudioEntry,
} from "./constants";
import { useAudioRecorder } from "../speechTranslate/useAudioRecorder";

export function useTranslateDubState() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const projectIdFromQuery = searchParams.get("projectId") || "";
  const { isAuthenticated, token } = useAuth();
  const { refreshBalance } = useCredits();
  const isGuest = !isAuthenticated;
  const dialog = useDialog();
  const [authRequiredOpen, setAuthRequiredOpen] = useState(false);
  const [insufficientCreditsInfo, setInsuffCreditsInfo] = useState<{ required: number; current: number } | null>(null);
  const [workflowId] = useState(() => crypto.randomUUID());

  // Step tracking — 3-step flow
  const [currentStep, setCurrentStep] = useState<StepType>(1);
  const [maxStepUnlocked, setMaxStepUnlocked] = useState<StepType>(1);

  // Input state
  const [mode, setMode] = useState<Mode>("text");
  const [textSourceText, setTextSourceText] = useState("");
  const [audioTranscriptText, setAudioTranscriptText] = useState("");
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioDurationSeconds, setAudioDurationSeconds] = useState<
    number | null
  >(null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const textFileInputRef = useRef<HTMLInputElement | null>(null);
  const [inputFileRecord, setInputFileRecord] =
    useState<StoredFileRecord | null>(null);

  // Microphone recording (B2)
  const recorder = useAudioRecorder();

  // Translation state
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);
  const [sourceLanguageName, setSourceLanguageName] = useState<string | null>(
    null,
  );
  const [sourceLanguageCode, setSourceLanguageCode] = useState<string | null>(
    null,
  );
  const [sourceLanguageOverride, setSourceLanguageOverride] = useState<
    string | null
  >(null);
  const [textTranslatedText, setTextTranslatedText] = useState("");
  const [audioTranslatedText, setAudioTranslatedText] = useState("");
  const [textEditedTranslation, setTextEditedTranslation] = useState("");
  const [audioEditedTranslation, setAudioEditedTranslation] = useState("");
  const [showOriginalText, setShowOriginalText] = useState(false);

  // Multi-language translations (B1)
  const [translationsMap, setTranslationsMap] = useState<
    Record<string, string>
  >({});
  const [editedTranslationsMap, setEditedTranslationsMap] = useState<
    Record<string, string>
  >({});
  const [activeTranslationLang, setActiveTranslationLang] = useState("es");

  // Voice state
  const [selectedVoice, setSelectedVoice] = useState<VoiceName>(
    VoiceName.JENNY,
  );
  const [rate, setRate] = useState(0);
  const [pitch, setPitch] = useState(0);
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [outputFormat, setOutputFormat] = useState<"wav" | "mp3">("wav");

  // Preview state
  const [previewLoadingId, setPreviewLoadingId] = useState<VoiceName | null>(
    null,
  );
  const [previewPlayingId, setPreviewPlayingId] = useState<VoiceName | null>(
    null,
  );
  const previewRef = useRef<HTMLAudioElement | null>(null);
  const previewCacheRef = useRef<Map<string, string>>(new Map());

  // Regional language toggle (filter target languages dropdown to regional only)
  const [isRegionalOnly, setIsRegionalOnly] = useState(false);

  // Processing state
  const [isTranslating, setIsTranslating] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [outputUrl, setOutputUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [outputFileRecord, setOutputFileRecord] =
    useState<StoredFileRecord | null>(null);
  const [fileActionKey, setFileActionKey] = useState<string | null>(null);
  const generateProgress = useWizardProgress({ ceiling: 95 });
  const generatePercent = generateProgress.percent;
  const startGenerateProgress = generateProgress.start;
  const stopGenerateProgress = generateProgress.stop;

  // Project state
  const [activeProjectId, setActiveProjectId] = useState(projectIdFromQuery);
  const [textProjectName, setTextProjectName] = useState("");
  const [audioProjectName, setAudioProjectName] = useState("");

  const projectName = mode === "text" ? textProjectName : audioProjectName;
  const setProjectName = (value: string) => {
    if (mode === "text") setTextProjectName(value);
    else setAudioProjectName(value);
  };

  const originalText =
    mode === "text" ? textSourceText : audioTranscriptText;
  const translatedText =
    mode === "text" ? textTranslatedText : audioTranslatedText;
  const editedTranslation =
    mode === "text" ? textEditedTranslation : audioEditedTranslation;
  const setEditedTranslation = (value: string) => {
    if (mode === "text") setTextEditedTranslation(value);
    else setAudioEditedTranslation(value);
  };

  // Usage state
  const [projectModalPurpose, setProjectModalPurpose] = useState<
    "draft" | "project" | null
  >(null);
  const [pendingProjectName, setPendingProjectName] = useState("");
  const [projectModalError, setProjectModalError] = useState<string | null>(
    null,
  );
  const [projectModalStatus, setProjectModalStatus] = useState<
    "idle" | "saved"
  >("idle");

  // Progress tracking
  const translateProgress = useWizardProgress({
    interval: 180,
    maxBump: 10,
    baseBump: 5,
  });
  const translateInProgress = translateProgress.inProgress;
  const translatePercent = translateProgress.percent;
  const [translateLabel, setTranslateLabel] = useState<
    "Transcribing" | "Translating"
  >("Translating");
  const textDetectSeqRef = useRef(0);

  const saveDraftProgress = useWizardProgress({ ceiling: 95 });
  const saveDraftInProgress = saveDraftProgress.inProgress;
  const saveDraftPercent = saveDraftProgress.percent;

  const saveProjectProgress = useWizardProgress({ ceiling: 95 });
  const saveProjectInProgress = saveProjectProgress.inProgress;
  const saveProjectPercent = saveProjectProgress.percent;
  const [uploadPercent, setUploadPercent] = useState(0);

  // Auto-save (C13)
  const [isDirty, setIsDirty] = useState(false);
  const [lastAutoSave, setLastAutoSave] = useState<string | null>(null);

  // Translation edit history (C14)
  const [editHistory, setEditHistory] = useState<string[]>([]);
  const [editHistoryIndex, setEditHistoryIndex] = useState(-1);
  const [originalTranslation, setOriginalTranslation] = useState("");

  // Generation phase labels (B10)
  const [generatePhase, setGeneratePhase] = useState<string>("");

  // ---------- Derived values ----------

  const estimatedMinutes = useMemo(() => {
    return estimateVoiceMinutes(editedTranslation || translatedText);
  }, [translatedText, editedTranslation]);

  const inputMinutes = useMemo(() => {
    if (
      mode !== "audio" ||
      audioDurationSeconds == null ||
      !Number.isFinite(audioDurationSeconds)
    )
      return null;
    return audioDurationSeconds / 60;
  }, [audioDurationSeconds, mode]);

  const voicesForTarget = useMemo<VoiceOption[]>(() => {
    const primary = selectedLanguages[0] || "es";
    return AVAILABLE_VOICES.filter((v) =>
      String(v.id).startsWith(`${primary}-`),
    );
  }, [selectedLanguages]);

  // Regional detection — mirrors backend VoiceResolver logic
  const isSourceRegional = useMemo(() => {
    const code = (sourceLanguageOverride || sourceLanguageCode || "").split("-")[0].toLowerCase();
    return !!code && REGIONAL_LANG_CODES.has(code);
  }, [sourceLanguageCode, sourceLanguageOverride]);

  const isTargetRegional = useMemo(
    () => voicesForTarget[0]?.region === "Indian" || voicesForTarget[0]?.region === "SE Asian",
    [voicesForTarget],
  );

  const translateIsRegional = isSourceRegional || isTargetRegional;

  // Live credit cost estimates (based on source text length before translation)
  const estimatedCharCount = mode === "text" ? textSourceText.length : audioTranscriptText.length;
  const estimatedTranslationCredits = Math.max(1, Math.ceil(estimatedCharCount / 1000 * (translateIsRegional ? 6 : 3)));
  const estimatedTtsCredits = Math.max(1, Math.ceil(estimatedCharCount / 100 * (isTargetRegional ? 2 : 1)));

  const wordCount = useMemo(() => {
    const s = (editedTranslation || "").trim();
    if (!s) return 0;
    return s.split(/\s+/).filter(Boolean).length;
  }, [editedTranslation]);

  const selectedLanguage = selectedLanguages[0] || "";

  // ---------- Helper functions ----------

  const stopTranslateProgress = () => {
    translateProgress.stop();
    setTranslateLabel("Translating");
  };

  const startTranslateProgress = (label: "Transcribing" | "Translating") => {
    setTranslateLabel(label);
    translateProgress.start();
  };

  const finishTranslateProgress = async () => {
    await translateProgress.finish();
    setTranslateLabel("Translating");
  };

  const startSaveDraftProgress = saveDraftProgress.start;
  const stopSaveDraftProgress = saveDraftProgress.stop;
  const finishSaveDraftProgress = saveDraftProgress.finish;

  const startSaveProjectProgress = saveProjectProgress.start;
  const stopSaveProjectProgress = saveProjectProgress.stop;
  const finishSaveProjectProgress = saveProjectProgress.finish;

  const applyProtectedError = (message: string, status?: number) => {
    setError(message);
    if (status === 401 || status === 403) setAuthRequiredOpen(true);
  };

  const requireProtectedAccess = () => {
    if (isAuthenticated && token) return true;
    setError(
      "Please login before storing files or generating translated dubs.",
    );
    setAuthRequiredOpen(true);
    return false;
  };

  const normalizeProjectName = (value: string) =>
    value.trim().replace(/\s+/g, " ").toLowerCase();

  const validateNewProjectName = (
    value: string,
    excludeId?: string,
  ): string | null => {
    const collapsed = value.trim().replace(/\s+/g, " ");
    if (collapsed.length <= 3)
      return "Project name must be at least 4 characters.";
    const normalized = normalizeProjectName(collapsed);
    const exclude = excludeId ?? activeProjectId;
    const isDuplicate = listProjects().some(
      (p) => normalizeProjectName(p.name) === normalized && p.id !== exclude,
    );
    if (isDuplicate) return "Project name must be unique.";
    return null;
  };

  const projectNameError = useMemo(() => {
    const candidate = projectName.trim();
    if (!candidate) return null;
    return validateNewProjectName(candidate, activeProjectId);
  }, [projectName, activeProjectId]);

  const getDefaultProjectName = () => {
    if (projectName.trim()) return projectName.trim();
    return mode === "text" ? "Text Translate Dub" : "Audio Translate Dub";
  };

  const ensureProject = (overrideName?: string): string | null => {
    if (activeProjectId) return activeProjectId;
    let rawName = overrideName ?? projectName;
    let name = rawName.trim().replace(/\s+/g, " ");
    if (!name) name = getDefaultProjectName();

    let err = validateNewProjectName(name, activeProjectId);
    if (err) {
      const timestamp = new Date()
        .toLocaleString("en-US", {
          month: "short",
          day: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          hour12: true,
        })
        .replace(/,/g, "");
      name = `${name} ${timestamp}`;
      err = validateNewProjectName(name, activeProjectId);
      if (err) {
        name = `${name} ${Math.random().toString(36).substr(2, 4)}`;
      }
    }

    const now = new Date().toISOString();
    const project = createProject({
      name,
      type: "Dub",
      status: "Processing",
      data: {
        drafts: {
          dub: {
            mode,
            sourceText: originalText || undefined,
            translatedText:
              editedTranslation || translatedText || undefined,
            sourceLang: sourceLanguageCode || undefined,
            targetLang: selectedLanguage,
            voice: selectedVoice,
            text: {
              projectName: textProjectName.trim() || undefined,
              sourceText: textSourceText || undefined,
              translatedText:
                (textEditedTranslation || textTranslatedText) || undefined,
              sourceLang: sourceLanguageCode || undefined,
              targetLang: selectedLanguage,
              voice: selectedVoice,
              updatedAt: now,
            },
            audio: {
              projectName: audioProjectName.trim() || undefined,
              transcriptText: audioTranscriptText || undefined,
              translatedText:
                (audioEditedTranslation || audioTranslatedText) || undefined,
              sourceLang: sourceLanguageCode || undefined,
              targetLang: selectedLanguage,
              voice: selectedVoice,
              updatedAt: now,
            },
            updatedAt: now,
          },
        },
        outputs: {},
      },
    });
    if (!project) return null;
    setActiveProjectId(project.id);
    setProjectName(name);
    return project.id;
  };

  const saveDraftToProject = (overrideName?: string): string | null => {
    const projectId = ensureProject(overrideName);
    if (!projectId) return null;
    const project = getProjectById(projectId);
    if (!project) return null;

    const now = new Date().toISOString();
    const nextName = (overrideName ?? projectName)
      .trim()
      .replace(/\s+/g, " ");
    const namePatch =
      nextName && !validateNewProjectName(nextName, projectId)
        ? { name: nextName }
        : {};

    const prevDub: any = project.data?.drafts?.dub || {};
    const nextDub: any = {
      ...prevDub,
      mode,
      sourceText: originalText || undefined,
      translatedText:
        editedTranslation || translatedText || undefined,
      sourceLang: sourceLanguageCode || undefined,
      targetLang: selectedLanguage,
      voice: selectedVoice,
      updatedAt: now,
    };

    if (mode === "text") {
      nextDub.text = {
        ...(prevDub?.text || {}),
        projectName: textProjectName.trim() || undefined,
        sourceText: textSourceText || undefined,
        translatedText:
          (textEditedTranslation || textTranslatedText) || undefined,
        sourceLang: sourceLanguageCode || undefined,
        targetLang: selectedLanguage,
        voice: selectedVoice,
        updatedAt: now,
      };
    } else {
      nextDub.audio = {
        ...(prevDub?.audio || {}),
        projectName: audioProjectName.trim() || undefined,
        transcriptText: audioTranscriptText || undefined,
        translatedText:
          (audioEditedTranslation || audioTranslatedText) || undefined,
        sourceLang: sourceLanguageCode || undefined,
        targetLang: selectedLanguage,
        voice: selectedVoice,
        updatedAt: now,
      };
    }

    updateProject(projectId, {
      ...namePatch,
      type: "Dub",
      status:
        project.status === "Completed" ? "Completed" : "Processing",
      data: {
        ...(project.data || {}),
        drafts: {
          ...(project.data?.drafts || {}),
          dub: nextDub,
        },
      },
    });

    setIsDirty(false);
    return projectId;
  };

  const persistManagedArtifacts = (
    projectId: string,
    options?: {
      inputRecord?: StoredFileRecord | null;
      outputRecord?: StoredFileRecord | null;
      scriptEntries?: Array<{
        source: string;
        text: string;
        record: StoredFileRecord;
      }>;
      markCompleted?: boolean;
    },
  ) => {
    const project = getProjectById(projectId);
    if (!project) return null;
    const now = new Date().toISOString();
    const thisInputRecord =
      options && "inputRecord" in options
        ? options.inputRecord ?? null
        : inputFileRecord;
    const thisOutputRecord =
      options && "outputRecord" in options
        ? options.outputRecord ?? null
        : outputFileRecord;
    const preservedAudio = (
      project.data?.outputs?.audioVersions || []
    ).filter(
      (entry) =>
        !isTranslateDubAudioEntry((entry.settings as any) || {}),
    );
    const nextAudioVersions = [...preservedAudio];

    if (mode === "audio" && thisInputRecord?.fileId) {
      nextAudioVersions.unshift({
        id: `translate-dub-source-${thisInputRecord.fileId}`,
        audioUrl: `managed-file:${thisInputRecord.fileId}`,
        createdAt: thisInputRecord.uploadedAt || now,
        fileId: thisInputRecord.fileId,
        contentType: thisInputRecord.contentType,
        fileName: thisInputRecord.fileName,
        expiresAt: thisInputRecord.expiresAt,
        estimatedMinutes: inputMinutes ?? undefined,
        settings: {
          feature: "translate-dub",
          source: "upload",
          fileId: thisInputRecord.fileId,
          fileName: thisInputRecord.fileName,
          contentType: thisInputRecord.contentType,
          expiresAt: thisInputRecord.expiresAt,
        },
      });
    }

    if (thisOutputRecord?.fileId) {
      nextAudioVersions.unshift({
        id: `translate-dub-output-${thisOutputRecord.fileId}`,
        audioUrl: `managed-file:${thisOutputRecord.fileId}`,
        createdAt: thisOutputRecord.uploadedAt || now,
        fileId: thisOutputRecord.fileId,
        contentType: thisOutputRecord.contentType,
        fileName: thisOutputRecord.fileName,
        expiresAt: thisOutputRecord.expiresAt,
        voice: selectedVoice,
        estimatedMinutes,
        settings: {
          feature: "translate-dub",
          source: "generated",
          fileId: thisOutputRecord.fileId,
          fileName: thisOutputRecord.fileName,
          contentType: thisOutputRecord.contentType,
          expiresAt: thisOutputRecord.expiresAt,
        },
      });
    }

    const existingScripts = project.data?.outputs?.scripts || [];
    const managedScriptEntries = [...(options?.scriptEntries || [])];
    if (mode === "text" && thisInputRecord?.fileId) {
      managedScriptEntries.unshift({
        source: TRANSLATE_DUB_INPUT_SOURCE,
        text: textSourceText,
        record: thisInputRecord,
      });
    }
    const managedSources = new Set(
      managedScriptEntries.map((entry) => entry.source),
    );
    const nextScripts = [
      ...managedScriptEntries.map((entry) => ({
        id: `${entry.source.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${entry.record.fileId}`,
        text: entry.text,
        createdAt: entry.record.uploadedAt || now,
        fileId: entry.record.fileId,
        contentType: entry.record.contentType,
        fileName: entry.record.fileName,
        expiresAt: entry.record.expiresAt,
        source: entry.source,
      })),
      ...existingScripts.filter(
        (entry) => !managedSources.has(entry.source || ""),
      ),
    ].slice(0, 20);

    const updated = updateProject(projectId, {
      type: "Dub",
      status: options?.markCompleted
        ? "Completed"
        : project.status || "Processing",
      data: {
        ...(project.data || {}),
        outputs: {
          ...(project.data?.outputs || {}),
          scripts: nextScripts,
          audioVersions: nextAudioVersions.slice(0, 20),
        },
      },
    });
    return updated;
  };

  const buildInputSourceFile = () => {
    if (mode === "text") {
      return new File(
        [textSourceText],
        `translate-dub-input-${workflowId}.txt`,
        { type: "text/plain;charset=utf-8" },
      );
    }
    return audioFile;
  };

  const uploadTextArtifact = async (
    projectId: string,
    text: string,
    source: string,
    fileName: string,
  ) => {
    if (!text.trim() || !token) return null;
    const result = await uploadManagedTextFile(token, text, {
      fileName,
      feature: "translate-dub",
      jobId: projectId,
      durationMinutes: mode === "audio" ? inputMinutes : estimatedMinutes,
      isOutput: source !== TRANSLATE_DUB_INPUT_SOURCE,
    });
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return null;
    }
    return { source, text, record: result.data };
  };

  const ensureReviewTextStored = async (projectId: string) => {
    const scriptEntries: Array<{
      source: string;
      text: string;
      record: StoredFileRecord;
    }> = [];

    if (mode === "audio" && audioTranscriptText.trim()) {
      const transcriptEntry = await uploadTextArtifact(
        projectId,
        audioTranscriptText.trim(),
        TRANSLATE_DUB_TRANSCRIPT_SOURCE,
        `translate-dub-transcript-${workflowId}.txt`,
      );
      if (!transcriptEntry) return null;
      scriptEntries.push(transcriptEntry);
    }

    const nextTranslatedText = (
      editedTranslation || translatedText
    ).trim();
    if (nextTranslatedText) {
      const translatedEntry = await uploadTextArtifact(
        projectId,
        nextTranslatedText,
        TRANSLATE_DUB_TRANSLATION_SOURCE,
        `translate-dub-translation-${selectedLanguage}-${workflowId}.txt`,
      );
      if (!translatedEntry) return null;
      scriptEntries.push(translatedEntry);
    }

    return scriptEntries;
  };

  const ensureInputStored = async (projectId: string) => {
    if (!requireProtectedAccess() || !token) return null;
    const sourceFile = buildInputSourceFile();
    if (!sourceFile) return null;

    if (
      inputFileRecord &&
      inputFileRecord.fileName === sourceFile.name &&
      (inputFileRecord.sizeBytes == null ||
        inputFileRecord.sizeBytes === sourceFile.size)
    ) {
      return inputFileRecord;
    }

    setUploadPercent(0);
    const result = await uploadManagedFile(token, sourceFile, {
      feature: "translate-dub",
      jobId: projectId,
      durationMinutes: mode === "audio" ? inputMinutes : null,
      isOutput: false,
      onProgress: (percent) => setUploadPercent(percent),
    });
    setUploadPercent(0);
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return null;
    }
    setInputFileRecord(result.data);
    persistManagedArtifacts(projectId, { inputRecord: result.data });
    return result.data;
  };

  const buildGeneratedOutputFile = async (sourceUrl = outputUrl) => {
    if (!sourceUrl) return null;
    const response = await fetch(sourceUrl);
    const blob = await response.blob();
    const ext = outputFormat === "mp3" ? "mp3" : "wav";
    return new File(
      [blob],
      `translate-dub-output-${workflowId}.${ext}`,
      { type: blob.type || `audio/${ext}` },
    );
  };

  // ---------- Effects ----------

  // Create audio URL for preview
  useEffect(() => {
    if (!audioFile) {
      setAudioUrl(null);
      return;
    }
    const url = URL.createObjectURL(audioFile);
    setAudioUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [audioFile]);

  // Detect audio duration
  useEffect(() => {
    if (!audioFile) {
      setAudioDurationSeconds(null);
      return;
    }
    let canceled = false;
    const url = URL.createObjectURL(audioFile);
    const audio = new Audio();
    audio.src = url;
    const onLoaded = () => {
      if (canceled) return;
      const d = audio.duration;
      setAudioDurationSeconds(Number.isFinite(d) ? d : null);
    };
    audio.addEventListener("loadedmetadata", onLoaded);
    return () => {
      canceled = true;
      audio.removeEventListener("loadedmetadata", onLoaded);
      URL.revokeObjectURL(url);
    };
  }, [audioFile]);

  // Auto-enable regional-only toggle when source is detected as regional
  useEffect(() => {
    if (isSourceRegional) setIsRegionalOnly(true);
  }, [isSourceRegional]);

  // Auto-detect source language for text mode (debounced)
  useEffect(() => {
    if (mode !== "text" || sourceLanguageOverride) return;
    const input = textSourceText.trim();
    if (!input) {
      setSourceLanguageName(null);
      setSourceLanguageCode(null);
      return;
    }
    const seq = ++textDetectSeqRef.current;
    const timer = window.setTimeout(() => {
      void (async () => {
        try {
          const [detectedName, detectedCode] = await Promise.all([
            detectTextLanguage(input),
            detectTextLanguageCode(input),
          ]);
          if (seq !== textDetectSeqRef.current) return;
          setSourceLanguageName(detectedName || null);
          setSourceLanguageCode(detectedCode || null);
        } catch {
          if (seq !== textDetectSeqRef.current) return;
          setSourceLanguageName(null);
          setSourceLanguageCode(null);
        }
      })();
    }, 500);
    return () => window.clearTimeout(timer);
  }, [mode, textSourceText, sourceLanguageOverride]);

  // Load output file if we have a record but no URL
  useEffect(() => {
    if (!outputFileRecord?.fileId || !token || outputUrl) return;
    let canceled = false;
    void (async () => {
      const result = await downloadManagedFile(
        token,
        outputFileRecord.fileId,
      );
      if (canceled) return;
      if (result.success === false) {
        applyProtectedError(result.error, result.status);
        return;
      }
      const url = URL.createObjectURL(result.data.blob);
      setOutputUrl(url);
    })();
    return () => {
      canceled = true;
    };
  }, [outputFileRecord?.fileId, outputUrl, token]);

  // Auto-select first voice when target language changes
  useEffect(() => {
    if (!voicesForTarget.length) return;
    const stillValid = voicesForTarget.some(
      (v) => v.id === selectedVoice,
    );
    if (!stillValid) setSelectedVoice(voicesForTarget[0].id as VoiceName);
  }, [selectedVoice, voicesForTarget]);

  // Stop generate progress on unmount
  useEffect(() => {
    return () => stopGenerateProgress();
  }, []);

  // Auto-save draft every 30 seconds (C13)
  useEffect(() => {
    if (!isAuthenticated || isGuest || !isDirty || !activeProjectId) return;
    const timer = setInterval(() => {
      saveDraftToProject();
      setLastAutoSave(new Date().toLocaleTimeString());
    }, 30000);
    return () => clearInterval(timer);
  }, [isAuthenticated, isGuest, isDirty, activeProjectId]);

  // Load existing project
  useEffect(() => {
    if (!projectIdFromQuery) return;
    const project = getProjectById(projectIdFromQuery);
    if (!project) return;
    setActiveProjectId(project.id);

    const draft: any = project.data?.drafts?.dub || null;
    if (draft?.mode === "audio" || draft?.mode === "text")
      setMode(draft.mode);

    const projectNameValue =
      typeof project.name === "string" ? project.name.trim() : "";

    const textDraft: any = draft?.text || null;
    const audioDraft: any = draft?.audio || null;

    if (typeof textDraft?.projectName === "string")
      setTextProjectName(textDraft.projectName);
    else if (projectNameValue) setTextProjectName(projectNameValue);

    if (typeof audioDraft?.projectName === "string")
      setAudioProjectName(audioDraft.projectName);

    const loadedTextSource =
      typeof textDraft?.sourceText === "string"
        ? textDraft.sourceText
        : draft?.mode === "text" &&
            typeof draft?.sourceText === "string"
          ? draft.sourceText
          : "";
    const loadedTextTranslated =
      typeof textDraft?.translatedText === "string"
        ? textDraft.translatedText
        : draft?.mode === "text" &&
            typeof draft?.translatedText === "string"
          ? draft.translatedText
          : "";

    setTextSourceText(loadedTextSource);
    setTextTranslatedText(loadedTextTranslated);
    setTextEditedTranslation(loadedTextTranslated);

    const loadedAudioTranscript =
      typeof audioDraft?.transcriptText === "string"
        ? audioDraft.transcriptText
        : draft?.mode === "audio" &&
            typeof draft?.sourceText === "string"
          ? draft.sourceText
          : "";
    const loadedAudioTranslated =
      typeof audioDraft?.translatedText === "string"
        ? audioDraft.translatedText
        : draft?.mode === "audio" &&
            typeof draft?.translatedText === "string"
          ? draft.translatedText
          : "";

    setAudioTranscriptText(loadedAudioTranscript);
    setAudioTranslatedText(loadedAudioTranslated);
    setAudioEditedTranslation(loadedAudioTranslated);

    const nextTargetLang =
      textDraft?.targetLang ||
      audioDraft?.targetLang ||
      draft?.targetLang;
    if (typeof nextTargetLang === "string")
      setSelectedLanguages([nextTargetLang]);

    const nextSourceLang =
      textDraft?.sourceLang ||
      audioDraft?.sourceLang ||
      draft?.sourceLang;
    if (typeof nextSourceLang === "string")
      setSourceLanguageCode(nextSourceLang);

    const nextVoice =
      textDraft?.voice || audioDraft?.voice || draft?.voice;
    if (nextVoice && typeof nextVoice === "string")
      setSelectedVoice(nextVoice as VoiceName);

    const initialMode: Mode =
      draft?.mode === "audio" || draft?.mode === "text"
        ? (draft.mode as Mode)
        : "text";
    const initialSource =
      initialMode === "text" ? loadedTextSource : loadedAudioTranscript;
    const initialTranslated =
      initialMode === "text"
        ? loadedTextTranslated
        : loadedAudioTranslated;

    let initialMaxUnlocked: StepType = 1;
    if (initialSource.trim()) initialMaxUnlocked = 2 as StepType;
    if (initialTranslated.trim()) initialMaxUnlocked = 2 as StepType;
    if (initialMaxUnlocked > 1)
      setMaxStepUnlocked(initialMaxUnlocked);
    setCurrentStep(
      initialTranslated.trim()
        ? 2
        : initialSource.trim()
          ? (1 as StepType)
          : (1 as StepType),
    );

    const latestDubAudio = (
      project.data?.outputs?.audioVersions || []
    ).find(
      (entry) =>
        (entry.settings as any)?.feature === "translate-dub" &&
        (entry.settings as any)?.source === "generated",
    );
    if (latestDubAudio?.fileId) {
      setOutputFileRecord({
        fileId: latestDubAudio.fileId,
        fileName: latestDubAudio.fileName || "dub-output.wav",
        contentType: latestDubAudio.contentType,
        expiresAt: latestDubAudio.expiresAt,
        uploadedAt: latestDubAudio.createdAt,
        feature: "translate-dub",
        isOutput: true,
      });
    } else {
      const latestAudio =
        project.data?.outputs?.audioVersions?.[0]?.audioUrl;
      if (
        typeof latestAudio === "string" &&
        latestAudio &&
        !outputUrl
      )
        setOutputUrl(latestAudio);
    }

    const latestInputText =
      project.data?.outputs?.scripts?.find(
        (entry) =>
          entry.fileId && entry.source === TRANSLATE_DUB_INPUT_SOURCE,
      );
    const latestInputAudio = (
      project.data?.outputs?.audioVersions || []
    ).find(
      (entry) =>
        (entry.settings as any)?.feature === "translate-dub" &&
        (entry.settings as any)?.source === "upload",
    );
    const latestInputRecord = latestInputText || latestInputAudio;
    if (latestInputRecord?.fileId) {
      setInputFileRecord({
        fileId: latestInputRecord.fileId,
        fileName:
          latestInputRecord.fileName || "translate-dub-input.txt",
        contentType: latestInputRecord.contentType,
        expiresAt: latestInputRecord.expiresAt,
        uploadedAt: latestInputRecord.createdAt,
        feature: "translate-dub",
        isOutput: false,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- Handlers ----------

  const resetForNewProject = () => {
    setActiveProjectId("");
    setCurrentStep(1);
    setMaxStepUnlocked(1);
    setMode("text");
    setTextProjectName("");
    setAudioProjectName("");
    setTextSourceText("");
    setTextTranslatedText("");
    setTextEditedTranslation("");
    setAudioFile(null);
    setAudioDurationSeconds(null);
    setAudioTranscriptText("");
    setAudioTranslatedText("");
    setAudioEditedTranslation("");
    setSourceLanguageName(null);
    setSourceLanguageCode(null);
    setSourceLanguageOverride(null);
    setSelectedLanguages(["es"]);
    setSelectedVoice(VoiceName.JENNY);
    setRate(0);
    setPitch(0);
    setAdvancedOpen(false);
    setShowOriginalText(false);
    setOutputUrl(null);
    setOutputFormat("wav");
    setError(null);
    setIsDirty(false);
    setEditHistory([]);
    setEditHistoryIndex(-1);
  };

  const computeProgressForMode = (nextMode: Mode) => {
    const source =
      nextMode === "text" ? textSourceText : audioTranscriptText;
    const translated =
      nextMode === "text" ? textTranslatedText : audioTranslatedText;

    let maxUnlocked: StepType = 1;
    if (
      source.trim().length > 0 ||
      (nextMode === "audio" && audioFile)
    )
      maxUnlocked = 2 as StepType;
    if (translated.trim().length > 0) maxUnlocked = 2 as StepType;

    const nextStep: StepType =
      translated.trim().length > 0
        ? 2
        : source.trim().length > 0
          ? (1 as StepType)
          : (1 as StepType);
    return { maxUnlocked, nextStep };
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.type.startsWith("audio/")) {
        setAudioFile(file);
        setAudioDurationSeconds(null);
        setError(null);
        setIsDirty(true);
      } else {
        setError(
          "Invalid file type. Please upload an audio file (WAV, MP3, OGG, M4A, FLAC, or WebM).",
        );
      }
    }
  };

  const handleTextFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      let text = ev.target?.result as string;
      // SRT parsing: strip timestamps and sequence numbers
      if (file.name.endsWith(".srt")) {
        text = text
          .replace(/^\d+\s*$/gm, "")
          .replace(/\d{2}:\d{2}:\d{2}[.,]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[.,]\d{3}/g, "")
          .replace(/\n{3,}/g, "\n\n")
          .trim();
      }
      setTextSourceText(text);
      setIsDirty(true);
    };
    reader.readAsText(file);
  };

  const handlePreview = async (voice: VoiceName) => {
    if (!isAuthenticated) {
      setAuthRequiredOpen(true);
      return;
    }
    if (previewPlayingId === voice) {
      previewRef.current?.pause();
      setPreviewPlayingId(null);
      return;
    }

    previewRef.current?.pause();
    setPreviewLoadingId(voice);

    const cached = previewCacheRef.current.get(voice);
    if (cached) {
      if (!previewRef.current) return;
      previewRef.current.src = cached;
      previewRef.current.onplay = () => {
        setPreviewLoadingId(null);
        setPreviewPlayingId(voice);
      };
      previewRef.current.onended = () => setPreviewPlayingId(null);
      void previewRef.current.play();
      return;
    }

    const voiceOption = AVAILABLE_VOICES.find((v) => v.id === voice);
    const previewText = getPreviewTextForVoice(voice);

    try {
      const url = await generateAzureSpeech(
        previewText,
        voice,
        rate,
        pitch,
        100,
        'general',
        1.0,
        token,
      );
      previewCacheRef.current.set(voice, url);
      void refreshBalance();
      if (!previewRef.current) return;
      previewRef.current.src = url;
      previewRef.current.onplay = () => {
        setPreviewLoadingId(null);
        setPreviewPlayingId(voice);
      };
      previewRef.current.onended = () => setPreviewPlayingId(null);
      await previewRef.current.play();
    } catch {
      setPreviewLoadingId(null);
    }
  };

  const handleDownloadTranslatedText = () => {
    const textToDownload = editedTranslation || translatedText;
    if (!textToDownload.trim()) {
      setError("No translated text available to download.");
      return;
    }
    try {
      const blob = new Blob([textToDownload], {
        type: "text/plain;charset=utf-8",
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `translated-text-${Date.now()}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Download failed:", err);
      setError("Failed to download translated text.");
    }
  };

  const handleDownloadOutput = async () => {
    if (!outputUrl) return;
    setFileActionKey("download-output");
    try {
      const link = document.createElement("a");
      link.href = outputUrl;
      const ext = outputFormat === "mp3" ? "mp3" : "wav";
      link.download = `translate-dub-${Date.now()}.${ext}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("Download failed:", err);
    } finally {
      setFileActionKey(null);
    }
  };

  const handleDeleteStoredDub = async () => {
    if (!outputFileRecord?.fileId || !token) return;
    if (!requireProtectedAccess()) return;

    const confirmed = await dialog.confirm(
      "Are you sure you want to delete this dub from storage? This action cannot be undone.",
      {
        title: "Delete Stored Dub?",
        confirmText: "Delete",
        cancelText: "Cancel",
        variant: "danger",
      },
    );
    if (!confirmed) return;

    setError(null);
    setFileActionKey(`delete-${outputFileRecord.fileId}`);
    const result = await deleteManagedFile(
      token,
      outputFileRecord.fileId,
    );
    setFileActionKey(null);
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return;
    }

    if (activeProjectId) {
      const project = getProjectById(activeProjectId);
      if (project) {
        updateProject(activeProjectId, {
          type: "Dub",
          status: "Processing",
          data: {
            ...(project.data || {}),
            outputs: {
              ...(project.data?.outputs || {}),
              audioVersions: (
                project.data?.outputs?.audioVersions || []
              ).filter(
                (entry) => entry.fileId !== outputFileRecord.fileId,
              ),
            },
          },
        });
      }
    }

    setOutputFileRecord(null);
    setOutputUrl(null);
  };

  // Step 1: Input & Configure — Continue
  const handleStep1Continue = async () => {
    if (isGuest) {
      setAuthRequiredOpen(true);
      return;
    }

    setError(null);
    setOutputUrl(null);

    const candidate = projectName.trim() || getDefaultProjectName();
    const projectId = ensureProject(candidate);

    // Translate immediately (C2)
    if (mode === "text") {
      startTranslateProgress("Translating");
      setIsTranslating(true);

      try {
        let detectedName: string | null = sourceLanguageName;
        let detectedCode: string | null = sourceLanguageCode;

        if (!sourceLanguageOverride) {
          detectedName = await detectTextLanguage(textSourceText);
          setSourceLanguageName(detectedName);
          detectedCode = await detectTextLanguageCode(textSourceText);
          setSourceLanguageCode(detectedCode || "");
        }

        const translated = await translateText(
          textSourceText,
          selectedLanguage,
          token,
          sourceLanguageOverride || detectedCode || null,
        );
        if (!translated) {
          setError("Translation failed. Please try again.");
          stopTranslateProgress();
          return;
        }

        setTextTranslatedText(translated);
        setTextEditedTranslation(translated);
        setOriginalTranslation(translated);
        setEditHistory([translated]);
        setEditHistoryIndex(0);
        void refreshBalance();
        await finishTranslateProgress();

        const now = new Date().toISOString();
        const project = projectId
          ? getProjectById(projectId)
          : null;
        if (project && projectId) {
          const nextName = projectName
            .trim()
            .replace(/\s+/g, " ");
          const namePatch =
            nextName &&
            !validateNewProjectName(nextName, projectId)
              ? { name: nextName }
              : {};

          const prevLang =
            project.data?.outputs?.languages || [];
          const prevDub: any =
            project.data?.drafts?.dub || {};
          const nextDub: any = {
            ...prevDub,
            mode: "text",
            sourceText: textSourceText,
            translatedText: translated,
            sourceLang: detectedCode || "",
            targetLang: selectedLanguage,
            voice: selectedVoice,
            updatedAt: now,
            text: {
              ...(prevDub?.text || {}),
              projectName:
                textProjectName.trim() || undefined,
              sourceText: textSourceText,
              translatedText: translated,
              sourceLang: detectedCode || "",
              targetLang: selectedLanguage,
              voice: selectedVoice,
              updatedAt: now,
            },
          };
          updateProject(projectId, {
            ...namePatch,
            type: "Dub",
            status: "Processing",
            data: {
              ...(project.data || {}),
              drafts: {
                ...(project.data?.drafts || {}),
                dub: nextDub,
              },
              outputs: {
                ...(project.data?.outputs || {}),
                languages: [
                  {
                    id: crypto.randomUUID(),
                    createdAt: now,
                    sourceLang: detectedCode || "",
                    targetLang: selectedLanguage,
                    sourceText: textSourceText,
                    translatedText: translated,
                  },
                  ...prevLang,
                ].slice(0, 20),
              },
            },
          });
        }

        setMaxStepUnlocked((prev) =>
          (prev >= 2 ? prev : 2) as StepType,
        );
        setCurrentStep(2);
      } finally {
        setIsTranslating(false);
      }
    } else {
      // Audio mode
      if (!audioFile) {
        setError("Please upload an audio file to translate.");
        return;
      }

      startTranslateProgress("Transcribing");
      setIsTranscribing(true);

      const stt = await transcribeAudioFile(audioFile, {
        language: "en-US",
        autoPunctuation: true,
        includeTimestamps: false,
      });
      setIsTranscribing(false);

      if (stt.success === false) {
        setError(stt.error);
        stopTranslateProgress();
        return;
      }

      setTranslateLabel("Translating");
      setIsTranslating(true);

      try {
        const transcript = stt.transcript || "";
        let detectedName: string | null = null;
        let detectedCode: string | null = null;

        if (!sourceLanguageOverride) {
          detectedName = await detectTextLanguage(transcript);
          setSourceLanguageName(detectedName);
          detectedCode = await detectTextLanguageCode(transcript);
          setSourceLanguageCode(detectedCode || "");
        }

        const translated = await translateText(
          transcript,
          selectedLanguage,
          token,
          sourceLanguageOverride || detectedCode || null,
        );
        if (!translated) {
          setError("Translation failed. Please try again.");
          stopTranslateProgress();
          return;
        }

        setAudioTranscriptText(transcript);
        setAudioTranslatedText(translated);
        setAudioEditedTranslation(translated);
        setOriginalTranslation(translated);
        setEditHistory([translated]);
        setEditHistoryIndex(0);
        await finishTranslateProgress();

        const now = new Date().toISOString();
        const project = projectId
          ? getProjectById(projectId)
          : null;
        if (project && projectId) {
          const nextName = projectName
            .trim()
            .replace(/\s+/g, " ");
          const namePatch =
            nextName &&
            !validateNewProjectName(nextName, projectId)
              ? { name: nextName }
              : {};

          const prevLang =
            project.data?.outputs?.languages || [];
          const prevDub: any =
            project.data?.drafts?.dub || {};
          const nextDub: any = {
            ...prevDub,
            mode: "audio",
            sourceText: transcript,
            translatedText: translated,
            sourceLang: detectedCode || "",
            targetLang: selectedLanguage,
            voice: selectedVoice,
            updatedAt: now,
            audio: {
              ...(prevDub?.audio || {}),
              projectName:
                audioProjectName.trim() || undefined,
              transcriptText: transcript,
              translatedText: translated,
              sourceLang: detectedCode || "",
              targetLang: selectedLanguage,
              voice: selectedVoice,
              updatedAt: now,
            },
          };
          updateProject(projectId, {
            ...namePatch,
            type: "Dub",
            status: "Processing",
            data: {
              ...(project.data || {}),
              drafts: {
                ...(project.data?.drafts || {}),
                dub: nextDub,
              },
              outputs: {
                ...(project.data?.outputs || {}),
                languages: [
                  {
                    id: crypto.randomUUID(),
                    createdAt: now,
                    sourceLang: detectedCode || "",
                    targetLang: selectedLanguage,
                    sourceText: transcript,
                    translatedText: translated,
                  },
                  ...prevLang,
                ].slice(0, 20),
              },
            },
          });
        }

        setMaxStepUnlocked((prev) =>
          (prev >= 2 ? prev : 2) as StepType,
        );
        setCurrentStep(2);
      } finally {
        setIsTranslating(false);
      }
    }
  };

  // Step 2: Review & Voice — Continue to Generate
  const handleStep2Continue = async () => {
    const projectId = ensureProject();
    if (!requireProtectedAccess()) return;

    const storedInput = await ensureInputStored(projectId!);
    if (!storedInput?.fileId) return;
    const scriptEntries = await ensureReviewTextStored(projectId!);
    if (scriptEntries === null) return;

    saveDraftToProject();
    persistManagedArtifacts(projectId!, {
      inputRecord: storedInput,
      scriptEntries,
    });
    setMaxStepUnlocked((prev) => (prev >= 3 ? prev : 3) as StepType);
    setCurrentStep(3);
  };

  // Step 3: Generate
  const handleGenerate = async () => {
    const text = (editedTranslation || translatedText).trim();
    if (!text) return;

    const projectId = ensureProject();
    if (!requireProtectedAccess() || !token) return;

    setError(null);
    setIsGenerating(true);
    setOutputUrl(null);
    setOutputFileRecord(null);
    startGenerateProgress();
    setGeneratePhase("Preparing text...");

    try {
      const storedInput = inputFileRecord?.fileId
        ? inputFileRecord
        : await ensureInputStored(projectId!);
      if (!storedInput?.fileId) return;
      const scriptEntries = await ensureReviewTextStored(projectId!);
      if (scriptEntries === null) return;

      setGeneratePhase("Generating speech...");
      const url = await generateAzureSpeech(
        text,
        selectedVoice,
        rate,
        pitch,
        100,
        "general",
        1.0,
        token,
        "translate-dub",
      );

      setGeneratePhase("Uploading result...");
      const outputFile = await buildGeneratedOutputFile(url);
      if (!outputFile) {
        setError(
          "Generated dub could not be prepared for Azure Files.",
        );
        return;
      }
      const uploadResult = await uploadManagedFile(token, outputFile, {
        feature: "translate-dub",
        jobId: projectId!,
        durationMinutes: estimatedMinutes,
        isOutput: true,
      });
      if (uploadResult.success === false) {
        applyProtectedError(
          uploadResult.error,
          uploadResult.status,
        );
        return;
      }

      setOutputUrl(url);
      setOutputFileRecord(uploadResult.data);
      persistManagedArtifacts(projectId!, {
        inputRecord: storedInput,
        outputRecord: uploadResult.data,
        scriptEntries,
      });
      void refreshBalance();
    } catch (err: any) {
      if ((err as any).insufficientCredits) {
        setInsuffCreditsInfo({ required: (err as any).requiredCredits ?? 0, current: (err as any).currentBalance ?? 0 });
      } else {
        setError(err instanceof Error ? err.message : "Generation failed. Please try again.");
      }
    } finally {
      stopGenerateProgress();
      setIsGenerating(false);
      setGeneratePhase("");
    }
  };

  const handleSaveProject = async (
    overrideName?: string,
  ): Promise<boolean> => {
    if (saveProjectInProgress) return false;
    if (!outputUrl) {
      setError("Generate the final dub before saving.");
      return false;
    }
    if (!requireProtectedAccess() || !token) return false;

    startSaveProjectProgress();
    const projectId = saveDraftToProject(overrideName);
    if (!projectId) {
      stopSaveProjectProgress();
      return false;
    }

    const storedInput = inputFileRecord?.fileId
      ? inputFileRecord
      : await ensureInputStored(projectId);
    if (!storedInput?.fileId) {
      stopSaveProjectProgress();
      return false;
    }
    const scriptEntries = await ensureReviewTextStored(projectId);
    if (scriptEntries === null) {
      stopSaveProjectProgress();
      return false;
    }
    let storedOutput = outputFileRecord;
    if (!storedOutput?.fileId) {
      const outputFile = await buildGeneratedOutputFile();
      if (!outputFile) {
        setError("Generate the final dub before saving.");
        stopSaveProjectProgress();
        return false;
      }
      const uploadResult = await uploadManagedFile(token, outputFile, {
        feature: "translate-dub",
        jobId: projectId,
        durationMinutes: estimatedMinutes,
        isOutput: true,
      });
      if (uploadResult.success === false) {
        applyProtectedError(
          uploadResult.error,
          uploadResult.status,
        );
        stopSaveProjectProgress();
        return false;
      }
      storedOutput = uploadResult.data;
      setOutputFileRecord(uploadResult.data);
    }
    const updated = persistManagedArtifacts(projectId, {
      inputRecord: storedInput,
      outputRecord: storedOutput,
      scriptEntries,
      markCompleted: true,
    });
    if (!updated) {
      setError("Could not save this project.");
      stopSaveProjectProgress();
      return false;
    }
    return true;
  };

  const handleSaveProjectClick = () => {
    if (!outputUrl) {
      setError("Generate the final dub before saving.");
      return;
    }
    if (!requireProtectedAccess() || !token) return;
    openProjectModal("project");
  };

  const resetProjectModal = () => {
    setProjectModalPurpose(null);
    setProjectModalError(null);
    setProjectModalStatus("idle");
  };

  const openProjectModal = (purpose: "draft" | "project") => {
    setPendingProjectName(getDefaultProjectName());
    setProjectModalError(null);
    setProjectModalStatus("idle");
    setProjectModalPurpose(purpose);
  };

  const handleProjectModalProceed = async () => {
    if (!projectModalPurpose) return;
    const candidate = pendingProjectName.trim();
    if (candidate.length <= 3) {
      setProjectModalError(
        "Project name must be at least 4 characters.",
      );
      return;
    }
    const validationError = validateNewProjectName(
      candidate,
      activeProjectId,
    );
    if (validationError) {
      setProjectModalError(validationError);
      return;
    }
    setProjectModalError(null);
    setPendingProjectName(candidate);
    setProjectModalStatus("idle");
    setProjectName(candidate);

    if (projectModalPurpose === "draft") {
      startSaveDraftProgress();
      saveDraftToProject(candidate);
      await finishSaveDraftProgress();
    } else {
      startSaveProjectProgress();
      const ok = await handleSaveProject(candidate);
      if (!ok) {
        stopSaveProjectProgress();
        return;
      }
      await finishSaveProjectProgress();
    }

    setProjectModalStatus("saved");
    window.setTimeout(() => navigate("/projects"), 600);
  };

  // Edit history helpers (C14)
  const pushEditHistory = useCallback(
    (text: string) => {
      setEditHistory((prev) => {
        const next = prev.slice(0, editHistoryIndex + 1);
        next.push(text);
        if (next.length > 50) next.shift();
        return next;
      });
      setEditHistoryIndex((prev) =>
        Math.min(prev + 1, 49),
      );
    },
    [editHistoryIndex],
  );

  const handleUndo = () => {
    if (editHistoryIndex <= 0) return;
    const newIndex = editHistoryIndex - 1;
    setEditHistoryIndex(newIndex);
    setEditedTranslation(editHistory[newIndex]);
  };

  const handleRedo = () => {
    if (editHistoryIndex >= editHistory.length - 1) return;
    const newIndex = editHistoryIndex + 1;
    setEditHistoryIndex(newIndex);
    setEditedTranslation(editHistory[newIndex]);
  };

  const handleResetTranslation = () => {
    if (!originalTranslation) return;
    setEditedTranslation(originalTranslation);
    pushEditHistory(originalTranslation);
  };

  // Navigation with confirmation (C4 — single dialog)
  const handleStepNavigation = async (
    targetStep: StepType,
  ): Promise<boolean> => {
    const isStep2Complete = maxStepUnlocked >= 2;
    const isStep3Complete = Boolean(outputUrl || outputFileRecord);

    const hasSubsequentProgress =
      (targetStep === 1 && (isStep2Complete || isStep3Complete)) ||
      (targetStep === 2 && isStep3Complete);

    if (hasSubsequentProgress) {
      const stepNames = ["Input & Configure", "Review & Voice", "Generate"];
      const stepName = stepNames[targetStep - 1];

      const result = await dialog.confirm(
        `Going back to "${stepName}" will clear progress from subsequent steps. Would you like to save before going back?`,
        {
          title: "Go Back?",
          confirmText: "Save & Go Back",
          cancelText: "Go Back Without Saving",
          variant: "warning",
        },
      );

      if (result) {
        // User wants to save first
        if (isStep3Complete && outputFileRecord) {
          openProjectModal("project");
        } else {
          openProjectModal("draft");
        }
        return false;
      }

      // Clear downstream state
      if (targetStep === 1) {
        setOutputFileRecord(null);
        setOutputUrl(null);
        setTextTranslatedText("");
        setTextEditedTranslation("");
        setAudioTranslatedText("");
        setAudioEditedTranslation("");
        setAudioTranscriptText("");
        setMaxStepUnlocked(1);
      } else if (targetStep === 2) {
        setOutputFileRecord(null);
        setOutputUrl(null);
        setMaxStepUnlocked(2 as StepType);
      }
    }
    return true;
  };

  // ---------- Computed values for steps ----------

  const isBusy =
    isTranslating ||
    isTranscribing ||
    isGenerating ||
    translateInProgress ||
    saveProjectInProgress;

  const isStep1Valid =
    selectedLanguage.length > 0 &&
    ((mode === "text" && textSourceText.trim().length > 0) ||
    (mode === "audio" &&
      (audioFile !== null ||
        audioTranscriptText.trim().length > 0)));
  const isStep2Valid =
    selectedVoice && voicesForTarget.length > 0;
  const isStep3Ready =
    (editedTranslation || translatedText).trim().length > 0;

  const isStep1Complete = isStep1Valid && maxStepUnlocked >= 2;
  const isStep2Complete = maxStepUnlocked >= 3;
  const isStep3Complete = Boolean(outputUrl || outputFileRecord);

  const step1Summary = useMemo(() => {
    if (mode === "text")
      return `Paste Text \u2022 ${textSourceText.length} chars`;
    const bits = ["Upload Audio"];
    if (audioDurationSeconds != null)
      bits.push(formatDuration(audioDurationSeconds));
    if (audioTranscriptText.trim())
      bits.push(`${audioTranscriptText.length} transcript chars`);
    return bits.join(" \u2022 ");
  }, [mode, textSourceText.length, audioDurationSeconds, audioTranscriptText]);

  const step2Summary = useMemo(() => {
    const lang =
      TARGET_LANGUAGES.find((l) => l.code === selectedLanguage)
        ?.name || selectedLanguage;
    const bits = [`Target: ${lang}`, `Voice: ${selectedVoice}`];
    if (editedTranslation.trim())
      bits.push(`${wordCount} words`);
    return bits.join(" \u2022 ");
  }, [selectedLanguage, selectedVoice, editedTranslation, wordCount]);

  const projectModalLoading =
    projectModalPurpose === "draft"
      ? saveDraftInProgress
      : projectModalPurpose === "project"
        ? saveProjectInProgress
        : false;
  const projectModalPercent =
    projectModalPurpose === "draft"
      ? saveDraftPercent
      : projectModalPurpose === "project"
        ? saveProjectPercent
        : 0;
  const projectModalTitle =
    projectModalPurpose === "project"
      ? "Save Project"
      : "Save Draft";
  const projectModalDescription =
    projectModalPurpose === "project"
      ? "Save the generated dub under this project name."
      : "Save the current draft under this project name.";
  const projectModalStatusMessage =
    projectModalStatus === "saved" ? "Saved" : undefined;

  return {
    // Navigation
    navigate,
    currentStep,
    setCurrentStep,
    maxStepUnlocked,
    setMaxStepUnlocked,
    handleStepNavigation,

    // Auth
    isAuthenticated,
    token,
    isGuest,
    authRequiredOpen,
    setAuthRequiredOpen,
    insufficientCreditsInfo,
    clearInsuffCreditsInfo: () => setInsuffCreditsInfo(null),
    activeProjectId,

    // Mode
    mode,
    setMode,
    computeProgressForMode,

    // Text input
    textSourceText,
    setTextSourceText,

    // Audio input
    audioFile,
    setAudioFile,
    audioUrl,
    audioDurationSeconds,
    setAudioDurationSeconds,
    audioTranscriptText,
    setAudioTranscriptText,
    dragOver,
    setDragOver,
    fileInputRef,
    textFileInputRef,
    handleDrop,
    handleTextFileUpload,
    recorder,

    // Input records
    inputFileRecord,
    setInputFileRecord,
    outputFileRecord,
    setOutputFileRecord,

    // Translation
    selectedLanguages,
    setSelectedLanguages,
    selectedLanguage,
    sourceLanguageName,
    sourceLanguageCode,
    sourceLanguageOverride,
    setSourceLanguageOverride,
    translatedText,
    editedTranslation,
    setEditedTranslation,
    originalText,
    showOriginalText,
    setShowOriginalText,
    translationsMap,
    setTranslationsMap,
    editedTranslationsMap,
    setEditedTranslationsMap,
    activeTranslationLang,
    setActiveTranslationLang,

    // Voice
    selectedVoice,
    setSelectedVoice,
    rate,
    setRate,
    pitch,
    setPitch,
    advancedOpen,
    setAdvancedOpen,
    outputFormat,
    setOutputFormat,
    voicesForTarget,
    previewLoadingId,
    previewPlayingId,
    previewRef,
    handlePreview,

    // Regional language support
    isRegionalOnly,
    setIsRegionalOnly,
    isSourceRegional,
    isTargetRegional,
    translateIsRegional,
    estimatedTranslationCredits,
    estimatedTtsCredits,

    // Processing
    isTranslating,
    isTranscribing,
    isGenerating,
    outputUrl,
    error,
    setError,
    generatePercent,
    generatePhase,
    translateInProgress,
    translatePercent,
    translateLabel,
    uploadPercent,
    isBusy,
    fileActionKey,

    // Validation
    isStep1Valid,
    isStep2Valid,
    isStep3Ready,
    isStep1Complete,
    isStep2Complete,
    isStep3Complete,

    // Summaries
    step1Summary,
    step2Summary,
    wordCount,
    estimatedMinutes,
    inputMinutes,

    // Project modal
    projectModalPurpose,
    pendingProjectName,
    setPendingProjectName,
    projectModalError,
    projectModalLoading,
    projectModalPercent,
    projectModalTitle,
    projectModalDescription,
    projectModalStatusMessage,
    resetProjectModal,
    openProjectModal,
    handleProjectModalProceed,

    // Actions
    handleStep1Continue,
    handleStep2Continue,
    handleGenerate,
    handleSaveProject,
    handleSaveProjectClick,
    handleDownloadTranslatedText,
    handleDownloadOutput,
    handleDeleteStoredDub,
    saveDraftToProject,

    // Project save progress
    saveProjectInProgress,

    // Edit history (C14)
    editHistory,
    editHistoryIndex,
    originalTranslation,
    pushEditHistory,
    handleUndo,
    handleRedo,
    handleResetTranslation,

    // Auto-save (C13)
    isDirty,
    setIsDirty,
    lastAutoSave,

    // Project name
    projectName,
    setProjectName,
    projectNameError,

    // Misc
    formatDuration,
  };
}
