import React from "react";
import StepCard from "../StepCard";
import { Slider } from "../createVoice/ui";
import VoiceGrid from "../createVoice/VoiceGrid";
import VoiceGridSkeleton from "./VoiceGridSkeleton";
import TranslationSkeleton from "./TranslationSkeleton";
import type { useTranslateDubState } from "./useTranslateDubState";

type Props = {
  state: ReturnType<typeof useTranslateDubState>;
};

const Step2ReviewVoice: React.FC<Props> = ({ state }) => {
  const {
    maxStepUnlocked,
    step2Summary,
    mode,
    originalText,
    editedTranslation,
    translatedText,
    setEditedTranslation,
    showOriginalText,
    setShowOriginalText,
    wordCount,
    isTranslating,
    setIsDirty,

    // Voice
    selectedVoice,
    setSelectedVoice,
    rate,
    setRate,
    pitch,
    setPitch,
    advancedOpen,
    setAdvancedOpen,
    outputFormat,
    setOutputFormat,
    voicesForTarget,
    previewLoadingId,
    previewPlayingId,
    handlePreview,

    // Edit history (C14)
    editHistoryIndex,
    editHistory,
    originalTranslation,
    pushEditHistory,
    handleUndo,
    handleRedo,
    handleResetTranslation,

    // Download
    handleDownloadTranslatedText,

    // Source comparison (C15)
  } = state;

  const sourceWordCount = (originalText || "")
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;
  const wordDiff = wordCount - sourceWordCount;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <StepCard
        step={2}
        title="Review & Choose Voice"
        description="Edit the translation, select your voice, and adjust settings before generating."
        isActive={true}
        isCompleted={maxStepUnlocked >= 3}
        summary={step2Summary}
      >
        <div className="space-y-6">
          {/* Translation Review Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-3">
                {/* Undo/Redo (C14) */}
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    disabled={editHistoryIndex <= 0}
                    onClick={handleUndo}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 disabled:opacity-30 transition-colors"
                    title="Undo"
                  >
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 10h10a5 5 0 015 5v2M3 10l4-4m-4 4l4 4"
                      />
                    </svg>
                  </button>
                  <button
                    type="button"
                    disabled={
                      editHistoryIndex >=
                      editHistory.length - 1
                    }
                    onClick={handleRedo}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 disabled:opacity-30 transition-colors"
                    title="Redo"
                  >
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 10H11a5 5 0 00-5 5v2m15-7l-4-4m4 4l-4 4"
                      />
                    </svg>
                  </button>
                  {originalTranslation &&
                    editedTranslation !== originalTranslation && (
                      <button
                        type="button"
                        onClick={handleResetTranslation}
                        className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors ml-1"
                      >
                        Reset
                      </button>
                    )}
                </div>

                <label className="inline-flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
                  <input
                    type="checkbox"
                    checked={showOriginalText}
                    onChange={(e) =>
                      setShowOriginalText(e.target.checked)
                    }
                    className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  Show original
                </label>
              </div>
            </div>

            {isTranslating ? (
              <TranslationSkeleton />
            ) : showOriginalText ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                    Original Text
                  </label>
                  <textarea
                    value={originalText}
                    readOnly
                    className="w-full min-h-[250px] p-4 rounded-2xl bg-slate-100/50 dark:bg-white/10 border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-300 resize-none font-medium text-sm leading-relaxed focus:outline-none opacity-75"
                  />
                </div>
                <div>
                  <label
                    htmlFor="td-translated"
                    className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2"
                  >
                    Translated Text
                    {editedTranslation !== originalTranslation && (
                      <span className="ml-2 text-amber-600 dark:text-amber-400">
                        (edited)
                      </span>
                    )}
                  </label>
                  <textarea
                    id="td-translated"
                    value={editedTranslation}
                    onChange={(e) => {
                      setEditedTranslation(e.target.value);
                      setIsDirty(true);
                      pushEditHistory(e.target.value);
                    }}
                    className={[
                      "w-full min-h-[250px] p-4 rounded-2xl bg-white/70 dark:bg-white/5 border text-slate-900 dark:text-white resize-none font-medium text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500/30",
                      editedTranslation !== originalTranslation
                        ? "border-amber-300 dark:border-amber-500/30"
                        : "border-slate-200 dark:border-white/10",
                    ].join(" ")}
                  />
                </div>
              </div>
            ) : (
              <div>
                <label
                  htmlFor="td-translated-full"
                  className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2"
                >
                  Translated Text
                </label>
                <textarea
                  id="td-translated-full"
                  value={editedTranslation}
                  onChange={(e) => {
                    setEditedTranslation(e.target.value);
                    setIsDirty(true);
                    pushEditHistory(e.target.value);
                  }}
                  className="w-full min-h-[280px] p-4 rounded-2xl bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white resize-none font-medium text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                />
              </div>
            )}

            {(editedTranslation || translatedText).trim().length >
              0 && (
              <button
                type="button"
                onClick={handleDownloadTranslatedText}
                className="w-full px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center gap-2"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                  />
                </svg>
                Download Translated Text
              </button>
            )}
          </div>

          {/* Voice Selection Section */}
          <div className="border-t border-slate-200/50 dark:border-white/10 pt-6 space-y-4">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <button
                type="button"
                onClick={() => setAdvancedOpen(!advancedOpen)}
                className="text-xs font-black uppercase tracking-widest text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors inline-flex items-center gap-2"
              >
                Voice Settings
                <svg
                  className={[
                    "w-4 h-4 transition-transform",
                    advancedOpen && "rotate-180",
                  ].join(" ")}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2.5}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>

              {/* Output format selector (B3) */}
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                  Format
                </span>
                <div className="flex rounded-lg border border-slate-200 dark:border-white/10 overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setOutputFormat("wav")}
                    className={[
                      "px-3 py-1 text-[10px] font-black uppercase tracking-widest transition-colors",
                      outputFormat === "wav"
                        ? "bg-indigo-600 text-white"
                        : "bg-white/80 dark:bg-white/5 text-slate-600 dark:text-slate-300",
                    ].join(" ")}
                  >
                    WAV
                  </button>
                  <button
                    type="button"
                    onClick={() => setOutputFormat("mp3")}
                    className={[
                      "px-3 py-1 text-[10px] font-black uppercase tracking-widest transition-colors",
                      outputFormat === "mp3"
                        ? "bg-indigo-600 text-white"
                        : "bg-white/80 dark:bg-white/5 text-slate-600 dark:text-slate-300",
                    ].join(" ")}
                  >
                    MP3
                  </button>
                </div>
              </div>
            </div>

            {advancedOpen && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Slider
                  label="Speed"
                  value={rate}
                  min={-50}
                  max={50}
                  onChange={setRate}
                />
                <Slider
                  label="Pitch"
                  value={pitch}
                  min={-50}
                  max={50}
                  onChange={setPitch}
                />
              </div>
            )}

            {voicesForTarget.length === 0 ? (
              <div className="rounded-2xl border border-amber-500/20 bg-amber-500/10 p-4 text-sm font-semibold text-amber-700 dark:text-amber-300">
                No voices available for this target language.
              </div>
            ) : (
              <>
                {(voicesForTarget[0]?.region === "Indian" || voicesForTarget[0]?.region === "SE Asian") && (
                  <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-start gap-3">
                    <svg className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                    </svg>
                    <div>
                      <p className="text-sm font-black text-amber-900 dark:text-amber-200">
                        Regional language — 2× credit rate applies
                      </p>
                      <p className="mt-1 text-xs font-medium text-amber-800 dark:text-amber-300/80">
                        Indian and Southeast Asian voices are charged at <span className="font-black">2 credits per 100 characters</span>, double the standard rate.
                      </p>
                    </div>
                  </div>
                )}
                <VoiceGrid
                  voices={voicesForTarget}
                  selectedVoice={selectedVoice}
                  onSelectVoice={setSelectedVoice}
                  previewLoadingId={previewLoadingId}
                  previewPlayingId={previewPlayingId}
                  onPreview={handlePreview}
                />
              </>
            )}
          </div>
        </div>
      </StepCard>
    </div>
  );
};

export default Step2ReviewVoice;
