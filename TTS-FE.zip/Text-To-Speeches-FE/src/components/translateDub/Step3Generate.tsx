import React from "react";
import { Lock } from "lucide-react";
import StepCard from "../StepCard";
import { MiniStat } from "../createVoice/ui";
import VoiceGrid from "../createVoice/VoiceGrid";
import ProgressPill from "../ProgressPill";
import { RETENTION_MESSAGE } from "./constants";
import { TARGET_LANGUAGES } from "../../data/languages";
import { formatDateTime } from "../../utils/format";
import type { useTranslateDubState } from "./useTranslateDubState";

type Props = {
  state: ReturnType<typeof useTranslateDubState>;
};

const Step3Generate: React.FC<Props> = ({ state }) => {
  const {
    isGuest,
    isGenerating,
    outputUrl,
    outputFileRecord,
    generatePercent,
    generatePhase,
    fileActionKey,
    isBusy,
    saveProjectInProgress,
    projectModalPurpose,
    isStep3Complete,
    selectedVoice,
    selectedLanguage,
    sourceLanguageName,
    estimatedMinutes,
    outputFormat,
    error,

    // Actions
    handleDownloadOutput,
    handleDeleteStoredDub,
    handleSaveProjectClick,
    openLimitModal,

    // Re-generate with different voice (B9)
    voicesForTarget,
    setSelectedVoice,
    previewLoadingId,
    previewPlayingId,
    handlePreview,
    handleGenerate,
  } = state;

  const [showVoiceChanger, setShowVoiceChanger] =
    React.useState(false);

  const targetLangName =
    TARGET_LANGUAGES.find((l) => l.code === selectedLanguage)?.name ||
    selectedLanguage;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <StepCard
        step={3}
        title="Generate Dub"
        description="Create your final dubbed audio, then save and download."
        isActive={true}
        isCompleted={isStep3Complete}
      >
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200/50 dark:border-white/10 bg-slate-50/50 dark:bg-white/5 p-4">
            <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
              Click "Generate Dub" to create your final dubbed audio
              with the selected voice and settings.
            </p>
          </div>

          {/* Regional credit warning */}
          {!outputUrl && (() => {
            const voiceRegion = voicesForTarget.find((v) => v.id === selectedVoice)?.region;
            if (voiceRegion === "Indian" || voiceRegion === "SE Asian") {
              return (
                <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-start gap-3">
                  <svg className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                  </svg>
                  <div>
                    <p className="text-sm font-black text-amber-900 dark:text-amber-200">
                      Regional voice selected — 2× credits will be charged
                    </p>
                    <p className="mt-1 text-xs font-medium text-amber-800 dark:text-amber-300/80">
                      This voice uses <span className="font-black">2 credits per 100 characters</span>, double the standard rate. Make sure you have sufficient credits before generating.
                    </p>
                  </div>
                </div>
              );
            }
            return null;
          })()}

          {outputUrl ? (
            <>
              {/* Success banner */}
              <div className="rounded-2xl border border-green-500/20 bg-green-500/10 p-4">
                <p className="text-xs font-black uppercase tracking-widest text-green-700 dark:text-green-300">
                  Success! Your dub is ready.
                </p>
              </div>

              {/* Metadata card (C11) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <MiniStat
                  label="Duration"
                  value={`~${estimatedMinutes.toFixed(2)} min`}
                />
                <MiniStat
                  label="Voice"
                  value={String(selectedVoice)
                    .split("-")
                    .pop() || String(selectedVoice)}
                />
                <MiniStat
                  label="Language"
                  value={targetLangName}
                />
                <MiniStat
                  label="Format"
                  value={outputFormat.toUpperCase()}
                />
              </div>

              {/* Audio player (C7 — wrapped for dark mode) */}
              <div className="rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800">
                <audio
                  controls
                  src={outputUrl}
                  className="w-full"
                />
              </div>

              {/* Retention notice */}
              <div className="rounded-2xl border border-sky-500/20 bg-sky-500/10 p-4 text-sm font-semibold text-sky-900 dark:text-sky-100">
                {RETENTION_MESSAGE}
              </div>

              {/* Storage info */}
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold">
                <div>
                  Stored dub:{" "}
                  {outputFileRecord?.fileId
                    ? "Saved"
                    : "Not saved yet"}
                </div>
                <div>
                  {outputFileRecord?.expiresAt
                    ? `Stored until: ${formatDateTime(outputFileRecord.expiresAt)}`
                    : "Save this project to store the dub"}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                {isGuest ? (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        openLimitModal("voiceMinutes")
                      }
                      className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center gap-2"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      Download
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        openLimitModal("voiceMinutes")
                      }
                      className="px-4 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm"
                    >
                      Sign Up to Save
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={handleDownloadOutput}
                      disabled={
                        fileActionKey === "download-output"
                      }
                      className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {fileActionKey === "download-output"
                        ? "Downloading..."
                        : "Download"}
                    </button>
                    {outputFileRecord?.fileId && (
                      <button
                        type="button"
                        onClick={() => {
                          void handleDeleteStoredDub();
                        }}
                        disabled={
                          fileActionKey ===
                          `delete-${outputFileRecord.fileId}`
                        }
                        className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {fileActionKey ===
                        `delete-${outputFileRecord.fileId}`
                          ? "Deleting..."
                          : "Delete"}
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={handleSaveProjectClick}
                      disabled={
                        isBusy ||
                        saveProjectInProgress ||
                        Boolean(projectModalPurpose)
                      }
                      className="px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-black uppercase tracking-widest transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Save to Project
                    </button>
                  </>
                )}
              </div>

              {/* Re-generate with different voice (B9) */}
              {!isGuest && (
                <div className="border-t border-slate-200/50 dark:border-white/10 pt-4">
                  <button
                    type="button"
                    onClick={() =>
                      setShowVoiceChanger(!showVoiceChanger)
                    }
                    className="text-xs font-black uppercase tracking-widest text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors inline-flex items-center gap-2"
                  >
                    Change Voice & Regenerate
                    <svg
                      className={[
                        "w-4 h-4 transition-transform",
                        showVoiceChanger && "rotate-180",
                      ].join(" ")}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2.5}
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </button>
                  {showVoiceChanger && (
                    <div className="mt-4 space-y-4">
                      <VoiceGrid
                        voices={voicesForTarget}
                        selectedVoice={selectedVoice}
                        onSelectVoice={setSelectedVoice}
                        previewLoadingId={previewLoadingId}
                        previewPlayingId={previewPlayingId}
                        onPreview={handlePreview}
                      />
                      {(() => {
                        const voiceRegion = voicesForTarget.find((v) => v.id === selectedVoice)?.region;
                        if (voiceRegion === "Indian" || voiceRegion === "SE Asian") {
                          return (
                            <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-3 flex items-start gap-2.5">
                              <svg className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                              </svg>
                              <p className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                                Regional voice — <span className="font-black">2× credits</span> will be charged for this regeneration.
                              </p>
                            </div>
                          );
                        }
                        return null;
                      })()}
                      <button
                        type="button"
                        onClick={() => {
                          setShowVoiceChanger(false);
                          void handleGenerate();
                        }}
                        disabled={isBusy}
                        className="w-full px-4 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Regenerate with New Voice
                      </button>
                    </div>
                  )}
                </div>
              )}
            </>
          ) : (
            <div className="space-y-3">
              {isGenerating && (
                <>
                  <ProgressPill
                    label={
                      generatePhase ||
                      "Generating final dub"
                    }
                    percent={generatePercent}
                  />
                  {/* Elapsed time counter (B10) */}
                  <GenerateTimer />
                </>
              )}
            </div>
          )}
        </div>
      </StepCard>
    </div>
  );
};

/** Simple elapsed time counter shown during generation */
const GenerateTimer = () => {
  const [elapsed, setElapsed] = React.useState(0);
  React.useEffect(() => {
    const interval = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(interval);
  }, []);
  const mins = Math.floor(elapsed / 60);
  const secs = elapsed % 60;
  return (
    <div className="text-xs text-slate-500 dark:text-slate-400 font-semibold text-center">
      Elapsed: {mins > 0 ? `${mins}m ` : ""}
      {secs}s
    </div>
  );
};

export default Step3Generate;
