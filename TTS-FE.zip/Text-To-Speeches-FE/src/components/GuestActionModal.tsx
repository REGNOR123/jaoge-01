import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Rocket, UserPlus, X } from 'lucide-react';

interface GuestActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onContinueAsGuest?: () => void;
  redirectTo?: string;
  actionName?: string;
}

const GuestActionModal: React.FC<GuestActionModalProps> = ({
  isOpen,
  onClose,
  onContinueAsGuest,
  redirectTo = '/',
  actionName,
}) => {
  const navigate = useNavigate();

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSignup = () => {
    onClose();
    navigate('/signup', {
      state: {
        redirectTo,
        fromGuestAction: true,
      },
    });
  };

  const handleContinueAsGuest = () => {
    onClose();
    onContinueAsGuest?.();
  };

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xl animate-in fade-in duration-300"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="glass studio-card w-full max-w-md scale-in-center !p-8 relative">
        {/* Close button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900/30 dark:to-purple-900/30 flex items-center justify-center">
            <Rocket className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
          </div>
        </div>

        {/* Title */}
        <h2 className="text-2xl font-black text-center text-slate-900 dark:text-white tracking-tight">
          🚀 Continue Your Work
        </h2>

        {/* Message */}
        <p className="mt-3 text-center text-slate-600 dark:text-slate-300 leading-relaxed">
          Save your progress and unlock more features by signing up.
          {actionName && (
            <span className="block mt-2 text-sm text-slate-500 dark:text-slate-400">
              You're about to: <span className="font-medium">{actionName}</span>
            </span>
          )}
        </p>

        {/* Benefits preview */}
        <div className="mt-6 p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800/30">
          <ul className="space-y-2 text-sm text-indigo-600 dark:text-indigo-400">
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
              Save your projects forever
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
              Access your work from any device
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
              Get 5x more usage credits
            </li>
          </ul>
        </div>

        {/* Action buttons */}
        <div className="mt-6 flex flex-col gap-3">
          <button
            type="button"
            onClick={handleSignup}
            className="w-full px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold transition-all duration-200 hover:scale-[1.02] hover:shadow-lg hover:shadow-indigo-500/25 inline-flex items-center justify-center gap-2"
          >
            <UserPlus className="w-4 h-4" />
            Sign Up Free
          </button>
          <button
            type="button"
            onClick={handleContinueAsGuest}
            className="w-full px-6 py-3 rounded-xl border border-slate-200 dark:border-white/10 bg-white/80 dark:bg-white/5 hover:bg-slate-50 dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 text-sm font-bold transition-colors inline-flex items-center justify-center gap-2"
          >
            Continue as Guest
          </button>
        </div>

        {/* Footer note */}
        <p className="mt-4 text-center text-xs text-slate-400 dark:text-slate-500">
          Free sign-up • No credit card required
        </p>
      </div>
    </div>
  );
};

export default GuestActionModal;
