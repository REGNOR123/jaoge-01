import React from "react";

interface TabButtonProps {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

const TabButton = ({ active, onClick, children }: TabButtonProps) => (
  <button
    type="button"
    role="tab"
    aria-selected={active}
    onClick={onClick}
    className={[
      "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-colors",
      active
        ? "bg-indigo-600 text-white shadow-sm"
        : "text-slate-600 dark:text-slate-300 hover:bg-white/70 dark:hover:bg-white/10",
    ].join(" ")}
  >
    {children}
  </button>
);

export default TabButton;
