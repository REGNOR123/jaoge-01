import React from 'react';
import { cn } from '@/lib/utils';

export type UsageState = 'normal' | 'warning' | 'danger';

export interface UsageProgressBarProps {
  label: string;
  used: number;
  total: number;
  icon?: React.ReactNode;
  className?: string;
  showPercentage?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export function getUsageState(used: number, total: number): UsageState {
  const percentage = (used / total) * 100;
  if (percentage >= 100) return 'danger';
  if (percentage >= 70) return 'warning';
  return 'normal';
}

export function getUsageColors(state: UsageState) {
  switch (state) {
    case 'danger':
      return {
        bar: 'bg-red-500',
        track: 'bg-red-100 dark:bg-red-950/50',
        text: 'text-red-600 dark:text-red-400',
        badge: 'bg-red-100 text-red-700 dark:bg-red-950/50 dark:text-red-400',
      };
    case 'warning':
      return {
        bar: 'bg-amber-500',
        track: 'bg-amber-100 dark:bg-amber-950/50',
        text: 'text-amber-600 dark:text-amber-400',
        badge: 'bg-amber-100 text-amber-700 dark:bg-amber-950/50 dark:text-amber-400',
      };
    default:
      return {
        bar: 'bg-indigo-500',
        track: 'bg-indigo-100 dark:bg-indigo-950/50',
        text: 'text-indigo-600 dark:text-indigo-400',
        badge: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-400',
      };
  }
}

export function UsageProgressBar({
  label,
  used,
  total,
  icon,
  className,
  showPercentage = false,
  size = 'md',
}: UsageProgressBarProps) {
  const percentage = Math.min((used / total) * 100, 100);
  const state = getUsageState(used, total);
  const colors = getUsageColors(state);

  const heightClass = {
    sm: 'h-1.5',
    md: 'h-2',
    lg: 'h-3',
  }[size];

  // Format used value - show 2 decimals for decimal numbers, whole numbers for integers
  const formatValue = (val: number) => {
    if (Number.isInteger(val)) {
      return val.toLocaleString();
    }
    return val.toFixed(2);
  };

  return (
    <div className={cn('space-y-1.5', className)}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
          {icon && <span className="opacity-70">{icon}</span>}
          <span>{label}</span>
        </div>
        <div className={cn('text-xs font-semibold', colors.text)}>
          {formatValue(used)} / {total.toLocaleString()}
          {showPercentage && (
            <span className="ml-1 opacity-70">({Math.round(percentage)}%)</span>
          )}
        </div>
      </div>
      <div className={cn('w-full rounded-full overflow-hidden', heightClass, colors.track)}>
        <div
          className={cn(
            'h-full rounded-full transition-all duration-500 ease-out',
            colors.bar
          )}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

export default UsageProgressBar;
