
import React, { useState, useEffect } from 'react';
import { SpeechEntry } from '../types';
import { triggerDownload, audioBufferToWav } from '../utils/audioUtils';

interface HistoryItemProps {
  entry: SpeechEntry;
  onPlay: () => void;
  onDelete: () => void;
  isPlaying?: boolean;
  currentTime?: number;
  duration?: number;
  audioRef?: React.RefObject<HTMLAudioElement | null>;
  onSeek?: (time: number) => void;
  onTogglePlay?: () => void;
}

const HistoryItem: React.FC<HistoryItemProps> = ({
  entry,
  onPlay,
  onDelete,
  isPlaying = false,
  currentTime = 0,
  duration = 0,
  audioRef,
  onSeek,
  onTogglePlay,
}) => {
  const [isConverting, setIsConverting] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  const [volume, setVolume] = useState(1);

  const format = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (onSeek) onSeek(val);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setVolume(vol);
    if (audioRef?.current) {
      audioRef.current.volume = vol;
    }
  };

  const handleDownloadMp3 = () => {
    if (!entry.audioUrl) return;
    const filename = `${entry.recordingName.replace(/\s+/g, '-').toLowerCase()}.mp3`;
    triggerDownload(entry.audioUrl, filename);
    setShowOptions(false);
  };

  const handleDownloadWav = async () => {
    if (!entry.audioUrl || isConverting) return;
    
    setIsConverting(true);
    try {
      const response = await fetch(entry.audioUrl);
      const arrayBuffer = await response.arrayBuffer();
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
      
      const wavBlob = audioBufferToWav(audioBuffer);
      const wavUrl = URL.createObjectURL(wavBlob);
      const filename = `${entry.recordingName.replace(/\s+/g, '-').toLowerCase()}.wav`;
      
      triggerDownload(wavUrl, filename);
      setTimeout(() => URL.revokeObjectURL(wavUrl), 100);
    } catch (error) {
      console.error("WAV conversion failed:", error);
    } finally {
      setIsConverting(false);
      setShowOptions(false);
    }
  };

  return (
    <div className={`p-5 rounded-3xl border transition-all duration-300 relative animate-in fade-in slide-in-from-left-4 ${
      isPlaying
        ? 'border-indigo-500/60 bg-indigo-50 dark:bg-indigo-500/10'
        : 'border-slate-200 dark:border-white/5 bg-white dark:bg-white/5 hover:border-indigo-500/40 group'
    }`}>
      <div className="flex flex-col gap-4">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0 flex-1">
            <h3 className={`text-xs font-black truncate mb-1 ${
              isPlaying
                ? 'text-indigo-600 dark:text-indigo-400'
                : 'text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors'
            }`}>
              {entry.recordingName}
            </h3>
            <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
              {entry.voiceLabel.split('(')[0]} • {new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={onDelete}
              className={`w-10 h-10 rounded-2xl glass flex items-center justify-center transition-all shadow-sm ${
                isPlaying
                  ? 'text-red-500 opacity-100'
                  : 'text-slate-300 dark:text-slate-600 hover:text-red-500 hover:bg-red-500/10 opacity-0 group-hover:opacity-100'
              }`}
              title="Delete record"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            </button>
            <button
              onClick={isPlaying ? onTogglePlay : onPlay}
              className={`w-10 h-10 rounded-2xl glass flex items-center justify-center transition-all shadow-sm ${
                isPlaying
                  ? 'bg-indigo-600 text-white'
                  : 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-600 hover:text-white'
              }`}
              title={isPlaying ? 'Pause recording' : 'Play recording'}
            >
              {isPlaying ? (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
              ) : (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
              )}
            </button>
          </div>
        </div>

        {isPlaying && (
          <div className="pt-4 border-t border-indigo-200 dark:border-indigo-500/30 space-y-3 animate-in fade-in slide-in-from-top-2">
            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[9px] font-bold text-slate-600 dark:text-slate-400">
                <span>{format(currentTime)}</span>
                <span>{format(duration || 0)}</span>
              </div>
              <input
                type="range"
                min="0"
                max={duration || 0}
                step="0.01"
                value={currentTime}
                onChange={handleSeek}
                className="w-full h-1.5 bg-slate-200 dark:bg-white/10 rounded-full appearance-none cursor-pointer accent-indigo-600"
              />
            </div>

            {/* Controls Row */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  if (audioRef?.current) {
                    audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - 10);
                  }
                }}
                className="p-1.5 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                title="Rewind 10s"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0019 16V8a1 1 0 00-1.6-.8l-5.334 4zM4.066 11.2a1 1 0 000 1.6l5.334 4A1 1 0 0011 16V8a1 1 0 00-1.6-.8l-5.334 4z" /></svg>
              </button>

              {/* Volume Control */}
              <div className="flex-1 flex items-center gap-2">
                <svg className="w-3.5 h-3.5 text-slate-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071a1 1 0 01-1.414-1.414A7.971 7.971 0 0017.071 10a7.971 7.971 0 00-2.336-5.646 1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={volume}
                  onChange={handleVolumeChange}
                  className="flex-1 h-1 bg-slate-200 dark:bg-white/10 rounded-full appearance-none cursor-pointer accent-indigo-600"
                />
              </div>

              <button
                onClick={() => {
                  if (audioRef?.current) {
                    audioRef.current.currentTime = Math.min(duration, audioRef.current.currentTime + 10);
                  }
                }}
                className="p-1.5 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                title="Forward 10s"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11.934 12.8a1 1 0 000-1.6l-5.334-4A1 1 0 005 8v8a1 1 0 001.6.8l5.334-4zM19.934 12.8a1 1 0 000-1.6l-5.334-4A1 1 0 0013 8v8a1 1 0 001.6.8l5.334-4z" /></svg>
              </button>
            </div>
          </div>
        )}

        {!isPlaying && (
          <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-white/5">
            {!showOptions ? (
              <button
                onClick={() => setShowOptions(true)}
                className="flex-1 py-2 text-[9px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 dark:hover:text-white transition-all flex items-center justify-center gap-2"
              >
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                Export
              </button>
            ) : (
              <div className="flex items-center w-full bg-slate-100 dark:bg-black/40 rounded-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                <button
                  onClick={handleDownloadMp3}
                  className="flex-1 py-2.5 text-[9px] font-black text-slate-500 dark:text-slate-400 hover:bg-indigo-600 hover:text-white transition-all border-r border-slate-200 dark:border-white/5"
                >
                  MP3
                </button>
                <button
                  onClick={handleDownloadWav}
                  disabled={isConverting}
                  className="flex-1 py-2.5 text-[9px] font-black text-slate-500 dark:text-slate-400 hover:bg-indigo-600 hover:text-white transition-all disabled:opacity-50"
                >
                  {isConverting ? '...' : 'WAV'}
                </button>
                <button
                  onClick={() => setShowOptions(false)}
                  className="px-3 py-2.5 text-slate-400 hover:text-red-500 transition-colors"
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryItem;
