import React from "react";

const BASE_CLASSES = [
  "w-full",
  "sm:w-auto",
  "px-6",
  "py-3",
  "rounded-xl",
  "bg-indigo-600",
  "hover:bg-indigo-700",
  "text-white",
  "text-sm",
  "font-black",
  "uppercase",
  "tracking-widest",
  "transition-colors",
  "shadow-sm",
  "disabled:opacity-50",
  "disabled:cursor-not-allowed",
].join(" ");

export type ContinueButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement>;

const ContinueButton = React.forwardRef<HTMLButtonElement, ContinueButtonProps>(
  ({ className, type = "button", ...rest }, ref) => (
    <button
      ref={ref}
      type={type}
      className={[BASE_CLASSES, className].filter(Boolean).join(" ")}
      {...rest}
    />
  ),
);

ContinueButton.displayName = "ContinueButton";

export default ContinueButton;
