import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User, 
  Sparkles, 
  LogIn, 
  HelpCircle,
  ChevronRight
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProfileDropdownGuestProps {
  isOpen: boolean;
  onClose: () => void;
}

const ProfileDropdownGuest: React.FC<ProfileDropdownGuestProps> = ({ isOpen, onClose }) => {
  const navigate = useNavigate();

  if (!isOpen) return null;

  const handleSignup = () => {
    onClose();
    navigate('/signup', { state: { redirectTo: window.location.pathname } });
  };

  const handleLogin = () => {
    onClose();
    navigate('/login', { state: { redirectTo: window.location.pathname } });
  };

  const handleHelp = () => {
    onClose();
    navigate('/help');
  };

  return (
    <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-2xl shadow-slate-900/20 dark:shadow-black/50 py-2 z-50 overflow-hidden">
      {/* Guest User Header */}
      <div className="px-4 py-4 bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-indigo-500/10 dark:from-indigo-900/30 dark:via-purple-900/30 dark:to-indigo-900/30 border-b border-slate-200 dark:border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-600 flex items-center justify-center">
            <User className="w-6 h-6 text-slate-500 dark:text-slate-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-base font-bold text-slate-900 dark:text-white">
              Guest User
            </p>
            <p className="text-xs text-indigo-600 dark:text-indigo-300 font-semibold hover:underline cursor-pointer"
               onClick={handleSignup}>
              Signup for 200 free credits
            </p>
          </div>
          <span className="px-2 py-1 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 text-[10px] font-bold uppercase tracking-wider">
            Free Trial
          </span>
        </div>
      </div>

      {/* Primary CTA Group */}
      <div className="p-2">
        <button
          type="button"
          onClick={handleSignup}
          className={cn(
            'w-full px-4 py-3 rounded-xl text-left transition-all duration-200',
            'bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700',
            'text-white shadow-lg shadow-indigo-500/25 hover:shadow-xl hover:shadow-indigo-500/30',
            'hover:scale-[1.02]'
          )}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <span className="text-sm font-bold block">Sign Up</span>
              <span className="text-xs opacity-80">Get full access</span>
            </div>
            <ChevronRight className="w-4 h-4 opacity-70" />
          </div>
        </button>

        <button
          type="button"
          onClick={handleLogin}
          className={cn(
            'w-full mt-2 px-4 py-3 rounded-xl text-left transition-all duration-200',
            'border border-slate-200 dark:border-white/10',
            'bg-white/80 dark:bg-white/5 hover:bg-slate-50 dark:hover:bg-white/10',
            'text-slate-700 dark:text-slate-200'
          )}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-white/10 flex items-center justify-center">
              <LogIn className="w-4 h-4 text-slate-600 dark:text-slate-300" />
            </div>
            <div className="flex-1">
              <span className="text-sm font-bold block">Login</span>
              <span className="text-xs text-slate-500 dark:text-slate-400">Already have an account</span>
            </div>
            <ChevronRight className="w-4 h-4 opacity-50" />
          </div>
        </button>
      </div>

      {/* Divider */}
      <div className="my-2 mx-4 border-t border-slate-200 dark:border-white/10" />

      {/* Secondary Options */}
      <div className="px-2 pb-2">
        <button
          type="button"
          onClick={handleHelp}
          className="w-full px-4 py-2.5 rounded-xl text-left text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/10 transition-colors flex items-center gap-3"
        >
          <HelpCircle className="w-4 h-4 opacity-60" />
          Help & Support
        </button>
      </div>

      {/* Footer */}
      <div className="px-4 py-3 bg-slate-50 dark:bg-white/5 border-t border-slate-200 dark:border-white/10">
        <p className="text-[10px] text-slate-400 dark:text-slate-500 text-center">
          Sign up to save your work and unlock premium features
        </p>
      </div>
    </div>
  );
};

export default ProfileDropdownGuest;
