import React from "react";

const SuccessMessage = ({
  message,
  onClose,
}: {
  message: string;
  onClose?: () => void;
}) => {
  if (!message) return null;

  return (
    <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-emerald-700 dark:text-emerald-300 flex items-start justify-between gap-3">
      <div className="text-sm font-semibold">{message}</div>
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          className="text-xs font-black uppercase tracking-widest text-emerald-700/80 hover:text-emerald-700 dark:text-emerald-200/80 dark:hover:text-emerald-200 transition-colors"
        >
          Close
        </button>
      )}
    </div>
  );
};

export default SuccessMessage;

