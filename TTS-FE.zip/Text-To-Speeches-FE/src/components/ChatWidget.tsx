import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useCredits } from "../contexts/CreditContext";
import { sendChatMessage } from "../services/chatApiService";
import InsufficientCreditsModal from "./InsufficientCreditsModal";

type Role = "user" | "assistant";
type ChatMessage = { role: Role; content: string };

const CHAT_WIDGET_TOGGLE_EVENT = "chat-widget-toggle";
const CHAT_WIDGET_STATE_EVENT = "chat-widget-state-change";
const CHAT_WIDGET_OPEN_KEY = "chat_widget_open_v1";
const CHAT_WIDGET_VISITED_PREFIX = "chat_widget_visited_v1";

const ChatWidget: React.FC = () => {
  const { token, isAuthenticated, user } = useAuth();
  const { refreshBalance } = useCredits();

  const [isOpen, setIsOpen] = useState(() => {
    try {
      return localStorage.getItem(CHAT_WIDGET_OPEN_KEY) === "1";
    } catch {
      return false;
    }
  });
  const [isSending, setIsSending] = useState(false);
  const [sendingProgress, setSendingProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [insuffCredits, setInsuffCredits] = useState<{ required: number; current: number } | null>(null);
  const [isFirstVisit, setIsFirstVisit] = useState(false);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");

  const panelRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const canSend = useMemo(() => {
    return isOpen && !isSending && input.trim().length > 0;
  }, [isOpen, isSending, input]);

  const userName = useMemo(() => {
    const full = user?.fullName?.trim();
    if (full) return full;

    const emailName = user?.email?.split("@")[0]?.trim();
    if (emailName) {
      return emailName.charAt(0).toUpperCase() + emailName.slice(1);
    }

    return "there";
  }, [user?.email, user?.fullName]);

  const starterPrompts = [
    "List available tools",
    "Help me think through a problem",
    "Get more perspectives on a topic",
  ];

  useEffect(() => {
    const onToggleChat = () => setIsOpen((prev) => !prev);
    window.addEventListener(CHAT_WIDGET_TOGGLE_EVENT, onToggleChat);
    return () => window.removeEventListener(CHAT_WIDGET_TOGGLE_EVENT, onToggleChat);
  }, []);

  useEffect(() => {
    window.dispatchEvent(
      new CustomEvent(CHAT_WIDGET_STATE_EVENT, {
        detail: { isOpen },
      }),
    );

    try {
      localStorage.setItem(CHAT_WIDGET_OPEN_KEY, isOpen ? "1" : "0");
    } catch {
      // ignore
    }
  }, [isOpen]);

  useEffect(() => {
    const identity = user?.id ?? user?.email ?? "guest";
    const key = `${CHAT_WIDGET_VISITED_PREFIX}:${identity}`;

    try {
      setIsFirstVisit(localStorage.getItem(key) !== "1");
    } catch {
      setIsFirstVisit(true);
    }
  }, [user?.email, user?.id]);

  useEffect(() => {
    if (!isOpen || !isFirstVisit) return;

    const identity = user?.id ?? user?.email ?? "guest";
    const key = `${CHAT_WIDGET_VISITED_PREFIX}:${identity}`;
    try {
      localStorage.setItem(key, "1");
    } catch {
      // ignore
    }
  }, [isFirstVisit, isOpen, user?.email, user?.id]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIsOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const el = listRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages.length, isSending, isOpen]);

  useEffect(() => {
    if (!isSending) {
      setSendingProgress(0);
      return;
    }

    setSendingProgress(0);
    const intervalId = window.setInterval(() => {
      setSendingProgress((prev) => {
        const next = prev + Math.floor(Math.random() * 6) + 1;
        return next >= 95 ? 95 : next;
      });
    }, 160);

    return () => window.clearInterval(intervalId);
  }, [isSending]);

  const handleClear = () => {
    setMessages([]);
    setError(null);
  };

  const handleSend = async () => {
    const message = input.trim();
    if (!message || isSending) return;

    setError(null);
    setIsSending(true);
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: message }]);

    const res = await sendChatMessage(
      {
        message,
      },
      token,
    );

    if (res.success === false) {
      if (res.insufficientCredits) {
        setInsuffCredits({ required: res.requiredCredits ?? 0, current: res.currentBalance ?? 0 });
        setIsSending(false);
        return;
      }
      setError(res.error);
      setIsSending(false);
      return;
    }

    setMessages((prev) => [...prev, { role: "assistant", content: res.reply }]);
    setIsSending(false);
    void refreshBalance();
  };

  return (
    <>
    <InsufficientCreditsModal
      isOpen={!!insuffCredits}
      onClose={() => setInsuffCredits(null)}
      requiredCredits={insuffCredits?.required ?? 0}
      currentBalance={insuffCredits?.current ?? 0}
    />
      <div
        className={`fixed z-[190] top-16 right-0 h-[calc(100vh-4rem)] transition-transform duration-300 ease-out ${
          isOpen ? "translate-x-0" : "translate-x-full pointer-events-none"
        }`}
      >
        <div
          ref={panelRef}
          className="w-[min(100vw,420px)] h-[calc(100vh-4rem)] overflow-hidden bg-white dark:bg-slate-950 border-l border-black/10 dark:border-white/10 shadow-[-12px_0_36px_-20px_rgba(0,0,0,0.35)] flex flex-col"
        >
          <div className="h-16 px-5 border-b border-black/5 dark:border-white/10 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-600 to-fuchsia-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2.5}
                    d="M8 10h8M8 14h5m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <div>
                <div className="text-sm font-black text-slate-900 dark:text-white tracking-tight">Ask AI</div>
                <div className="mt-0.5 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span className="text-xs text-slate-500 dark:text-slate-400">Ready</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleClear}
                className="px-3 py-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 text-[10px] font-black uppercase tracking-widest transition-all"
              >
                Clear
              </button>
              <button
                onClick={() => (!isSending ? setIsOpen(false) : null)}
                className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-slate-100 dark:hover:bg-white/10 transition-all"
                aria-label="Close chat"
              >
                <svg
                  className="w-5 h-5 text-slate-600 dark:text-slate-300"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2.5}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          </div>

          {error && (
            <div className="px-5 py-3 bg-red-50/80 dark:bg-red-500/10 border-b border-red-200/60 dark:border-red-500/20 shrink-0">
              <p className="text-sm font-semibold text-red-700 dark:text-red-300">{error}</p>
            </div>
          )}

          <div
            ref={listRef}
            className="flex-1 min-h-0 overflow-y-auto thin-scrollbar px-5 py-5 space-y-3 bg-slate-50/50 dark:bg-white/5"
          >
            {messages.length === 0 ? (
              <div className="h-full flex flex-col justify-end">
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h2 className="text-[42px] leading-[1.08] font-extrabold tracking-tight text-indigo-300">
                      Hello, {userName}
                    </h2>
                    <p className="text-[42px] leading-[1.08] font-semibold tracking-tight text-slate-300">
                      How can I help you today?
                    </p>
                  </div>

                  {isFirstVisit && (
                    <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">
                      Welcome to Ask AI.
                    </p>
                  )}

                  <div className="space-y-2 pt-2">
                    {starterPrompts.map((prompt) => (
                      <button
                        key={prompt}
                        type="button"
                        onClick={() => setInput(prompt)}
                        className="w-full text-left rounded-2xl px-4 py-3 bg-slate-900/80 hover:bg-slate-900 text-slate-100 text-base leading-snug font-semibold transition-colors"
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>
                </div>

                {!isAuthenticated && (
                  <div className="rounded-2xl px-4 py-3 bg-white/95 dark:bg-slate-900/60 ring-1 ring-black/5 dark:ring-white/10 text-sm font-medium text-slate-700 dark:text-slate-200 leading-relaxed">
                    <Link
                      to="/signup"
                      className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                    >
                      Signup to get 200 free credits
                    </Link>{" "}
                    and unlock all features.
                  </div>
                )}
              </div>
            ) : (
              messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 shadow-sm ${
                      m.role === "user"
                        ? "bg-indigo-600 text-white"
                        : "bg-white/95 dark:bg-slate-900/60 text-slate-900 dark:text-white ring-1 ring-black/5 dark:ring-white/10"
                    }`}
                  >
                    <div className="text-sm leading-relaxed font-medium whitespace-pre-wrap">{m.content}</div>
                  </div>
                </div>
              ))
            )}

            {isSending && (
              <div className="flex justify-start">
                <div className="max-w-[85%] rounded-2xl px-4 py-3 shadow-sm bg-white/95 dark:bg-slate-900/60 text-slate-900 dark:text-white ring-1 ring-black/5 dark:ring-white/10">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full border-2 border-slate-300 dark:border-white/15 border-t-indigo-600 dark:border-t-indigo-400 animate-spin" />
                    <div className="text-sm font-medium tabular-nums text-slate-700 dark:text-slate-200">
                      {sendingProgress}%
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="px-5 py-4 border-t border-black/5 dark:border-white/10 bg-white/80 dark:bg-slate-950/50 shrink-0">
            <div className="flex flex-col gap-3">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    if (canSend) handleSend();
                  }
                }}
                placeholder="Type a message..."
                className="w-full min-h-[44px] max-h-28 resize-y px-4 py-3 rounded-2xl bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-white/10 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
              <button
                onClick={handleSend}
                disabled={!canSend}
                className={`w-full h-11 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-sm flex items-center justify-center gap-2 ${
                  canSend
                    ? "bg-gradient-to-r from-indigo-600 to-fuchsia-600 hover:from-indigo-500 hover:to-fuchsia-500 text-white"
                    : "bg-slate-200 dark:bg-white/10 text-slate-500 dark:text-slate-400 cursor-not-allowed"
                }`}
              >
                <span>Send</span>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 10l18-7-7 18-2-8-9-3z" />
                </svg>
              </button>
            </div>
            <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">Enter to send • Shift+Enter for newline • Esc to close</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default ChatWidget;
