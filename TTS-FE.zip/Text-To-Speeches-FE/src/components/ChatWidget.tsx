import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useCredits } from "../contexts/CreditContext";
import { sendChatMessage } from "../services/chatApiService";
import InsufficientCreditsModal from "./InsufficientCreditsModal";

type Role = "user" | "assistant";
type ChatMessage = { role: Role; content: string };

const STORAGE_KEY = "chat_widget_launcher_pos_v1";
const BUTTON_SIZE = 56;
const EDGE_MARGIN = 24;
const PANEL_GAP = 12;
const PANEL_WIDTH = 380;
const PANEL_ESTIMATED_HEIGHT = 560;

const ChatWidget: React.FC = () => {
  const { token, isAuthenticated } = useAuth();
  const { refreshBalance } = useCredits();

  const [isOpen, setIsOpen] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [sendingProgress, setSendingProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [insuffCredits, setInsuffCredits] = useState<{ required: number; current: number } | null>(null);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");

  const [launcherPos, setLauncherPos] = useState<{ x: number; y: number } | null>(null);

  const panelRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{
    pointerId: number | null;
    isDragging: boolean;
    moved: boolean;
    startX: number;
    startY: number;
    offsetX: number;
    offsetY: number;
  }>({
    pointerId: null,
    isDragging: false,
    moved: false,
    startX: 0,
    startY: 0,
    offsetX: 0,
    offsetY: 0,
  });

  const canSend = useMemo(() => {
    return isOpen && !isSending && input.trim().length > 0;
  }, [isOpen, isSending, input]);

  const clampPos = (pos: { x: number; y: number }) => {
    const maxX = Math.max(EDGE_MARGIN, window.innerWidth - BUTTON_SIZE - EDGE_MARGIN);
    const maxY = Math.max(EDGE_MARGIN, window.innerHeight - BUTTON_SIZE - EDGE_MARGIN);
    return {
      x: Math.min(Math.max(pos.x, EDGE_MARGIN), maxX),
      y: Math.min(Math.max(pos.y, EDGE_MARGIN), maxY),
    };
  };

  useEffect(() => {
    if (launcherPos) return;

    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        const x = typeof parsed?.x === "number" ? parsed.x : NaN;
        const y = typeof parsed?.y === "number" ? parsed.y : NaN;
        if (Number.isFinite(x) && Number.isFinite(y)) {
          setLauncherPos(clampPos({ x, y }));
          return;
        }
      } catch {
        // ignore
      }
    }

    setLauncherPos(
      clampPos({
        x: window.innerWidth - EDGE_MARGIN - BUTTON_SIZE,
        y: window.innerHeight - EDGE_MARGIN - BUTTON_SIZE,
      }),
    );
  }, [launcherPos]);

  useEffect(() => {
    if (!launcherPos) return;
    const onResize = () => setLauncherPos((prev) => (prev ? clampPos(prev) : prev));
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [launcherPos]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIsOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const onMouseDown = (e: MouseEvent) => {
      const target = e.target as Node;
      if (panelRef.current && !panelRef.current.contains(target)) {
        if (!isSending) setIsOpen(false);
      }
    };
    window.addEventListener("mousedown", onMouseDown);
    return () => window.removeEventListener("mousedown", onMouseDown);
  }, [isOpen, isSending]);

  useEffect(() => {
    if (!isOpen) return;
    const el = listRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages.length, isSending, isOpen]);

  useEffect(() => {
    if (!isSending) {
      setSendingProgress(0);
      return;
    }

    setSendingProgress(0);
    const intervalId = window.setInterval(() => {
      setSendingProgress((prev) => {
        const next = prev + Math.floor(Math.random() * 6) + 1;
        return next >= 95 ? 95 : next;
      });
    }, 160);

    return () => window.clearInterval(intervalId);
  }, [isSending]);

  const handleClear = () => {
    setMessages([]);
    setError(null);
  };

  const handleSend = async () => {
    const message = input.trim();
    if (!message || isSending) return;

    setError(null);
    setIsSending(true);
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: message }]);

    const res = await sendChatMessage(
      {
        message,
      },
      token,
    );

    if (res.success === false) {
      if (res.insufficientCredits) {
        setInsuffCredits({ required: res.requiredCredits ?? 0, current: res.currentBalance ?? 0 });
        setIsSending(false);
        return;
      }
      setError(res.error);
      setIsSending(false);
      return;
    }

    setMessages((prev) => [...prev, { role: "assistant", content: res.reply }]);
    setIsSending(false);
    void refreshBalance();
  };

  const shouldOpenAbove = launcherPos
    ? launcherPos.y > PANEL_ESTIMATED_HEIGHT + EDGE_MARGIN
    : true;
  const shouldAlignLeft = launcherPos
    ? launcherPos.x < PANEL_WIDTH - BUTTON_SIZE - EDGE_MARGIN
    : false;

  return (
    <>
    <InsufficientCreditsModal
      isOpen={!!insuffCredits}
      onClose={() => setInsuffCredits(null)}
      requiredCredits={insuffCredits?.required ?? 0}
      currentBalance={insuffCredits?.current ?? 0}
    />
    <div
      className="fixed z-[200]"
      style={
        launcherPos
          ? { left: `${launcherPos.x}px`, top: `${launcherPos.y}px` }
          : { left: `${window.innerWidth - EDGE_MARGIN - BUTTON_SIZE}px`, top: `${window.innerHeight - EDGE_MARGIN - BUTTON_SIZE}px` }
      }
    >
      {isOpen && (
        <div
          ref={panelRef}
          className="absolute w-[360px] sm:w-[380px] max-w-[calc(100vw-3rem)] rounded-3xl overflow-hidden bg-white/90 dark:bg-slate-950/80 backdrop-blur-xl shadow-[0_24px_80px_-40px_rgba(0,0,0,0.35)] dark:shadow-[0_24px_80px_-40px_rgba(0,0,0,0.7)] ring-1 ring-black/5 dark:ring-white/10"
          style={{
            ...(shouldOpenAbove
              ? { bottom: `${BUTTON_SIZE + PANEL_GAP}px` }
              : { top: `${BUTTON_SIZE + PANEL_GAP}px` }),
            ...(shouldAlignLeft ? { left: 0 } : { right: 0 }),
          }}
        >
          <div className="px-5 py-4 border-b border-black/5 dark:border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-indigo-600 to-fuchsia-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2.5}
                    d="M8 10h8M8 14h5m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <div>
                <div className="text-sm font-black text-slate-900 dark:text-white tracking-tight">Assistant</div>
                <div className="mt-0.5 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span className="text-xs text-slate-500 dark:text-slate-400">Ready</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleClear}
                className="px-3 py-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 text-[10px] font-black uppercase tracking-widest transition-all"
              >
                Clear
              </button>
              <button
                onClick={() => (!isSending ? setIsOpen(false) : null)}
                className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-slate-100 dark:hover:bg-white/10 transition-all"
                aria-label="Close chat"
              >
                <svg
                  className="w-5 h-5 text-slate-600 dark:text-slate-300"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2.5}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          </div>

          {error && (
            <div className="px-5 py-3 bg-red-50/80 dark:bg-red-500/10 border-b border-red-200/60 dark:border-red-500/20">
              <p className="text-sm font-semibold text-red-700 dark:text-red-300">{error}</p>
            </div>
          )}

          <div
            ref={listRef}
            className="h-[360px] overflow-y-auto px-5 py-5 space-y-3 bg-slate-50/50 dark:bg-white/5"
          >
            {messages.length === 0 ? (
              <div className="space-y-3">
                <div className="text-sm text-slate-600 dark:text-slate-400">
                  Start by sending a message.
                </div>
                {!isAuthenticated && (
                  <div className="rounded-2xl px-4 py-3 bg-white/95 dark:bg-slate-900/60 ring-1 ring-black/5 dark:ring-white/10 text-sm font-medium text-slate-700 dark:text-slate-200 leading-relaxed">
                    <Link
                      to="/signup"
                      className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                    >
                      Signup to get 200 free credits
                    </Link>{" "}
                    and unlock all features.
                  </div>
                )}
              </div>
            ) : (
              messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 shadow-sm ${
                      m.role === "user"
                        ? "bg-indigo-600 text-white"
                        : "bg-white/95 dark:bg-slate-900/60 text-slate-900 dark:text-white ring-1 ring-black/5 dark:ring-white/10"
                    }`}
                  >
                    <div className="text-sm leading-relaxed font-medium whitespace-pre-wrap">{m.content}</div>
                  </div>
                </div>
              ))
            )}

            {isSending && (
              <div className="flex justify-start">
                <div className="max-w-[85%] rounded-2xl px-4 py-3 shadow-sm bg-white/95 dark:bg-slate-900/60 text-slate-900 dark:text-white ring-1 ring-black/5 dark:ring-white/10">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full border-2 border-slate-300 dark:border-white/15 border-t-indigo-600 dark:border-t-indigo-400 animate-spin" />
                    <div className="text-sm font-medium tabular-nums text-slate-700 dark:text-slate-200">
                      {sendingProgress}%
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="px-5 py-4 border-t border-black/5 dark:border-white/10 bg-white/80 dark:bg-slate-950/50">
            <div className="flex flex-col gap-3">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    if (canSend) handleSend();
                  }
                }}
                placeholder="Type a message..."
                className="w-full min-h-[44px] max-h-28 resize-y px-4 py-3 rounded-2xl bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-white/10 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500"
              />
              <button
                onClick={handleSend}
                disabled={!canSend}
                className={`w-full h-11 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-sm flex items-center justify-center gap-2 ${
                  canSend
                    ? "bg-gradient-to-r from-indigo-600 to-fuchsia-600 hover:from-indigo-500 hover:to-fuchsia-500 text-white"
                    : "bg-slate-200 dark:bg-white/10 text-slate-500 dark:text-slate-400 cursor-not-allowed"
                }`}
              >
                <span>Send</span>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 10l18-7-7 18-2-8-9-3z" />
                </svg>
              </button>
            </div>
            <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">Enter to send • Shift+Enter for newline • Esc to close</p>
          </div>
        </div>
      )}

      {!isOpen && (
        <button
          onPointerDown={(e) => {
            if (!launcherPos) return;
            dragRef.current.pointerId = e.pointerId;
            dragRef.current.isDragging = true;
            dragRef.current.moved = false;
            dragRef.current.startX = e.clientX;
            dragRef.current.startY = e.clientY;
            dragRef.current.offsetX = e.clientX - launcherPos.x;
            dragRef.current.offsetY = e.clientY - launcherPos.y;
            (e.currentTarget as HTMLButtonElement).setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => {
            if (!launcherPos) return;
            if (!dragRef.current.isDragging) return;
            if (dragRef.current.pointerId !== e.pointerId) return;

            const dx = Math.abs(e.clientX - dragRef.current.startX);
            const dy = Math.abs(e.clientY - dragRef.current.startY);
            if (!dragRef.current.moved && (dx > 3 || dy > 3)) {
              dragRef.current.moved = true;
            }

            const next = clampPos({
              x: e.clientX - dragRef.current.offsetX,
              y: e.clientY - dragRef.current.offsetY,
            });
            setLauncherPos(next);
          }}
          onPointerUp={(e) => {
            if (!launcherPos) return;
            if (!dragRef.current.isDragging) return;
            if (dragRef.current.pointerId !== e.pointerId) return;

            dragRef.current.isDragging = false;
            dragRef.current.pointerId = null;

            try {
              localStorage.setItem(STORAGE_KEY, JSON.stringify(launcherPos));
            } catch {
              // ignore
            }

            if (!dragRef.current.moved) {
              setIsOpen(true);
            }
          }}
          onPointerCancel={() => {
            dragRef.current.isDragging = false;
            dragRef.current.pointerId = null;
          }}
          className="w-14 h-14 rounded-full bg-gradient-to-br from-indigo-600 to-fuchsia-600 hover:from-indigo-500 hover:to-fuchsia-500 text-white shadow-2xl shadow-indigo-600/30 flex items-center justify-center transition-all ring-1 ring-black/5"
          aria-label="Open chat bot"
          style={{ touchAction: "none" }}
        >
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {/* Robot icon */}
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2.5}
              d="M12 3v2m-5 4h10a3 3 0 013 3v4a4 4 0 01-4 4H8a4 4 0 01-4-4v-4a3 3 0 013-3z"
            />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2.5}
              d="M8 13h.01M16 13h.01"
            />
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2.5}
              d="M9 16h6"
            />
          </svg>
        </button>
      )}
    </div>
    </>
  );
};

export default ChatWidget;
