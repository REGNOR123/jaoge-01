
import React from 'react';
import { VoiceName, VoiceOption } from '../types';
import VoiceSelector from './VoiceSelector';

interface VoiceLibrarySidebarProps {
  voiceSearch: string;
  onVoiceSearchChange: (value: string) => void;
  filteredVoices: VoiceOption[];
  selectedVoice: VoiceName;
  onSelectVoice: (voice: VoiceName) => void;
}

const VoiceLibrarySidebar: React.FC<VoiceLibrarySidebarProps> = ({
  voiceSearch, onVoiceSearchChange, filteredVoices, selectedVoice, onSelectVoice
}) => {
  return (
    <aside className="lg:col-span-3 space-y-8">
      <div className="sidebar-title">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
        Neural Voice Library
      </div>
      <input 
        type="text" 
        placeholder="Filter voices..." 
        value={voiceSearch} 
        onChange={(e) => onVoiceSearchChange(e.target.value)} 
        className="w-full bg-slate-100/50 dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-2xl py-4 px-6 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all" 
      />
      <div className="max-h-[75vh] overflow-y-auto scrollbar-hide">
        <VoiceSelector voices={filteredVoices} selectedVoice={selectedVoice} onSelect={onSelectVoice} />
      </div>
    </aside>
  );
};

export default VoiceLibrarySidebar;
