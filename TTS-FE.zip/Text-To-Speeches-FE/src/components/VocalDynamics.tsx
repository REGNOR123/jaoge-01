
import React from 'react';

interface VocalDynamicsProps {
  isOpen: boolean;
  onToggle: () => void;
  rate: number;
  pitch: number;
  volume: number;
  onRateChange: (value: number) => void;
  onPitchChange: (value: number) => void;
  onVolumeChange: (value: number) => void;
  onReset: () => void;
}

const VocalDynamics: React.FC<VocalDynamicsProps> = ({
  isOpen, onToggle, rate, pitch, volume, onRateChange, onPitchChange, onVolumeChange, onReset
}) => {
  const handleResetClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onReset();
  };

  return (
    <div className="rounded-4xl border border-black/5 dark:border-white/5 bg-slate-50 dark:bg-white/5 overflow-hidden transition-all duration-300">
      <button 
        onClick={onToggle}
        className="w-full px-8 py-6 flex items-center justify-between hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
      >
        <div className="flex items-center gap-4">
          <div className="w-1.5 h-1.5 rounded-full bg-indigo-500"></div>
          <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-500">Vocal Dynamics</h3>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={handleResetClick}
            className="text-[9px] font-black uppercase tracking-widest text-indigo-500 hover:text-indigo-600 transition-colors px-3 py-1 rounded-full bg-indigo-500/5"
          >
            Reset
          </button>
          <svg className={`w-4 h-4 text-slate-400 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" /></svg>
        </div>
      </button>
      
      {isOpen && (
        <div className="px-8 pb-8 pt-2 animate-in slide-in-from-top-2 duration-300">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase"><span>Tempo</span><span>{(1 + rate/100).toFixed(1)}x</span></div>
              <input type="range" min="-100" max="100" value={rate} onChange={(e) => onRateChange(parseInt(e.target.value))} className="w-full" />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase"><span>Pitch Shift</span><span>{pitch}%</span></div>
              <input type="range" min="-100" max="100" value={pitch} onChange={(e) => onPitchChange(parseInt(e.target.value))} className="w-full" />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase"><span>Volume</span><span>{volume}%</span></div>
              <input type="range" min="0" max="100" value={volume} onChange={(e) => onVolumeChange(parseInt(e.target.value))} className="w-full" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VocalDynamics;
