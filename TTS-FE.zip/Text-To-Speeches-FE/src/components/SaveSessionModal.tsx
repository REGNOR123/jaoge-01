
import React from 'react';
import { SpeechEntry } from '../types';

interface SaveSessionModalProps {
  pendingEntry: Partial<SpeechEntry>;
  recordingName: string;
  onRecordingNameChange: (name: string) => void;
  onDiscard: () => void;
  onSave: () => void;
}

const SaveSessionModal: React.FC<SaveSessionModalProps> = ({
  pendingEntry, recordingName, onRecordingNameChange, onDiscard, onSave
}) => {
  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-slate-900/60 dark:bg-black/80 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="glass studio-card w-full max-w-lg scale-in-center !p-12">
        <h2 className="text-3xl font-black text-slate-900 dark:text-white text-center mb-2">Save Session</h2>
        <p className="text-slate-500 dark:text-slate-400 text-center text-sm mb-10">Assign a name to your auditory project.</p>
        <input
          type="text"
          value={recordingName}
          onChange={(e) => onRecordingNameChange(e.target.value)}
          autoFocus
          className="w-full bg-slate-100/50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-3xl p-6 text-center text-xl font-bold text-slate-900 dark:text-white outline-none transition-all mb-10"
        />
        <div className="grid grid-cols-2 gap-4">
          <button onClick={onDiscard} className="py-5 text-slate-400 hover:text-slate-900 font-bold transition-all text-xs uppercase tracking-widest">Discard</button>
          <button onClick={onSave} className="bg-indigo-600 hover:bg-indigo-500 py-5 rounded-3xl text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-indigo-600/20 active:scale-95">Add to Archive</button>
        </div>
      </div>
    </div>
  );
};

export default SaveSessionModal;
