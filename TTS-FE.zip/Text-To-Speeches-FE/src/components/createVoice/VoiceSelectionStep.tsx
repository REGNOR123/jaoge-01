import React, { useEffect, useMemo, useState } from "react";
import { VoiceName, VoiceRegion, type VoiceOption } from "../../types";
import { Slider } from "./ui";
import { toneFromDescription } from "./utils";

type GenderFilter = "All" | "Male" | "Female";
type RegionFilter = "All" | VoiceRegion;

const REGION_OPTIONS: RegionFilter[] = [
  "All",
  "English",
  "Indian",
  "SE Asian",
  "East Asian",
  "European",
  "Middle Eastern",
];

const VoiceSelectionStep = ({
  languageLabel,
  voices,
  readOnly = false,
  selectedVoice,
  onSelectVoice,
  previewLoadingId,
  previewPlayingId,
  onPreview,
  advancedOpen,
  onToggleAdvanced,
  rate,
  onRateChange,
  pitch,
  onPitchChange,
  searchQuery = "",
  onSearchChange,
  genderFilter = "All",
  onGenderFilterChange,
  regionFilter = "All",
  onRegionFilterChange,
}: {
  languageLabel: string;
  voices: VoiceOption[];
  readOnly?: boolean;
  selectedVoice: VoiceName;
  onSelectVoice: (voice: VoiceName) => void;
  previewLoadingId: VoiceName | null;
  previewPlayingId: VoiceName | null;
  onPreview: (voice: VoiceName) => void;
  advancedOpen: boolean;
  onToggleAdvanced: () => void;
  rate: number;
  onRateChange: (value: number) => void;
  pitch: number;
  onPitchChange: (value: number) => void;
  searchQuery?: string;
  onSearchChange?: (value: string) => void;
  genderFilter?: GenderFilter;
  onGenderFilterChange?: (value: GenderFilter) => void;
  regionFilter?: RegionFilter;
  onRegionFilterChange?: (value: RegionFilter) => void;
}) => {
  const filteredVoices = useMemo(() => {
    let result = voices;
    if (regionFilter !== "All") {
      result = result.filter((v) => v.region === regionFilter);
    }
    if (genderFilter !== "All") {
      result = result.filter((v) => v.gender === genderFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      result = result.filter(
        (v) =>
          v.name.toLowerCase().includes(q) ||
          v.description.toLowerCase().includes(q),
      );
    }
    return result;
  }, [voices, regionFilter, genderFilter, searchQuery]);

  const availableRegions = useMemo(() => {
    const regions = new Set(voices.map((v) => v.region));
    return REGION_OPTIONS.filter((r) => r === "All" || regions.has(r as VoiceRegion));
  }, [voices]);

  const genderOptions: GenderFilter[] = ["All", "Male", "Female"];

  const isRegionalVoiceSet = voices.length > 0 && (
    voices[0].region === "Indian" || voices[0].region === "SE Asian"
  );

  const [regionalDismissed, setRegionalDismissed] = useState(false);
  useEffect(() => { setRegionalDismissed(false); }, [isRegionalVoiceSet]);

  return (
    <section className="glass studio-card !p-8 space-y-6">
      {readOnly && (
        <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-5 text-sm font-semibold text-slate-700 dark:text-slate-200">
          Complete Step 1 to select a voice.
        </div>
      )}

      {!readOnly && isRegionalVoiceSet && !regionalDismissed && (
        <div className="relative rounded-3xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-start gap-3">
          <svg className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
          </svg>
          <div>
            <p className="text-sm font-black text-amber-900 dark:text-amber-200">
              Regional language detected — 2× credit rate applies
            </p>
            <p className="mt-1 text-xs font-medium text-amber-800 dark:text-amber-300/80">
              Indian and Southeast Asian voices are charged at <span className="font-black">2 credits per 100 characters</span> (vs. 1 credit for standard voices). Ensure you have sufficient credits before generating.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setRegionalDismissed(true)}
            className="absolute top-2 right-2 p-1 rounded-md text-amber-600 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-200 hover:bg-amber-500/15 transition-colors"
            aria-label="Dismiss"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            Voice Selection
          </h2>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 font-medium">
            Choose a voice for your detected language, then tweak advanced settings if needed.
          </p>
        </div>

        {languageLabel ? (
          <div className="text-sm font-semibold text-slate-600 dark:text-slate-300">
            Detected language:{" "}
            <span className="font-black text-slate-900 dark:text-white">{languageLabel}</span>
          </div>
        ) : null}
      </div>

      {/* Region Filter */}
      {availableRegions.length > 2 && (
        <div className="flex flex-wrap gap-1.5">
          {availableRegions.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => onRegionFilterChange?.(r)}
              disabled={readOnly}
              className={[
                "px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-widest transition-colors",
                regionFilter === r
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-white/10",
                readOnly ? "opacity-50 cursor-not-allowed" : "",
              ].join(" ")}
            >
              {r}
            </button>
          ))}
        </div>
      )}

      {/* Search & Gender Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <svg
            className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-500 pointer-events-none"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange?.(e.target.value)}
            placeholder="Search voices..."
            disabled={readOnly}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-sm font-medium text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
          />
        </div>
        <div className="flex items-center gap-1 p-1 rounded-xl bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-white/10">
          {genderOptions.map((g) => (
            <button
              key={g}
              type="button"
              onClick={() => onGenderFilterChange?.(g)}
              disabled={readOnly}
              className={[
                "px-3 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-colors",
                genderFilter === g
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-white/10",
                readOnly ? "opacity-50 cursor-not-allowed" : "",
              ].join(" ")}
            >
              {g}
            </button>
          ))}
        </div>
      </div>

      {voices.length === 0 && (
        <div className="rounded-3xl border border-amber-500/20 bg-amber-500/10 p-5 text-sm font-semibold text-amber-900 dark:text-amber-200">
          No voices found for the detected language. Try adjusting the script text.
        </div>
      )}

      {voices.length > 0 && filteredVoices.length === 0 && (
        <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-5 text-sm font-semibold text-slate-600 dark:text-slate-300 text-center">
          No voices match your filters. Try a different search or filter.
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredVoices.map((voice) => {
          const isSelected = voice.id === selectedVoice;
          const isPlaying = previewPlayingId === voice.id;
          const isLoading = previewLoadingId === voice.id;
          return (
            <button
              key={voice.id}
              type="button"
              onClick={() => {
                if (readOnly) return;
                onSelectVoice(voice.id as VoiceName);
              }}
              disabled={readOnly}
              className={[
                "text-left rounded-3xl p-5 border transition-all group",
                "shadow-sm hover:shadow-lg hover:shadow-indigo-600/10",
                isSelected
                  ? "bg-indigo-600 text-white border-indigo-600"
                  : "glass border-black/5 dark:border-white/10 text-slate-900 dark:text-white hover:border-indigo-500/25",
                readOnly ? "opacity-60 cursor-not-allowed hover:shadow-sm" : "",
              ].join(" ")}
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-sm font-black tracking-tight">{voice.name}</div>
                  <div
                    className={[
                      "mt-1 text-[10px] font-black uppercase tracking-widest",
                      isSelected
                        ? "text-indigo-100"
                        : "text-slate-500 dark:text-slate-400",
                    ].join(" ")}
                  >
                    {voice.gender} • {toneFromDescription(voice.description)}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (readOnly) return;
                    onPreview(voice.id as VoiceName);
                  }}
                  disabled={readOnly}
                  className={[
                    "h-10 w-10 rounded-2xl flex items-center justify-center transition-colors border",
                    isSelected
                      ? "bg-white/15 hover:bg-white/20 border-white/20"
                      : "bg-white/60 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 border-slate-200 dark:border-white/10",
                    readOnly ? "opacity-60 cursor-not-allowed" : "",
                  ].join(" ")}
                  aria-label="Preview voice"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-slate-300 border-t-indigo-600 rounded-full animate-spin" />
                  ) : isPlaying ? (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z"
                        clipRule="evenodd"
                      />
                    </svg>
                  ) : (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"
                        clipRule="evenodd"
                      />
                    </svg>
                  )}
                </button>
              </div>

              <div
                className={[
                  "mt-3 text-xs font-medium leading-relaxed",
                  isSelected ? "text-indigo-100" : "text-slate-600 dark:text-slate-300",
                ].join(" ")}
              >
                {voice.description}
              </div>
            </button>
          );
        })}
      </div>

      <div className="pt-2">
        <button
          type="button"
          onClick={onToggleAdvanced}
          disabled={readOnly}
          className="w-full flex items-center justify-between px-4 py-3 rounded-2xl border border-slate-200 dark:border-white/10 bg-white/60 dark:bg-white/5 hover:bg-white dark:hover:bg-white/10 transition-colors text-xs font-black uppercase tracking-widest text-slate-600 dark:text-slate-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <span>Speed &amp; Pitch Settings</span>
          <svg
            className={`w-4 h-4 transition-transform duration-300 ${advancedOpen ? "rotate-180" : ""}`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        {advancedOpen && (
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <Slider label="Speed" value={rate} min={-50} max={50} onChange={onRateChange} disabled={readOnly} />
            <Slider label="Pitch" value={pitch} min={-50} max={50} onChange={onPitchChange} disabled={readOnly} />
          </div>
        )}
      </div>
    </section>
  );
};

export default VoiceSelectionStep;
