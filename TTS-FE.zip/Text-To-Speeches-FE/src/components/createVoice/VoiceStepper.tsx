import React from "react";

const VoiceStepper = ({
  step,
  onStepChange,
  maxStepUnlocked,
  isStep1Complete,
}: {
  step: 1 | 2 | 3;
  onStepChange: (step: 1 | 2 | 3) => void;
  maxStepUnlocked: 1 | 2 | 3;
  isStep1Complete: boolean;
}) => {
  const steps: { id: 1 | 2 | 3; label: string }[] = [
    { id: 1, label: "Script" },
    { id: 2, label: "Voice" },
    { id: 3, label: "Generate" },
  ];

  return (
    <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
      {steps.map((s, idx) => {
        const isActive = s.id === step;
        const isDone = s.id < step;
        const isLocked = isStep1Complete && s.id > maxStepUnlocked;
        return (
          <button
            key={s.id}
            type="button"
            onClick={() => onStepChange(s.id)}
            disabled={isLocked}
            className={[
              "flex items-center gap-3 px-4 py-3 rounded-2xl border transition-colors text-left",
              isActive
                ? "bg-indigo-600 text-white border-indigo-600"
                : isLocked
                  ? "bg-white/40 dark:bg-white/5 border-slate-200 dark:border-white/10 text-slate-400 dark:text-slate-500 opacity-80"
                  : "bg-white/70 dark:bg-white/5 border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-white/10",
            ].join(" ")}
          >
            <span
              className={[
                "h-7 w-7 rounded-xl flex items-center justify-center text-[10px] font-black uppercase tracking-widest border",
                isActive
                  ? "bg-white/15 border-white/20"
                  : isDone
                    ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-700 dark:text-emerald-300"
                    : isLocked
                      ? "bg-slate-50 dark:bg-white/5 border-slate-200 dark:border-white/10 text-slate-400 dark:text-slate-500"
                      : "bg-slate-100 dark:bg-white/5 border-slate-200 dark:border-white/10",
              ].join(" ")}
            >
              {isDone ? "✓" : isLocked ? "🔒" : s.id}
            </span>
            <div className="min-w-0">
              <div className="text-xs font-black uppercase tracking-widest truncate">
                Step {s.id}
              </div>
              <div className="text-sm font-semibold truncate">{s.label}</div>
            </div>
            {idx < steps.length - 1 && (
              <span className="hidden sm:inline-flex ml-2 text-slate-300 dark:text-slate-700">
                →
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};

export default VoiceStepper;
