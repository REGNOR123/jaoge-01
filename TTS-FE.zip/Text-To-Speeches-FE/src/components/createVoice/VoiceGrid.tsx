import React from "react";
import { VoiceName, type VoiceOption } from "../../types";
import { toneFromDescription } from "./utils";

const VoiceGrid = ({
  voices,
  selectedVoice,
  onSelectVoice,
  previewLoadingId,
  previewPlayingId,
  onPreview,
  columns = "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
}: {
  voices: VoiceOption[];
  selectedVoice: VoiceName;
  onSelectVoice: (voice: VoiceName) => void;
  previewLoadingId: VoiceName | null;
  previewPlayingId: VoiceName | null;
  onPreview: (voice: VoiceName) => void;
  columns?: string;
}) => {
  return (
    <div className={`grid ${columns} gap-4`}>
      {voices.map((voice) => {
        const isSelected = voice.id === selectedVoice;
        const isPlaying = previewPlayingId === voice.id;
        const isLoading = previewLoadingId === voice.id;
        return (
          <button
            key={voice.id}
            type="button"
            onClick={() => onSelectVoice(voice.id as VoiceName)}
            className={[
              "text-left rounded-3xl p-5 border transition-all group",
              "shadow-sm hover:shadow-lg hover:shadow-indigo-600/10",
              isSelected
                ? "bg-indigo-600 text-white border-indigo-600"
                : "glass border-black/5 dark:border-white/10 text-slate-900 dark:text-white hover:border-indigo-500/25",
            ].join(" ")}
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-sm font-black tracking-tight">{voice.name}</div>
                <div
                  className={[
                    "mt-1 text-[10px] font-black uppercase tracking-widest",
                    isSelected ? "text-indigo-100" : "text-slate-500 dark:text-slate-400",
                  ].join(" ")}
                >
                  {voice.gender} • {toneFromDescription(voice.description)}
                </div>
              </div>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onPreview(voice.id as VoiceName);
                }}
                className={[
                  "h-10 w-10 rounded-2xl flex items-center justify-center transition-colors border",
                  isSelected
                    ? "bg-white/15 hover:bg-white/20 border-white/20"
                    : "bg-white/60 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 border-slate-200 dark:border-white/10",
                ].join(" ")}
                aria-label="Preview voice"
              >
                {isLoading ? (
                  <div className="w-4 h-4 border-2 border-slate-300 border-t-indigo-600 rounded-full animate-spin" />
                ) : isPlaying ? (
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z"
                      clipRule="evenodd"
                    />
                  </svg>
                ) : (
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"
                      clipRule="evenodd"
                    />
                  </svg>
                )}
              </button>
            </div>

            <div
              className={[
                "mt-3 text-xs font-medium leading-relaxed",
                isSelected ? "text-indigo-100" : "text-slate-600 dark:text-slate-300",
              ].join(" ")}
            >
              {voice.description}
            </div>
          </button>
        );
      })}
    </div>
  );
};

export default VoiceGrid;

