import React, { useEffect, useState } from "react";
import { MAX_TEXT_LENGTH } from "../../constants";
import ProgressPill from "../ProgressPill";

const ScriptStep = ({
  text,
  onTextChange,
  isDetecting,
  detectedLang,
  isRegional,
  isTextTooLong,
  estimatedMinutes,
  isEnhancing,
  enhancePercent,
  enhanceError,
  onEnhance,
}: {
  text: string;
  onTextChange: (value: string) => void;
  isDetecting: boolean;
  detectedLang: string | null;
  isRegional: boolean;
  isTextTooLong: boolean;
  estimatedMinutes: number;
  isEnhancing: boolean;
  enhancePercent: number;
  enhanceError: string | null;
  onEnhance: () => void;
}) => {
  const disableUntilScript = text.trim().length === 0;
  const [regionalDismissed, setRegionalDismissed] = useState(false);

  useEffect(() => {
    setRegionalDismissed(false);
  }, [detectedLang]);

  return (
    <section className="glass studio-card !p-5 sm:!p-6 space-y-3">
      <div className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/40 dark:bg-white/5 p-3 sm:p-4 space-y-2">
        <div className="flex items-center justify-between gap-3">
          <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
            Script text
          </label>
          {isEnhancing ? (
            <div className="min-w-[170px]">
              <ProgressPill label="Enhancing" percent={enhancePercent} />
            </div>
          ) : (
            <button
              type="button"
              onClick={onEnhance}
              disabled={disableUntilScript}
              className="px-3 py-2 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-[10px] font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Enhance with AI
            </button>
          )}
        </div>

        <textarea
          value={text}
          onChange={(e) => onTextChange(e.target.value)}
          maxLength={MAX_TEXT_LENGTH}
          placeholder="Write or paste your script..."
          className="w-full min-h-[240px] rounded-2xl bg-slate-100/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 px-4 py-3 text-sm font-medium text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 resize-none leading-relaxed"
        />
      </div>

      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
        <span>
          {text.length} / {MAX_TEXT_LENGTH} chars
        </span>
        <span>Estimated voice usage: {estimatedMinutes.toFixed(2)} mins</span>
        <span>Detected language :</span>
        {isDetecting ? (
          <span>Processing...</span>
        ) : detectedLang && detectedLang !== "Unknown" ? (
          <>
            <span className=" font-black tracking-widest text-emerald-600 dark:text-emerald-300">
              {detectedLang}
            </span>
          </>
        ) : text.trim().length >= 5 ? (
          <span className="font-semibold text-amber-600 dark:text-amber-400">
            Language not recognized. Please check your text.
          </span>
        ) : null}
        {isTextTooLong && (
          <span className="text-red-600 dark:text-red-400">
            Script exceeds maximum length.
          </span>
        )}
      </div>

      {isRegional && detectedLang && detectedLang !== "Unknown" && !isDetecting && !regionalDismissed && (
        <div className="relative rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-start gap-3">
          <svg className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
          </svg>
          <div>
            <p className="text-sm font-black text-amber-900 dark:text-amber-200">
              Regional language detected ({detectedLang}) — 2× credit rate applies
            </p>
            <p className="mt-1 text-xs font-medium text-amber-800 dark:text-amber-300/80">
              Indian and Southeast Asian voices are charged at{" "}
              <span className="font-black">2 credits per 100 characters</span>{" "}
              (vs. 1 credit for standard voices). Ensure you have sufficient credits before generating.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setRegionalDismissed(true)}
            className="absolute top-2 right-2 p-1 rounded-md text-amber-600 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-200 hover:bg-amber-500/15 transition-colors"
            aria-label="Dismiss"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      )}

      {enhanceError && (
        <div className="text-xs font-semibold text-red-600 dark:text-red-400">
          {enhanceError}
        </div>
      )}
    </section>
  );
};

export default ScriptStep;
