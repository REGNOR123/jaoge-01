import React from "react";

export type ActionType = "continue" | "generate" | "custom";

export interface BottomActionBarProps {
  currentStep: number;
  totalSteps: number;
  canGoBack: boolean;
  canGoForward: boolean;
  primaryActionLabel: string;
  primaryActionDisabled?: boolean;
  primaryActionLoading?: boolean;
  primaryActionProgress?: number;
  onPrevious: () => void;
  onPrimaryAction: () => void;
  showPrimaryAction?: boolean;
  isGuestLocked?: boolean;
}

const BottomActionBar = ({
  currentStep,
  totalSteps,
  canGoBack,
  canGoForward,
  primaryActionLabel,
  primaryActionDisabled = false,
  primaryActionLoading = false,
  primaryActionProgress = 0,
  onPrevious,
  onPrimaryAction,
  showPrimaryAction = true,
  isGuestLocked = false,
}: BottomActionBarProps) => {
  return (
    <div className="sticky bottom-0 left-0 right-0 z-40 mt-8">
      {/* Glass background with blur */}
      <div className="glass border-t border-slate-200 dark:border-white/10 backdrop-blur-xl bg-white/90 dark:bg-slate-900/90 shadow-2xl rounded-2xl">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between gap-4">
            {/* Previous Button */}
            <button
              type="button"
              onClick={onPrevious}
              disabled={!canGoBack}
              className={[
                "px-4 sm:px-6 py-3 rounded-xl font-black text-xs sm:text-sm uppercase tracking-widest transition-all duration-300",
                "border border-slate-200 dark:border-white/10",
                canGoBack
                  ? "bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white shadow-sm hover:shadow-md hover:-translate-y-0.5"
                  : "bg-slate-100/50 dark:bg-white/5 text-slate-400 dark:text-slate-500 cursor-not-allowed opacity-50",
              ].join(" ")}
            >
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
                </svg>
                <span className="hidden sm:inline">Previous</span>
                <span className="sm:hidden">Back</span>
              </span>
            </button>

            {/* Step Indicator */}
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-slate-100/70 dark:bg-white/10 border border-slate-200 dark:border-white/10">
              <div className="text-xs sm:text-sm font-black text-slate-600 dark:text-slate-300 tracking-wider">
                Step {currentStep} of {totalSteps}
              </div>
            </div>

            {/* Primary Action Button */}
            {showPrimaryAction && (
              <button
                type="button"
                onClick={onPrimaryAction}
                disabled={isGuestLocked ? false : (primaryActionDisabled || primaryActionLoading || !canGoForward)}
                className={[
                  "px-4 sm:px-6 py-3 rounded-xl font-black text-xs sm:text-sm uppercase tracking-widest transition-all duration-300",
                  "relative overflow-hidden",
                  isGuestLocked
                    ? "bg-amber-500 hover:bg-amber-600 text-white shadow-sm hover:shadow-md hover:-translate-y-0.5"
                    : !primaryActionDisabled && !primaryActionLoading && canGoForward
                      ? "bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg hover:shadow-xl hover:shadow-indigo-500/30 hover:-translate-y-0.5"
                      : "bg-slate-300 dark:bg-slate-700 text-slate-500 dark:text-slate-400 cursor-not-allowed opacity-50",
                ].join(" ")}
              >
                {primaryActionLoading && (
                  <div
                    className="absolute left-0 top-0 bottom-0 bg-white/20 transition-all duration-300"
                    style={{ width: `${Math.min(primaryActionProgress, 100)}%` }}
                  />
                )}
                <span className="relative z-10 flex items-center gap-2">
                  {primaryActionLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>{Math.round(primaryActionProgress)}%</span>
                    </>
                  ) : isGuestLocked ? (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                      <span>Sign Up to {primaryActionLabel}</span>
                    </>
                  ) : (
                    <>
                      <span>{primaryActionLabel}</span>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
                      </svg>
                    </>
                  )}
                </span>
              </button>
            )}

            {!showPrimaryAction && <div className="w-[120px] sm:w-[140px]" />}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BottomActionBar;
