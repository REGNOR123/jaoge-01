import type { Dispatch, SetStateAction } from "react";
import type { VoiceName, VoiceOption } from "../../types";

export type SpeechSynthesisLike = {
  text: string;
  setText: Dispatch<SetStateAction<string>>;
  isTextTooLong: boolean;
  isTextEmpty: boolean;
  isDetecting: boolean;
  detectedLang: string | null;
  isMismatched: boolean;

  selectedVoice: VoiceName;
  setSelectedVoice: Dispatch<SetStateAction<VoiceName>>;
  selectedVoiceInfo?: VoiceOption;

  rate: number;
  setRate: Dispatch<SetStateAction<number>>;
  pitch: number;
  setPitch: Dispatch<SetStateAction<number>>;

  isProcessing: boolean;
  progress: number;
  error: string | null;
  insufficientCreditsInfo: { required: number; current: number } | null;
  clearInsuffCreditsInfo: () => void;
  handleGenerate: () => Promise<any | null> | any | null;

  pendingEntry: any;
  setPendingEntry: Dispatch<SetStateAction<any>>;
};
