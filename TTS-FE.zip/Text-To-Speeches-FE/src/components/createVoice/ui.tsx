import React from "react";

export const MiniStat = ({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string;
  tone?: "neutral" | "danger";
}) => (
  <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-4">
    <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
      {label}
    </div>
    <div
      className={[
        "mt-1 text-sm font-black tracking-tight",
        tone === "danger"
          ? "text-red-600 dark:text-red-400"
          : "text-slate-900 dark:text-white",
      ].join(" ")}
    >
      {value}
    </div>
  </div>
);

export const Slider = ({
  label,
  value,
  min,
  max,
  onChange,
  disabled = false,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (value: number) => void;
  disabled?: boolean;
}) => (
  <div
    className={[
      "rounded-2xl border border-black/5 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-4",
      disabled ? "opacity-60" : "",
    ].join(" ")}
  >
    <div className="flex items-center justify-between gap-4">
      <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
        {label}
      </div>
      <div className="text-xs font-black text-slate-900 dark:text-white tabular-nums">
        {value}
      </div>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      step={1}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      disabled={disabled}
      className="mt-3 w-full"
    />
  </div>
);
