import React from "react";

export type StepStatus = "pending" | "active" | "completed";

export interface Step {
  number: number;
  title: string;
  status: StepStatus;
  isClickable: boolean;
}

const ProgressStepBar = ({
  steps,
  onStepClick,
}: {
  steps: Step[];
  onStepClick: (stepNumber: number) => void;
}) => {
  return (
    <div className="glass studio-card !p-6 mb-6 transition-all duration-300">
      <div className="flex items-center justify-between gap-2 md:gap-4">
        {steps.map((step, index) => {
          const isLast = index === steps.length - 1;
          const isPending = step.status === "pending";
          const isActive = step.status === "active";
          const isCompleted = step.status === "completed";

          return (
            <React.Fragment key={step.number}>
              <div className="flex items-center gap-3 flex-1">
                {/* Step Circle */}
                <button
                  type="button"
                  onClick={() => step.isClickable && onStepClick(step.number)}
                  disabled={!step.isClickable}
                  className={[
                    "flex-shrink-0 w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center font-black text-sm md:text-base transition-all duration-300 ease-out",
                    step.isClickable && !isActive ? "cursor-pointer" : "",
                    !step.isClickable ? "cursor-not-allowed" : "",
                    isActive
                      ? "bg-indigo-600 text-white ring-4 ring-indigo-300 dark:ring-indigo-500/30 scale-110 shadow-lg shadow-indigo-500/30"
                      : isCompleted && step.isClickable
                        ? "bg-green-500 text-white hover:ring-4 hover:ring-green-300 dark:hover:ring-green-500/30 hover:scale-105 shadow-md hover:shadow-lg"
                        : isCompleted
                          ? "bg-green-500/20 text-green-700 dark:text-green-300 shadow-sm"
                          : "bg-slate-200/50 dark:bg-white/10 text-slate-400 dark:text-slate-500",
                  ].join(" ")}
                  aria-label={`${step.title} - ${step.status}`}
                >
                  {isCompleted ? (
                    <svg className="w-6 h-6 animate-in fade-in zoom-in duration-300" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  ) : (
                    step.number
                  )}
                </button>

                {/* Step Title */}
                <div className="hidden sm:block flex-1 min-w-0">
                  <div
                    className={[
                      "text-xs md:text-sm font-black uppercase tracking-wider truncate transition-colors duration-300",
                      isActive
                        ? "text-indigo-600 dark:text-indigo-400"
                        : isCompleted
                          ? "text-green-600 dark:text-green-400"
                          : "text-slate-400 dark:text-slate-500",
                    ].join(" ")}
                  >
                    {step.title}
                  </div>
                  <div className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 mt-0.5">
                    {isActive ? "In Progress" : isCompleted ? "Completed" : "Pending"}
                  </div>
                </div>
              </div>

              {/* Connector Line */}
              {!isLast && (
                <div className="hidden md:block flex-1 h-1 mx-2">
                  <div
                    className={[
                      "h-full rounded-full transition-all duration-500 ease-out",
                      isCompleted
                        ? "bg-green-500"
                        : "bg-slate-200 dark:bg-white/10",
                    ].join(" ")}
                  />
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Mobile Step Titles */}
      <div className="sm:hidden mt-4 text-center">
        {steps.map((step) => {
          if (step.status !== "active") return null;
          return (
            <div key={step.number} className="text-sm font-black text-indigo-600 dark:text-indigo-400 animate-in fade-in slide-in-from-bottom-2 duration-300">
              {step.title}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProgressStepBar;
