export const estimateVoiceMinutes = (text: string): number => {
  const words = text.trim() ? text.trim().split(/\s+/).filter(Boolean).length : 0;
  return Math.max(0, words / 150);
};

/** Estimate voice minutes from character count (750 chars ≈ 1 minute). */
export const estimateMinutesFromChars = (charCount: number): number => {
  return Math.max(0, charCount / 750);
};

export const toneFromDescription = (description: string): string => {
  const lower = description.toLowerCase();
  if (lower.includes("professional")) return "Professional";
  if (lower.includes("friendly")) return "Friendly";
  if (lower.includes("warm")) return "Warm";
  if (lower.includes("energetic")) return "Energetic";
  if (lower.includes("calm")) return "Calm";
  if (lower.includes("authoritative")) return "Authoritative";
  return "Neutral";
};

const PREVIEW_TEXTS: Record<string, string> = {
  // Indian regional
  'hi-IN': 'नमस्ते! यह एक आवाज़ का नमूना है।',
  'ta-IN': 'வணக்கம்! இது ஒரு குரல் மாதிரி.',
  'te-IN': 'నమస్కారం! ఇది ఒక వాయిస్ ప్రివ్యూ.',
  'ml-IN': 'നമസ്കാരം! ഇത് ഒരു ശബ്ദ പ്രിവ്യൂ ആണ്.',
  'bn-IN': 'হ্যালো! এটি একটি ভয়েস প্রিভিউ।',
  'mr-IN': 'नमस्कार! हे एक आवाज प्रिव्ह्यू आहे.',
  'gu-IN': 'નમસ્તે! આ એક અવાજ પ્રીવ્યૂ છે.',
  'kn-IN': 'ನಮಸ್ಕಾರ! ಇದು ಒಂದು ಧ್ವನಿ ಮಾದರಿ.',
  'pa-IN': 'ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ! ਇਹ ਇੱਕ ਆਵਾਜ਼ ਦੀ ਝਲਕ ਹੈ.',
  'ur-IN': 'السلام علیکم! یہ ایک آواز کا نمونہ ہے۔',
  'or-IN': 'ନମସ୍କାର! ଏହା ଏକ ଭଏସ୍ ପ୍ରିଭ୍ୟୁ।',
  'as-IN': 'নমস্কাৰ! এইটো এটা কণ্ঠ পূৰ্বদৰ্শন।',
  // Southeast Asian
  'id-ID': 'Halo! Ini adalah pratinjau suara.',
  'fil-PH': 'Kumusta! Ito ay isang voice preview.',
  'ms-MY': 'Helo! Ini ialah pratonton suara.',
  'vi-VN': 'Xin chào! Đây là bản xem trước giọng nói.',
  'th-TH': 'สวัสดี! นี่คือตัวอย่างเสียง',
  // East Asian
  'ja-JP': 'こんにちは！これは音声プレビューです。',
  'ko-KR': '안녕하세요! 이것은 음성 미리보기입니다.',
  'zh-CN': '你好！这是语音预览。',
  'zh-HK': '你好！這是語音預覽。',
  'zh-TW': '你好！這是語音預覽。',
  // Middle Eastern
  'ar-SA': 'مرحباً! هذا معاينة للصوت.',
  'ar-AE': 'مرحباً! هذا معاينة للصوت.',
  'he-IL': 'שלום! זוהי תצוגה מקדימה של קול.',
  // European
  'fr-FR': 'Bonjour ! Ceci est un aperçu vocal.',
  'fr-CA': 'Bonjour ! Ceci est un aperçu vocal.',
  'de-DE': 'Hallo! Dies ist eine Sprachvorschau.',
  'es-ES': '¡Hola! Esta es una vista previa de voz.',
  'es-MX': '¡Hola! Esta es una vista previa de voz.',
  'it-IT': 'Ciao! Questa è un\'anteprima vocale.',
  'pt-BR': 'Olá! Esta é uma prévia de voz.',
  'pt-PT': 'Olá! Esta é uma prévia de voz.',
  'ru-RU': 'Привет! Это предварительный просмотр голоса.',
  'tr-TR': 'Merhaba! Bu bir ses önizlemesidir.',
  'nl-NL': 'Hallo! Dit is een spraakvoorbeeld.',
  'pl-PL': 'Cześć! To jest podgląd głosu.',
  'sv-SE': 'Hej! Det här är en röstförhandsvisning.',
  'el-GR': 'Γεια σου! Αυτή είναι μια προεπισκόπηση φωνής.',
  'da-DK': 'Hej! Dette er en stemmeforhåndsvisning.',
  'fi-FI': 'Hei! Tämä on äänen esikatselu.',
  'nb-NO': 'Hei! Dette er en taleforhåndsvisning.',
};

export const getPreviewTextForVoice = (voiceId: string): string => {
  const parts = voiceId.split('-');
  if (parts.length >= 2) {
    const locale = `${parts[0]}-${parts[1]}`;
    if (PREVIEW_TEXTS[locale]) return PREVIEW_TEXTS[locale];
  }
  return 'Hello! This is a voice preview.';
};

