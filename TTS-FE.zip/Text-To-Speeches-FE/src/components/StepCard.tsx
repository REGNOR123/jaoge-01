import React from "react";

interface StepCardProps {
  step: number;
  title: string;
  isActive: boolean;
  isCompleted: boolean;
  summary?: React.ReactNode;
  description?: string;
  onHeaderClick?: () => void;
  children: React.ReactNode;
}

const StepCard = ({
  step,
  title,
  isActive,
  isCompleted,
  summary,
  description,
  onHeaderClick,
  children,
}: StepCardProps) => {
  const isExpanded = isActive;

  return (
    <div
      className={[
        "glass studio-card !p-8 transition-all",
        isExpanded ? "ring-2 ring-indigo-500/30" : "",
      ].join(" ")}
    >
      <button
        type="button"
        onClick={onHeaderClick}
        disabled={!onHeaderClick}
        className="w-full flex items-start justify-between gap-4 disabled:cursor-default text-left"
      >
        <div className="flex-1 block">
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            {title}
          </h2>
          {description && (
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 font-medium">
              {description}
            </p>
          )}
        </div>

        {onHeaderClick && (
          <svg
            className={[
              "w-5 h-5 text-slate-500 dark:text-slate-400 transition-transform flex-shrink-0",
              isExpanded && "rotate-180",
            ].join(" ")}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 9l-7 7-7-7"
            />
          </svg>
        )}
      </button>

      {!isExpanded && isCompleted && summary ? (
        <div className="mt-4 text-sm font-semibold text-slate-600 dark:text-slate-300">
          {summary}
        </div>
      ) : null}

      <div
        className={[
          "grid transition-[grid-template-rows,opacity] duration-300 ease-out",
          isExpanded
            ? "grid-rows-[1fr] opacity-100"
            : "grid-rows-[0fr] opacity-0",
        ].join(" ")}
      >
        <div className="overflow-hidden">
          <div className="mt-6 pt-6">{children}</div>
        </div>
      </div>
    </div>
  );
};

export default StepCard;
