import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Settings,
  LogOut,
} from 'lucide-react';

interface ProfileDropdownUserProps {
  isOpen: boolean;
  onClose: () => void;
  user: {
    fullName?: string;
    email?: string;
    profilePicture?: string;
  } | null;
  onLogout: () => void;
}

const ProfileDropdownUser: React.FC<ProfileDropdownUserProps> = ({
  isOpen,
  onClose,
  user,
  onLogout
}) => {
  const navigate = useNavigate();
  const [imageLoadError, setImageLoadError] = useState(false);

  if (!isOpen) return null;

  const initial =
    user?.fullName?.trim()?.charAt(0)?.toUpperCase() ||
    user?.email?.trim()?.charAt(0)?.toUpperCase() ||
    '?';

  const displayName = user?.fullName || 'User';
  const hasProfilePicture = !!user?.profilePicture && !imageLoadError;

  const handleNavigate = (path: string) => {
    onClose();
    navigate(path);
  };

  const handleLogout = () => {
    onClose();
    onLogout();
    navigate('/login');
  };

  return (
    <div className="absolute right-0 mt-2 w-64 rounded-2xl glass border border-slate-200 dark:border-white/10 shadow-2xl shadow-slate-900/10 dark:shadow-black/30 py-2 z-50 overflow-hidden">
      {/* User Header */}
      <div className="px-4 py-4 border-b border-slate-200 dark:border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg shadow-lg shadow-indigo-500/25 overflow-hidden flex-shrink-0">
            {hasProfilePicture ? (
              <img
                src={user.profilePicture}
                alt={displayName}
                className="w-full h-full object-cover"
                onError={() => setImageLoadError(true)}
              />
            ) : (
              initial
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-base font-bold text-slate-900 dark:text-white truncate">
              {displayName}
            </p>
          </div>
        </div>
        {user?.email && (
          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 truncate">
            {user.email}
          </p>
        )}
      </div>

      {/* Menu Options */}
      <div className="p-2">
        <button
          type="button"
          onClick={() => handleNavigate('/account')}
          className="w-full px-4 py-2.5 rounded-xl text-left text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/10 transition-colors flex items-center gap-3"
        >
          <Settings className="w-4 h-4 text-slate-500 dark:text-slate-400" />
          Settings
        </button>
      </div>

      {/* Divider */}
      <div className="mx-4 border-t border-slate-200 dark:border-white/10" />

      {/* Logout */}
      <div className="p-2">
        <button
          type="button"
          onClick={handleLogout}
          className="w-full px-4 py-2.5 rounded-xl text-left text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors flex items-center gap-3"
        >
          <LogOut className="w-4 h-4" />
          Logout
        </button>
      </div>
    </div>
  );
};

export default ProfileDropdownUser;
