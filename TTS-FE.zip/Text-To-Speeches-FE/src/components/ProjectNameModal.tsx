import React, { useCallback, useEffect, useRef } from "react";
import ProgressPill from "./ProgressPill";

type ProjectNameModalProps = {
  isOpen: boolean;
  title: string;
  description?: React.ReactNode;
  projectName: string;
  error?: string | null;
  loading?: boolean;
  progressPercent?: number;
  statusMessage?: string;
  proceedDisabled?: boolean;
  onProjectNameChange: (value: string) => void;
  onCancel: () => void;
  onProceed: () => void;
};

const ProjectNameModal: React.FC<ProjectNameModalProps> = ({
  isOpen,
  title,
  description,
  projectName,
  error,
  loading,
  progressPercent,
  statusMessage,
  proceedDisabled,
  onProjectNameChange,
  onCancel,
  onProceed,
}) => {
  const dialogRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [isOpen]);

  // Escape to close
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !loading) {
        onCancel();
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, loading, onCancel]);

  // Focus trap
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key !== "Tab" || !dialogRef.current) return;
      const focusable = dialogRef.current.querySelectorAll<HTMLElement>(
        'button:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])',
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    },
    [],
  );

  if (!isOpen) return null;

  const handleBackdropClick = () => {
    if (!loading) onCancel();
  };

  const titleId = "project-name-modal-title";

  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center px-4 py-8">
      <button
        type="button"
        aria-label="Close modal"
        onClick={handleBackdropClick}
        className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm"
        tabIndex={-1}
      />
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onKeyDown={handleKeyDown}
        className="relative w-full max-w-lg rounded-3xl border border-black/5 dark:border-white/10 bg-white/90 dark:bg-slate-950/70 shadow-2xl"
      >
        <div className="px-8 py-6 space-y-4">
          <div>
            <div
              id={titleId}
              className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400"
            >
              {title}
            </div>
            {description && <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{description}</p>}
          </div>

          <div>
            <label
              htmlFor="project-name-input"
              className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2"
            >
              Project name
            </label>
            <input
              ref={inputRef}
              id="project-name-input"
              value={projectName}
              onChange={(event) => onProjectNameChange(event.target.value)}
              disabled={Boolean(loading)}
              placeholder="Enter project name..."
              className="w-full px-3 py-3 rounded-xl bg-slate-100/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/30 disabled:opacity-60"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !proceedDisabled && !loading) onProceed();
              }}
            />
            {error ? <div className="mt-2 text-xs font-semibold text-red-600 dark:text-red-400" role="alert">{error}</div> : null}
          </div>

          {loading ? (
            <div className="space-y-3">
              <ProgressPill label="Saving" percent={progressPercent ?? 0} />
              {statusMessage && (
                <div className="text-center text-xs font-black uppercase tracking-widest text-emerald-700 dark:text-emerald-200">
                  {statusMessage}
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center justify-end gap-3 pt-4">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-colors border border-slate-200 dark:border-white/10 bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={onProceed}
                disabled={Boolean(proceedDisabled)}
                className="px-4 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-colors shadow-sm bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Proceed
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProjectNameModal;
