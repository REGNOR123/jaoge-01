import React, { useEffect, useRef, useState } from "react";
import { CheckSquare, Columns3, Download, Filter, PencilLine, RefreshCcw, Search, Trash2, X } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";

type ColumnToggle = {
  id: string;
  label: string;
  visible: boolean;
};

type TableToolbarProps = {
  editMode: boolean;
  filtersVisible: boolean;
  globalSearch: string;
  selectedCount: number;
  totalCount: number;
  activeFilterCount: number;
  columnToggles: ColumnToggle[];
  onEditToggle: () => void;
  onFiltersToggle: () => void;
  onColumnToggle: (id: string, checked: boolean) => void;
  onExport: () => void;
  onRefresh: () => void;
  onDeleteSelected: () => void;
  onGlobalSearchChange: (value: string) => void;
  onClearFilters: () => void;
};

const TableToolbar: React.FC<TableToolbarProps> = ({
  editMode,
  filtersVisible,
  globalSearch,
  selectedCount,
  totalCount,
  activeFilterCount,
  columnToggles,
  onEditToggle,
  onFiltersToggle,
  onColumnToggle,
  onExport,
  onRefresh,
  onDeleteSelected,
  onGlobalSearchChange,
  onClearFilters,
}) => {
  const [searchValue, setSearchValue] = useState(globalSearch);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => {
    setSearchValue(globalSearch);
  }, [globalSearch]);

  const handleSearchChange = (value: string) => {
    setSearchValue(value);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      onGlobalSearchChange(value);
    }, 300);
  };

  useEffect(() => {
    return () => clearTimeout(debounceRef.current);
  }, []);

  return (
    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
      <div className="flex flex-wrap items-center gap-2.5">
        <Button
          variant={editMode ? "default" : "outline"}
          size="sm"
          className="rounded-lg"
          onClick={onEditToggle}
          aria-label={editMode ? "Exit edit mode" : "Enter edit mode"}
        >
          {editMode ? <CheckSquare className="h-4 w-4" /> : <PencilLine className="h-4 w-4" />}
          {editMode ? "Done" : "Edit"}
        </Button>

        {editMode && selectedCount > 0 && (
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
            {selectedCount} of {totalCount} selected
          </span>
        )}

        {editMode && (
          <Button
            variant="destructive"
            size="sm"
            className="rounded-lg"
            onClick={onDeleteSelected}
            disabled={selectedCount === 0}
            aria-label={`Delete ${selectedCount} selected projects`}
          >
            <Trash2 className="h-4 w-4" />
            Delete Selected
          </Button>
        )}

        <Button
          variant="outline"
          size="sm"
          className="rounded-lg relative"
          onClick={onFiltersToggle}
          aria-label={filtersVisible ? "Hide filters" : "Show filters"}
        >
          <Filter className="h-4 w-4" />
          {filtersVisible ? "Hide Filters" : "Show Filters"}
          {activeFilterCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-indigo-600 text-[10px] font-bold text-white">
              {activeFilterCount}
            </span>
          )}
        </Button>

        {activeFilterCount > 0 && (
          <Button
            variant="ghost"
            size="sm"
            className="rounded-lg text-xs text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
            onClick={onClearFilters}
            aria-label="Clear all filters"
          >
            <X className="h-3.5 w-3.5" />
            Clear Filters
          </Button>
        )}

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="rounded-lg" aria-label="Toggle column visibility">
              <Columns3 className="h-4 w-4" />
              Columns
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-56">
            <DropdownMenuLabel>Toggle columns</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {columnToggles.map((column) => (
              <DropdownMenuCheckboxItem
                key={column.id}
                checked={column.visible}
                onCheckedChange={(checked) => onColumnToggle(column.id, Boolean(checked))}
              >
                {column.label}
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        <Button variant="outline" size="sm" className="rounded-lg" onClick={onExport} aria-label="Export projects as CSV">
          <Download className="h-4 w-4" />
          Export CSV
        </Button>

        <Button variant="outline" size="sm" className="rounded-lg" onClick={onRefresh} aria-label="Refresh project list">
          <RefreshCcw className="h-4 w-4" />
          Refresh
        </Button>
      </div>

      <div className="relative w-full lg:max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <Input
          value={searchValue}
          onChange={(event) => handleSearchChange(event.target.value)}
          placeholder="Search projects..."
          aria-label="Search projects"
          className="h-10 rounded-lg border-slate-200 bg-slate-50 pl-9 shadow-none dark:bg-white/5"
        />
        {searchValue && (
          <button
            type="button"
            onClick={() => handleSearchChange("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            aria-label="Clear search"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};

export default TableToolbar;
