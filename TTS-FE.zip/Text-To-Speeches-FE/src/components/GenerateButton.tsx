
import React from 'react';
import { VoiceOption } from '../types';

interface GenerateButtonProps {
  isAuthenticated: boolean;
  isProcessing: boolean;
  isTextEmpty: boolean;
  isTextTooLong: boolean;
  isMismatched: boolean;
  progress: number;
  detectedLang: string | null;
  selectedVoiceInfo?: VoiceOption;
  error: string | null;
  onGenerate: () => void;
  onAuthRequired?: () => void;
  isTranslating?: boolean;
  onTranslate?: () => void;
}

const GenerateButton: React.FC<GenerateButtonProps> = ({
  isAuthenticated,
  isProcessing, isTextEmpty, isTextTooLong, isMismatched, progress,
  detectedLang, selectedVoiceInfo, error, onGenerate, isTranslating = false, onTranslate,
  onAuthRequired,
}) => {
  const handleAuthRequired = () => onAuthRequired?.();
  const canGenerate = isAuthenticated && !isProcessing && !isTextEmpty && !isTextTooLong;
  const canTranslate = isAuthenticated && !isTranslating && !isProcessing;

  return (
    <>
      <div className="mt-14">
        {!isMismatched ? (
          <button
            onClick={canGenerate ? onGenerate : handleAuthRequired}
            aria-disabled={!canGenerate}
            className={`w-full py-7 rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-xs transition-all relative overflow-hidden ${
              canGenerate
                ? 'bg-indigo-600 text-white shadow-2xl hover:scale-[1.01]'
                : 'bg-slate-100 dark:bg-white/5 text-slate-300 dark:text-slate-700 cursor-not-allowed'
            }`}
          >
            {isProcessing && (
              <div
                className="absolute left-0 top-0 bottom-0 bg-white/10 transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            )}
            <span className="relative z-10">
              {isProcessing ? `Neural Synthesis ${progress}%` : 'Generate Neural Voice'}
            </span>
          </button>
        ) : (
          <div className="p-8 rounded-[2.5rem] bg-orange-500/5 border border-orange-500/20 flex flex-col items-center text-center animate-in zoom-in-95 gap-4">
            <div className="w-12 h-12 rounded-2xl bg-orange-500/10 flex items-center justify-center text-orange-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.268 17c-.77 1.333.192 3 1.732 3z" /></svg>
            </div>
            <div className="space-y-3">
              <p className="text-[11px] font-bold leading-relaxed text-orange-700 dark:text-orange-400">
                The Entered text language was detected as <span className="underline">{detectedLang}</span>, but the selected voice is <span className="underline">{selectedVoiceInfo?.lang}</span>. 
                Please choose a voice in (<span className="font-black">{detectedLang}</span>).
              </p>
              <p className="text-[11px] leading-relaxed">
                <span className="text-slate-600 dark:text-slate-400">or</span>
              </p>
              <button
                onClick={canTranslate ? onTranslate : handleAuthRequired}
                aria-disabled={!canTranslate}
                className={`text-[11px] font-bold underline transition-colors ${
                  canTranslate
                    ? 'text-green-600 dark:text-green-400 hover:text-green-700 dark:hover:text-green-300'
                    : 'text-slate-400 dark:text-slate-500 cursor-not-allowed'
                }`}
              >
                {isTranslating ? 'Translating...' : `proceed to translate in (${selectedVoiceInfo?.lang})`}
              </button>
            </div>
          </div>
        )}
      </div>
      
      {error && <div className="mt-8 p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-center animate-in fade-in"><p className="text-red-500 text-[10px] font-black uppercase tracking-widest">{error}</p></div>}
    </>
  );
};

export default GenerateButton;
