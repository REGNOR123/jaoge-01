import React from "react";
import { FileText, Clock, Zap, TrendingUp } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useSimpleUsage } from "../hooks/useSimpleUsage";
import type { SimpleUsageSummary, FeatureUsageSummary } from "../services/usageApiService";

// ============================================================================
// Stat Card Component
// ============================================================================
type StatCardProps = {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ReactNode;
};

const StatCard: React.FC<StatCardProps> = ({ title, value, subtitle, icon }) => {
  return (
    <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-4 backdrop-blur-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
            {title}
          </p>
          <p className="mt-1 text-xl font-bold text-slate-900 dark:text-white">
            {typeof value === "number" ? value.toLocaleString() : value}
          </p>
          {subtitle && (
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>
          )}
        </div>
        {icon && (
          <div className="rounded-xl bg-indigo-100 dark:bg-indigo-900/30 p-2 text-indigo-600 dark:text-indigo-400">
            {icon}
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// Feature Usage Row Component
// ============================================================================
type FeatureRowProps = {
  feature: FeatureUsageSummary;
};

const FeatureRow: React.FC<FeatureRowProps> = ({ feature }) => {
  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "—";
    try {
      return new Date(dateStr).toLocaleDateString();
    } catch {
      return "—";
    }
  };

  return (
    <tr className="border-b border-slate-100 dark:border-slate-700/50 last:border-0">
      <td className="py-3 px-4 text-sm font-medium text-slate-900 dark:text-white">
        {feature.displayName}
      </td>
      <td className="py-3 px-4 text-sm text-slate-600 dark:text-slate-300 text-right">
        {feature.characters.toLocaleString()}
      </td>
      <td className="py-3 px-4 text-sm text-slate-600 dark:text-slate-300 text-right">
        {feature.minutes.toFixed(2)}
      </td>
      <td className="py-3 px-4 text-sm text-slate-600 dark:text-slate-300 text-right">
        {feature.requests}
      </td>
      <td className="py-3 px-4 text-sm text-slate-500 dark:text-slate-400 text-right">
        {formatDate(feature.lastUsed)}
      </td>
    </tr>
  );
};

// ============================================================================
// Usage Summary Widget Props
// ============================================================================
type UsageSummaryWidgetProps = {
  className?: string;
  showFeatureBreakdown?: boolean;
};

// ============================================================================
// Usage Summary Widget Component
// ============================================================================
export const UsageSummaryWidget: React.FC<UsageSummaryWidgetProps> = ({
  className = "",
  showFeatureBreakdown = false,
}) => {
  const { token } = useAuth();
  const { usage, loading, error, refresh } = useSimpleUsage(token);

  if (loading && !usage) {
    return (
      <div className={`${className} animate-pulse`}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-20 bg-slate-200 dark:bg-slate-700 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`${className} p-4 rounded-xl bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400`}>
        <p className="text-sm">{error}</p>
        <button
          onClick={refresh}
          className="mt-2 text-sm underline hover:no-underline"
        >
          Try again
        </button>
      </div>
    );
  }

  if (!usage) return null;

  return (
    <div className={className}>
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          title="Characters"
          value={usage.totalCharacters}
          icon={<FileText className="w-4 h-4" />}
        />
        <StatCard
          title="Voice Minutes"
          value={usage.totalMinutes.toFixed(2)}
          subtitle="minutes"
          icon={<Clock className="w-4 h-4" />}
        />
        <StatCard
          title="Enhancements"
          value={usage.totalEnhancements}
          icon={<Zap className="w-4 h-4" />}
        />
        <StatCard
          title="Total Requests"
          value={usage.totalRequests}
          icon={<TrendingUp className="w-4 h-4" />}
        />
      </div>

      {/* Feature Breakdown */}
      {showFeatureBreakdown && usage.byFeature.length > 0 && (
        <div className="mt-6 rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 overflow-hidden">
          <div className="p-4 border-b border-slate-100 dark:border-slate-700/50">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Usage by Feature
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50">
                  <th className="py-2 px-4 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Feature
                  </th>
                  <th className="py-2 px-4 text-right text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Characters
                  </th>
                  <th className="py-2 px-4 text-right text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Minutes
                  </th>
                  <th className="py-2 px-4 text-right text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Requests
                  </th>
                  <th className="py-2 px-4 text-right text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Last Used
                  </th>
                </tr>
              </thead>
              <tbody>
                {usage.byFeature.map((feature) => (
                  <FeatureRow key={feature.feature} feature={feature} />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default UsageSummaryWidget;
