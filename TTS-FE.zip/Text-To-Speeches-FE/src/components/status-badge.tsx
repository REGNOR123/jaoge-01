import React from "react";
import type { ProjectTableStatus, ProjectTableType } from "../data/projects";
import { cn } from "../lib/utils";

export const StatusBadge: React.FC<{ status: ProjectTableStatus }> = ({ status }) => {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold",
        status === "Completed" && "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/20",
        status === "Processing" && "bg-amber-50 text-amber-700 ring-1 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/20",
        status === "Draft" && "bg-slate-100 text-slate-600 ring-1 ring-slate-200 dark:bg-white/10 dark:text-slate-300 dark:ring-white/10",
      )}
    >
      {status}
    </span>
  );
};

const TYPE_STYLES: Record<ProjectTableType, string> = {
  VOICE: "bg-indigo-50 text-indigo-700 ring-1 ring-indigo-200 dark:bg-indigo-500/10 dark:text-indigo-300 dark:ring-indigo-500/20",
  TRANSCRIPT: "bg-amber-50 text-amber-700 ring-1 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/20",
  DUB: "bg-purple-50 text-purple-700 ring-1 ring-purple-200 dark:bg-purple-500/10 dark:text-purple-300 dark:ring-purple-500/20",
  SPEECHTRANSLATE: "bg-teal-50 text-teal-700 ring-1 ring-teal-200 dark:bg-teal-500/10 dark:text-teal-300 dark:ring-teal-500/20",
  SCRIPT: "bg-rose-50 text-rose-700 ring-1 ring-rose-200 dark:bg-rose-500/10 dark:text-rose-300 dark:ring-rose-500/20",
};

const TYPE_LABELS: Record<ProjectTableType, string> = {
  VOICE: "Voice",
  TRANSCRIPT: "Transcript",
  DUB: "Dub",
  SPEECHTRANSLATE: "Speech Translate",
  SCRIPT: "Script",
};

export const TypeBadge: React.FC<{ type: ProjectTableType }> = ({ type }) => {
  return (
    <span className={cn("inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold", TYPE_STYLES[type])}>
      {TYPE_LABELS[type] || type}
    </span>
  );
};
