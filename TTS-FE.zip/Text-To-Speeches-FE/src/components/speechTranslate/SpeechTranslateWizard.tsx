import React, { useCallback, useEffect } from "react";
import { useSpeechTranslateState } from "./useSpeechTranslateState";
import Step1UploadAudio from "./Step1UploadAudio";
import Step2Configure from "./Step2Configure";
import Step3GenerateReview from "./Step3GenerateReview";
import AuthRequiredModal from "../AuthRequiredModal";
import InsufficientCreditsModal from "../InsufficientCreditsModal";
import ProjectNameModal from "../ProjectNameModal";
import ProgressStepBar from "../createVoice/ProgressStepBar";
import BottomActionBar from "../createVoice/BottomActionBar";
import { RETENTION_MESSAGE } from "./constants";
import type { StepId } from "./constants";

const SpeechTranslateWizard: React.FC = () => {
  const state = useSpeechTranslateState();

  const {
    // Auth
    isGuest,
    // Wizard
    step,
    setStep,
    maxStepUnlocked,
    authRequiredOpen,
    setAuthRequiredOpen,
    // Project
    projectModalPurpose,
    pendingProjectName,
    setPendingProjectName,
    projectModalError,
    projectModalLoading,
    projectModalPercent,
    projectModalStatus,
    resetProjectModal,
    openProjectModal,
    handleProjectModalProceed,
    activeProjectId,
    newProjectName,
    setNewProjectName,
    projectNameError,
    // Steps
    isStep1Complete,
    isStep2Complete,
    isStep3Complete,
    audioFile,
    selectedTargets,
    voicesByTarget,
    // Progress
    translateInProgress,
    translatePercent,
    uploadPercent,
    // Actions
    isBusy,
    canSaveDraft,
    handleContinue,
    handleStep2Continue,
    handleTranslate,
    handleStepNavigation,
    handleStartNew,
    // Error
    error,
    // Regional language support
    isTargetRegional,
    // Auto-save
    isDirty,
    lastAutoSaved,
    isAuthenticated,
    // Format
    formatDateTime,
    // Preview audio element
    previewRef,
  } = state;

  // Keyboard shortcut: Ctrl+Enter to generate (C15)
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter" && step === 3 && !translateInProgress) {
        e.preventDefault();
        void handleTranslate();
      }
    },
    [step, translateInProgress, handleTranslate],
  );

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  return (
    <div className="max-w-6xl mx-auto px-5 pt-8 pb-8 space-y-6">
      {/* Hidden audio element for voice preview */}
      <audio
        ref={previewRef}
        className="hidden"
        crossOrigin="anonymous"
        onError={(e) => console.error('Audio playback error:', (e.target as HTMLAudioElement).error?.message)}
      />

      <AuthRequiredModal
        isOpen={authRequiredOpen}
        onClose={() => setAuthRequiredOpen(false)}
        redirectTo="/speech-translate"
      />
      <InsufficientCreditsModal
        isOpen={!!state.insufficientCreditsInfo}
        onClose={() => state.clearInsuffCreditsInfo()}
        requiredCredits={state.insufficientCreditsInfo?.required ?? 0}
        currentBalance={state.insufficientCreditsInfo?.current ?? 0}
      />

      {/* Header with project name (C14) */}
      <header className="flex items-start justify-between gap-6 relative">
        <div>
          <h1 className="m-0 text-3xl sm:text-4xl font-black leading-tight tracking-tight text-slate-900 dark:text-white">
            Speech Translate
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl">
            Translate speech-to-speech with authenticated file storage and usage-aware controls.
            {activeProjectId && newProjectName && (
              <span className="ml-2 px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 text-xs font-bold">
                {newProjectName}
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {!isGuest && (
            <button
              type="button"
              disabled={!canSaveDraft || Boolean(projectModalPurpose)}
              onClick={openProjectModal}
              title="Save draft to a named project."
              className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Save Draft
            </button>
          )}
          {(isStep1Complete || isStep3Complete) && (
            <button
              type="button"
              onClick={() => void handleStartNew()}
              className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10"
            >
              New
            </button>
          )}
        </div>
      </header>

      {/* Auto-save indicator */}
      {lastAutoSaved && !isDirty && isAuthenticated && (
        <div className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 text-right">
          Draft saved {formatDateTime(lastAutoSaved)}
        </div>
      )}

      {/* Progress Step Bar */}
      <ProgressStepBar
        steps={[
          {
            number: 1,
            title: "Upload Source Audio",
            status: step === 1 ? "active" : maxStepUnlocked >= 2 ? "completed" : "pending",
            isClickable: maxStepUnlocked >= 1 && step !== 1,
          },
          {
            number: 2,
            title: "Configure Translation",
            status: step === 2 ? "active" : maxStepUnlocked >= 3 ? "completed" : "pending",
            isClickable: maxStepUnlocked >= 2 && step !== 2,
          },
          {
            number: 3,
            title: "Generate & Review",
            status: step === 3 ? "active" : isStep3Complete ? "completed" : "pending",
            isClickable: maxStepUnlocked >= 3 && step !== 3,
          },
        ]}
        onStepClick={(stepNumber) => {
          if (stepNumber >= 1 && stepNumber <= maxStepUnlocked && stepNumber !== step) {
            void (async () => {
              const shouldProceed = await handleStepNavigation(stepNumber as StepId);
              if (shouldProceed) setStep(stepNumber as StepId);
            })();
          }
        }}
      />

      {/* Step content */}
      <div className="space-y-6">
        {step === 1 && <Step1UploadAudio state={state} />}
        {step === 2 && <Step2Configure state={state} />}
        {step === 3 && <Step3GenerateReview state={state} />}

        {/* Error banner */}
        {error && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
            <p className="text-red-600 dark:text-red-400 text-xs font-bold uppercase tracking-wide">
              {error}
            </p>
          </div>
        )}
      </div>

      {/* Accessibility: aria-live region for announcements (C7) */}
      <div aria-live="polite" className="sr-only">
        {translateInProgress
          ? "Translation in progress..."
          : isStep3Complete
            ? "Translation complete. Review your outputs."
            : `Currently on step ${step} of 3.`}
      </div>

      {/* Bottom Action Bar */}
      <BottomActionBar
        currentStep={step}
        totalSteps={3}
        canGoBack={step > 1}
        canGoForward={
          step === 1
            ? isStep1Complete
            : step === 2
              ? isStep1Complete && selectedTargets.length > 0
              : true
        }
        primaryActionLabel={
          step === 1
            ? "Continue"
            : step === 2
              ? isTargetRegional
                ? "Confirm & Continue (2× charge)"
                : "Continue"
              : isTargetRegional
                ? "Generate (2× charge)"
                : "Generate Translation"
        }
        primaryActionDisabled={
          step === 1
            ? !audioFile
            : step === 2
              ? !selectedTargets.length
              : translateInProgress
        }
        primaryActionLoading={
          uploadPercent > 0 || (step === 3 && translateInProgress)
        }
        primaryActionProgress={
          uploadPercent > 0 ? uploadPercent : step === 3 ? translatePercent : 0
        }
        showPrimaryAction={
          step === 1
            ? true
            : step === 2
              ? selectedTargets.length > 0 &&
                selectedTargets.every((t: string) => Boolean(voicesByTarget[t]))
              : !isStep3Complete
        }
        isGuestLocked={isGuest}
        onPrevious={() => {
          if (step > 1) {
            void (async () => {
              const targetStep = (step - 1) as StepId;
              const shouldProceed = await handleStepNavigation(targetStep);
              if (shouldProceed) setStep(targetStep);
            })();
          }
        }}
        onPrimaryAction={() => {
          if (step === 1) {
            void handleContinue();
          } else if (step === 2) {
            handleStep2Continue();
          } else if (step === 3) {
            void handleTranslate();
          }
        }}
      />

      {/* Project Name Modal */}
      <ProjectNameModal
        isOpen={projectModalPurpose === "draft"}
        onCancel={resetProjectModal}
        title="Save Draft"
        description="Store your draft under this project name."
        projectName={pendingProjectName}
        onProjectNameChange={setPendingProjectName}
        error={projectModalError}
        loading={projectModalLoading}
        progressPercent={projectModalPercent}
        statusMessage={projectModalStatus === "saved" ? "Saved" : undefined}
        onProceed={handleProjectModalProceed}
      />
    </div>
  );
};

export default SpeechTranslateWizard;
