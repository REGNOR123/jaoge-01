import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { AVAILABLE_VOICES } from "../../constants";
import { useAuth } from "../../contexts/AuthContext";
import { useTheme } from "../../contexts/ThemeContext";
import { useCredits } from "../../contexts/CreditContext";
import {
  deleteManagedFile,
  downloadManagedFile,
  uploadManagedFile,
  uploadManagedTextFile,
  type StoredFileRecord,
} from "../../services/filesApiService";
import {
  translateSpeechToSpeech,
  type SpeechTranslateAudioItem,
  type SpeechTranslateOutputFormat,
} from "../../services/speechTranslateService";
import { generateAzureSpeech } from "../../services/azureService";
import type { VoiceName, VoiceOption } from "../../types";
import { loadAudioBlob } from "../../utils/audioBlobStore";
import { getPreviewTextForVoice } from "../createVoice/utils";
import {
  createProject,
  getProjectById,
  listProjects,
  updateProject,
} from "../../utils/projectsStorage";
import { useDialog } from "../dialogs";
import { useWizardProgress } from "../../hooks/useWizardProgress";
import { formatDuration, formatDateTime, downloadHref } from "../../utils/format";
import { TARGET_LANGUAGES } from "./languages";

const REGIONAL_LANG_CODES = new Set([
  "hi", "ta", "te", "ml", "bn", "mr", "gu", "kn", "pa", "ur", "or", "as",
  "ms", "id", "fil", "jv", "my", "km", "lo",
]);
import { useAudioRecorder } from "./useAudioRecorder";
import {
  type StepId,
  SPEECH_TRANSLATE_TRANSCRIPT_SOURCE,
  SPEECH_TRANSLATE_TRANSLATION_SOURCE_PREFIX,
  getTargetLabel,
  targetCodeToVoicePrefix,
  isSpeechTranslateEntry,
  isSourceEntry,
  isGeneratedEntry,
  GENERATION_PHASES,
} from "./constants";

export function useSpeechTranslateState() {
  const { isAuthenticated, token } = useAuth();
  const isGuest = !isAuthenticated;
  const { theme, toggleTheme } = useTheme();
  const { refreshBalance } = useCredits();
  const dialog = useDialog();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const projectIdFromQuery = searchParams.get("projectId") || "";

  // ── UI / wizard state ──────────────────────────────────────────────
  const [authRequiredOpen, setAuthRequiredOpen] = useState(false);
  const [insufficientCreditsInfo, setInsuffCreditsInfo] = useState<{ required: number; current: number } | null>(null);
  const [workflowId] = useState(() => crypto.randomUUID());
  const [step, setStep] = useState<StepId>(1);
  const [maxStepUnlocked, setMaxStepUnlocked] = useState<StepId>(1);
  const [completedSteps, setCompletedSteps] = useState<Set<StepId>>(new Set());
  const [projectModalPurpose, setProjectModalPurpose] = useState<"draft" | null>(null);
  const [pendingProjectName, setPendingProjectName] = useState("");
  const [projectModalError, setProjectModalError] = useState<string | null>(null);
  const [projectModalStatus, setProjectModalStatus] = useState<"idle" | "saved">("idle");
  const [activeProjectId, setActiveProjectId] = useState(projectIdFromQuery);
  const [newProjectName, setNewProjectName] = useState("");

  // ── Input state ────────────────────────────────────────────────────
  const [inputMode, setInputMode] = useState<"audio" | "text">("audio");
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [sourceFileRecord, setSourceFileRecord] = useState<StoredFileRecord | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const {
    isRecording,
    error: recordError,
    start: startRecording,
    stop: stopRecording,
  } = useAudioRecorder();
  const [recordingElapsed, setRecordingElapsed] = useState(0);
  const recordingTimerRef = useRef<number | null>(null);
  const [textInput, setTextInput] = useState("");

  // ── Audio / output state ───────────────────────────────────────────
  const [inputAudioUrl, setInputAudioUrl] = useState<string | null>(null);
  const [durationSeconds, setDurationSeconds] = useState<number | null>(null);
  const [selectedTargets, setSelectedTargets] = useState<string[]>([]);
  const [outputFormat, setOutputFormat] = useState<SpeechTranslateOutputFormat>("mp3");
  const [showTextOutput, setShowTextOutput] = useState(false);
  const [voicesByTarget, setVoicesByTarget] = useState<Record<string, VoiceName | "">>({});
  const [sourceLanguageOverride, setSourceLanguageOverride] = useState<string | null>(null);
  const [isRegionalOnly, setIsRegionalOnly] = useState(false);

  // ── Progress ───────────────────────────────────────────────────────
  const translateProgress = useWizardProgress({ interval: 150 });
  const saveDraftProgress = useWizardProgress({ maxBump: 14, finishDelay: 450 });
  const [uploadPercent, setUploadPercent] = useState(0);
  const [generationPhase, setGenerationPhase] = useState(0);
  const [generationStartTime, setGenerationStartTime] = useState<number | null>(null);
  const [generationElapsed, setGenerationElapsed] = useState(0);
  const elapsedTimerRef = useRef<number | null>(null);

  // ── Results ────────────────────────────────────────────────────────
  const [detectedLanguage, setDetectedLanguage] = useState<string | null>(null);
  const [recognizedText, setRecognizedText] = useState("");
  const [translationsByTarget, setTranslationsByTarget] = useState<Record<string, string>>({});
  const [showOriginalTranscript, setShowOriginalTranscript] = useState(false);
  const [audioByTarget, setAudioByTarget] = useState<Record<string, SpeechTranslateAudioItem>>({});
  const [error, setError] = useState<string | null>(null);
  const [fileActionKey, setFileActionKey] = useState<string | null>(null);

  // ── Edit history for translations (undo/redo) ──────────────────────
  const [translationEditHistory, setTranslationEditHistory] = useState<Record<string, string>[]>([]);
  const [translationEditPointer, setTranslationEditPointer] = useState(-1);
  const [translationOriginals, setTranslationOriginals] = useState<Record<string, string>>({});

  // ── Voice preview state ────────────────────────────────────────────
  const [previewLoadingId, setPreviewLoadingId] = useState<VoiceName | null>(null);
  const [previewPlayingId, setPreviewPlayingId] = useState<VoiceName | null>(null);
  const previewRef = useRef<HTMLAudioElement | null>(null);
  const previewCacheRef = useRef<Map<string, string>>(new Map());

  // ── Auto-save state ────────────────────────────────────────────────
  const [isDirty, setIsDirty] = useState(false);
  const [lastAutoSaved, setLastAutoSaved] = useState<string | null>(null);

  // ── Re-generate ────────────────────────────────────────────────────
  const [showRegenVoicePicker, setShowRegenVoicePicker] = useState(false);

  // ── Refs ────────────────────────────────────────────────────────────
  const restoredSourceFileIdRef = useRef<string | null>(null);
  const outputObjectUrlsRef = useRef<Record<string, { fileId: string; url: string }>>({});

  // ── Derived values ─────────────────────────────────────────────────
  const normalizeProjectName = (value: string) =>
    value.trim().replace(/\s+/g, " ").toLowerCase();

  const validateNewProjectName = useCallback(
    (value: string, excludeId?: string) => {
      const collapsed = value.trim().replace(/\s+/g, " ");
      if (collapsed.length <= 3) return "Project name must be at least 4 characters.";
      const normalized = normalizeProjectName(collapsed);
      const exclude = excludeId ?? activeProjectId;
      return listProjects().some(
        (project) => normalizeProjectName(project.name) === normalized && project.id !== exclude,
      )
        ? "Project name must be unique."
        : null;
    },
    [activeProjectId],
  );

  const projectNameError = useMemo(() => {
    const value = newProjectName.trim();
    return value ? validateNewProjectName(value, activeProjectId) : null;
  }, [activeProjectId, newProjectName, validateNewProjectName]);

  const canUseProjectName = useMemo(() => {
    const value = newProjectName.trim();
    return value ? !validateNewProjectName(value, activeProjectId) : false;
  }, [activeProjectId, newProjectName, validateNewProjectName]);

  const estimatedMinutes = useMemo(() => {
    if (durationSeconds == null || !Number.isFinite(durationSeconds)) return null;
    return (durationSeconds / 60) * Math.max(1, selectedTargets.length);
  }, [durationSeconds, selectedTargets.length]);

  const sourceMinutes = useMemo(() => {
    if (durationSeconds == null || !Number.isFinite(durationSeconds)) return null;
    return durationSeconds / 60;
  }, [durationSeconds]);

  const isStep1Complete = useMemo(
    () => audioFile !== null || sourceFileRecord !== null,
    [audioFile, sourceFileRecord],
  );
  const isStep2Complete = useMemo(() => maxStepUnlocked >= 3, [maxStepUnlocked]);
  const isStep3Complete = useMemo(
    () => Object.keys(audioByTarget).length > 0,
    [audioByTarget],
  );

  const voicesForTarget = useMemo(() => {
    const next: Record<string, VoiceOption[]> = {};
    for (const target of selectedTargets) {
      const prefix = targetCodeToVoicePrefix(target);
      next[target] = AVAILABLE_VOICES.filter((voice) =>
        String(voice.id).startsWith(`${prefix}-`),
      );
    }
    return next;
  }, [selectedTargets]);

  const isTargetRegional = useMemo(
    () =>
      selectedTargets.some((t) => {
        const r = (voicesForTarget[t] || [])[0]?.region;
        return r === "Indian" || r === "SE Asian";
      }),
    [selectedTargets, voicesForTarget],
  );

  const filteredTargetLanguages = useMemo(
    () =>
      isRegionalOnly
        ? TARGET_LANGUAGES.filter((l) =>
            REGIONAL_LANG_CODES.has(l.code.split("-")[0].toLowerCase()),
          )
        : TARGET_LANGUAGES,
    [isRegionalOnly],
  );

  const selectedTargetsLabel = useMemo(() => {
    if (selectedTargets.length === 0) return "None";
    if (selectedTargets.length === 1)
      return getTargetLabel(selectedTargets[0], TARGET_LANGUAGES);
    return `${selectedTargets.length} languages`;
  }, [selectedTargets]);

  const isBusy = translateProgress.inProgress || saveDraftProgress.inProgress;

  const canSaveDraft =
    isAuthenticated &&
    Boolean(token) &&
    Boolean(audioFile) &&
    !isBusy;

  const canTranslateSpeech =
    isAuthenticated &&
    Boolean(token) &&
    Boolean(audioFile) &&
    selectedTargets.length > 0 &&
    !isBusy;

  const getDefaultProjectName = () => {
    if (newProjectName.trim()) return newProjectName.trim();
    const existing = listProjects().filter((p) => p.type === "SpeechTranslate");
    const nextNum = existing.length + 1;
    return `Speech Translate #${nextNum}`;
  };

  // ── step summaries ─────────────────────────────────────────────────
  const step1Summary = audioFile
    ? `${audioFile.name} | ${formatDuration(durationSeconds)}`
    : "-";
  const step2Summary = `${selectedTargets.length} target${selectedTargets.length === 1 ? "" : "s"} | ${outputFormat.toUpperCase()} | ${showTextOutput ? "Text on" : "Text off"}`;
  const step3Summary = Object.keys(audioByTarget).length
    ? `${Object.keys(audioByTarget).length} output${Object.keys(audioByTarget).length === 1 ? "" : "s"} ready`
    : "-";

  // ── Error helpers ──────────────────────────────────────────────────
  const applyProtectedError = (message: string, status?: number) => {
    setError(message);
    if (status === 401 || status === 403) setAuthRequiredOpen(true);
  };

  const requireProtectedAccess = () => {
    if (isAuthenticated && token) return true;
    setAuthRequiredOpen(true);
    return false;
  };

  // ── Recording timer ────────────────────────────────────────────────
  useEffect(() => {
    if (isRecording) {
      setRecordingElapsed(0);
      recordingTimerRef.current = window.setInterval(
        () => setRecordingElapsed((prev) => prev + 1),
        1000,
      );
    } else {
      if (recordingTimerRef.current) window.clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    return () => {
      if (recordingTimerRef.current) window.clearInterval(recordingTimerRef.current);
    };
  }, [isRecording]);

  // ── Generation elapsed timer ───────────────────────────────────────
  useEffect(() => {
    if (generationStartTime) {
      elapsedTimerRef.current = window.setInterval(
        () => setGenerationElapsed(Math.floor((Date.now() - generationStartTime) / 1000)),
        1000,
      );
    } else {
      if (elapsedTimerRef.current) window.clearInterval(elapsedTimerRef.current);
      elapsedTimerRef.current = null;
      setGenerationElapsed(0);
    }
    return () => {
      if (elapsedTimerRef.current) window.clearInterval(elapsedTimerRef.current);
    };
  }, [generationStartTime]);

  // ── Step navigation with confirmation ──────────────────────────────
  const handleStepNavigation = async (targetStep: StepId): Promise<boolean> => {
    const hasSubsequentProgress =
      (targetStep === 1 && (isStep2Complete || isStep3Complete)) ||
      (targetStep === 2 && isStep3Complete);

    if (!hasSubsequentProgress) return true;

    const stepName = targetStep === 1 ? "Upload Source Audio" : "Configure Translation";
    const result = await dialog.confirm(
      `Editing "${stepName}" will clear subsequent progress.\n\nWould you like to save your current project first?`,
      {
        title: "Save Before Going Back?",
        confirmText: "Save & Go Back",
        cancelText: "Go Back Without Saving",
        variant: "warning",
      },
    );

    if (result === null || result === undefined) return false; // dialog dismissed

    if (result) {
      // User chose "Save & Go Back"
      setProjectModalPurpose("draft");
      return false; // modal handles navigation
    }

    // "Go Back Without Saving" — clear downstream state
    if (targetStep === 1) {
      setSelectedTargets(["hi"]);
      setVoicesByTarget({});
      setAudioByTarget({});
      setRecognizedText("");
      setTranslationsByTarget({});
      setDetectedLanguage(null);
      setMaxStepUnlocked(1);
    } else if (targetStep === 2) {
      setAudioByTarget({});
      setRecognizedText("");
      setTranslationsByTarget({});
      setDetectedLanguage(null);
      setMaxStepUnlocked(2);
    }
    return true;
  };

  // ── Project helpers ────────────────────────────────────────────────
  const resetProjectModal = () => {
    setProjectModalPurpose(null);
    setProjectModalError(null);
    setProjectModalStatus("idle");
  };

  const openProjectModal = () => {
    setPendingProjectName(getDefaultProjectName());
    setProjectModalError(null);
    setProjectModalStatus("idle");
    setProjectModalPurpose("draft");
  };

  const ensureProject = (overrideName?: string) => {
    if (activeProjectId) return activeProjectId;
    const rawName = overrideName ?? newProjectName;
    const name = rawName.trim().replace(/\s+/g, " ");
    if (!name || validateNewProjectName(name, activeProjectId)) return null;
    const now = new Date().toISOString();
    const project = createProject({
      name,
      type: "SpeechTranslate",
      status: "Processing",
      data: {
        drafts: {
          speechTranslate: {
            targets: selectedTargets,
            outputFormat,
            showTextOutput,
            voicesByTarget: voicesByTarget as Record<string, string>,
            detectedLanguage: detectedLanguage || undefined,
            recognizedText: recognizedText || undefined,
            translationsByTarget,
            updatedAt: now,
          },
        },
        outputs: {},
      },
    });
    if (!project) return null;
    setActiveProjectId(project.id);
    setNewProjectName(name);
    return project.id;
  };

  const persistProjectState = (
    projectId: string,
    options?: {
      status?: "Processing" | "Completed";
      sourceRecord?: StoredFileRecord | null;
      detectedLanguageValue?: string | null;
      recognizedTextValue?: string;
      translationsValue?: Record<string, string>;
      outputItems?: Record<string, SpeechTranslateAudioItem>;
      scriptEntries?: Array<{
        source: string;
        text: string;
        record: StoredFileRecord;
      }>;
    },
  ) => {
    const project = getProjectById(projectId);
    if (!project) return null;

    const nextName = newProjectName.trim().replace(/\s+/g, " ");
    const namePatch =
      nextName && !validateNewProjectName(nextName, projectId) ? { name: nextName } : {};
    const sRecord =
      options && "sourceRecord" in options
        ? (options.sourceRecord ?? null)
        : sourceFileRecord;
    const outputItems = options?.outputItems ?? audioByTarget;
    const managedScriptEntries = options?.scriptEntries || [];
    const preservedAudio = (project.data?.outputs?.audioVersions || []).filter(
      (entry) => !isSpeechTranslateEntry((entry.settings as any) || {}),
    );
    const preservedScripts = (project.data?.outputs?.scripts || []).filter(
      (entry) =>
        !entry.source?.startsWith(SPEECH_TRANSLATE_TRANSCRIPT_SOURCE) &&
        !entry.source?.startsWith(SPEECH_TRANSLATE_TRANSLATION_SOURCE_PREFIX),
    );

    const speechTranslateAudio: any[] = [];
    if (sRecord) {
      speechTranslateAudio.push({
        id: `speech-translate-source-${sRecord.fileId}`,
        audioUrl: `managed-file:${sRecord.fileId}`,
        createdAt: sRecord.uploadedAt || new Date().toISOString(),
        fileId: sRecord.fileId,
        contentType: sRecord.contentType,
        fileName: sRecord.fileName,
        expiresAt: sRecord.expiresAt,
        estimatedMinutes: sourceMinutes ?? undefined,
        settings: {
          source: "upload",
          feature: "speech-translate",
          fileId: sRecord.fileId,
          fileName: sRecord.fileName,
          contentType: sRecord.contentType,
          expiresAt: sRecord.expiresAt,
        },
      });
    }

    for (const [target, item] of Object.entries(outputItems)) {
      if (!item || (!item.fileId && !item.dataUrl)) continue;
      speechTranslateAudio.push({
        id: item.fileId
          ? `speech-translate-output-${target}-${item.fileId}`
          : crypto.randomUUID(),
        audioUrl: item.dataUrl || (item.fileId ? `managed-file:${item.fileId}` : ""),
        createdAt: new Date().toISOString(),
        fileId: item.fileId,
        contentType: item.contentType,
        fileName: item.fileName || `translated-${target}.${outputFormat}`,
        expiresAt: item.expiresAt,
        voice: item.voice,
        settings: {
          source: "generated",
          feature: "speech-translate",
          target,
          voice: item.voice,
          fileId: item.fileId,
          fileName: item.fileName || `translated-${target}.${outputFormat}`,
          contentType: item.contentType,
          expiresAt: item.expiresAt,
        },
      });
    }

    const updated = updateProject(projectId, {
      ...namePatch,
      type: "SpeechTranslate",
      status: options?.status || (project.status === "Completed" ? "Completed" : "Processing"),
      data: {
        ...(project.data || {}),
        drafts: {
          ...(project.data?.drafts || {}),
          speechTranslate: {
            targets: selectedTargets,
            outputFormat,
            showTextOutput,
            voicesByTarget: voicesByTarget as Record<string, string>,
            detectedLanguage:
              options?.detectedLanguageValue !== undefined
                ? (options.detectedLanguageValue || undefined)
                : (detectedLanguage || undefined),
            recognizedText:
              options?.recognizedTextValue !== undefined
                ? (options.recognizedTextValue || undefined)
                : (recognizedText || undefined),
            translationsByTarget: options?.translationsValue ?? translationsByTarget,
            updatedAt: new Date().toISOString(),
          },
        },
        outputs: {
          ...(project.data?.outputs || {}),
          audioVersions: [...speechTranslateAudio, ...preservedAudio],
          scripts: [
            ...managedScriptEntries.map((entry) => ({
              id: `${entry.source.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${entry.record.fileId}`,
              text: entry.text,
              createdAt: entry.record.uploadedAt || new Date().toISOString(),
              fileId: entry.record.fileId,
              contentType: entry.record.contentType,
              fileName: entry.record.fileName,
              expiresAt: entry.record.expiresAt,
              source: entry.source,
            })),
            ...preservedScripts,
          ].slice(0, 20),
        },
      },
    });

    return updated ? projectId : null;
  };

  // ── File management ────────────────────────────────────────────────
  const ensureSourceStored = async (jobId: string) => {
    if (!audioFile) return null;
    if (!requireProtectedAccess() || !token) return null;
    if (
      sourceFileRecord &&
      sourceFileRecord.fileName === audioFile.name &&
      (sourceFileRecord.sizeBytes == null || sourceFileRecord.sizeBytes === audioFile.size)
    ) {
      return sourceFileRecord;
    }
    setUploadPercent(0);
    const result = await uploadManagedFile(token, audioFile, {
      feature: "speech-translate",
      jobId,
      durationMinutes: sourceMinutes,
      isOutput: false,
      onProgress: (percent) => setUploadPercent(percent),
    });
    setUploadPercent(0);
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return null;
    }
    restoredSourceFileIdRef.current = result.data.fileId;
    setSourceFileRecord(result.data);
    return result.data;
  };

  const saveDraftToProject = async (
    options?: {
      status?: "Processing" | "Completed";
      sourceRecord?: StoredFileRecord | null;
      uploadIfMissing?: boolean;
      projectName?: string;
    },
    projectIdOverride?: string,
  ) => {
    const projectId = projectIdOverride || ensureProject(options?.projectName);
    if (!projectId) return null;
    let nextSourceRecord =
      options && "sourceRecord" in options
        ? (options.sourceRecord ?? null)
        : sourceFileRecord;
    if (audioFile && options?.uploadIfMissing !== false) {
      nextSourceRecord = nextSourceRecord || (await ensureSourceStored(projectId));
      if (!nextSourceRecord) return null;
    }
    return persistProjectState(projectId, {
      status: options?.status,
      sourceRecord: nextSourceRecord,
    });
  };

  const resetResults = () => {
    setError(null);
    setDetectedLanguage(null);
    setRecognizedText("");
    setTranslationsByTarget({});
    setAudioByTarget({});
    setTranslationEditHistory([]);
    setTranslationEditPointer(-1);
    setTranslationOriginals({});
  };

  const revokeOutputUrl = (target: string) => {
    const cached = outputObjectUrlsRef.current[target];
    if (!cached) return;
    URL.revokeObjectURL(cached.url);
    delete outputObjectUrlsRef.current[target];
  };

  const dataUrlToFile = async (
    dataUrl: string,
    fileName: string,
    contentType?: string,
  ): Promise<File> => {
    const response = await fetch(dataUrl);
    const blob = await response.blob();
    return new File([blob], fileName, {
      type: contentType || blob.type || "audio/mpeg",
    });
  };

  const ensureGeneratedOutputsStored = async (
    jobId: string,
    outputs: Record<string, SpeechTranslateAudioItem>,
  ): Promise<Record<string, SpeechTranslateAudioItem> | null> => {
    if (!requireProtectedAccess() || !token) return null;
    const nextEntries = await Promise.all(
      Object.entries(outputs).map(async ([target, item]) => {
        if (!item) return [target, item] as const;
        if (item.fileId) return [target, item] as const;
        if (!item.dataUrl) {
          throw new Error(`Missing generated audio data for ${getTargetLabel(target, TARGET_LANGUAGES)}.`);
        }
        const fileName = item.fileName || `translated-${target}.${outputFormat}`;
        const file = await dataUrlToFile(item.dataUrl, fileName, item.contentType);
        const uploadResult = await uploadManagedFile(token, file, {
          feature: "speech-translate",
          jobId,
          durationMinutes: sourceMinutes,
          isOutput: true,
          onProgress: (percent) => setUploadPercent(percent),
        });
        if (uploadResult.success === false) throw new Error(uploadResult.error);
        return [
          target,
          {
            ...item,
            fileId: uploadResult.data.fileId,
            fileName: uploadResult.data.fileName || item.fileName || fileName,
            contentType: uploadResult.data.contentType || item.contentType || file.type,
            expiresAt: uploadResult.data.expiresAt || item.expiresAt,
          },
        ] as const;
      }),
    );
    return Object.fromEntries(nextEntries);
  };

  const ensureTextOutputsStored = async (
    jobId: string,
    transcriptText: string,
    translations: Record<string, string>,
  ) => {
    if (!token) return null;
    const scriptEntries: Array<{ source: string; text: string; record: StoredFileRecord }> = [];
    const cleanedTranscript = transcriptText.trim();
    if (cleanedTranscript) {
      const transcriptResult = await uploadManagedTextFile(token, cleanedTranscript, {
        fileName: `speech-translate-transcript-${workflowId}.txt`,
        feature: "speech-translate",
        jobId,
        durationMinutes: sourceMinutes,
        isOutput: true,
      });
      if (transcriptResult.success === false) {
        applyProtectedError(transcriptResult.error, transcriptResult.status);
        return null;
      }
      scriptEntries.push({
        source: SPEECH_TRANSLATE_TRANSCRIPT_SOURCE,
        text: cleanedTranscript,
        record: transcriptResult.data,
      });
    }
    for (const [target, value] of Object.entries(translations)) {
      const cleaned = value.trim();
      if (!cleaned) continue;
      const translationResult = await uploadManagedTextFile(token, cleaned, {
        fileName: `speech-translate-${target}-${workflowId}.txt`,
        feature: "speech-translate",
        jobId,
        durationMinutes: sourceMinutes,
        isOutput: true,
      });
      if (translationResult.success === false) {
        applyProtectedError(translationResult.error, translationResult.status);
        return null;
      }
      scriptEntries.push({
        source: `${SPEECH_TRANSLATE_TRANSLATION_SOURCE_PREFIX} (${target})`,
        text: cleaned,
        record: translationResult.data,
      });
    }
    return scriptEntries;
  };

  // ── Download / delete handlers ─────────────────────────────────────
  const handleDownloadSource = async () => {
    if (sourceFileRecord?.fileId) {
      if (!requireProtectedAccess() || !token) return;
      setFileActionKey("source-download");
      const result = await downloadManagedFile(token, sourceFileRecord.fileId);
      setFileActionKey(null);
      if (result.success === false) {
        applyProtectedError(result.error, result.status);
        return;
      }
      const url = URL.createObjectURL(result.data.blob);
      downloadHref(url, result.data.fileName || sourceFileRecord.fileName || "source-audio.wav");
      window.setTimeout(() => URL.revokeObjectURL(url), 0);
      return;
    }
    if (inputAudioUrl && audioFile) {
      downloadHref(inputAudioUrl, audioFile.name || "source-audio.wav");
    }
  };

  const handleDownloadTarget = async (target: string, item: SpeechTranslateAudioItem) => {
    const fallbackName = item.fileName || `translated-${target}.${outputFormat}`;
    if (item.fileId) {
      if (!requireProtectedAccess() || !token) return;
      setFileActionKey(`download-${target}`);
      const result = await downloadManagedFile(token, item.fileId);
      setFileActionKey(null);
      if (result.success === false) {
        applyProtectedError(result.error, result.status);
        return;
      }
      const url = URL.createObjectURL(result.data.blob);
      downloadHref(url, result.data.fileName || fallbackName);
      window.setTimeout(() => URL.revokeObjectURL(url), 0);
      return;
    }
    if (item.dataUrl) {
      downloadHref(item.dataUrl, fallbackName);
    }
  };

  const handleDeleteSource = async () => {
    if (!sourceFileRecord?.fileId) return;
    if (!requireProtectedAccess() || !token) return;
    const confirmDelete = await dialog.confirm(
      "Are you sure you want to delete the source audio file? This action cannot be undone.",
      { title: "Delete Source Audio", confirmText: "Delete", cancelText: "Cancel", variant: "danger" },
    );
    if (!confirmDelete) return;
    setFileActionKey("source-delete");
    const result = await deleteManagedFile(token, sourceFileRecord.fileId);
    setFileActionKey(null);
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return;
    }
    restoredSourceFileIdRef.current = null;
    setSourceFileRecord(null);
    if (activeProjectId) persistProjectState(activeProjectId, { sourceRecord: null });
  };

  const handleDeleteTarget = async (target: string, item: SpeechTranslateAudioItem) => {
    if (!item.fileId) return;
    if (!requireProtectedAccess() || !token) return;
    const confirmDelete = await dialog.confirm(
      `Are you sure you want to delete the ${getTargetLabel(target, TARGET_LANGUAGES)} translation? This action cannot be undone.`,
      { title: "Delete Translation", confirmText: "Delete", cancelText: "Cancel", variant: "danger" },
    );
    if (!confirmDelete) return;
    setFileActionKey(`delete-${target}`);
    const result = await deleteManagedFile(token, item.fileId);
    setFileActionKey(null);
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return;
    }
    revokeOutputUrl(target);
    const nextAudio = { ...audioByTarget };
    delete nextAudio[target];
    setAudioByTarget(nextAudio);
    if (activeProjectId) persistProjectState(activeProjectId, { outputItems: nextAudio });
  };

  const handleDownloadAll = async () => {
    const entries = selectedTargets
      .map((target) => [target, audioByTarget[target]] as const)
      .filter((entry) => Boolean(entry[1]));
    if (!entries.length) return;
    setFileActionKey("download-all");
    for (const [target, item] of entries) {
      await handleDownloadTarget(target, item);
    }
    setFileActionKey(null);
  };

  const handleDeleteAll = async () => {
    if (!requireProtectedAccess() || !token) return;
    const confirmDelete = await dialog.confirm(
      "Are you sure you want to delete all translations? This action cannot be undone.",
      { title: "Delete All Translations", confirmText: "Delete All", cancelText: "Cancel", variant: "danger" },
    );
    if (!confirmDelete) return;
    setFileActionKey("delete-all");
    const entries = selectedTargets
      .map((target) => [target, audioByTarget[target]] as const)
      .filter(([, item]) => Boolean(item) && Boolean(item?.fileId));
    for (const [target, item] of entries) {
      if (item?.fileId) {
        const result = await deleteManagedFile(token, item.fileId);
        if (result.success === false) {
          applyProtectedError(result.error, result.status);
          setFileActionKey(null);
          return;
        }
        revokeOutputUrl(target);
      }
    }
    setAudioByTarget({});
    if (activeProjectId) persistProjectState(activeProjectId, { outputItems: {} });
    setFileActionKey(null);
  };

  const handleDownloadTranslatedText = () => {
    const lines: string[] = [];
    if (recognizedText.trim()) {
      lines.push("=== Original Transcript ===\n");
      lines.push(recognizedText.trim());
      lines.push("\n");
    }
    for (const target of selectedTargets) {
      const text = translationsByTarget[target];
      if (text?.trim()) {
        lines.push(`\n=== ${getTargetLabel(target, TARGET_LANGUAGES)} (${target}) ===\n`);
        lines.push(text.trim());
      }
    }
    if (!lines.length) return;
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    downloadHref(url, `speech-translate-text-${Date.now()}.txt`);
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  };

  // ── Input handlers ─────────────────────────────────────────────────
  const onPickFile = (next: File | null) => {
    resetResults();
    restoredSourceFileIdRef.current = null;
    setSourceFileRecord(null);
    setAudioFile(next);
    setShowOriginalTranscript(false);
    setCompletedSteps(next ? new Set<StepId>([1]) : new Set());
    setStep(1);
    setIsDirty(true);
  };

  const handleRecordClick = async () => {
    resetResults();
    restoredSourceFileIdRef.current = null;
    setSourceFileRecord(null);
    if (isRecording) {
      const wav = await stopRecording();
      if (wav) onPickFile(wav);
      return;
    }
    await startRecording();
  };

  const handleTextFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      let text = reader.result as string;
      if (file.name.endsWith(".srt")) {
        text = text
          .replace(/^\d+\s*$/gm, "")
          .replace(
            /\d{2}:\d{2}:\d{2}[.,]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[.,]\d{3}/g,
            "",
          )
          .replace(/\n{3,}/g, "\n\n")
          .trim();
      }
      setTextInput(text);
      setIsDirty(true);
    };
    reader.readAsText(file);
  };

  // ── Voice preview ──────────────────────────────────────────────────
  // Calls the real TTS endpoint so the preview reflects the actual Azure Neural voice.
  // First play charges credits via the create-voice backend; replays use cached audio (free).
  const handlePreview = async (voice: VoiceName) => {
    if (!isAuthenticated) {
      setAuthRequiredOpen(true);
      return;
    }
    if (previewPlayingId === voice) {
      previewRef.current?.pause();
      setPreviewPlayingId(null);
      return;
    }

    previewRef.current?.pause();
    setPreviewLoadingId(voice);

    const cached = previewCacheRef.current.get(voice);
    if (cached) {
      if (!previewRef.current) return;
      previewRef.current.src = cached;
      previewRef.current.onplay = () => {
        setPreviewLoadingId(null);
        setPreviewPlayingId(voice);
      };
      previewRef.current.onended = () => setPreviewPlayingId(null);
      void previewRef.current.play();
      return;
    }

    const voiceOption = AVAILABLE_VOICES.find((v) => v.id === voice);
    const previewText = getPreviewTextForVoice(voice);

    try {
      const url = await generateAzureSpeech(
        previewText, voice, 0, 0, 100, "general", 1.0, token,
      );
      previewCacheRef.current.set(voice, url);
      void refreshBalance();
      if (!previewRef.current) return;
      previewRef.current.src = url;
      previewRef.current.onplay = () => {
        setPreviewLoadingId(null);
        setPreviewPlayingId(voice);
      };
      previewRef.current.onended = () => setPreviewPlayingId(null);
      await previewRef.current.play();
    } catch {
      setPreviewLoadingId(null);
    }
  };

  // ── Translation edit history (undo/redo) ───────────────────────────
  const pushTranslationEdit = (next: Record<string, string>) => {
    setTranslationsByTarget(next);
    setTranslationEditHistory((prev) => {
      const newHistory = prev.slice(0, translationEditPointer + 1);
      newHistory.push({ ...next });
      if (newHistory.length > 50) newHistory.shift();
      return newHistory;
    });
    setTranslationEditPointer((prev) => Math.min(prev + 1, 49));
    setIsDirty(true);
  };

  const handleTranslationChange = (target: string, value: string) => {
    pushTranslationEdit({ ...translationsByTarget, [target]: value });
  };

  const undoTranslation = () => {
    if (translationEditPointer <= 0) return;
    const newPointer = translationEditPointer - 1;
    setTranslationEditPointer(newPointer);
    setTranslationsByTarget(translationEditHistory[newPointer]);
  };

  const redoTranslation = () => {
    if (translationEditPointer >= translationEditHistory.length - 1) return;
    const newPointer = translationEditPointer + 1;
    setTranslationEditPointer(newPointer);
    setTranslationsByTarget(translationEditHistory[newPointer]);
  };

  const resetTranslationEdits = () => {
    if (Object.keys(translationOriginals).length) {
      setTranslationsByTarget({ ...translationOriginals });
    }
  };

  const canUndo = translationEditPointer > 0;
  const canRedo = translationEditPointer < translationEditHistory.length - 1;

  // ── Step handlers ──────────────────────────────────────────────────
  const handleContinue = async () => {
    setError(null);
    if (!audioFile) {
      setError("Please upload or record an audio file.");
      return;
    }
    if (!requireProtectedAccess()) return;
    const sourceRecord = await ensureSourceStored(activeProjectId || workflowId);
    if (!sourceRecord) return;

    setMaxStepUnlocked((prev) => (prev >= 2 ? prev : 2) as StepId);
    if (activeProjectId) {
      persistProjectState(activeProjectId, { status: "Processing", sourceRecord });
    } else {
      void saveDraftToProject({
        status: "Processing",
        sourceRecord,
        uploadIfMissing: false,
        projectName: getDefaultProjectName(),
      });
    }
    setStep(2);
  };

  const handleStep2Continue = () => {
    setError(null);
    if (!audioFile) return setStep(1);
    if (!selectedTargets.length) return setError("Please select at least one target language.");
    setMaxStepUnlocked((prev) => (prev >= 3 ? prev : 3) as StepId);
    if (activeProjectId && sourceFileRecord) {
      persistProjectState(activeProjectId, {
        status: "Processing",
        sourceRecord: sourceFileRecord,
      });
    } else if (sourceFileRecord) {
      void saveDraftToProject({
        status: "Processing",
        sourceRecord: sourceFileRecord,
        uploadIfMissing: false,
        projectName: getDefaultProjectName(),
      });
    }
    setStep(3);
  };

  const handleSaveDraft = async (projectName?: string): Promise<boolean> => {
    setError(null);
    if (!requireProtectedAccess()) return false;
    if (!audioFile) {
      setError("Please upload or record an audio file.");
      return false;
    }
    const projectId = await saveDraftToProject({ status: "Processing", projectName });
    if (!projectId) {
      setError("Could not save draft. Please try again.");
      return false;
    }
    return true;
  };

  const handleTranslate = async () => {
    setError(null);
    resetResults();
    if (!requireProtectedAccess() || !token) return;
    if (!audioFile) return setError("Please upload or record an audio file.");
    if (!selectedTargets.length) return setError("Please select at least one target language.");

    let projectId: string | null = activeProjectId;
    if (!projectId) {
      projectId = ensureProject(getDefaultProjectName());
    }
    if (!projectId) return setError("Could not create project. Please try again.");
    if (!sourceFileRecord?.fileId) {
      return setError("Please complete Step 1 so the source audio is uploaded before generating.");
    }

    const savedProjectId = await saveDraftToProject(
      { status: "Processing", sourceRecord: sourceFileRecord, uploadIfMissing: false },
      projectId,
    );
    if (!savedProjectId)
      return setError("Could not save your current draft. Please check your browser storage and try again.");

    setGenerationPhase(0);
    setGenerationStartTime(Date.now());
    translateProgress.start();

    // Phase tracking
    const phaseTimer = window.setInterval(() => {
      setGenerationPhase((prev) =>
        prev < GENERATION_PHASES.length - 1 ? prev + 1 : prev,
      );
    }, 3000);

    const result = await translateSpeechToSpeech(audioFile, {
      targets: selectedTargets,
      outputFormat,
      voicesByTarget: voicesByTarget as Record<string, string | undefined>,
      token,
      jobId: savedProjectId,
      inputFileId: sourceFileRecord.fileId,
    });

    window.clearInterval(phaseTimer);

    if (result.success === false) {
      translateProgress.stop();
      setGenerationStartTime(null);
      if (result.insufficientCredits) {
        setInsuffCreditsInfo({ required: result.requiredCredits ?? 0, current: result.currentBalance ?? 0 });
        return;
      }
      return applyProtectedError(result.error, result.status);
    }

    setGenerationPhase(GENERATION_PHASES.length - 1);

    const nextDetectedLanguage = result.data.detectedLanguage || null;
    const nextRecognizedText = (result.data.text || "").trim();
    const nextTranslations = result.data.translations || {};
    const rawAudio = result.data.audio || {};

    let nextAudio: Record<string, SpeechTranslateAudioItem>;
    try {
      const storedOutputs = await ensureGeneratedOutputsStored(savedProjectId, rawAudio);
      if (!storedOutputs) {
        translateProgress.stop();
        setGenerationStartTime(null);
        return;
      }
      nextAudio = storedOutputs;
    } catch (err: any) {
      translateProgress.stop();
      setGenerationStartTime(null);
      setError(err?.message || "Generated output could not be stored in Azure Files.");
      return;
    }

    const nextScriptEntries = await ensureTextOutputsStored(
      savedProjectId,
      nextRecognizedText,
      nextTranslations,
    );
    if (nextScriptEntries === null) {
      translateProgress.stop();
      setGenerationStartTime(null);
      return;
    }

    setDetectedLanguage(nextDetectedLanguage);
    setRecognizedText(nextRecognizedText);
    setTranslationsByTarget(nextTranslations);
    setTranslationOriginals({ ...nextTranslations });
    setTranslationEditHistory([{ ...nextTranslations }]);
    setTranslationEditPointer(0);
    setAudioByTarget(nextAudio);

    persistProjectState(savedProjectId, {
      status: "Completed",
      sourceRecord: sourceFileRecord,
      detectedLanguageValue: nextDetectedLanguage,
      recognizedTextValue: nextRecognizedText,
      translationsValue: nextTranslations,
      outputItems: nextAudio,
      scriptEntries: nextScriptEntries,
    });

    await translateProgress.finish();
    setGenerationStartTime(null);
    setIsDirty(false);
    setLastAutoSaved(new Date().toISOString());
    void refreshBalance();
  };

  const handleStartNew = async () => {
    if (isStep1Complete || isStep3Complete) {
      const confirmed = await dialog.confirm(
        "Start a new translation? Any unsaved progress will be lost.",
        {
          title: "Start New Translation",
          confirmText: "Start New",
          cancelText: "Cancel",
          variant: "warning",
        },
      );
      if (!confirmed) return;
    }
    setError(null);
    setAudioFile(null);
    setSourceFileRecord(null);
    restoredSourceFileIdRef.current = null;
    setDetectedLanguage(null);
    setRecognizedText("");
    setTranslationsByTarget({});
    setAudioByTarget({});
    setShowOriginalTranscript(false);
    setCompletedSteps(new Set());
    setStep(1);
    setActiveProjectId("");
    setNewProjectName("");
    setIsDirty(false);
  };

  const handleProjectModalProceed = async () => {
    if (!projectModalPurpose) return;
    const candidate = pendingProjectName.trim();
    if (candidate.length <= 3) {
      setProjectModalError("Project name must be at least 4 characters.");
      return;
    }
    const validationError = validateNewProjectName(candidate, activeProjectId);
    if (validationError) {
      setProjectModalError(validationError);
      return;
    }
    setProjectModalError(null);
    setPendingProjectName(candidate);
    setProjectModalStatus("idle");
    setNewProjectName(candidate);

    saveDraftProgress.start();
    const saved = await handleSaveDraft(candidate);
    if (!saved) {
      saveDraftProgress.stop();
      return;
    }
    await saveDraftProgress.finish();
    setProjectModalStatus("saved");
    setIsDirty(false);
    setLastAutoSaved(new Date().toISOString());
    window.setTimeout(() => navigate("/projects"), 600);
  };

  // ── Project restore ────────────────────────────────────────────────
  useEffect(() => {
    if (!projectIdFromQuery) return;
    const project = getProjectById(projectIdFromQuery);
    if (!project) return;

    setActiveProjectId(project.id);
    if (project.name.trim()) setNewProjectName(project.name);

    const draft = project.data?.drafts?.speechTranslate;
    if (Array.isArray(draft?.targets) && draft.targets.length) setSelectedTargets(draft.targets);
    if (draft?.outputFormat === "mp3" || draft?.outputFormat === "wav")
      setOutputFormat(draft.outputFormat);
    if (typeof draft?.showTextOutput === "boolean") setShowTextOutput(draft.showTextOutput);
    if (draft?.voicesByTarget && typeof draft.voicesByTarget === "object") {
      setVoicesByTarget(draft.voicesByTarget as Record<string, VoiceName | "">);
    }
    if (typeof draft?.detectedLanguage === "string") setDetectedLanguage(draft.detectedLanguage);
    if (typeof draft?.recognizedText === "string") setRecognizedText(draft.recognizedText);
    if (draft?.translationsByTarget && typeof draft.translationsByTarget === "object") {
      setTranslationsByTarget(draft.translationsByTarget as Record<string, string>);
    }

    const versions = project.data?.outputs?.audioVersions || [];
    const source = versions.find((entry) => isSourceEntry((entry.settings as any) || {}));
    const outputs = versions.filter((entry) => isGeneratedEntry((entry.settings as any) || {}));

    if (source) {
      const settings: any = source.settings || {};
      const fileId = source.fileId || settings?.fileId;
      const fileName = source.fileName || settings?.fileName || "source-audio.wav";
      const contentType = source.contentType || settings?.contentType || settings?.mimeType;
      const expiresAt = source.expiresAt || settings?.expiresAt;
      if (typeof fileId === "string" && fileId.trim()) {
        restoredSourceFileIdRef.current = null;
        setSourceFileRecord({
          fileId,
          fileName,
          contentType: typeof contentType === "string" ? contentType : undefined,
          uploadedAt: source.createdAt,
          expiresAt: typeof expiresAt === "string" ? expiresAt : undefined,
          feature: "speech-translate",
          isOutput: false,
        });
      }
      if (typeof source.audioUrl === "string" && source.audioUrl.startsWith("idb-audio:")) {
        const blobId = source.audioUrl.slice("idb-audio:".length).trim();
        if (blobId) {
          void (async () => {
            try {
              const blob = await loadAudioBlob(blobId);
              if (!blob) return;
              setAudioFile(
                new File([blob], fileName, { type: contentType || blob.type || "audio/wav" }),
              );
            } catch {
              // ignore legacy storage errors
            }
          })();
        }
      }
    }

    const nextOutputs = outputs.reduce<Record<string, SpeechTranslateAudioItem>>((acc, entry) => {
      const settings: any = entry.settings || {};
      const target = settings?.target;
      if (typeof target !== "string" || !target.trim()) return acc;
      acc[target] = {
        fileId:
          typeof (entry.fileId || settings?.fileId) === "string"
            ? String(entry.fileId || settings?.fileId)
            : undefined,
        fileName:
          typeof (entry.fileName || settings?.fileName) === "string"
            ? String(entry.fileName || settings?.fileName)
            : undefined,
        contentType:
          typeof (entry.contentType || settings?.contentType) === "string"
            ? String(entry.contentType || settings?.contentType)
            : undefined,
        voice:
          typeof (entry.voice || settings?.voice) === "string"
            ? String(entry.voice || settings?.voice)
            : undefined,
        expiresAt:
          typeof (entry.expiresAt || settings?.expiresAt) === "string"
            ? String(entry.expiresAt || settings?.expiresAt)
            : undefined,
        dataUrl:
          typeof entry.audioUrl === "string" &&
          (entry.audioUrl.startsWith("data:") || entry.audioUrl.startsWith("blob:"))
            ? entry.audioUrl
            : undefined,
      };
      return acc;
    }, {});
    setAudioByTarget(nextOutputs);

    const nextCompleted = new Set<StepId>();
    if (source) nextCompleted.add(1);
    if (Array.isArray(draft?.targets) && draft.targets.length) nextCompleted.add(2);
    if (
      Object.keys(nextOutputs).length ||
      (draft?.translationsByTarget && Object.keys(draft.translationsByTarget).length)
    ) {
      nextCompleted.add(3);
    }
    setCompletedSteps(nextCompleted);
    const maxCompleted = Math.max(...Array.from(nextCompleted), 0) as StepId;
    if (maxCompleted > 0) {
      setMaxStepUnlocked((maxCompleted + 1) as StepId);
    }
    setStep(nextCompleted.has(3) ? 3 : nextCompleted.has(1) ? 2 : 1);
  }, [projectIdFromQuery]);

  // ── Source file restore from server ────────────────────────────────
  useEffect(() => {
    if (!sourceFileRecord?.fileId || !token || audioFile) return;
    if (restoredSourceFileIdRef.current === sourceFileRecord.fileId) return;
    let canceled = false;
    restoredSourceFileIdRef.current = sourceFileRecord.fileId;
    void (async () => {
      const result = await downloadManagedFile(token, sourceFileRecord.fileId);
      if (canceled) return;
      if (result.success === false) {
        applyProtectedError(result.error, result.status);
        return;
      }
      setAudioFile(
        new File([result.data.blob], sourceFileRecord.fileName, {
          type:
            sourceFileRecord.contentType ||
            result.data.contentType ||
            result.data.blob.type ||
            "audio/wav",
        }),
      );
    })();
    return () => {
      canceled = true;
    };
  }, [audioFile, sourceFileRecord, token]);

  // ── Output blob URLs for audio players ─────────────────────────────
  useEffect(() => {
    for (const [target, cached] of Object.entries(outputObjectUrlsRef.current)) {
      const nextItem = audioByTarget[target];
      if (!nextItem?.fileId || nextItem.fileId !== cached.fileId) {
        URL.revokeObjectURL(cached.url);
        delete outputObjectUrlsRef.current[target];
      }
    }
    if (!token) return;
    let canceled = false;
    for (const [target, item] of Object.entries(audioByTarget)) {
      if (!item?.fileId || item.dataUrl) continue;
      const cached = outputObjectUrlsRef.current[target];
      if (cached && cached.fileId === item.fileId) {
        setAudioByTarget((prev) =>
          prev[target] && prev[target].dataUrl !== cached.url
            ? { ...prev, [target]: { ...prev[target], dataUrl: cached.url } }
            : prev,
        );
        continue;
      }
      void (async () => {
        const result = await downloadManagedFile(token, item.fileId as string);
        if (canceled || !result.success) return;
        const url = URL.createObjectURL(result.data.blob);
        revokeOutputUrl(target);
        outputObjectUrlsRef.current[target] = { fileId: item.fileId as string, url };
        setAudioByTarget((prev) =>
          prev[target]
            ? {
                ...prev,
                [target]: {
                  ...prev[target],
                  dataUrl: url,
                  contentType: prev[target].contentType || result.data.contentType,
                  fileName: prev[target].fileName || result.data.fileName,
                },
              }
            : prev,
        );
      })();
    }
    return () => {
      canceled = true;
    };
  }, [audioByTarget, token]);

  // ── URL cleanup ────────────────────────────────────────────────────
  useEffect(() => {
    return () => {
      for (const cached of Object.values(outputObjectUrlsRef.current))
        URL.revokeObjectURL(cached.url);
    };
  }, []);

  // ── Duration detection ─────────────────────────────────────────────
  useEffect(() => {
    if (!inputAudioUrl) {
      setDurationSeconds(null);
      return;
    }
    let canceled = false;
    const audio = new Audio();
    audio.src = inputAudioUrl;
    const onLoaded = () => {
      if (canceled) return;
      setDurationSeconds(Number.isFinite(audio.duration) ? audio.duration : null);
    };
    audio.addEventListener("loadedmetadata", onLoaded);
    return () => {
      canceled = true;
      audio.removeEventListener("loadedmetadata", onLoaded);
    };
  }, [inputAudioUrl]);

  // ── Input audio URL ────────────────────────────────────────────────
  useEffect(() => {
    if (inputAudioUrl) URL.revokeObjectURL(inputAudioUrl);
    if (!audioFile) {
      setInputAudioUrl(null);
      return;
    }
    const url = URL.createObjectURL(audioFile);
    setInputAudioUrl(url);
    return () => URL.revokeObjectURL(url);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioFile]);

  // ── Sync voicesByTarget keys when targets change (keep existing, remove stale) ──
  useEffect(() => {
    setVoicesByTarget((prev) => {
      const next: Record<string, VoiceName | ""> = {};
      for (const target of selectedTargets) {
        next[target] = prev[target] ?? "";
      }
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTargets.join("|")]);

  // ── Auto-save (30s interval, auth only) ────────────────────────────
  useEffect(() => {
    if (!isAuthenticated || !token || !isDirty || !activeProjectId) return;
    const timer = window.setInterval(() => {
      if (!isDirty) return;
      void (async () => {
        const saved = await saveDraftToProject({
          status: "Processing",
          uploadIfMissing: false,
        });
        if (saved) {
          setIsDirty(false);
          setLastAutoSaved(new Date().toISOString());
        }
      })();
    }, 30000);
    return () => window.clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, token, isDirty, activeProjectId]);

  return {
    // Theme
    theme,
    toggleTheme,
    // Auth
    isAuthenticated,
    token,
    isGuest,
    // Wizard
    step,
    setStep,
    maxStepUnlocked,
    completedSteps,
    isStep1Complete,
    isStep2Complete,
    isStep3Complete,
    authRequiredOpen,
    setAuthRequiredOpen,
    insufficientCreditsInfo,
    clearInsuffCreditsInfo: () => setInsuffCreditsInfo(null),
    // Project modal
    projectModalPurpose,
    pendingProjectName,
    setPendingProjectName,
    projectModalError,
    projectModalStatus,
    projectModalLoading: projectModalPurpose === "draft" ? saveDraftProgress.inProgress : false,
    projectModalPercent: projectModalPurpose === "draft" ? saveDraftProgress.percent : 0,
    resetProjectModal,
    openProjectModal,
    handleProjectModalProceed,
    activeProjectId,
    newProjectName,
    setNewProjectName,
    projectNameError,
    canUseProjectName,
    // Input
    inputMode,
    setInputMode,
    audioFile,
    sourceFileRecord,
    dragOver,
    setDragOver,
    fileInputRef,
    isRecording,
    recordError,
    recordingElapsed,
    textInput,
    setTextInput,
    inputAudioUrl,
    durationSeconds,
    onPickFile,
    handleRecordClick,
    handleTextFileUpload,
    sourceLanguageOverride,
    setSourceLanguageOverride,
    // Regional language support
    isRegionalOnly,
    setIsRegionalOnly,
    isTargetRegional,
    filteredTargetLanguages,
    // Targets / config
    selectedTargets,
    setSelectedTargets,
    outputFormat,
    setOutputFormat,
    showTextOutput,
    setShowTextOutput,
    voicesByTarget,
    setVoicesByTarget,
    voicesForTarget,
    selectedTargetsLabel,
    // Voice preview
    previewLoadingId,
    previewPlayingId,
    previewRef,
    handlePreview,
    // Progress
    translateInProgress: translateProgress.inProgress,
    translatePercent: translateProgress.percent,
    saveDraftInProgress: saveDraftProgress.inProgress,
    saveDraftPercent: saveDraftProgress.percent,
    uploadPercent,
    generationPhase,
    generationElapsed,
    // Results
    detectedLanguage,
    recognizedText,
    translationsByTarget,
    showOriginalTranscript,
    setShowOriginalTranscript,
    audioByTarget,
    error,
    setError,
    fileActionKey,
    // Translation editing
    handleTranslationChange,
    undoTranslation,
    redoTranslation,
    resetTranslationEdits,
    canUndo,
    canRedo,
    translationOriginals,
    // Re-generate
    showRegenVoicePicker,
    setShowRegenVoicePicker,
    // Actions
    isBusy,
    canSaveDraft,
    canTranslateSpeech,
    handleContinue,
    handleStep2Continue,
    handleSaveDraft,
    handleTranslate,
    handleStartNew,
    handleStepNavigation,
    resetResults,
    // File actions
    handleDownloadSource,
    handleDownloadTarget,
    handleDeleteSource,
    handleDeleteTarget,
    handleDownloadAll,
    handleDeleteAll,
    handleDownloadTranslatedText,
    // Summaries
    step1Summary,
    step2Summary,
    step3Summary,
    // Auto-save
    isDirty,
    lastAutoSaved,
    // Formatters re-exported for steps
    formatDuration,
    formatDateTime,
    getDefaultProjectName,
    // Constants
    TARGET_LANGUAGES,
    GENERATION_PHASES,
  };
}
