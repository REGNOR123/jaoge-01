import React from "react";
import type { useSpeechTranslateState } from "./useSpeechTranslateState";
import StepCard from "../StepCard";
import type { VoiceName } from "../../types";
import { getTargetLabel } from "./constants";
import { TARGET_LANGUAGES } from "./languages";

type Props = { state: ReturnType<typeof useSpeechTranslateState> };

const REGIONAL_CODES = new Set([
  "hi", "ta", "te", "ml", "bn", "mr", "gu", "kn", "pa", "ur", "or", "as",
  "ms", "id", "fil", "jv", "my", "km", "lo",
]);

const Step2Configure: React.FC<Props> = ({ state }) => {
  const {
    selectedTargets,
    setSelectedTargets,
    outputFormat,
    setOutputFormat,
    showTextOutput,
    setShowTextOutput,
    voicesByTarget,
    setVoicesByTarget,
    voicesForTarget,
    resetResults,
    isStep2Complete,
    step2Summary,
    previewLoadingId,
    previewPlayingId,
    handlePreview,
    // Regional language support
    isTargetRegional,
    isRegionalOnly,
    setIsRegionalOnly,
    filteredTargetLanguages,
  } = state;

  const [dropdownOpen, setDropdownOpen] = React.useState(false);
  const [langSearch, setLangSearch] = React.useState("");
  const [regionalDismissed, setRegionalDismissed] = React.useState(false);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => { setRegionalDismissed(false); }, [isTargetRegional]);

  React.useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node))
        setDropdownOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filteredLanguages = filteredTargetLanguages.filter((l) =>
    l.name.toLowerCase().includes(langSearch.toLowerCase()),
  );

  return (
    <StepCard
      step={2}
      title="Configure Speech"
      description="Select target languages, output format, and voice settings."
      isActive
      isCompleted={isStep2Complete}
      summary={step2Summary}
    >
      <div className="space-y-6">
        {/* Regional target banner */}
        {isTargetRegional && !regionalDismissed && (
          <div className="relative rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-start gap-3">
            <svg className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
            </svg>
            <div>
              <p className="text-sm font-black text-amber-900 dark:text-amber-200">
                Regional target language selected — 2× credit rate applies
              </p>
              <p className="mt-1 text-xs font-medium text-amber-800 dark:text-amber-300/80">
                Indian and Southeast Asian voices are charged at{" "}
                <span className="font-black">2 credits per 100 characters</span>{" "}
                (vs. 1 cr for standard). Languages marked <span className="font-black">2×</span> below use this rate.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setRegionalDismissed(true)}
              className="absolute top-2 right-2 p-1 rounded-md text-amber-600 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-200 hover:bg-amber-500/15 transition-colors"
              aria-label="Dismiss"
            >
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        )}

        {/* Output Settings */}
        <div>
          <h3 className="mb-4 text-xs font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
            Output Settings
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Audio Format */}
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/70 dark:bg-white/5 p-4">
              <label
                htmlFor="output-format"
                className="block text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-3"
              >
                Audio Format
              </label>
              <select
                id="output-format"
                value={outputFormat}
                onChange={(e) => setOutputFormat(e.target.value as "mp3" | "wav")}
                className="w-full px-4 py-3 rounded-xl bg-white/60 dark:bg-slate-800 border border-slate-200 dark:border-white/15 text-sm font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
              >
                <option value="mp3">MP3</option>
                <option value="wav">WAV</option>
              </select>
            </div>

            {/* Show text toggle */}
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/70 dark:bg-white/5 p-4 flex items-end">
              <label className="flex items-center justify-between gap-3 w-full">
                <span className="text-sm font-semibold text-slate-900 dark:text-white">
                  Show recognized/translated text
                </span>
                <input
                  type="checkbox"
                  checked={showTextOutput}
                  onChange={(e) => setShowTextOutput(e.target.checked)}
                  className="h-5 w-5 accent-indigo-600 flex-shrink-0"
                />
              </label>
            </div>
          </div>
        </div>

        {/* Target Languages */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
              Target Languages
            </h3>
            {/* Display regional languages checkbox */}
            <label className="inline-flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isRegionalOnly}
                onChange={(e) => {
                  const next = e.target.checked;
                  setIsRegionalOnly(next);
                  if (next) {
                    resetResults();
                    setSelectedTargets((prev: string[]) =>
                      prev.filter((t: string) => REGIONAL_CODES.has(t.split("-")[0].toLowerCase())),
                    );
                  }
                }}
                className="h-3.5 w-3.5 accent-amber-500 flex-shrink-0"
              />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Display regional languages
              </span>
            </label>
          </div>
          {isRegionalOnly && (
            <div className="mb-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-3 flex items-start gap-2">
              <svg className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
              </svg>
              <p className="text-xs font-medium text-amber-800 dark:text-amber-300/80">
                Regional languages (Indian & SE Asian) are charged at{" "}
                <span className="font-black">2 credits per 100 characters</span>{" "}
                (2× standard rate).
              </p>
            </div>
          )}
          <div className="space-y-3">
            {/* Dropdown trigger */}
            <div className="relative" ref={dropdownRef}>
              <button
                type="button"
                onClick={() => { setDropdownOpen((p) => !p); setLangSearch(""); }}
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-white/60 dark:bg-slate-800 border border-slate-200 dark:border-white/15 text-sm font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
              >
                <span className={selectedTargets.length > 0 ? "text-slate-900 dark:text-white" : "text-slate-400"}>
                  {selectedTargets.length > 0 ? `${selectedTargets.length} language${selectedTargets.length > 1 ? "s" : ""} selected` : "Select languages..."}
                </span>
                <svg className={`w-4 h-4 text-slate-400 transition-transform ${dropdownOpen ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {dropdownOpen && (
                <div className="absolute z-20 w-full mt-1 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-white/15 shadow-xl overflow-hidden">
                  <div className="p-2 border-b border-slate-100 dark:border-white/10">
                    <input
                      autoFocus
                      type="text"
                      placeholder="Search languages..."
                      value={langSearch}
                      onChange={(e) => setLangSearch(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-700 border border-slate-200 dark:border-white/10 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-slate-900 dark:text-white placeholder:text-slate-400"
                    />
                  </div>
                  <div className="max-h-52 overflow-auto">
                    {filteredLanguages.length === 0 ? (
                      <p className="px-4 py-3 text-sm text-slate-400">No languages found.</p>
                    ) : filteredLanguages.map((lang) => {
                      const selected = selectedTargets.includes(lang.code);
                      const isRegionalLang = REGIONAL_CODES.has(lang.code.split("-")[0].toLowerCase());
                      return (
                        <button
                          key={lang.code}
                          type="button"
                          onClick={() => {
                            resetResults();
                            setSelectedTargets((prev: string[]) =>
                              selected ? prev.filter((t: string) => t !== lang.code) : [...prev, lang.code],
                            );
                          }}
                          className={`w-full flex items-center justify-between px-4 py-2.5 text-sm text-left transition-colors ${
                            selected
                              ? "bg-indigo-50 dark:bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 font-bold"
                              : "text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-50 dark:hover:bg-white/5"
                          }`}
                        >
                          <span>
                            {lang.name}
                            {isRegionalLang && (
                              <span className="ml-1.5 text-[10px] font-black text-amber-600 dark:text-amber-400">(2×)</span>
                            )}
                          </span>
                          {selected && (
                            <svg className="w-4 h-4 text-indigo-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Selected language chips */}
            {selectedTargets.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {selectedTargets.map((code: string) => (
                  <span
                    key={code}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-100 dark:bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 text-xs font-bold"
                  >
                    {getTargetLabel(code, TARGET_LANGUAGES)}
                    <button
                      type="button"
                      onClick={() => { resetResults(); setSelectedTargets((prev: string[]) => prev.filter((t: string) => t !== code)); }}
                      className="hover:text-indigo-900 dark:hover:text-white transition-colors"
                    >
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Voice Selection */}
        {selectedTargets.length > 0 && (
          <div>
            <h3 className="mb-3 text-xs font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
              Voice Selection
            </h3>
            <p className="mb-3 text-[11px] text-slate-400 dark:text-slate-500">
              1 credit per new voice preview · replays are free
            </p>

            <div className="space-y-3">
              {selectedTargets.map((target: string) => {
                const voices = voicesForTarget[target] || [];
                const selectedVoice = voicesByTarget[target] || "";
                const isRegional = voices[0]?.region === "Indian" || voices[0]?.region === "SE Asian";

                return (
                  <div key={target} className="flex items-center gap-3">
                    <span className="w-24 shrink-0 text-xs font-bold text-slate-700 dark:text-slate-300 truncate flex items-center gap-1.5">
                      {getTargetLabel(target, TARGET_LANGUAGES)}
                      {isRegional && (
                        <span className="px-1.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 text-[9px] font-black uppercase tracking-wider">
                          2×
                        </span>
                      )}
                    </span>
                    {voices.length === 0 ? (
                      <span className="text-xs text-slate-400 italic">No voices available</span>
                    ) : (
                      <>
                        <select
                          value={selectedVoice}
                          onChange={(e) => {
                            resetResults();
                            setVoicesByTarget((prev: Record<string, VoiceName | "">) => ({
                              ...prev,
                              [target]: e.target.value as VoiceName,
                            }));
                          }}
                          className="flex-1 px-3 py-2 rounded-xl bg-white/60 dark:bg-slate-800 border border-slate-200 dark:border-white/15 text-sm font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                        >
                          <option value="" disabled>Select a voice...</option>
                          {voices.map((v) => (
                            <option key={v.id} value={v.id}>
                              {v.name} — {v.gender}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          disabled={!selectedVoice || previewLoadingId === (selectedVoice as VoiceName)}
                          onClick={() => selectedVoice && void handlePreview(selectedVoice as VoiceName)}
                          title={previewPlayingId === selectedVoice ? "Stop preview" : "Preview voice"}
                          className="shrink-0 w-9 h-9 flex items-center justify-center rounded-xl border border-slate-200 dark:border-white/15 bg-white/60 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          {previewLoadingId === (selectedVoice as VoiceName) ? (
                            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                            </svg>
                          ) : previewPlayingId === (selectedVoice as VoiceName) ? (
                            <svg className="w-4 h-4 text-indigo-500" fill="currentColor" viewBox="0 0 24 24">
                              <rect x="6" y="4" width="4" height="16" rx="1" />
                              <rect x="14" y="4" width="4" height="16" rx="1" />
                            </svg>
                          ) : (
                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z" />
                            </svg>
                          )}
                        </button>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </StepCard>
  );
};

export default Step2Configure;
