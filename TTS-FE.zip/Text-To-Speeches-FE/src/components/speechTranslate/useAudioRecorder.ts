import { useCallback, useRef, useState } from "react";
import { decodeAudioFileToBuffer, encodeWavPcm16Mono, resampleToMono16k } from "../../utils/audioTranscode";

const toWavFile = async (file: File): Promise<File> => {
  const decoded = await decodeAudioFileToBuffer(file);
  const rendered = await resampleToMono16k(decoded);
  const wavArrayBuffer = encodeWavPcm16Mono(rendered);
  const wavBlob = new Blob([wavArrayBuffer], { type: "audio/wav" });
  const base = file.name.replace(/\.[^.]+$/, "") || "recording";
  return new File([wavBlob], `${base}.wav`, { type: "audio/wav" });
};

export const useAudioRecorder = () => {
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);

  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const start = useCallback(async () => {
    if (isRecording) return null;
    setError(null);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mimeType =
        MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
          ? "audio/webm;codecs=opus"
          : MediaRecorder.isTypeSupported("audio/webm")
            ? "audio/webm"
            : "";
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.start();
      setIsRecording(true);
      return true;
    } catch {
      setError("Microphone permission denied or unavailable.");
      return null;
    }
  }, [isRecording]);

  const stop = useCallback(async (): Promise<File | null> => {
    const recorder = mediaRecorderRef.current;
    if (!recorder) return null;
    if (recorder.state === "inactive") return null;

    return await new Promise<File | null>((resolve) => {
      recorder.onstop = async () => {
        try {
          const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
          const raw = new File([blob], `recording-${Date.now()}.webm`, { type: blob.type });
          const wav = await toWavFile(raw);
          resolve(wav);
        } catch {
          setError("Failed to process recording. Please try again.");
          resolve(null);
        } finally {
          try {
            streamRef.current?.getTracks().forEach((t) => t.stop());
          } catch {
            // ignore
          }
          streamRef.current = null;
          mediaRecorderRef.current = null;
          chunksRef.current = [];
          setIsRecording(false);
        }
      };

      recorder.stop();
    });
  }, []);

  return { isRecording, error, start, stop };
};

