import React from "react";
import { Lock } from "lucide-react";
import type { useSpeechTranslateState } from "./useSpeechTranslateState";
import type { SpeechTranslateAudioItem } from "../../services/speechTranslateService";
import type { VoiceName } from "../../types";
import StepCard from "../StepCard";
import ProgressPill from "../ProgressPill";
import VoiceGrid from "../createVoice/VoiceGrid";
import { getTargetLabel, GENERATION_PHASES } from "./constants";

type Props = { state: ReturnType<typeof useSpeechTranslateState> };

const Step3GenerateReview: React.FC<Props> = ({ state }) => {
  const {
    selectedTargets,
    audioByTarget,
    detectedLanguage,
    recognizedText,
    translationsByTarget,
    showOriginalTranscript,
    setShowOriginalTranscript,
    showTextOutput,
    outputFormat,
    translateInProgress,
    translatePercent,
    generationPhase,
    generationElapsed,
    error: _error,
    fileActionKey,
    isStep3Complete,
    step3Summary,
    // Edit
    handleTranslationChange,
    undoTranslation,
    redoTranslation,
    resetTranslationEdits,
    canUndo,
    canRedo,
    translationOriginals,
    // Downloads
    handleDownloadTarget,
    handleDeleteTarget,
    handleDownloadAll,
    handleDeleteAll,
    handleDownloadTranslatedText,
    handleDownloadSource,
    // Re-generate
    showRegenVoicePicker,
    setShowRegenVoicePicker,
    voicesForTarget,
    voicesByTarget,
    setVoicesByTarget,
    previewLoadingId,
    previewPlayingId,
    handlePreview,
    resetResults,
    // Guest
    isGuest,
    openLimitModal,
    canSaveDraft,
    openProjectModal,
    // Metadata
    durationSeconds,
    formatDuration,
    formatDateTime,
    TARGET_LANGUAGES,
    sourceLanguageOverride,
  } = state;

  const hasOutputs = Object.keys(audioByTarget).length > 0;
  const wordCount = (text: string) =>
    text
      .trim()
      .split(/\s+/)
      .filter(Boolean).length;
  const sourceWordCount = wordCount(recognizedText);

  return (
    <StepCard
      step={3}
      title="Generate and Review Output"
      description="Review translations and generated audio. Download or save your work."
      isActive
      isCompleted={isStep3Complete}
      summary={step3Summary}
    >
      <div className="space-y-4">
        {/* Multi-phase progress (C4) */}
        {translateInProgress && (
          <div className="space-y-3">
            <ProgressPill label="Translating" percent={translatePercent} />
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                {GENERATION_PHASES[generationPhase] || "Processing..."}
              </span>
              <span>{formatDuration(generationElapsed)} elapsed</span>
            </div>
          </div>
        )}

        {/* Detected language (C6 metadata) */}
        {detectedLanguage && !translateInProgress && (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/60 dark:bg-white/5 p-4">
            <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Detected language
            </div>
            <div className="mt-2 text-sm font-bold text-slate-900 dark:text-white">
              {detectedLanguage}
              {sourceLanguageOverride && (
                <span className="ml-2 text-xs text-slate-400">(override: {sourceLanguageOverride})</span>
              )}
            </div>
          </div>
        )}

        {/* Success metadata (C6) */}
        {hasOutputs && !translateInProgress && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-3">
              <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Duration</div>
              <div className="mt-1 text-sm font-bold text-slate-900 dark:text-white">{formatDuration(durationSeconds)}</div>
            </div>
            <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-3">
              <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Languages</div>
              <div className="mt-1 text-sm font-bold text-slate-900 dark:text-white">{Object.keys(audioByTarget).length}</div>
            </div>
            <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-3">
              <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Format</div>
              <div className="mt-1 text-sm font-bold text-slate-900 dark:text-white">{outputFormat.toUpperCase()}</div>
            </div>
            <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-3">
              <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">Source Words</div>
              <div className="mt-1 text-sm font-bold text-slate-900 dark:text-white">{sourceWordCount || "-"}</div>
            </div>
          </div>
        )}

        {/* Audio output cards (C12) */}
        {hasOutputs ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {selectedTargets.map((target) => {
              const item = audioByTarget[target];
              if (!item) return null;
              const targetWords = wordCount(translationsByTarget[target] || "");
              const wordDiff = targetWords - sourceWordCount;

              return (
                <div
                  key={target}
                  className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-6 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                        {getTargetLabel(target, TARGET_LANGUAGES)} ({target})
                      </div>
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-semibold flex items-center gap-2">
                        <span>
                          Expires:{" "}
                          {item.expiresAt
                            ? formatDateTime(item.expiresAt)
                            : "24h retention"}
                        </span>
                        {item.voice && (
                          <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-white/10 text-[10px]">
                            {item.voice}
                          </span>
                        )}
                      </div>
                      {/* Word count diff (C15 visual comparison) */}
                      {sourceWordCount > 0 && (
                        <div className="mt-1 text-[10px] font-bold">
                          <span className={wordDiff > 0 ? "text-emerald-600 dark:text-emerald-400" : wordDiff < 0 ? "text-amber-600 dark:text-amber-400" : "text-slate-400"}>
                            {wordDiff > 0 ? `+${wordDiff}` : wordDiff} words vs source
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      {isGuest ? (
                        <>
                          <button
                            type="button"
                            onClick={() => openLimitModal("voiceMinutes")}
                            title="Download"
                            className="p-3 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/20 text-slate-600 dark:text-slate-300 transition-colors"
                          >
                            <Lock className="w-5 h-5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => openLimitModal("voiceMinutes")}
                            title="Delete"
                            className="p-3 rounded-lg bg-rose-100 hover:bg-rose-200 dark:bg-rose-500/20 dark:hover:bg-rose-500/30 text-rose-600 dark:text-rose-400 transition-colors"
                          >
                            <Lock className="w-5 h-5" />
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() =>
                              void handleDownloadTarget(target, item)
                            }
                            disabled={fileActionKey === `download-${target}`}
                            title="Download"
                            className="p-3 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/20 text-slate-600 dark:text-slate-300 transition-colors disabled:opacity-50"
                          >
                            <svg
                              className="w-5 h-5"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                              />
                            </svg>
                          </button>
                          {item.fileId && (
                            <button
                              type="button"
                              onClick={() =>
                                void handleDeleteTarget(target, item)
                              }
                              disabled={fileActionKey === `delete-${target}`}
                              title="Delete"
                              className="p-3 rounded-lg bg-rose-100 hover:bg-rose-200 dark:bg-rose-500/20 dark:hover:bg-rose-500/30 text-rose-600 dark:text-rose-400 transition-colors disabled:opacity-50"
                            >
                              <svg
                                className="w-5 h-5"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                />
                              </svg>
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </div>

                  {/* Dark-mode-aware audio player (C1) */}
                  {item.dataUrl ? (
                    <div className="rounded-2xl bg-slate-100 dark:bg-slate-800 p-2">
                      <audio controls src={item.dataUrl} className="w-full" />
                    </div>
                  ) : (
                    <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/70 dark:bg-white/5 p-4 text-sm font-semibold text-slate-600 dark:text-slate-300 animate-pulse">
                      Loading audio from secure storage...
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : isStep3Complete ? (
          <div className="rounded-3xl border border-amber-500/20 bg-amber-500/10 p-5 text-sm font-semibold text-amber-900 dark:text-amber-200">
            No audio outputs received. Go back and try again.
          </div>
        ) : null}

        {/* Skeleton placeholders while generating (C3) */}
        {translateInProgress && !hasOutputs && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {selectedTargets.map((target) => (
              <div
                key={target}
                className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/60 dark:bg-white/5 p-6 space-y-3 animate-pulse"
              >
                <div className="h-3 w-24 rounded bg-slate-200 dark:bg-white/10" />
                <div className="h-2 w-32 rounded bg-slate-200 dark:bg-white/10 mt-2" />
                <div className="h-12 w-full rounded-2xl bg-slate-200 dark:bg-white/10 mt-4" />
              </div>
            ))}
          </div>
        )}

        {/* Text output with edit history (B9, B10, C14, C15) */}
        {showTextOutput && (recognizedText || Object.keys(translationsByTarget).length > 0) && (
          <div className="space-y-3">
            {/* Undo/Redo/Reset toolbar */}
            <div className="flex items-center gap-2 flex-wrap">
              <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-200 font-medium select-none">
                <input
                  type="checkbox"
                  checked={showOriginalTranscript}
                  onChange={(event) => setShowOriginalTranscript(event.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                />
                Show original transcript
              </label>
              <div className="flex-1" />
              <button
                type="button"
                onClick={undoTranslation}
                disabled={!canUndo}
                className="px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-300 disabled:opacity-30 hover:bg-slate-200 dark:hover:bg-white/15 transition-colors"
                title="Undo (Ctrl+Z)"
              >
                Undo
              </button>
              <button
                type="button"
                onClick={redoTranslation}
                disabled={!canRedo}
                className="px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-300 disabled:opacity-30 hover:bg-slate-200 dark:hover:bg-white/15 transition-colors"
                title="Redo (Ctrl+Y)"
              >
                Redo
              </button>
              <button
                type="button"
                onClick={resetTranslationEdits}
                disabled={Object.keys(translationOriginals).length === 0}
                className="px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 disabled:opacity-30 hover:bg-amber-200 dark:hover:bg-amber-500/30 transition-colors"
              >
                Reset
              </button>
              <button
                type="button"
                onClick={() => void handleDownloadTranslatedText()}
                className="px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest bg-indigo-100 dark:bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-200 dark:hover:bg-indigo-500/30 transition-colors"
              >
                Download Text
              </button>
            </div>

            {showOriginalTranscript && (
              <div>
                <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1">
                  Original Transcript ({wordCount(recognizedText)} words)
                </div>
                <textarea
                  value={recognizedText}
                  readOnly
                  aria-label="Original transcript"
                  className="w-full min-h-[180px] p-4 rounded-2xl bg-slate-50/70 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-800 dark:text-slate-100 resize-y font-medium text-sm leading-relaxed"
                />
              </div>
            )}

            {selectedTargets.map((target) => {
              const text = translationsByTarget[target] || "";
              const targetWordCount = wordCount(text);
              const diff = targetWordCount - sourceWordCount;
              const hasEdits =
                translationOriginals[target] != null &&
                text !== translationOriginals[target];

              return (
                <div key={target}>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                      {getTargetLabel(target, TARGET_LANGUAGES)} ({target})
                    </div>
                    {sourceWordCount > 0 && (
                      <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500">
                        {targetWordCount} words ({diff >= 0 ? `+${diff}` : diff})
                      </span>
                    )}
                  </div>
                  <textarea
                    value={text}
                    onChange={(event) =>
                      handleTranslationChange(target, event.target.value)
                    }
                    aria-label={`Translation for ${getTargetLabel(target, TARGET_LANGUAGES)}`}
                    className={[
                      "w-full min-h-[120px] p-3 rounded-xl bg-white/80 dark:bg-white/5 border text-slate-900 dark:text-white resize-y text-sm",
                      hasEdits
                        ? "border-amber-400 dark:border-amber-500/40"
                        : "border-slate-200 dark:border-white/10",
                    ].join(" ")}
                  />
                </div>
              );
            })}
          </div>
        )}

        {/* Re-generate with different voice (B4) */}
        {hasOutputs && !translateInProgress && (
          <div className="space-y-3">
            <button
              type="button"
              onClick={() => setShowRegenVoicePicker(!showRegenVoicePicker)}
              className="px-4 py-2 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10"
            >
              {showRegenVoicePicker ? "Hide Voice Picker" : "Change Voice & Regenerate"}
            </button>

            {showRegenVoicePicker && (
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/60 dark:bg-white/5 p-4 space-y-4">
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Select a new voice for any target, then click "Generate Translation" below to regenerate.
                </p>

                {/* Regional warning if any target uses a regional voice */}
                {selectedTargets.some((t) => {
                  const r = (voicesForTarget[t] || [])[0]?.region;
                  return r === "Indian" || r === "SE Asian";
                }) && (
                  <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-3 flex items-start gap-2.5">
                    <svg className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                    </svg>
                    <p className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                      One or more selected languages use regional voices — <span className="font-black">2× credits</span> will be charged for those languages.
                    </p>
                  </div>
                )}

                {selectedTargets.map((target) => {
                  const voices = voicesForTarget[target] || [];
                  if (voices.length === 0) return null;
                  const isRegional = voices[0]?.region === "Indian" || voices[0]?.region === "SE Asian";
                  return (
                    <div key={target}>
                      <div className="text-sm font-black text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                        {getTargetLabel(target, TARGET_LANGUAGES)}
                        {isRegional && (
                          <span className="px-1.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 text-[9px] font-black uppercase tracking-wider">
                            2×
                          </span>
                        )}
                      </div>
                      <VoiceGrid
                        voices={voices}
                        selectedVoice={(voicesByTarget[target] || voices[0]?.id || "") as VoiceName}
                        onSelectVoice={(voice: VoiceName) => {
                          resetResults();
                          setVoicesByTarget((prev: Record<string, VoiceName | "">) => ({
                            ...prev,
                            [target]: voice,
                          }));
                        }}
                        previewLoadingId={previewLoadingId}
                        previewPlayingId={previewPlayingId}
                        onPreview={handlePreview}
                        columns="grid-cols-1 sm:grid-cols-2"
                      />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Action buttons */}
        {hasOutputs && (
          <div className="flex gap-3 pt-4 flex-wrap">
            {isGuest ? (
              <>
                <button
                  type="button"
                  onClick={() => openLimitModal("voiceMinutes")}
                  className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center gap-2"
                >
                  <Lock className="w-3.5 h-3.5" />
                  {Object.keys(audioByTarget).length > 1 ? "Download All" : "Download"}
                </button>
                <button
                  type="button"
                  onClick={() => openLimitModal("voiceMinutes")}
                  className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center gap-2"
                >
                  <Lock className="w-3.5 h-3.5" />
                  {Object.keys(audioByTarget).length > 1 ? "Delete All" : "Delete"}
                </button>
                <button
                  type="button"
                  onClick={() => openLimitModal("voiceMinutes")}
                  className="px-4 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm"
                >
                  Sign Up to Save
                </button>
              </>
            ) : (
              <>
                {Object.keys(audioByTarget).length > 1 ? (
                  <>
                    <button
                      type="button"
                      onClick={() => void handleDownloadAll()}
                      disabled={fileActionKey === "download-all"}
                      className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {fileActionKey === "download-all" ? "Downloading..." : "Download All"}
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleDeleteAll()}
                      disabled={fileActionKey === "delete-all"}
                      className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {fileActionKey === "delete-all" ? "Deleting..." : "Delete All"}
                    </button>
                  </>
                ) : (
                  Object.entries(audioByTarget).map(([target, item]) =>
                    item ? (
                      <div key={target} className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => void handleDownloadTarget(target, item)}
                          disabled={fileActionKey === `download-${target}`}
                          className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Download
                        </button>
                        {item.fileId && (
                          <button
                            type="button"
                            onClick={() => void handleDeleteTarget(target, item)}
                            disabled={fileActionKey === `delete-${target}`}
                            className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    ) : null,
                  )
                )}
                <button
                  type="button"
                  onClick={openProjectModal}
                  disabled={!canSaveDraft}
                  title={
                    !canSaveDraft
                      ? "Upload audio file to enable save"
                      : undefined
                  }
                  className="px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-black uppercase tracking-widest transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Save to Project
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </StepCard>
  );
};

export default Step3GenerateReview;
