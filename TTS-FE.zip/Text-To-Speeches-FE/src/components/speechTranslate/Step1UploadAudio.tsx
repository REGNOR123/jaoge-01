import React, { useRef } from "react";
import type { useSpeechTranslateState } from "./useSpeechTranslateState";
import StepCard from "../StepCard";
import TabButton from "../TabButton";
import { ACCEPTED_AUDIO_TYPES, RETENTION_MESSAGE } from "./constants";

type Props = { state: ReturnType<typeof useSpeechTranslateState> };

const Step1UploadAudio: React.FC<Props> = ({ state }) => {
  const textFileRef = useRef<HTMLInputElement | null>(null);

  const {
    audioFile,
    sourceFileRecord,
    dragOver,
    setDragOver,
    fileInputRef,
    isRecording,
    recordError,
    recordingElapsed,
    inputAudioUrl,
    durationSeconds,
    inputMode,
    setInputMode,
    textInput,
    setTextInput,
    onPickFile,
    handleRecordClick,
    handleTextFileUpload,
    handleDownloadSource,
    handleDeleteSource,
    fileActionKey,
    formatDuration,
    formatDateTime,
    isStep1Complete,
    step1Summary,
    // Limits
    usageSummary,
    fileMinutesLimitReached,
    estimatedMinutes,
    remainingMinutes,
    selectedTargets,
  } = state;

  const hasAudioSource = Boolean(audioFile) || Boolean(sourceFileRecord?.fileId);

  return (
    <StepCard
      step={1}
      title="Upload Source Audio"
      description="Upload a file or record your voice. Stored samples are retained for 24 hours."
      isActive
      isCompleted={isStep1Complete}
      summary={step1Summary}
    >
      <div className="space-y-4">
        {/* Mode tabs (A11y: tablist) */}
        <div className="flex gap-2" role="tablist" aria-label="Input mode">
          <TabButton active={inputMode === "audio"} onClick={() => setInputMode("audio")}>
            Upload / Record
          </TabButton>
        </div>

        {inputMode === "audio" && (
          <>
            {/* Drag-and-drop zone with visual feedback (C2) */}
            <div
              role="tabpanel"
              onDragOver={(event) => {
                event.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(event) => {
                event.preventDefault();
                setDragOver(false);
                const dropped = event.dataTransfer.files?.[0] || null;
                if (dropped && dropped.type.startsWith("audio/")) {
                  onPickFile(dropped);
                }
              }}
              className={[
                "rounded-3xl border-2 border-dashed p-8 transition-all min-h-[200px] flex items-center justify-center",
                dragOver
                  ? "border-indigo-500 bg-indigo-500/5 animate-pulse"
                  : "border-slate-200 dark:border-white/10 bg-white/60 dark:bg-white/5",
              ].join(" ")}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept={ACCEPTED_AUDIO_TYPES}
                className="hidden"
                onChange={(event) => onPickFile(event.target.files?.[0] || null)}
              />

              <div className="flex flex-col items-center text-center gap-3 w-full">
                <div className="text-sm font-bold text-slate-900 dark:text-white">
                  {audioFile ? audioFile.name : "Drop an audio file here"}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Supported formats: WAV, MP3, OGG, M4A, FLAC, WebM
                  {usageSummary?.maxFileMinutes != null && (
                    <span> — Max {usageSummary.maxFileMinutes} min</span>
                  )}
                </div>

                <div className="flex flex-wrap justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10"
                  >
                    Choose file
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleRecordClick()}
                    className={[
                      "px-4 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-colors shadow-sm border",
                      isRecording
                        ? "bg-rose-600 hover:bg-rose-700 text-white border-rose-600/20"
                        : "bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white border-slate-200 dark:border-white/10",
                    ].join(" ")}
                  >
                    {isRecording ? (
                      <span className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                        Stop {formatDuration(recordingElapsed)}
                      </span>
                    ) : (
                      "Record"
                    )}
                  </button>
                  {(sourceFileRecord?.fileId || inputAudioUrl) && (
                    <button
                      type="button"
                      onClick={() => void handleDownloadSource()}
                      disabled={fileActionKey === "source-download"}
                      className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 disabled:opacity-50"
                    >
                      {fileActionKey === "source-download" ? "Downloading..." : "Download source"}
                    </button>
                  )}
                  {sourceFileRecord?.fileId && (
                    <button
                      type="button"
                      onClick={() => void handleDeleteSource()}
                      disabled={fileActionKey === "source-delete"}
                      className="px-4 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm disabled:opacity-50"
                    >
                      {fileActionKey === "source-delete" ? "Deleting..." : "Delete stored file"}
                    </button>
                  )}
                </div>

                {recordError && (
                  <div className="text-xs font-bold text-rose-600 dark:text-rose-300">
                    {recordError}
                  </div>
                )}

                {/* Audio player wrapped for dark mode (C1) */}
                {inputAudioUrl && (
                  <div className="mt-2 w-full max-w-xl rounded-2xl bg-slate-100 dark:bg-slate-800 p-2">
                    <audio controls src={inputAudioUrl} className="w-full" />
                  </div>
                )}
              </div>
            </div>

          </>
        )}

        {inputMode === "text" && (
          <div role="tabpanel" className="space-y-3">
            <textarea
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              placeholder="Paste a paragraph, speech transcript, or article to translate..."
              aria-label="Text to translate"
              className="w-full min-h-[200px] p-4 rounded-2xl bg-white/60 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white resize-y text-sm font-medium leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
            />
            <div className="flex flex-wrap gap-2">
              <input
                ref={textFileRef}
                type="file"
                accept=".txt,.srt"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleTextFileUpload(file);
                }}
              />
              <button
                type="button"
                onClick={() => textFileRef.current?.click()}
                className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10"
              >
                Upload .txt / .srt
              </button>
              <span className="text-xs text-slate-500 dark:text-slate-400 self-center">
                {textInput.length} characters
              </span>
            </div>
          </div>
        )}

        {/* File metadata (when audio file is loaded) */}
        {audioFile && inputMode === "audio" && (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/60 dark:bg-white/5 p-4 grid grid-cols-1 md:grid-cols-3 gap-3 text-sm font-semibold text-slate-700 dark:text-slate-200">
            <div>Duration: {formatDuration(durationSeconds)}</div>
            <div>
              Stored until:{" "}
              {sourceFileRecord?.expiresAt
                ? formatDateTime(sourceFileRecord.expiresAt)
                : "Not stored yet"}
            </div>
            <div>{RETENTION_MESSAGE}</div>
          </div>
        )}

        {/* Cost estimation (C9) */}
        {hasAudioSource && estimatedMinutes != null && (
          <div className="rounded-2xl border border-sky-500/20 bg-sky-500/10 p-3 text-xs font-semibold text-sky-900 dark:text-sky-100 flex items-center justify-between gap-2">
            <span>
              Est. usage: ~{estimatedMinutes.toFixed(2)} min
              {selectedTargets.length > 1 && ` (${selectedTargets.length} targets)`}
            </span>
            {remainingMinutes != null && (
              <span>
                {remainingMinutes.toFixed(2)} min remaining
              </span>
            )}
          </div>
        )}

        {/* Limit warnings (C10) */}
        {fileMinutesLimitReached && usageSummary?.maxFileMinutes != null && (
          <div className="rounded-2xl border border-red-500/20 bg-red-500/10 p-3 text-xs font-bold text-red-700 dark:text-red-300">
            Audio exceeds the {usageSummary.maxFileMinutes} minute per-file limit. Trim the recording or split it into smaller clips.
          </div>
        )}

        {/* Tips (C5) */}
        {!hasAudioSource && inputMode === "audio" && (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-4 text-xs text-slate-500 dark:text-slate-400 space-y-1">
            <div className="font-black uppercase tracking-widest text-[10px] text-slate-600 dark:text-slate-300 mb-2">
              Tips for best results
            </div>
            <ul className="list-disc list-inside space-y-1">
              <li>Use clear audio with minimal background noise</li>
              <li>Speak at a natural pace for better recognition</li>
              <li>Shorter clips (&lt;5 min) process faster</li>
            </ul>
          </div>
        )}
      </div>
    </StepCard>
  );
};

export default Step1UploadAudio;
