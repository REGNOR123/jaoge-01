export const RETENTION_MESSAGE = "Files are auto-deleted after 24 hours.";

export const SPEECH_TRANSLATE_TRANSCRIPT_SOURCE = "Speech Translate Transcript";
export const SPEECH_TRANSLATE_TRANSLATION_SOURCE_PREFIX =
  "Speech Translate Translation";

export const ACCEPTED_AUDIO_TYPES =
  ".wav,.mp3,.ogg,.webm,.m4a,.flac,audio/*";

export type StepId = 1 | 2 | 3;

export const isSpeechTranslateEntry = (settings: any) =>
  settings?.feature === "speech-translate";

export const isSourceEntry = (settings: any) =>
  isSpeechTranslateEntry(settings) && settings?.source === "upload";

export const isGeneratedEntry = (settings: any) =>
  isSpeechTranslateEntry(settings) && settings?.source === "generated";

export const getTargetLabel = (code: string, languages: { code: string; name: string }[]) =>
  languages.find((item) => item.code === code)?.name || code;

export const targetCodeToVoicePrefix = (code: string) =>
  code === "no" ? "nb" : code;

export const GENERATION_PHASES = [
  "Uploading audio...",
  "Recognizing speech...",
  "Translating text...",
  "Generating voices...",
  "Storing outputs...",
] as const;
