export {
  TARGET_LANGUAGES,
  RECOGNITION_LANGUAGES,
} from "../../data/languages";
