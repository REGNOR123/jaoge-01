import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import InsufficientCreditsModal from '../InsufficientCreditsModal';
import {
  getKeyStatus,
  generateVoiceCloningKey,
  synthesizeWithClonedVoice,
} from '../../services/voiceCloneApiService';

const CONSENT_SCRIPT =
  'I am the owner of this voice and I consent to Google using this voice to create a synthetic voice model.';

const LANGUAGES = [
  { code: 'en-US', label: 'English (US)' },
  { code: 'en-GB', label: 'English (UK)' },
  { code: 'hi-IN', label: 'Hindi' },
  { code: 'es-ES', label: 'Spanish' },
  { code: 'fr-FR', label: 'French' },
  { code: 'de-DE', label: 'German' },
  { code: 'ja-JP', label: 'Japanese' },
  { code: 'ko-KR', label: 'Korean' },
  { code: 'pt-BR', label: 'Portuguese (BR)' },
  { code: 'zh-CN', label: 'Chinese (Simplified)' },
];

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Strip the data URL prefix (e.g. "data:audio/mpeg;base64,")
      resolve(result.split(',')[1] ?? result);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function detectAudioEncoding(file: File): string {
  const name = file.name.toLowerCase();
  if (name.endsWith('.mp3')) return 'MP3';
  if (name.endsWith('.wav')) return 'LINEAR16';
  if (name.endsWith('.m4a')) return 'M4A';
  return 'MP3';
}

const VoiceCloneWizard: React.FC = () => {
  const { token, isAuthenticated } = useAuth();

  const [hasKey, setHasKey] = useState(false);
  const [showSetup, setShowSetup] = useState(false);
  const [referenceFile, setReferenceFile] = useState<File | null>(null);
  const [consentFile, setConsentFile] = useState<File | null>(null);
  const [setupLanguage, setSetupLanguage] = useState('en-US');
  const [isGeneratingKey, setIsGeneratingKey] = useState(false);
  const [setupError, setSetupError] = useState<string | null>(null);
  const [setupSuccess, setSetupSuccess] = useState(false);

  const [synthText, setSynthText] = useState('');
  const [synthLanguage, setSynthLanguage] = useState('en-US');
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [synthError, setSynthError] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const [insuffCredits, setInsuffCredits] = useState<{ required: number; current: number } | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const prevAudioUrl = useRef<string | null>(null);

  useEffect(() => {
    if (!isAuthenticated || !token) return;
    getKeyStatus(token).then((res) => {
      if (res.success && res.data) {
        setHasKey(res.data.hasKey);
        setShowSetup(!res.data.hasKey);
      }
    });
  }, [isAuthenticated, token]);

  useEffect(() => {
    return () => {
      if (prevAudioUrl.current) URL.revokeObjectURL(prevAudioUrl.current);
    };
  }, []);

  const handleGenerateKey = useCallback(async () => {
    if (!token || !referenceFile || !consentFile) return;
    setIsGeneratingKey(true);
    setSetupError(null);
    setSetupSuccess(false);

    try {
      const [refBase64, consentBase64] = await Promise.all([
        fileToBase64(referenceFile),
        fileToBase64(consentFile),
      ]);

      const encoding = detectAudioEncoding(referenceFile);
      const res = await generateVoiceCloningKey(
        { referenceAudioBase64: refBase64, consentAudioBase64: consentBase64, languageCode: setupLanguage, audioEncoding: encoding },
        token,
      );

      if (res.status === 402 && res.data) {
        setInsuffCredits({ required: (res.data as any).requiredCredits ?? 50, current: (res.data as any).currentBalance ?? 0 });
        return;
      }

      if (!res.success) {
        setSetupError(res.error || 'Failed to generate voice clone.');
        return;
      }

      setHasKey(true);
      setShowSetup(false);
      setSetupSuccess(true);
    } finally {
      setIsGeneratingKey(false);
    }
  }, [token, referenceFile, consentFile, setupLanguage]);

  const handleSynthesize = useCallback(async () => {
    if (!token || !synthText.trim()) return;
    setIsSynthesizing(true);
    setSynthError(null);

    if (prevAudioUrl.current) {
      URL.revokeObjectURL(prevAudioUrl.current);
      prevAudioUrl.current = null;
    }
    setAudioUrl(null);

    const res = await synthesizeWithClonedVoice(synthText.trim(), synthLanguage, token);
    setIsSynthesizing(false);

    if (res.status === 402 && res.data) {
      setInsuffCredits({ required: (res.data as any).requiredCredits ?? 10, current: (res.data as any).currentBalance ?? 0 });
      return;
    }

    if (!res.success || !res.data?.audioContent) {
      setSynthError(res.error || 'Synthesis failed. Please try again.');
      return;
    }

    const binary = atob(res.data.audioContent);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const blob = new Blob([bytes], { type: 'audio/mpeg' });
    const url = URL.createObjectURL(blob);
    prevAudioUrl.current = url;
    setAudioUrl(url);
  }, [token, synthText, synthLanguage]);

  const handleDownload = useCallback(() => {
    if (!audioUrl) return;
    const a = document.createElement('a');
    a.href = audioUrl;
    a.download = 'voice-clone.mp3';
    a.click();
  }, [audioUrl]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight mb-1">Voice Clone</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Clone your voice and synthesize speech that sounds like you.
        </p>
      </div>

      {/* ── Setup Section ─────────────────────────────── */}
      {(showSetup || !hasKey) ? (
        <section className="glass studio-card !p-8 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-slate-900 dark:text-white">Voice Setup</h2>
            <span className="text-xs font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/10 px-3 py-1 rounded-full">
              50 credits
            </span>
          </div>

          {/* Consent Script */}
          <div className="p-4 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 border border-indigo-200 dark:border-indigo-500/30">
            <p className="text-[10px] font-black uppercase tracking-widest text-indigo-600 dark:text-indigo-400 mb-2">
              Consent Script — Record yourself reading this aloud
            </p>
            <p className="text-sm font-semibold text-indigo-900 dark:text-indigo-100 leading-relaxed italic">
              "{CONSENT_SCRIPT}"
            </p>
          </div>

          {/* Reference Audio */}
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
              Reference Audio <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              Upload a clear voice sample (30+ seconds recommended). MP3, WAV, or M4A.
            </p>
            <label className="flex items-center gap-3 cursor-pointer p-4 rounded-xl border-2 border-dashed border-slate-300 dark:border-white/20 hover:border-indigo-400 dark:hover:border-indigo-500 transition-colors group">
              <svg className="w-5 h-5 text-slate-400 group-hover:text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 1a4 4 0 014 4v7a4 4 0 11-8 0V5a4 4 0 014-4zm6 11a6 6 0 01-12 0M12 19v4m-4 0h8" />
              </svg>
              <span className="text-sm text-slate-600 dark:text-slate-300">
                {referenceFile ? referenceFile.name : 'Choose reference audio file…'}
              </span>
              <input
                type="file"
                accept="audio/*"
                className="hidden"
                onChange={(e) => setReferenceFile(e.target.files?.[0] ?? null)}
              />
            </label>
          </div>

          {/* Consent Audio */}
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
              Consent Audio <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              Upload your recording of the consent script above.
            </p>
            <label className="flex items-center gap-3 cursor-pointer p-4 rounded-xl border-2 border-dashed border-slate-300 dark:border-white/20 hover:border-indigo-400 dark:hover:border-indigo-500 transition-colors group">
              <svg className="w-5 h-5 text-slate-400 group-hover:text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
              </svg>
              <span className="text-sm text-slate-600 dark:text-slate-300">
                {consentFile ? consentFile.name : 'Choose consent audio file…'}
              </span>
              <input
                type="file"
                accept="audio/*"
                className="hidden"
                onChange={(e) => setConsentFile(e.target.files?.[0] ?? null)}
              />
            </label>
          </div>

          {/* Language */}
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
              Language
            </label>
            <select
              value={setupLanguage}
              onChange={(e) => setSetupLanguage(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>{l.label}</option>
              ))}
            </select>
          </div>

          {setupError && (
            <p className="text-sm font-medium text-red-600 dark:text-red-400">{setupError}</p>
          )}

          <button
            type="button"
            onClick={() => void handleGenerateKey()}
            disabled={isGeneratingKey || !referenceFile || !consentFile}
            className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isGeneratingKey ? (
              <>
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Generating Voice Clone…
              </>
            ) : (
              'Generate Voice Clone'
            )}
          </button>
        </section>
      ) : (
        <section className="glass studio-card !p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-500/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <p className="text-sm font-bold text-slate-900 dark:text-white">Voice clone ready</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Your cloned voice is saved to your account.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowSetup(true)}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            Re-clone
          </button>
        </section>
      )}

      {setupSuccess && (
        <div className="p-3 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-sm font-semibold text-green-800 dark:text-green-300">
          Voice clone created! You can now synthesize speech below.
        </div>
      )}

      {/* ── Synthesize Section ────────────────────────── */}
      <section className={`glass studio-card !p-8 space-y-6 ${!hasKey ? 'opacity-50 pointer-events-none' : ''}`}>
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-black text-slate-900 dark:text-white">Synthesize Speech</h2>
          <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-500/10 px-3 py-1 rounded-full">
            10 credits
          </span>
        </div>

        {!hasKey && (
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Complete Voice Setup above to enable synthesis.
          </p>
        )}

        <div>
          <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
            Text to Synthesize
          </label>
          <textarea
            value={synthText}
            onChange={(e) => setSynthText(e.target.value)}
            maxLength={500}
            placeholder="Enter the text you want to speak in your cloned voice…"
            className="w-full min-h-[120px] p-4 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white resize-none text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
          />
          <p className="text-xs text-slate-400 text-right mt-1">{synthText.length}/500</p>
        </div>

        <div>
          <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
            Language
          </label>
          <select
            value={synthLanguage}
            onChange={(e) => setSynthLanguage(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
          >
            {LANGUAGES.map((l) => (
              <option key={l.code} value={l.code}>{l.label}</option>
            ))}
          </select>
        </div>

        {synthError && (
          <p className="text-sm font-medium text-red-600 dark:text-red-400">{synthError}</p>
        )}

        <button
          type="button"
          onClick={() => void handleSynthesize()}
          disabled={isSynthesizing || !synthText.trim() || !hasKey}
          className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isSynthesizing ? (
            <>
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Synthesizing…
            </>
          ) : (
            'Synthesize with My Voice'
          )}
        </button>

        {audioUrl && (
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 space-y-3">
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
              Output
            </p>
            {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
            <audio ref={audioRef} src={audioUrl} controls className="w-full" />
            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center gap-2 text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Download MP3
            </button>
          </div>
        )}
      </section>

      <InsufficientCreditsModal
        isOpen={!!insuffCredits}
        onClose={() => setInsuffCredits(null)}
        requiredCredits={insuffCredits?.required ?? 0}
        currentBalance={insuffCredits?.current ?? 0}
      />
    </div>
  );
};

export default VoiceCloneWizard;
