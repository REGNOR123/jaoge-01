<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# TextToSpeeches — Neural Voice Synthesis

A professional neural voice synthesis platform built with React, TypeScript, and Vite. It combines Azure Cognitive Services Text-to-Speech with Google Gemini for real-time language detection, delivering expressive, human-like speech from text input.

---

## Run Locally

**Prerequisites:** Node.js 22+

1. Install dependencies:
   ```bash
   npm install
   ```
2. Set the `GEMINI_API_KEY` in `.env.local` to your Gemini API key.
3. Run the app:
   ```bash
   npm run dev
   ```

The dev server starts at `http://localhost:3000`. The API defaults to `http://localhost:5127/api` in development and the Azure-hosted backend in production (configurable via `VITE_API_BASE_URL`).

---

## Tech Stack

| Layer | Technology |
|---|---|
| **Framework** | React 19 + TypeScript 5.8 |
| **Build** | Vite 6 |
| **Routing** | react-router-dom 7 |
| **Styling** | Tailwind CSS 3.4 + PostCSS |
| **UI Primitives** | Radix UI, Lucide icons, class-variance-authority, shadcn-ui patterns |
| **Data Tables** | @tanstack/react-table 8 |
| **Auth** | Google OAuth + custom email/password auth |
| **Speech** | Azure Cognitive Services TTS (via backend) |
| **AI** | Google Gemini (language detection) |
| **Payments** | Razorpay |
| **Hosting** | Azure Static Web Apps |
| **CI/CD** | Azure Pipelines |
| **Serverless** | Azure Functions (chat completion proxy) |

---

## Project Structure

```
TTS-FE/
├── index.html                    # HTML entry point
├── package.json                  # Dependencies & scripts
├── tsconfig.json                 # TypeScript config (path alias @/* -> ./src/*)
├── vite.config.ts                # Vite config (React plugin, port 3000)
├── tailwind.config.js            # Tailwind config (dark mode, studio palette)
├── staticwebapp.config.json      # Azure SWA config
├── azure-pipelines.yml           # CI/CD pipeline
│
├── api/                          # Azure Functions serverless API
│   └── chat/complete/            # POST /api/chat/complete (OpenAI proxy)
│
└── src/
    ├── index.tsx                 # React mount + provider tree
    ├── App.tsx                   # Router with all routes
    ├── types.ts                  # Shared types (VoiceName, SpeechStyle, etc.)
    ├── constants.tsx             # Voice catalog, speech styles, config
    │
    ├── components/
    │   ├── app/                  # App shell layout
    │   │   ├── AppShell.tsx      # Authenticated page layout (navbar + sidebar + footer)
    │   │   ├── AppNavbar.tsx     # Top navigation bar with theme toggle
    │   │   ├── AppSidebar.tsx    # Left navigation sidebar
    │   │   ├── AppFooter.tsx     # Footer with nav links
    │   │   └── OnboardingModal.tsx
    │   │
    │   ├── createVoice/          # Voice creation wizard
    │   │   ├── CreateVoiceWizard.tsx
    │   │   ├── VoiceSelectionStep.tsx
    │   │   ├── ScriptStep.tsx
    │   │   ├── GenerateStep.tsx
    │   │   ├── VoiceGrid.tsx
    │   │   ├── BottomActionBar.tsx
    │   │   └── ProgressStepBar.tsx
    │   │
    │   ├── scriptStudio/         # AI script generation
    │   │   ├── DynamicForm.tsx
    │   │   └── StepNavigation.tsx
    │   │
    │   ├── speechTranslate/      # Speech translation
    │   │   ├── SpeechTranslateWizard.tsx
    │   │   ├── languages.ts      # Shared language constants
    │   │   └── useAudioRecorder.ts
    │   │
    │   ├── dialogs/              # Dialog system (DialogProvider)
    │   ├── ui/                   # Reusable UI primitives (button, input, dropdown)
    │   │
    │   ├── ChatWidget.tsx        # Floating AI chat assistant
    │   ├── GuestLimitModal.tsx   # Guest usage limit modal
    │   ├── GuestSignupPrompt.tsx # Guest sign-up prompt
    │   ├── GuestTrialBanner.tsx  # Trial usage banner
    │   ├── AuthRequiredModal.tsx # Auth required prompt
    │   ├── ProfileDropdownUser.tsx / ProfileDropdownGuest.tsx
    │   ├── ProjectNameModal.tsx  # Project naming dialog
    │   ├── UsageProgressBar.tsx  # Usage quota display
    │   ├── WizardStepNav.tsx     # Multi-step wizard navigation
    │   ├── projects-table.tsx    # Projects data table
    │   ├── table-filters.tsx     # Table filtering controls
    │   └── table-toolbar.tsx     # Table toolbar
    │
    ├── pages/
    │   ├── DashboardPage.tsx     # Main dashboard
    │   ├── CreateVoicePage.tsx   # Text-to-speech voice creation
    │   ├── TranscribePage.tsx    # Speech-to-text transcription
    │   ├── TranslateDubPage.tsx  # Translation & dubbing
    │   ├── SpeechTranslatePage.tsx # Live speech translation
    │   ├── ScriptStudioPage.tsx  # AI script generation
    │   ├── ProjectsPage.tsx      # Project management list
    │   ├── ProjectDetailPage.tsx # Individual project view
    │   ├── UsagePageV2.tsx       # Usage statistics
    │   ├── BillingPage.tsx       # Billing & subscription
    │   ├── AccountPage.tsx       # Account settings
    │   ├── PricingPage.tsx       # Pricing plans
    │   ├── LoginPage.tsx / SignupPage.tsx / VerifyEmailPage.tsx
    │   ├── DocsPage.tsx / HelpPage.tsx / AboutPage.tsx
    │   └── PrivacyPage.tsx / TermsPage.tsx
    │
    ├── services/
    │   ├── apiBase.ts            # API base URL resolution
    │   ├── apiUtils.ts           # Shared helpers (parseBody, getAuthHeaders)
    │   ├── authApiService.ts     # Email/password + Google OAuth auth
    │   ├── azureService.ts       # Azure TTS synthesis
    │   ├── billingApiService.ts  # Billing & subscription management
    │   ├── chatApiService.ts     # AI chat completion
    │   ├── filesApiService.ts    # Managed file upload/download
    │   ├── langService.ts        # Language detection (Gemini)
    │   ├── paymentApiService.ts  # Razorpay payment processing
    │   ├── scriptStudioService.ts # Script generation
    │   ├── speechTranslateService.ts # Speech translation
    │   ├── transcribeService.ts  # Audio transcription
    │   └── usageApiService.ts    # Usage tracking & quotas
    │
    ├── hooks/
    │   ├── useSpeechSynthesis.ts # Core TTS state & handlers
    │   ├── useSimpleUsage.ts     # Simple usage summary
    │   ├── useUsagePage.ts       # Detailed usage page data
    │   ├── useUsageLimits.ts     # Usage limit checks
    │   └── useWizardProgress.ts  # Wizard step tracking
    │
    ├── contexts/
    │   ├── AuthContext.tsx        # Authentication state
    │   ├── GuestUsageContext.tsx  # Guest trial usage tracking
    │   └── ThemeContext.tsx       # Dark/light theme toggle
    │
    ├── config/
    │   └── scriptStudioConfig.ts # Script type SKU definitions
    │
    ├── utils/
    │   ├── audioBlobStore.ts     # IndexedDB audio blob storage
    │   ├── audioTranscode.ts    # Audio decoding & WAV encoding
    │   ├── authErrorMapper.ts   # Auth error message mapping
    │   ├── authStorage.ts       # localStorage auth token management
    │   ├── format.ts            # Date & duration formatting
    │   ├── googleCredential.ts  # Google OAuth credential parsing
    │   ├── planTier.ts          # Plan tier utilities
    │   ├── prefillScript.ts     # Script prefill helpers
    │   ├── projectsStorage.ts   # localStorage project CRUD
    │   └── usageEvents.ts       # Usage event tracking
    │
    ├── data/
    │   └── projects.ts          # Project table types & helpers
    │
    └── lib/
        └── utils.ts             # cn() helper (clsx + tailwind-merge)
```

---

## Routes

### Public
| Path | Page |
|------|------|
| `/login` | Login |
| `/signup` | Sign up |
| `/verify-email` | Email verification |
| `/pricing` | Pricing plans |
| `/privacy`, `/terms`, `/docs`, `/help`, `/about` | Info pages |

### App (inside AppShell layout)
| Path | Page |
|------|------|
| `/dashboard` | Main dashboard |
| `/create-voice` | Text-to-speech voice creation |
| `/transcribe` | Speech-to-text transcription |
| `/translate-dub` | Translation & dubbing |
| `/speech-translate` | Live speech translation |
| `/script-studio` | AI script generation |
| `/projects` | Project management |
| `/projects/:projectId` | Project detail |
| `/usage` | Usage statistics (auth required) |
| `/billing` | Billing management (auth required) |
| `/account` | Account settings (auth required) |

### Redirects
`/` -> `/dashboard`, `/translate` -> `/translate-dub`, `/speech-to-text` -> `/transcribe`, `/speech-to-speech` -> `/translate-dub`, `/audio-library` -> `/projects`

---

## Chat Bot

- **UI:** Bottom-right floating chat icon (`ChatWidget.tsx`)
- **API:** `POST /api/chat/complete` (proxied via Azure Function to OpenAI)
- **Body:** `{ "message": "Hello", "systemPrompt": "optional override" }`

---

## Authentication

Dual authentication model:
- **Registered users:** Email/password sign-up with email verification, or Google OAuth
- **Guest users:** Hidden trial plan tracked via localStorage with limits on characters, voice minutes, AI enhancements, and auto-generate

Provider hierarchy: `GoogleOAuthProvider` > `BrowserRouter` > `AuthProvider` > `GuestUsageContext` > `ThemeContext` > `DialogProvider` > `App`

---

## Deployment

- **Hosting:** Azure Static Web Apps with SPA fallback (`staticwebapp.config.json`)
- **CI/CD:** Azure Pipelines triggered on `feature/dev` branch (`azure-pipelines.yml`)
- **Backend:** .NET API hosted on Azure App Service (East Asia region)
- **Build:** `npm run build` outputs to `dist/`
