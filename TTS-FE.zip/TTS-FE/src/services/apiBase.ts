const LOCAL_API_BASE =
  (import.meta.env.VITE_LOCAL_API_BASE as string | undefined)?.trim() ||
  'http://localhost:5127';

const PROD_API_BASE =
  (import.meta.env.VITE_PROD_API_BASE as string | undefined)?.trim() ||
  'https://text-to-speeches-dotnet-be-h2e9gwgpc9g3h6hy.eastasia-01.azurewebsites.net';

const isLocalHost =
  window.location.hostname === 'localhost' ||
  window.location.hostname === '127.0.0.1';

const configuredApiBase =
  (import.meta.env.VITE_API_BASE_URL as string | undefined)?.trim() || '';

const normalizeApiBase = (value: string): string => {
  return value.endsWith('/api') ? value : `${value}/api`;
};

export const resolveApiBase = (): string => {
  if (configuredApiBase) {
    return normalizeApiBase(configuredApiBase);
  }

  if (import.meta.env.DEV && isLocalHost) {
    return normalizeApiBase(LOCAL_API_BASE);
  }

  return normalizeApiBase(isLocalHost ? LOCAL_API_BASE : PROD_API_BASE);
};

export const API_BASE = resolveApiBase();

