import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { GoogleLogin, CredentialResponse } from '@react-oauth/google';
import { useAuth } from '../contexts/AuthContext';
import { getLastEmail, getLastName, setLastEmail, setLastName } from '../utils/authStorage';
import { mapAuthErrorMessage } from '../utils/authErrorMapper';
import { getGoogleCredentialEmail } from '../utils/googleCredential';

const SignupPage: React.FC = () => {
  const [name, setName] = useState(() => getLastName());
  const [email, setEmail] = useState(() => getLastEmail());
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { signup, googleLogin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const redirectTo = (location.state as { redirectTo?: string } | null)?.redirectTo;
  const redirectState = (location.state as { redirectState?: unknown } | null)?.redirectState;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please enter your name.');
      return;
    }
    if (!email.trim()) {
      setError('Please enter your email.');
      return;
    }
    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setIsLoading(true);
    const normalizedName = name.trim();
    const normalizedEmail = email.trim().toLowerCase();
    const res = await signup(normalizedName, normalizedEmail, password);
    setIsLoading(false);

    if (res.success) {
      setLastName(normalizedName);
      setLastEmail(normalizedEmail);
      if (res.authenticated) {
        navigate(redirectTo ?? '/dashboard', { state: redirectState });
        return;
      }
      navigate('/verify-code', {
        state: { email: normalizedEmail, redirectTo, redirectState },
      });
      return;
    }

    setError(
      mapAuthErrorMessage({
        flow: 'signup',
        status: res.status,
        error: res.error,
        errors: res.errors,
      }),
    );
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-gradient-to-br from-slate-50 via-white to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            </div>
            <h1 className="text-2xl font-black tracking-tighter text-slate-900 dark:text-white uppercase">
              TextTo<span className="text-indigo-500">Speeches</span>
            </h1>
          </Link>
        </div>

        {/* Card */}
        <div className="glass studio-card !p-8 sm:!p-10">
          <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Create Account</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-8">
            Sign up to start generating AI voices
          </p>

          {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20">
              <p className="text-sm font-medium text-red-600 dark:text-red-400">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Name */}
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                Full Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="John Doe"
                className="w-full px-4 py-3 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/40 transition-all text-sm"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-3 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/40 transition-all text-sm"
                required
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min. 8 characters"
                className="w-full px-4 py-3 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/40 transition-all text-sm"
                required
                minLength={8}
              />
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                Confirm Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter password"
                className="w-full px-4 py-3 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/40 transition-all text-sm"
                required
                minLength={8}
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm uppercase tracking-wider transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-600/20 hover:shadow-indigo-600/30"
            >
              {isLoading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Creating Account...
                </div>
              ) : (
                'Create Account'
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200 dark:border-white/10"></div>
            </div>
            <div className="relative flex justify-center">
              <span className="px-4 text-[10px] font-bold uppercase tracking-widest text-slate-400 bg-white dark:bg-slate-900">
                or continue with
              </span>
            </div>
          </div>

          {/* Google Signup */}
          <div className="flex justify-center">
            <GoogleLogin
              onSuccess={async (credentialResponse: CredentialResponse) => {
                if (credentialResponse.credential) {
                  setIsLoading(true);
                  setError('');
                  const googleEmail = getGoogleCredentialEmail(credentialResponse.credential);
                  if (googleEmail) {
                    setLastEmail(googleEmail.toLowerCase());
                  }
                  const res = await googleLogin(credentialResponse.credential);
                  setIsLoading(false);
                  if (res.success) {
                    if (redirectTo) {
                      navigate(redirectTo, { state: redirectState });
                    } else {
                      navigate('/dashboard');
                    }
                  } else {
                    const errorMessage = res.error || 'Google signup failed. Please try again.';
                    const isEmailAlreadyRegistered = errorMessage
                      .toLowerCase()
                      .includes('already registered');

                    if (isEmailAlreadyRegistered) {
                      setError('This email is already registered with us, please choose different email.');
                      return;
                    }

                    setError(errorMessage);
                  }
                }
              }}
              onError={() => {
                setError('Google signup failed. Please try again.');
              }}
              theme="outline"
              size="large"
              width={200}
              text="signup_with"
              shape="rectangular"
              logo_alignment="left"
            />
          </div>

          {/* Login Link */}
          <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-8">
            Already have an account?{' '}
            <Link to="/login" className="font-bold text-indigo-600 dark:text-indigo-400 hover:underline">
              Log in
            </Link>
          </p>
          <p className="text-center mt-3">
            <Link to="/dashboard" className="text-sm text-slate-500 dark:text-slate-400 underline hover:text-indigo-600 dark:hover:text-indigo-400">
              i'll do it later
            </Link>
          </p>

        </div>
      </div>
    </div>
  );
};

export default SignupPage;
