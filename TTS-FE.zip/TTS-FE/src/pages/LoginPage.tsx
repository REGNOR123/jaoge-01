import React, { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { GoogleLogin, CredentialResponse } from '@react-oauth/google';
import { useAuth } from '../contexts/AuthContext';
import { clearRememberedEmail, getRememberedEmail, setRememberedEmail } from '../utils/authStorage';
import { mapAuthErrorMessage } from '../utils/authErrorMapper';
import { getGoogleCredentialEmail } from '../utils/googleCredential';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { login, googleLogin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const infoMessage = (location.state as { infoMessage?: string } | null)?.infoMessage;
  const redirectTo = (location.state as { redirectTo?: string } | null)?.redirectTo;
  const redirectState = (location.state as { redirectState?: unknown } | null)?.redirectState;

  useEffect(() => {
    if (infoMessage) {
      setInfo(infoMessage);
      navigate(location.pathname, {
        replace: true,
        state: redirectTo ? { redirectTo, redirectState } : null,
      });
    }
  }, [infoMessage, location.pathname, navigate, redirectState, redirectTo]);

  useEffect(() => {
    const rememberedEmail = getRememberedEmail();
    if (rememberedEmail) {
      setEmail(rememberedEmail);
      setRememberMe(true);
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setInfo('');

    if (!email.trim()) {
      setError('Please enter your email.');
      return;
    }
    if (!password) {
      setError('Please enter your password.');
      return;
    }

    setIsLoading(true);
    const trimmedEmail = email.trim();
    const normalizedEmail = trimmedEmail.toLowerCase();
    const res = await login(normalizedEmail, password);
    setIsLoading(false);

    if (res.success) {
      if (rememberMe) {
        setRememberedEmail(trimmedEmail);
      } else {
        clearRememberedEmail();
      }
      if (redirectTo) {
        navigate(redirectTo, { state: redirectState });
      } else {
        navigate('/dashboard');
      }
    } else {
      setError(
        mapAuthErrorMessage({
          flow: 'login',
          status: res.status,
          error: res.error,
          errors: res.errors,
        }),
      );
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-gradient-to-br from-slate-50 via-white to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            </div>
            <h1 className="text-2xl font-black tracking-tighter text-slate-900 dark:text-white uppercase">
              TextTo<span className="text-indigo-500">Speeches</span>
            </h1>
          </Link>
        </div>

        {/* Card */}
        <div className="glass studio-card !p-8 sm:!p-10">
          <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Welcome Back</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-8">
            Log in to your account
          </p>

          {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20">
              <p className="text-sm font-medium text-red-600 dark:text-red-400">{error}</p>
            </div>
          )}

          {(info || infoMessage) && (
            <div className="mb-6 p-4 rounded-xl bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20">
              <p className="text-sm font-medium text-amber-700 dark:text-amber-300">{info || infoMessage}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email */}
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-3 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/40 transition-all text-sm"
                required
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full px-4 py-3 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/40 focus:border-indigo-500/40 transition-all text-sm"
                required
              />
            </div>

            <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300 select-none">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
              />
              Remember me
            </label>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm uppercase tracking-wider transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-600/20 hover:shadow-indigo-600/30"
            >
              {isLoading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Logging in...
                </div>
              ) : (
                'Log In'
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200 dark:border-white/10"></div>
            </div>
            <div className="relative flex justify-center">
              <span className="px-4 text-[10px] font-bold uppercase tracking-widest text-slate-400 bg-white dark:bg-slate-900">
                or continue with
              </span>
            </div>
          </div>

          {/* Google Login */}
          <div className="flex justify-center">
            <GoogleLogin
              onSuccess={async (credentialResponse: CredentialResponse) => {
                if (credentialResponse.credential) {
                  setIsLoading(true);
                  setError('');
                  setInfo('');
                  const googleEmail = getGoogleCredentialEmail(credentialResponse.credential);
                  if (googleEmail) {
                    setEmail(googleEmail.toLowerCase());
                  }
                  const res = await googleLogin(credentialResponse.credential);
                   setIsLoading(false);
                   if (res.success) {
                     if (redirectTo) {
                       navigate(redirectTo, { state: redirectState });
                     } else {
                       navigate('/dashboard');
                     }
                   } else {
                     const errorMessage = res.error || 'Google login failed. Please try again.';
                     const isManualPasswordConflict = errorMessage
                       .toLowerCase()
                       .includes('registered with password');

                    if (isManualPasswordConflict) {
                      setInfo('This email already has a password account. Please log in with your password.');
                      return;
                    }

                    setError(errorMessage);
                  }
                }
              }}
              onError={() => {
                setError('Google login failed. Please try again.');
              }}
              theme="outline"
              size="large"
              width={200}
              text="signin_with"
              shape="rectangular"
              logo_alignment="left"
            />
          </div>

          {/* Signup Link */}
          <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-8">
            Don't have an account?{' '}
            <Link to="/signup" className="font-bold text-indigo-600 dark:text-indigo-400 hover:underline">
              Sign up
            </Link>
          </p>
          <p className="text-center mt-3">
            <Link to="/dashboard" className="text-sm text-slate-500 dark:text-slate-400 underline hover:text-indigo-600 dark:hover:text-indigo-400">
              i'll do it later
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
