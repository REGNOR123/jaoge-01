import React, { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { AVAILABLE_VOICES } from "../../constants";
import { VoiceName, VoiceRegion, type VoiceOption } from "../../types";
import { useAuth } from "../../contexts/AuthContext";
import { useWizardProgress } from "../../hooks/useWizardProgress";
import { sendChatMessage } from "../../services/chatApiService";
import { generateAzureSpeech } from "../../services/azureService";
import {
  deleteManagedFile,
  downloadManagedFile,
  uploadManagedFile,
  uploadManagedTextFile,
  type StoredFileRecord,
} from "../../services/filesApiService";
import {
  createProject,
  getProjectById,
  listProjects,
  updateProject,
  type Project,
} from "../../utils/projectsStorage";
import ScriptStep from "./ScriptStep";
import VoiceSelectionStep from "./VoiceSelectionStep";
import GenerateStep from "./GenerateStep";
import ProgressStepBar from "./ProgressStepBar";
import BottomActionBar from "./BottomActionBar";
import { estimateVoiceMinutes, getPreviewTextForVoice } from "./utils";
import type { SpeechSynthesisLike } from "./types";
import { consumePrefillScript } from "../../utils/prefillScript";
import AuthRequiredModal from "../AuthRequiredModal";
import InsufficientCreditsModal from "../InsufficientCreditsModal";
import { useCredits } from "../../contexts/CreditContext";
import { useDialog } from "../dialogs";
import ProjectNameModal from "../ProjectNameModal";
import { downloadHref } from "../../utils/format";

const RETENTION_MESSAGE = "Files are auto-deleted after 24 hours.";


const getAudioContentType = (audioUrl: string) => {
  if (!audioUrl.startsWith("data:")) return undefined;
  const match = audioUrl.match(/^data:([^;,]+)[;,]/i);
  return match?.[1]?.trim() || undefined;
};

const getExtensionFromContentType = (contentType?: string) => {
  switch ((contentType || "").toLowerCase()) {
    case "audio/mpeg":
    case "audio/mp3":
      return "mp3";
    case "audio/wav":
    case "audio/wave":
    case "audio/x-wav":
      return "wav";
    case "audio/ogg":
      return "ogg";
    case "audio/webm":
      return "webm";
    case "audio/aac":
      return "aac";
    default:
      return "wav";
  }
};

const sanitizeFileSegment = (value: string) =>
  value.replace(/[^a-z0-9-]+/gi, "-").replace(/^-+|-+$/g, "");

const CreateVoiceWizard = ({
  token,
  synthesis,
  initialProjectId,
}: {
  token: string | null;
  synthesis: SpeechSynthesisLike;
  initialProjectId?: string;
}) => {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const isGuest = !authLoading && !isAuthenticated;
  const dialog = useDialog();
  const navigate = useNavigate();
  const { refreshBalance } = useCredits();
  const [searchParams] = useSearchParams();
  const [authRequiredOpen, setAuthRequiredOpen] = useState(false);
  const [insuffCredits, setInsuffCredits] = useState<{ required: number; current: number } | null>(null);
  const [workflowId] = useState(() => crypto.randomUUID());
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [maxStepUnlocked, setMaxStepUnlocked] = useState<1 | 2 | 3>(1);

  const enhanceProgress = useWizardProgress();
  const isEnhancing = enhanceProgress.inProgress;
  const enhancePercent = enhanceProgress.percent;
  const [enhanceError, setEnhanceError] = useState<string | null>(null);

  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [step1Loading, setStep1Loading] = useState(false);
  const [voiceSearchQuery, setVoiceSearchQuery] = useState("");
  const [voiceGenderFilter, setVoiceGenderFilter] = useState<"All" | "Male" | "Female">("All");
  const [voiceRegionFilter, setVoiceRegionFilter] = useState<"All" | VoiceRegion>("All");

  const [previewLoadingId, setPreviewLoadingId] = useState<VoiceName | null>(
    null,
  );
  const [previewPlayingId, setPreviewPlayingId] = useState<VoiceName | null>(
    null,
  );
  const previewRef = useRef<HTMLAudioElement | null>(null);
  const previewCacheRef = useRef<Map<string, string>>(new Map());

  const [projects, setProjects] = useState<Project[]>(() => listProjects());
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [newProjectName, setNewProjectName] = useState("");

  const [projectModalPurpose, setProjectModalPurpose] = useState<"draft" | "project" | null>(null);
  const [pendingProjectName, setPendingProjectName] = useState("");
  const [projectModalError, setProjectModalError] = useState<string | null>(null);
  const [projectModalStatus, setProjectModalStatus] = useState<"idle" | "saved">("idle");
  const [pendingNavigationTarget, setPendingNavigationTarget] = useState<1 | 2 | 3 | null>(null);

  const saveDraftProgress = useWizardProgress();
  const saveDraftInProgress = saveDraftProgress.inProgress;
  const saveDraftPercent = saveDraftProgress.percent;

  const saveToProjectProgress = useWizardProgress();
  const saveToProjectInProgress = saveToProjectProgress.inProgress;
  const saveToProjectPercent = saveToProjectProgress.percent;
  const [outputFileRecord, setOutputFileRecord] =
    useState<StoredFileRecord | null>(null);
  const [outputUploadInProgress, setOutputUploadInProgress] = useState(false);
  const [outputUploadError, setOutputUploadError] = useState<string | null>(
    null,
  );
  const [fileActionKey, setFileActionKey] = useState<string | null>(null);
  const [outputDownloaded, setOutputDownloaded] = useState(false);
  const [uploadPercent, setUploadPercent] = useState(0);
  const lastUploadedPendingUrlRef = useRef<string | null>(null);
  const restoredOutputUrlRef = useRef<string | null>(null);
  const restoredOutputFileIdRef = useRef<string | null>(null);
  const lastStoredScriptRef = useRef<{
    projectId: string;
    text: string;
    data: StoredFileRecord;
  } | null>(null);

  const startSaveDraftProgress = saveDraftProgress.start;
  const stopSaveDraftProgress = saveDraftProgress.stop;
  const finishSaveDraftProgress = saveDraftProgress.finish;

  const startSaveToProjectProgress = saveToProjectProgress.start;
  const stopSaveToProjectProgress = saveToProjectProgress.stop;
  const finishSaveToProjectProgress = saveToProjectProgress.finish;

  const startEnhanceProgress = enhanceProgress.start;
  const stopEnhanceProgress = enhanceProgress.stop;
  const finishEnhanceProgress = enhanceProgress.finish;

  useEffect(() => {
    if (synthesis.text.trim()) return;
    const prefill = consumePrefillScript();
    if (!prefill) return;
    synthesis.setText(prefill);
  }, [synthesis]);

  useEffect(() => {
    const pid = initialProjectId || searchParams.get("projectId") || "";
    if (!pid) return;
    const project = getProjectById(pid);
    if (!project) return;

    setSelectedProjectId(project.id);
    const draft = project.data?.drafts?.voice;
    const audioVersions = project.data?.outputs?.audioVersions || [];
    const latestAudio = audioVersions[0];

    if (!synthesis.text.trim() && typeof draft?.script === "string") {
      synthesis.setText(draft.script);
    }

    if (draft?.voice && typeof draft.voice === "string") {
      synthesis.setSelectedVoice(draft.voice as VoiceName);
    } else if (latestAudio?.voice && typeof latestAudio.voice === "string") {
      synthesis.setSelectedVoice(latestAudio.voice as VoiceName);
    }

    const latestSettings = (latestAudio?.settings as any) || {};
    const latestFileId =
      typeof (latestAudio?.fileId || latestSettings.fileId) === "string"
        ? String(latestAudio?.fileId || latestSettings.fileId)
        : "";
    if (latestFileId) {
      setOutputFileRecord({
        fileId: latestFileId,
        fileName:
          typeof (latestAudio?.fileName || latestSettings.fileName) === "string"
            ? String(latestAudio?.fileName || latestSettings.fileName)
            : "create-voice-output.wav",
        contentType:
          typeof (latestAudio?.contentType || latestSettings.contentType) ===
          "string"
            ? String(latestAudio?.contentType || latestSettings.contentType)
            : undefined,
        expiresAt:
          typeof (latestAudio?.expiresAt || latestSettings.expiresAt) ===
          "string"
            ? String(latestAudio?.expiresAt || latestSettings.expiresAt)
            : undefined,
        uploadedAt:
          typeof latestAudio?.createdAt === "string"
            ? latestAudio.createdAt
            : undefined,
        durationMinutes:
          typeof latestAudio?.estimatedMinutes === "number"
            ? latestAudio.estimatedMinutes
            : undefined,
        isOutput: true,
        feature: "create-voice",
        jobId: project.id,
      });
    }

    if (typeof draft?.rate === "number") synthesis.setRate(draft.rate);
    if (typeof draft?.pitch === "number") synthesis.setPitch(draft.pitch);

    refreshProjects();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const languages = useMemo(() => {
    return Array.from(new Set(AVAILABLE_VOICES.map((v) => v.lang))).sort(
      (a, b) => a.localeCompare(b),
    );
  }, []);

  const [language, setLanguage] = useState(
    () => synthesis.selectedVoiceInfo?.lang || languages[0] || "",
  );

  useEffect(() => {
    const next = synthesis.selectedVoiceInfo?.lang;
    if (!next) return;
    if (next !== language) setLanguage(next);
  }, [language, synthesis.selectedVoiceInfo?.lang]);

  useEffect(() => {
    if (!language && languages[0]) setLanguage(languages[0]);
  }, [language, languages]);

  const detectedLangKey = useMemo(() => {
    const detected = synthesis.detectedLang?.trim();
    if (!detected || detected === "Unknown") return null;
    return detected.toLowerCase();
  }, [synthesis.detectedLang]);

  const voicesForSelection: VoiceOption[] = useMemo(() => {
    if (detectedLangKey) {
      const matches = AVAILABLE_VOICES.filter((v) =>
        v.lang.toLowerCase().includes(detectedLangKey),
      );
      if (matches.length) return matches;
    }
    const fallbackLanguage =
      synthesis.selectedVoiceInfo?.lang || language || languages[0] || "";
    return AVAILABLE_VOICES.filter((v) => v.lang === fallbackLanguage);
  }, [detectedLangKey, language, languages, synthesis.selectedVoiceInfo?.lang]);

  const isDetectedRegional = useMemo(() => {
    if (!detectedLangKey) return false;
    return voicesForSelection.some(
      (v) => v.region === "Indian" || v.region === "SE Asian",
    );
  }, [detectedLangKey, voicesForSelection]);

  useEffect(() => {
    const stillValid = voicesForSelection.some(
      (v) => v.id === synthesis.selectedVoice,
    );
    if (!stillValid)
      synthesis.setSelectedVoice(voicesForSelection[0].id as VoiceName);
  }, [synthesis, voicesForSelection]);

  const estimatedMinutes = useMemo(
    () => estimateVoiceMinutes(synthesis.text),
    [synthesis.text],
  );

  const getDefaultProjectName = () => {
    if (newProjectName.trim()) return newProjectName.trim();
    return "Create Voice";
  };

  const resetProjectModal = () => {
    setProjectModalPurpose(null);
    setProjectModalError(null);
    setProjectModalStatus("idle");
    setPendingNavigationTarget(null);
  };

  const openProjectModal = (purpose: "draft" | "project") => {
    setPendingProjectName(getDefaultProjectName());
    setProjectModalError(null);
    setProjectModalStatus("idle");
    setProjectModalPurpose(purpose);
  };

  const projectModalLoading =
    projectModalPurpose === "draft"
      ? saveDraftInProgress
      : projectModalPurpose === "project"
        ? saveToProjectInProgress
        : false;
  const projectModalPercent =
    projectModalPurpose === "draft"
      ? saveDraftPercent
      : projectModalPurpose === "project"
        ? saveToProjectPercent
        : 0;
  const projectModalTitle = projectModalPurpose === "project" ? "Save Project" : "Save Draft";
  const projectModalDescription =
    projectModalPurpose === "project"
      ? "Store the generated audio under this project name."
      : "Store the current draft under this project name.";
  const projectModalStatusMessage = projectModalStatus === "saved" ? "Saved" : undefined;

  const handleProjectModalProceed = async () => {
    if (!projectModalPurpose) return;
    const candidate = pendingProjectName.trim();
    if (candidate.length <= 3) {
      setProjectModalError("Project name must be at least 4 characters.");
      return;
    }
    const validationError = validateNewProjectName(candidate, projects);
    if (validationError) {
      setProjectModalError(validationError);
      return;
    }
    setProjectModalError(null);
    setPendingProjectName(candidate);
    setProjectModalStatus("idle");
    setNewProjectName(candidate);

    if (projectModalPurpose === "draft") {
      startSaveDraftProgress();
      const ok = saveDraftToProject(candidate);
      if (!ok) {
        stopSaveDraftProgress();
        setProjectModalError(projectNameError || "Enter a unique project name.");
        return;
      }
      await finishSaveDraftProgress();
    } else {
      startSaveToProjectProgress();
      const ok = await saveGeneratedToProject(candidate);
      if (!ok) {
        stopSaveToProjectProgress();
        await dialog.alert("Couldn't save to project. Please try again.", {
          title: "Save Failed",
          variant: "danger",
        });
        return;
      }
      await finishSaveToProjectProgress();
    }

    setProjectModalStatus("saved");
    if (pendingNavigationTarget !== null) {
      // Resume deferred step navigation after save
      const target = pendingNavigationTarget;
      window.setTimeout(() => {
        if (target === 1) {
          synthesis.setPendingEntry(null);
          setOutputFileRecord(null);
          setMaxStepUnlocked(1);
        } else if (target === 2) {
          synthesis.setPendingEntry(null);
          setOutputFileRecord(null);
          setMaxStepUnlocked(2);
        }
        setStep(target);
        resetProjectModal();
      }, 600);
    } else {
      window.setTimeout(() => navigate("/projects"), 600);
    }
  };

  const applyProtectedError = (message: string, status?: number) => {
    setOutputUploadError(message);
    if (status === 401 || status === 403) setAuthRequiredOpen(true);
  };

  // Check if user can access protected features (authenticated users only)
  const requireProtectedAccess = () => {
    if (isAuthenticated && token) return true;
    setOutputUploadError(
      "Please login before generating or storing voice samples.",
    );
    setAuthRequiredOpen(true);
    return false;
  };

  const refreshProjects = () => setProjects(listProjects());

  const normalizeProjectName = (value: string) =>
    value.trim().replace(/\s+/g, " ").toLowerCase();

  const validateNewProjectName = (
    value: string,
    existing: Project[],
    excludeId?: string,
  ): string | null => {
    const collapsed = value.trim().replace(/\s+/g, " ");
    if (collapsed.length <= 3)
      return "Project name must be at least 4 characters.";
    const normalized = normalizeProjectName(collapsed);
    const isDuplicate = existing.some(
      (p) =>
        normalizeProjectName(p.name) === normalized &&
        (!excludeId || p.id !== excludeId),
    );
    if (isDuplicate) return "Project name must be unique.";
    return null;
  };

  const projectNameError = useMemo(() => {
    if (selectedProjectId) return null;
    const candidate = newProjectName.trim();
    if (!candidate) return null;
    return validateNewProjectName(candidate, projects);
  }, [newProjectName, projects, selectedProjectId]);

  const canSaveDraft = synthesis.text.trim().length > 0;
  const canContinueFromScript =
    synthesis.text.trim().length > 0 &&
    !synthesis.isTextTooLong &&
    !synthesis.isDetecting;
  const isStep1Complete = canContinueFromScript;
  const isStep2Complete = maxStepUnlocked >= 3 || step === 3;
  const isStep3Complete = Boolean(synthesis.pendingEntry?.audioUrl);
  const step1Summary = useMemo(() => {
    const text = synthesis.text.trim();
    if (!text) return undefined;
    const snippet = text.split("\n")[0].trim();
    const preview = snippet.length > 80 ? `${snippet.slice(0, 80)}…` : snippet;
    return `${preview} • ${estimatedMinutes.toFixed(2)} mins`;
  }, [estimatedMinutes, synthesis.text]);

  const step2Summary = useMemo(() => {
    const voiceName =
      synthesis.selectedVoiceInfo?.name || synthesis.selectedVoice || "";
    const locale =
      synthesis.selectedVoiceInfo?.lang || language || "Language";
    if (!voiceName) return undefined;
    return `${voiceName} • ${locale}`;
  }, [
    language,
    synthesis.selectedVoice,
    synthesis.selectedVoiceInfo?.lang,
    synthesis.selectedVoiceInfo?.name,
  ]);

  const step3Summary = useMemo(() => {
    if (!synthesis.pendingEntry?.audioUrl) return undefined;
    const fileName = outputFileRecord?.fileName || "Generated audio";
    return `Audio ready • ${fileName}`;
  }, [outputFileRecord?.fileName, synthesis.pendingEntry?.audioUrl]);

  const activeProjectName = useMemo(() => {
    if (selectedProjectId)
      return projects.find((p) => p.id === selectedProjectId)?.name || "";
    return newProjectName;
  }, [newProjectName, projects, selectedProjectId]);

  useEffect(() => {
    if (isStep1Complete) return;
    setMaxStepUnlocked(1);
    setStep(1);
  }, [isStep1Complete]);

  useEffect(() => {
    const trimmed = synthesis.text.trim();
    const stored = lastStoredScriptRef.current;
    if (!trimmed || !stored) {
      lastStoredScriptRef.current = null;
      return;
    }
    if (
      stored.projectId !== selectedProjectId ||
      stored.text !== trimmed
    ) {
      lastStoredScriptRef.current = null;
    }
  }, [selectedProjectId, synthesis.text]);

  const ensureProject = (overrideName?: string): string | null => {
    if (selectedProjectId) {
      if (overrideName) {
        const raw = overrideName.trim();
        const normalized = raw.replace(/\s+/g, " ");
        if (normalized) {
          const currentProject = getProjectById(selectedProjectId);
          if (currentProject && currentProject.name !== normalized) {
            const error = validateNewProjectName(
              normalized,
              listProjects(),
              selectedProjectId,
            );
            if (!error) {
              updateProject(selectedProjectId, {
                name: normalized,
              });
              refreshProjects();
            }
            setNewProjectName(normalized);
          }
        }
      }
      return selectedProjectId;
    }
    const baseName =
      (overrideName?.trim() && overrideName.trim()) ||
      (newProjectName.trim() ? newProjectName.trim() : getDefaultProjectName());
    const normalizedBase = baseName.replace(/\s+/g, " ");
    const existingProjects = listProjects();
    let candidateName = normalizedBase;
    let suffix = 2;
    while (
      validateNewProjectName(candidateName, existingProjects) ===
      "Project name must be unique."
    ) {
      candidateName = `${normalizedBase} ${suffix}`;
      suffix += 1;
    }
    const error = validateNewProjectName(candidateName, existingProjects);
    if (error) return null;
    const project = createProject({
      name: candidateName,
      type: "Voice",
      status: "Processing",
      data: {
        drafts: {
          voice: {
            script: synthesis.text,
            updatedAt: new Date().toISOString(),
          },
        },
        outputs: {
          scripts: synthesis.text.trim()
            ? [
                {
                  id: crypto.randomUUID(),
                  text: synthesis.text.trim(),
                  createdAt: new Date().toISOString(),
                  source: "Create Voice",
                },
              ]
            : [],
        },
      },
    });
    if (!project) return null;
    setSelectedProjectId(project.id);
    setNewProjectName(candidateName);
    refreshProjects();
    return project.id;
  };

  const saveDraftToProject = (overrideName?: string): boolean => {
    const projectId = ensureProject(overrideName);
    if (!projectId) return false;
    const existing = getProjectById(projectId);
    const now = new Date().toISOString();
    const updated = updateProject(projectId, {
      type: "Voice",
      status: "Processing",
      data: {
        ...(existing?.data || {}),
        drafts: {
          ...(existing?.data?.drafts || {}),
          voice: {
            script: synthesis.text,
            language,
            voice: synthesis.selectedVoice,
            rate: synthesis.rate,
            pitch: synthesis.pitch,
            updatedAt: now,
          },
        },
      },
    });
    if (!updated) return false;
    refreshProjects();
    return true;
  };

  const dataUrlToFile = async (
    dataUrl: string,
    fileName: string,
    contentType?: string,
  ): Promise<File> => {
    const response = await fetch(dataUrl);
    const blob = await response.blob();
    return new File([blob], fileName, {
      type: contentType || blob.type || "audio/wav",
    });
  };

  const buildGeneratedFileName = (audioUrl: string) => {
    const contentType = getAudioContentType(audioUrl);
    const extension = getExtensionFromContentType(contentType);
    const voiceSegment =
      sanitizeFileSegment(String(synthesis.selectedVoice || "voice")) ||
      "voice";
    return `create-voice-${voiceSegment}-${workflowId}-${Date.now()}.${extension}`;
  };

  const storeCurrentScriptSample = async (projectId: string) => {
    const nextScript = synthesis.text.trim();
    if (!nextScript) return null;
    const cached = lastStoredScriptRef.current;
    if (
      cached &&
      cached.projectId === projectId &&
      cached.text === nextScript
    ) {
      return cached.data;
    }
    if (!requireProtectedAccess() || !token) return null;

    const result = await uploadManagedTextFile(token, nextScript, {
      fileName: `create-voice-script-${workflowId}.txt`,
      feature: "create-voice",
      jobId: projectId,
      durationMinutes: estimatedMinutes,
      isOutput: false,
    });
    if (result.success === false) {
      applyProtectedError(result.error, result.status);
      return null;
    }

    const project = getProjectById(projectId);
    if (project) {
      const now = result.data.uploadedAt || new Date().toISOString();
      const existingScripts = project.data?.outputs?.scripts || [];
      updateProject(projectId, {
        type: "Voice",
        status: project.status,
        data: {
          ...(project.data || {}),
          outputs: {
            ...(project.data?.outputs || {}),
            scripts: [
              {
                id: `create-voice-script-${result.data.fileId}`,
                text: nextScript,
                createdAt: now,
                fileId: result.data.fileId,
                contentType: result.data.contentType,
                fileName: result.data.fileName,
                expiresAt: result.data.expiresAt,
                source: "Create Voice",
              },
              ...existingScripts.filter(
                (entry) => entry.source !== "Create Voice",
              ),
            ].slice(0, 20),
          },
        },
      });
      refreshProjects();
    }

    lastStoredScriptRef.current = {
      projectId,
      text: nextScript,
      data: result.data,
    };

    return result.data;
  };

  const clearGeneratedOutput = () => {
    if (restoredOutputUrlRef.current) {
      URL.revokeObjectURL(restoredOutputUrlRef.current);
      restoredOutputUrlRef.current = null;
    }
    restoredOutputFileIdRef.current = null;
    lastUploadedPendingUrlRef.current = null;
    setOutputFileRecord(null);
    setOutputUploadError(null);
    setOutputDownloaded(false);
    synthesis.setPendingEntry(null);
  };

  const ensureGeneratedOutputStored = async () => {
    const pendingAudioUrl = synthesis.pendingEntry?.audioUrl as
      | string
      | undefined;
    if (!pendingAudioUrl) return null;
    if (
      outputFileRecord?.fileId &&
      lastUploadedPendingUrlRef.current &&
      lastUploadedPendingUrlRef.current === pendingAudioUrl
    ) {
      return outputFileRecord;
    }
    if (!requireProtectedAccess() || !token) return null;

    setOutputUploadError(null);
    setOutputUploadInProgress(true);
    setUploadPercent(0);
    try {
      const fileName = buildGeneratedFileName(pendingAudioUrl);
      const contentType = getAudioContentType(pendingAudioUrl);
      const file = await dataUrlToFile(pendingAudioUrl, fileName, contentType);
      const result = await uploadManagedFile(token, file, {
        feature: "create-voice",
        jobId: workflowId,
        durationMinutes: estimatedMinutes,
        isOutput: true,
        onProgress: (percent) => setUploadPercent(percent),
      });
      if (result.success === false) {
        applyProtectedError(result.error, result.status);
        return null;
      }

      setOutputFileRecord(result.data);
      lastUploadedPendingUrlRef.current = pendingAudioUrl;
      return result.data;
    } finally {
      setOutputUploadInProgress(false);
      setUploadPercent(0);
    }
  };

  const handleDownloadGeneratedOutput = async () => {
    const pendingAudioUrl = synthesis.pendingEntry?.audioUrl as
      | string
      | undefined;
    const fallbackName =
      outputFileRecord?.fileName ||
      (pendingAudioUrl
        ? buildGeneratedFileName(pendingAudioUrl)
        : "create-voice-output.wav");

    if (outputFileRecord?.fileId) {
      if (!requireProtectedAccess() || !token) return;
      setOutputUploadError(null);
      setFileActionKey("download-output");
      const result = await downloadManagedFile(token, outputFileRecord.fileId);
      setFileActionKey(null);
      if (result.success === false) {
        applyProtectedError(result.error, result.status);
        return;
      }
      const url = URL.createObjectURL(result.data.blob);
      downloadHref(url, result.data.fileName || fallbackName);
      window.setTimeout(() => URL.revokeObjectURL(url), 0);
      setOutputDownloaded(true);
      return;
    }

    if (pendingAudioUrl) {
      downloadHref(pendingAudioUrl, fallbackName);
      setOutputDownloaded(true);
    }
  };

  const handleDeleteGeneratedOutput = async () => {
    const confirmDelete = await dialog.confirm(
      "Are you sure you want to delete this generated audio? This action cannot be undone.",
      {
        title: "Delete Generated Audio",
        confirmText: "Delete",
        cancelText: "Cancel",
        variant: "danger",
      }
    );

    if (!confirmDelete) return;

    if (outputFileRecord?.fileId) {
      if (!requireProtectedAccess() || !token) return;
      setOutputUploadError(null);
      setFileActionKey("delete-output");
      const result = await deleteManagedFile(token, outputFileRecord.fileId);
      setFileActionKey(null);
      if (result.success === false) {
        applyProtectedError(result.error, result.status);
        return;
      }
    }
    clearGeneratedOutput();
  };

  const saveGeneratedToProject = async (overrideName?: string): Promise<boolean> => {
    if (!synthesis.pendingEntry?.audioUrl) return false;
    const projectId = ensureProject(overrideName);
    if (!projectId) return false;
    const storedScript = await storeCurrentScriptSample(projectId);
    if (synthesis.pendingEntry.text?.trim() && !storedScript) return false;
    const storedRecord = outputFileRecord?.fileId
      ? outputFileRecord
      : await ensureGeneratedOutputStored();
    if (!storedRecord?.fileId) return false;
    const existing = getProjectById(projectId);
    const now = new Date().toISOString();
    const nextScript = synthesis.pendingEntry.text?.trim() || "";
    const scripts = existing?.data?.outputs?.scripts || [];
    const audioVersions = existing?.data?.outputs?.audioVersions || [];

    const updated = updateProject(projectId, {
      type: "Voice",
      status: "Completed",
      data: {
        ...(existing?.data || {}),
        drafts: {
          ...(existing?.data?.drafts || {}),
          voice: {
            script: nextScript,
            language,
            voice: synthesis.pendingEntry.voice,
            rate: synthesis.rate,
            pitch: synthesis.pitch,
            updatedAt: now,
          },
        },
        outputs: {
          ...(existing?.data?.outputs || {}),
          scripts: nextScript
            ? [
                {
                  id: storedScript?.fileId
                    ? `create-voice-script-${storedScript.fileId}`
                    : `create-voice-script-${now}`,
                  text: nextScript,
                  createdAt: storedScript?.uploadedAt || now,
                  fileId: storedScript?.fileId,
                  contentType: storedScript?.contentType,
                  fileName: storedScript?.fileName,
                  expiresAt: storedScript?.expiresAt,
                  source: "Create Voice",
                },
                ...scripts.filter((entry) => entry.source !== "Create Voice"),
              ].slice(0, 20)
            : scripts,
          audioVersions: [
            {
              id: `create-voice-output-${storedRecord.fileId}`,
              audioUrl: `managed-file:${storedRecord.fileId}`,
              createdAt: storedRecord.uploadedAt || now,
              fileId: storedRecord.fileId,
              contentType: storedRecord.contentType,
              fileName: storedRecord.fileName,
              expiresAt: storedRecord.expiresAt,
              voice: synthesis.pendingEntry.voice,
              voiceLabel: synthesis.pendingEntry.voiceLabel,
              settings: {
                ...(synthesis.pendingEntry.settings as any),
                feature: "create-voice",
                source: "generated",
                fileId: storedRecord.fileId,
                fileName: storedRecord.fileName,
                contentType: storedRecord.contentType,
                expiresAt: storedRecord.expiresAt,
              },
              estimatedMinutes,
            },
            ...audioVersions.filter(
              (entry) => entry.fileId !== storedRecord.fileId,
            ),
          ].slice(0, 20),
          transcripts: existing?.data?.outputs?.transcripts,
          languages: existing?.data?.outputs?.languages,
        },
        usage: {
          ...(existing?.data?.usage || {}),
          voiceMinutesUsed:
            (existing?.data?.usage?.voiceMinutesUsed || 0) + estimatedMinutes,
        },
      },
    });

    refreshProjects();
    return Boolean(updated);
  };

  useEffect(() => {
    if (!selectedProjectId || !synthesis.text.trim()) return;
    const t = window.setTimeout(() => {
      saveDraftToProject();
    }, 650);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    selectedProjectId,
    synthesis.text,
    synthesis.selectedVoice,
    synthesis.rate,
    synthesis.pitch,
    language,
  ]);

  useEffect(() => {
    return () => {
      if (restoredOutputUrlRef.current) {
        URL.revokeObjectURL(restoredOutputUrlRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!outputFileRecord?.fileId || !token) return;
    const currentPendingUrl = synthesis.pendingEntry?.audioUrl as
      | string
      | undefined;
    if (currentPendingUrl && !currentPendingUrl.startsWith("managed-file:"))
      return;
    if (restoredOutputFileIdRef.current === outputFileRecord.fileId) return;

    let active = true;
    restoredOutputFileIdRef.current = outputFileRecord.fileId;
    void (async () => {
      const result = await downloadManagedFile(token, outputFileRecord.fileId);
      if (!active) return;
      if (result.success === false) {
        restoredOutputFileIdRef.current = null;
        applyProtectedError(result.error, result.status);
        return;
      }

      if (restoredOutputUrlRef.current)
        URL.revokeObjectURL(restoredOutputUrlRef.current);
      const url = URL.createObjectURL(result.data.blob);
      restoredOutputUrlRef.current = url;
      synthesis.setPendingEntry((prev: any) => ({
        ...(prev || {}),
        text: prev?.text || synthesis.text.trim(),
        voice: prev?.voice || synthesis.selectedVoice,
        voiceLabel:
          prev?.voiceLabel ||
          `${synthesis.selectedVoiceInfo?.name || synthesis.selectedVoice} (${synthesis.selectedVoiceInfo?.lang || language})`,
        audioUrl: url,
        settings: prev?.settings || {
          rate: synthesis.rate,
          pitch: synthesis.pitch,
        },
      }));
      lastUploadedPendingUrlRef.current = url;
    })();

    return () => {
      active = false;
    };
  }, [
    language,
    outputFileRecord?.fileId,
    synthesis.pendingEntry?.audioUrl,
    synthesis.rate,
    synthesis.selectedVoice,
    synthesis.selectedVoiceInfo?.lang,
    synthesis.selectedVoiceInfo?.name,
    synthesis.text,
    token,
  ]);

  const handleEnhance = async () => {
    if (!synthesis.text.trim()) return;
    if (isEnhancing) return;
    if (!requireProtectedAccess()) return;
    setEnhanceError(null);
    const original = synthesis.text;
    startEnhanceProgress();
    let res: Awaited<ReturnType<typeof sendChatMessage>>;
    try {
      res = await sendChatMessage(
        {
          systemPrompt:
            "You are a helpful writing assistant. Reframe the user's script to be clearer and more engaging for a voiceover. Return ONLY the rewritten script, no quotes, no markdown.",
          message: synthesis.text.trim(),
        },
        token,
      );
    } catch {
      stopEnhanceProgress();
      setEnhanceError("Enhance failed. Please try again.");
      return;
    }
    if (res.success === false) {
      stopEnhanceProgress();
      if (res.insufficientCredits) {
        setInsuffCredits({ required: res.requiredCredits ?? 0, current: res.currentBalance ?? 0 });
        return;
      }
      const raw = String(res.error || "").trim();
      const lower = raw.toLowerCase();
      const looksTechnical =
        res.status === 400 ||
        raw.includes("{") ||
        lower.includes("azure") ||
        lower.includes("openai") ||
        lower.includes("api version") ||
        lower.includes("not supported") ||
        lower.includes("chat failed");
      setEnhanceError(
        looksTechnical
          ? "Enhance with AI is temporarily unavailable. Please try again later."
          : raw || "Enhance failed. Please try again.",
      );
      return;
    }
    const next = res.reply.trim();
    if (!next) {
      stopEnhanceProgress();
      setEnhanceError(
        "Enhance returned empty text. Try again or simplify the input.",
      );
      return;
    }

    synthesis.setText(next);
    void refreshBalance();
    await finishEnhanceProgress();
  };

  const handlePreview = async (voice: VoiceName) => {
    if (!isAuthenticated) {
      setAuthRequiredOpen(true);
      return;
    }
    if (previewPlayingId === voice) {
      previewRef.current?.pause();
      setPreviewPlayingId(null);
      return;
    }

    previewRef.current?.pause();
    setPreviewLoadingId(voice);

    const cached = previewCacheRef.current.get(voice);
    if (cached) {
      if (!previewRef.current) return;
      previewRef.current.src = cached;
      previewRef.current.onplay = () => {
        setPreviewLoadingId(null);
        setPreviewPlayingId(voice);
      };
      previewRef.current.onended = () => setPreviewPlayingId(null);
      void previewRef.current.play();
      return;
    }

    const voiceOption = AVAILABLE_VOICES.find((v) => v.id === voice);
    const previewText = getPreviewTextForVoice(voice);

    try {
      const url = await generateAzureSpeech(
        previewText, voice, 0, 0, 100, "general", 1.0, token,
      );
      previewCacheRef.current.set(voice, url);
      void refreshBalance();
      if (!previewRef.current) return;
      previewRef.current.src = url;
      previewRef.current.onplay = () => {
        setPreviewLoadingId(null);
        setPreviewPlayingId(voice);
      };
      previewRef.current.onended = () => setPreviewPlayingId(null);
      await previewRef.current.play();
    } catch {
      setPreviewLoadingId(null);
    }
  };

  const handleGenerateAction = async () => {
    if (synthesis.isProcessing || outputUploadInProgress) return;
    if (!requireProtectedAccess()) return;

    const ok = await dialog.confirm(
      `Generate audio now? This will use about ${estimatedMinutes.toFixed(2)} voice minute(s).`,
      {
        title: "Generate Audio",
        confirmText: "Generate",
        variant: "warning",
      },
    );
    if (!ok) return;
    clearGeneratedOutput();
    await synthesis.handleGenerate();
    const generatedEntry = synthesis.pendingEntry;
    if (!generatedEntry?.audioUrl) return;

    if (isAuthenticated && token) {
      await ensureGeneratedOutputStored();
    }
  };

  // Helper function to handle navigation with confirmation when editing completed steps
  const handleStepNavigation = async (targetStep: 1 | 2 | 3): Promise<boolean> => {
    const hasSubsequentProgress =
      (targetStep === 1 && (isStep2Complete || isStep3Complete)) ||
      (targetStep === 2 && isStep3Complete);

    if (hasSubsequentProgress) {
      const stepName = targetStep === 1 ? "Script" : "Voice Selection";
      const confirmEdit = await dialog.confirm(
        `Do you want to proceed with editing the ${stepName} step?`,
        {
          title: "Edit Previous Step",
          confirmText: "Yes, Proceed",
          cancelText: "Cancel",
          variant: "warning",
        }
      );

      if (!confirmEdit) return false;

      const wantToSave = await dialog.confirm(
        "Making changes to this step will clear the progress of subsequent completed steps.\n\nWould you like to save the current project before continuing?",
        {
          title: "Warning: Progress Will Be Lost",
          confirmText: "Save Project",
          cancelText: "Continue Without Saving",
          variant: "warning",
        }
      );

      if (wantToSave) {
        setPendingNavigationTarget(targetStep);
        if (isStep3Complete && synthesis.pendingEntry?.audioUrl) {
          openProjectModal("project");
        } else {
          openProjectModal("draft");
        }
        return false;
      }

      if (targetStep === 1) {
        synthesis.setPendingEntry(null);
        setOutputFileRecord(null);
        setMaxStepUnlocked(1);
      } else if (targetStep === 2) {
        synthesis.setPendingEntry(null);
        setOutputFileRecord(null);
        setMaxStepUnlocked(2);
      }
    }

    return true;
  };

  return (
    <div className="max-w-6xl mx-auto px-5 pb-3 space-y-4">
      <audio ref={previewRef} className="hidden" />
      <ProjectNameModal
        isOpen={Boolean(projectModalPurpose)}
        title={projectModalTitle}
        description={projectModalDescription}
        projectName={pendingProjectName}
        error={projectModalError}
        loading={projectModalLoading}
        progressPercent={projectModalPercent}
        statusMessage={projectModalStatusMessage}
        proceedDisabled={!pendingProjectName.trim()}
        onProjectNameChange={setPendingProjectName}
        onCancel={resetProjectModal}
        onProceed={handleProjectModalProceed}
      />

      <header className="flex items-start justify-between gap-6 relative">
        <div>
          <h1 className="m-0 text-2xl sm:text-3xl font-black leading-tight tracking-tight text-slate-900 dark:text-white">
            Create Voice
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl">
            A guided workflow to script, pick voice settings, and generate
            audio.
          </p>
        </div>
        <div className="flex items-center gap-2 relative">
          {!isGuest && (
            <button
              type="button"
              disabled={!canSaveDraft || Boolean(projectModalPurpose)}
              onClick={() => openProjectModal("draft")}
              title="Enter script text, then click Save Draft to name the project."
              className="px-3 py-2 rounded-lg bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Save Draft
            </button>
          )}
        </div>
      </header>

      {/* Progress Step Bar */}
      <ProgressStepBar
        steps={[
          {
            number: 1,
            title: "Script",
            status: step === 1 ? "active" : maxStepUnlocked >= 2 ? "completed" : "pending",
            isClickable: maxStepUnlocked >= 1 && step !== 1,
          },
          {
            number: 2,
            title: "Voice Selection",
            status: step === 2 ? "active" : maxStepUnlocked >= 3 ? "completed" : maxStepUnlocked >= 2 ? "pending" : "pending",
            isClickable: maxStepUnlocked >= 2 && step !== 2,
          },
          {
            number: 3,
            title: "Generate",
            status: step === 3 ? "active" : isStep3Complete ? "completed" : "pending",
            isClickable: maxStepUnlocked >= 3 && step !== 3,
          },
        ]}
        onStepClick={(stepNumber) => {
          if (stepNumber >= 1 && stepNumber <= maxStepUnlocked && stepNumber !== step) {
            void (async () => {
              const shouldProceed = await handleStepNavigation(stepNumber as 1 | 2 | 3);
              if (shouldProceed) {
                setStep(stepNumber as 1 | 2 | 3);
              }
            })();
          }
        }}
      />

      {/* Main content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Steps */}
        <div className="lg:col-span-12 space-y-6">
          {/* Step 1 - Script */}
          {step === 1 && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              <ScriptStep
              text={synthesis.text}
              onTextChange={(value) => {
                synthesis.setText(value);
              }}
              isDetecting={synthesis.isDetecting}
              detectedLang={synthesis.detectedLang}
              isRegional={isDetectedRegional}
              isTextTooLong={synthesis.isTextTooLong}
              estimatedMinutes={estimatedMinutes}
              isEnhancing={isEnhancing}
              enhancePercent={enhancePercent}
              enhanceError={enhanceError}
              onEnhance={handleEnhance}
            />
            </div>
          )}

          {/* Step 2 - Voice Selection */}
          {step === 2 && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              <VoiceSelectionStep
              languageLabel={
                synthesis.text.trim().length > 0
                  ? (synthesis.detectedLang && synthesis.detectedLang !== "Unknown"
                      ? synthesis.detectedLang
                      : language) || "Select Language"
                  : ""
              }
              voices={voicesForSelection}
              readOnly={!isStep1Complete}
              selectedVoice={synthesis.selectedVoice}
              onSelectVoice={synthesis.setSelectedVoice}
              previewLoadingId={previewLoadingId}
              previewPlayingId={previewPlayingId}
              onPreview={handlePreview}
              advancedOpen={advancedOpen}
              onToggleAdvanced={() => setAdvancedOpen((prev) => !prev)}
              rate={synthesis.rate}
              onRateChange={(value) => synthesis.setRate(value)}
              pitch={synthesis.pitch}
              onPitchChange={(value) => synthesis.setPitch(value)}
              searchQuery={voiceSearchQuery}
              onSearchChange={setVoiceSearchQuery}
              genderFilter={voiceGenderFilter}
              onGenderFilterChange={setVoiceGenderFilter}
              regionFilter={voiceRegionFilter}
              onRegionFilterChange={setVoiceRegionFilter}
            />
            </div>
          )}

          {/* Step 3 - Generate */}
          {step === 3 && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-4">
              <GenerateStep
              estimatedMinutes={estimatedMinutes}
              readOnly={!isStep1Complete}
              isProcessing={synthesis.isProcessing}
              progressPercent={synthesis.progress}
              isProjectModalOpen={Boolean(projectModalPurpose)}
              isTextEmpty={synthesis.isTextEmpty}
              isTextTooLong={synthesis.isTextTooLong}
              isMismatched={synthesis.isMismatched}
              error={synthesis.error}
              outputUploadError={outputUploadError}
              pendingAudioUrl={
                (synthesis.pendingEntry?.audioUrl as string | undefined) || null
              }
              outputFileRecord={outputFileRecord}
              outputUploadInProgress={outputUploadInProgress}
              outputDownloaded={outputDownloaded}
              fileActionKey={fileActionKey}
              retentionMessage={RETENTION_MESSAGE}
              isGuest={isGuest}
              onGenerate={() => {
                void handleGenerateAction();
              }}
              onSaveToProject={() => {
                if (!requireProtectedAccess()) return;
                if (saveToProjectInProgress || outputUploadInProgress) return;
                if (!synthesis.pendingEntry?.audioUrl) return;
                openProjectModal("project");
              }}
              onDownloadOutput={() => {
                void handleDownloadGeneratedOutput();
              }}
              onDeleteOutput={() => {
                void handleDeleteGeneratedOutput();
              }}
            />
            </div>
          )}
        </div>
      </div>

      {/* Bottom Action Bar */}
      <BottomActionBar
        currentStep={step}
        totalSteps={3}
        canGoBack={step > 1}
        canGoForward={
          step === 1
            ? canContinueFromScript
            : step === 2
              ? isStep1Complete
              : true
        }
        primaryActionLabel={
          step === 1
            ? "Continue"
            : step === 2
              ? "Continue"
              : isStep3Complete
                ? "Regenerate"
                : "Generate Voice"
        }
        primaryActionDisabled={
          step === 1
            ? !canContinueFromScript
            : step === 2
              ? !isStep1Complete
              : !isStep1Complete ||
                synthesis.isTextEmpty ||
                synthesis.isTextTooLong ||
                synthesis.isMismatched ||
                outputUploadInProgress
        }
        primaryActionLoading={
          uploadPercent > 0 || (step === 3 && synthesis.isProcessing) || (step === 1 && step1Loading)
        }
        primaryActionProgress={
          uploadPercent > 0 ? uploadPercent : (step === 3 ? synthesis.progress : 0)
        }
        showPrimaryAction={true}
        isGuestLocked={isGuest && step === 3}
        onPrevious={() => {
          if (step > 1) {
            void (async () => {
              const targetStep = (step - 1) as 1 | 2 | 3;
              const shouldProceed = await handleStepNavigation(targetStep);
              if (shouldProceed) {
                setStep(targetStep);
              }
            })();
          }
        }}
        onPrimaryAction={() => {
          if (step === 1) {
            if (isGuest) {
              setMaxStepUnlocked((prev) => (prev >= 2 ? prev : 2));
              setStep(2);
              return;
            }
            void (async () => {
              setStep1Loading(true);
              try {
                const projectId = ensureProject();
                if (!projectId) return;
                const storedScript = await storeCurrentScriptSample(projectId);
                if (synthesis.text.trim() && !storedScript) return;
                setMaxStepUnlocked((prev) => (prev >= 2 ? prev : 2));
                setStep(2);
              } finally {
                setStep1Loading(false);
              }
            })();
          } else if (step === 2) {
            setMaxStepUnlocked((prev) => (prev >= 3 ? prev : 3));
            setStep(3);
          } else if (step === 3) {
            void handleGenerateAction();
          }
        }}
      />

      <AuthRequiredModal
        isOpen={authRequiredOpen}
        onClose={() => setAuthRequiredOpen(false)}
        redirectTo="/create-voice"
        redirectState={
          selectedProjectId ? { projectId: selectedProjectId } : undefined
        }
      />
      <InsufficientCreditsModal
        isOpen={!!(insuffCredits || synthesis.insufficientCreditsInfo)}
        onClose={() => { setInsuffCredits(null); synthesis.clearInsuffCreditsInfo(); }}
        requiredCredits={(insuffCredits || synthesis.insufficientCreditsInfo)?.required ?? 0}
        currentBalance={(insuffCredits || synthesis.insufficientCreditsInfo)?.current ?? 0}
      />
    </div>
  );
};

export default CreateVoiceWizard;
