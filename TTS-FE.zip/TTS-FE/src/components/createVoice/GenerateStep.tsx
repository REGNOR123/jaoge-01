import React from "react";
import { Lock } from "lucide-react";
import type { StoredFileRecord } from "../../services/filesApiService";
import ProgressPill from "../ProgressPill";

const formatDateTime = (value?: string) => {
  if (!value) return "-";
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? "-" : parsed.toLocaleString();
};

const GenerateStep = ({
  estimatedMinutes,
  readOnly = false,
  isProcessing,
  progressPercent,
  isProjectModalOpen,
  isTextEmpty,
  isTextTooLong,
  isMismatched,
  error,
  outputUploadError,
  pendingAudioUrl,
  outputFileRecord,
  outputUploadInProgress,
  outputDownloaded,
  fileActionKey,
  retentionMessage,
  onGenerate,
  onSaveToProject,
  onDownloadOutput,
  onDeleteOutput,
  isGuest = false,
}: {
  estimatedMinutes: number;
  readOnly?: boolean;
  isProcessing: boolean;
  progressPercent: number;
  isProjectModalOpen: boolean;
  isTextEmpty: boolean;
  isTextTooLong: boolean;
  isMismatched: boolean;
  error: string | null;
  outputUploadError: string | null;
  pendingAudioUrl: string | null;
  outputFileRecord: StoredFileRecord | null;
  outputUploadInProgress: boolean;
  outputDownloaded: boolean;
  fileActionKey: string | null;
  retentionMessage: string;
  onGenerate: () => void;
  onSaveToProject: () => void;
  onDownloadOutput: () => void;
  onDeleteOutput: () => void;
  isGuest?: boolean;
}) => {
  const storageStatus = outputUploadInProgress
    ? "Uploading..."
    : outputDownloaded
      ? "Downloaded"
      : outputFileRecord?.fileId
        ? "Stored"
        : pendingAudioUrl
          ? "Pending"
          : "-";
  const hasOutput = Boolean(pendingAudioUrl);

  return (
    <section className="glass studio-card !p-8 space-y-6">
      <div>
        <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Generate
        </h2>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 font-medium">
          Generate your sample, store it securely, and save it to the project.
        </p>
      </div>

      {readOnly && (
        <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-slate-50/60 dark:bg-white/5 p-5 text-sm font-semibold text-slate-700 dark:text-slate-200">
          Complete Step 1 and Step 2 to generate audio.
        </div>
      )}

      <div className="rounded-2xl border border-sky-500/20 bg-sky-500/10 p-4 text-sm font-semibold text-sky-900 dark:text-sky-100">
        {retentionMessage}
      </div>

      {/* Status Messages */}
      {outputUploadInProgress && (
        <div className="rounded-2xl border border-indigo-500/20 bg-indigo-500/10 p-4">
          <div className="text-sm font-semibold text-indigo-900 dark:text-indigo-200 flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin"></div>
            Uploading generated audio to secure storage...
          </div>
        </div>
      )}

      {(error || outputUploadError) && (
        <div className="rounded-2xl border border-red-500/20 bg-red-500/10 p-4">
          <div className="text-sm font-semibold text-red-700 dark:text-red-300">
            {error || outputUploadError}
          </div>
        </div>
      )}

      {hasOutput && (
        <div className="space-y-4">
          <div className="rounded-3xl border border-black/5 dark:border-white/10 bg-white/50 dark:bg-white/5 p-5 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-400">
                Output
              </div>
              <div className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                Status: {storageStatus}
              </div>
            </div>
            <audio
              controls
              src={pendingAudioUrl || undefined}
              className="w-full"
              controlsList={isGuest ? "nodownload noplaybackrate" : undefined}
            />
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Stored until: {outputFileRecord?.expiresAt ? formatDateTime(outputFileRecord.expiresAt) : "24h retention"}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            {!isGuest && (
              <>
                <button
                  type="button"
                  onClick={onDownloadOutput}
                  disabled={fileActionKey === "download-output"}
                  className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {fileActionKey === "download-output" ? "Downloading..." : "Download"}
                </button>
                <button
                  type="button"
                  onClick={onDeleteOutput}
                  disabled={fileActionKey === "delete-output"}
                  className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 inline-flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {fileActionKey === "delete-output" ? "Deleting..." : "Delete"}
                </button>
              </>
            )}
            <button
              type="button"
              onClick={onSaveToProject}
              disabled={readOnly || outputUploadInProgress || isProjectModalOpen}
              className="px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-black uppercase tracking-widest transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isGuest ? "Sign Up to Save" : "Save to Project"}
            </button>
          </div>
        </div>
      )}
    </section>
  );
};

export default GenerateStep;
