import React from "react";
import AuthRequiredModal from "../AuthRequiredModal";
import InsufficientCreditsModal from "../InsufficientCreditsModal";
import ProjectNameModal from "../ProjectNameModal";
import ProgressStepBar from "../createVoice/ProgressStepBar";
import BottomActionBar from "../createVoice/BottomActionBar";
import { RETENTION_MESSAGE, type StepType } from "./constants";
import { useTranslateDubState } from "./useTranslateDubState";
import Step1InputContent from "./Step1InputContent";
import Step2ReviewVoice from "./Step2ReviewVoice";
import Step3Generate from "./Step3Generate";

const TranslateDubWizard: React.FC = () => {
  const state = useTranslateDubState();

  const {
    currentStep,
    setCurrentStep,
    maxStepUnlocked,
    handleStepNavigation,
    authRequiredOpen,
    setAuthRequiredOpen,
    activeProjectId,
    isGuest,
    isBusy,
    isStep1Valid,
    isStep1Complete,
    isStep2Valid,
    isStep3Ready,
    isStep3Complete,
    isTranslating,
    isTranscribing,
    isGenerating,
    translateInProgress,
    translatePercent,
    uploadPercent,
    generatePercent,
    error,
    lastAutoSave,

    // Project modal
    projectModalPurpose,
    pendingProjectName,
    setPendingProjectName,
    projectModalError,
    projectModalLoading,
    projectModalPercent,
    projectModalTitle,
    projectModalDescription,
    projectModalStatusMessage,
    resetProjectModal,
    openProjectModal,
    handleProjectModalProceed,

    // Actions
    handleStep1Continue,
    handleStep2Continue,
    handleGenerate,

    // Audio
    previewRef,
  } = state;

  return (
    <div className="max-w-6xl mx-auto px-5 pb-8 space-y-6">
      <AuthRequiredModal
        isOpen={authRequiredOpen}
        onClose={() => setAuthRequiredOpen(false)}
        redirectTo="/translate-dub"
        redirectState={
          activeProjectId
            ? { projectId: activeProjectId }
            : undefined
        }
      />
      <InsufficientCreditsModal
        isOpen={!!state.insufficientCreditsInfo}
        onClose={() => state.clearInsuffCreditsInfo()}
        requiredCredits={state.insufficientCreditsInfo?.required ?? 0}
        currentBalance={state.insufficientCreditsInfo?.current ?? 0}
      />
      <ProjectNameModal
        isOpen={Boolean(projectModalPurpose)}
        title={projectModalTitle}
        description={projectModalDescription}
        projectName={pendingProjectName}
        error={projectModalError}
        loading={projectModalLoading}
        progressPercent={projectModalPercent}
        statusMessage={projectModalStatusMessage}
        proceedDisabled={!pendingProjectName.trim()}
        onProjectNameChange={setPendingProjectName}
        onCancel={resetProjectModal}
        onProceed={handleProjectModalProceed}
      />
      <audio ref={previewRef} className="hidden" />

      {/* Header */}
      <header className="flex items-start justify-between gap-6 relative">
        <div>
          <h1 className="m-0 text-3xl sm:text-4xl font-black leading-tight tracking-tight text-slate-900 dark:text-white">
            Translate & Dub
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl">
            Transform text or audio into a dubbed voiceover with a
            streamlined 3-step workflow.
          </p>
          {/* Auto-save indicator (C13) */}
          {lastAutoSave && (
            <p className="mt-1 text-[10px] font-semibold text-slate-400 dark:text-slate-500">
              Draft saved at {lastAutoSave}
            </p>
          )}
        </div>

        <div className="flex items-center gap-2 relative">
          {!isGuest && (
            <button
              type="button"
              disabled={
                isBusy || Boolean(projectModalPurpose)
              }
              onClick={() => openProjectModal("draft")}
              className="px-4 py-3 rounded-xl bg-white/80 hover:bg-white dark:bg-white/10 dark:hover:bg-white/15 text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200 dark:border-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Upload content and click Save Draft to name the project."
            >
              Save Draft
            </button>
          )}
        </div>
      </header>

      {/* Progress Step Bar — 3 steps */}
      <ProgressStepBar
        steps={[
          {
            number: 1,
            title: "Input & Configure",
            status:
              currentStep === 1
                ? "active"
                : maxStepUnlocked >= 2
                  ? "completed"
                  : "pending",
            isClickable:
              maxStepUnlocked >= 1 && currentStep !== 1,
          },
          {
            number: 2,
            title: "Review & Voice",
            status:
              currentStep === 2
                ? "active"
                : maxStepUnlocked >= 3
                  ? "completed"
                  : maxStepUnlocked >= 2
                    ? "pending"
                    : "pending",
            isClickable:
              maxStepUnlocked >= 2 && currentStep !== 2,
          },
          {
            number: 3,
            title: "Generate",
            status:
              currentStep === 3
                ? "active"
                : isStep3Complete
                  ? "completed"
                  : "pending",
            isClickable:
              maxStepUnlocked >= 3 && currentStep !== 3,
          },
        ]}
        onStepClick={async (stepNumber) => {
          if (
            stepNumber >= 1 &&
            stepNumber <= maxStepUnlocked &&
            stepNumber !== currentStep
          ) {
            const shouldProceed =
              await handleStepNavigation(
                stepNumber as StepType,
              );
            if (shouldProceed) {
              setCurrentStep(stepNumber as StepType);
            }
          }
        }}
      />

      {/* Step announcement for screen readers (C9) */}
      <div aria-live="polite" className="sr-only">
        {currentStep === 1 && "Step 1: Input and Configure"}
        {currentStep === 2 && "Step 2: Review and Choose Voice"}
        {currentStep === 3 && "Step 3: Generate Dub"}
      </div>

      {/* Main content */}
      <div className="space-y-6">
        {currentStep === 1 && (
          <Step1InputContent state={state} />
        )}
        {currentStep === 2 && maxStepUnlocked >= 2 && (
          <Step2ReviewVoice state={state} />
        )}
        {currentStep === 3 && maxStepUnlocked >= 3 && (
          <Step3Generate state={state} />
        )}

        {/* Error */}
        {error && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
            <p className="text-red-600 dark:text-red-400 text-xs font-bold uppercase tracking-wide">
              {error}
            </p>
          </div>
        )}
      </div>

      {/* Bottom Action Bar */}
      <BottomActionBar
        currentStep={currentStep}
        totalSteps={3}
        canGoBack={currentStep > 1}
        canGoForward={
          currentStep === 1
            ? isStep1Valid
            : currentStep === 2
              ? isStep2Valid
              : true
        }
        primaryActionLabel={
          currentStep === 1
            ? (state.isSourceRegional || state.isTargetRegional)
                ? "Translate & Confirm (2× charge)"
                : "Translate & Continue"
            : currentStep === 2
              ? "Continue"
              : "Generate Dub"
        }
        primaryActionDisabled={
          currentStep === 1
            ? !isStep1Valid || isBusy
            : currentStep === 2
              ? !isStep2Valid || isBusy
              : !isStep3Ready || isBusy
        }
        primaryActionLoading={
          currentStep === 1
            ? isTranslating ||
              isTranscribing ||
              translateInProgress
            : currentStep === 3
              ? isGenerating
              : uploadPercent > 0
        }
        primaryActionProgress={
          uploadPercent > 0
            ? uploadPercent
            : currentStep === 1
              ? translatePercent
              : currentStep === 3
                ? generatePercent
                : 0
        }
        showPrimaryAction={
          currentStep !== 3 || !isStep3Complete
        }
        isGuestLocked={isGuest && (currentStep === 1 || currentStep === 3)}
        onPrevious={async () => {
          if (currentStep > 1) {
            const shouldProceed =
              await handleStepNavigation(
                (currentStep - 1) as StepType,
              );
            if (shouldProceed) {
              setCurrentStep(
                (currentStep - 1) as StepType,
              );
            }
          }
        }}
        onPrimaryAction={async () => {
          if (currentStep === 1) {
            await handleStep1Continue();
          } else if (currentStep === 2) {
            await handleStep2Continue();
          } else if (currentStep === 3) {
            await handleGenerate();
          }
        }}
      />
    </div>
  );
};

export default TranslateDubWizard;
