# API Endpoints & Services Reference

Complete reference of all backend API endpoints consumed by the TTS-FE frontend and the service modules that call them.

---

## Base URL

| Environment | Base URL |
|---|---|
| **Development** | `http://localhost:5127/api` |
| **Production** | `https://text-to-speeches-dotnet-be-h2e9gwgpc9g3h6hy.eastasia-01.azurewebsites.net/api` |
| **Override** | Set `VITE_API_BASE_URL` env variable |

All endpoint paths below are relative to this base URL (referred to as `API_BASE`).

---

## Authentication Headers

Most endpoints require a Bearer token in the `Authorization` header. Shared header utilities are in `src/services/apiUtils.ts`:

- **`getAuthHeaders(token)`** — returns `{ "Content-Type": "application/json", "Authorization": "Bearer <token>" }`
- **`getHeaders(token?)`** — same but token is optional (for public endpoints)

---

## 1. Authentication Service

**File:** `src/services/authApiService.ts`

### POST `/auth/signup`

Register a new user with email and password.

| Field | Detail |
|---|---|
| **Auth** | None |
| **Body** | `{ "fullName": string, "email": string, "password": string }` |
| **Response** | `{ success, message, user?: AuthUser, token?: string, verificationUrl?: string }` |
| **Errors** | Returns `errors[]` array for validation failures |

### POST `/auth/login`

Login with email and password.

| Field | Detail |
|---|---|
| **Auth** | None |
| **Body** | `{ "email": string, "password": string }` |
| **Response** | `{ success, user?: AuthUser, token?: string }` |

### POST `/auth/google`

Login or sign up via Google OAuth.

| Field | Detail |
|---|---|
| **Auth** | None |
| **Body** | `{ "idToken": string }` |
| **Response** | `{ success, user?: AuthUser, token?: string }` |

### GET `/auth/verify-email`

Verify email address using a token.

| Field | Detail |
|---|---|
| **Auth** | None |
| **Query** | `?token=<verification_token>` |
| **Response** | `{ success, message }` |

### POST `/auth/resend-verification`

Resend the verification email.

| Field | Detail |
|---|---|
| **Auth** | None |
| **Body** | `{ "email": string }` |
| **Response** | `{ success, message }` |

### GET `/auth/me`

Get the currently authenticated user.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Response** | `{ success, data: AuthUser }` |

### DELETE `/auth/delete-account`

Permanently delete the user's account.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Body** | `{ "email": string }` |
| **Response** | `{ success, message }` |

#### AuthUser Type

```typescript
{
  id: number;
  fullName: string;
  email: string;
  profilePicture?: string;
}
```

---

## 2. Speech Synthesis (TTS) Service

**File:** `src/services/azureService.ts`

### POST `/speech/tts`

Generate speech audio from text using Azure Neural Voices.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (optional, for usage tracking) |
| **Body** | `{ "text": string, "voice": VoiceName, "rate": number, "pitch": number, "volume": number, "style": SpeechStyle, "degree": number, "feature"?: string }` |
| **Response** | `{ success, data: { audioUrl: string } }` |
| **Returns** | Audio data URL (base64-encoded audio) |
| **Notes** | `feature` field identifies the calling page for usage tracking (e.g., `"create-voice"`, `"translate-dub"`) |

---

## 3. Language & Translation Service

**File:** `src/services/langService.ts`

### POST `/translator/detect`

Detect the language of input text.

| Field | Detail |
|---|---|
| **Auth** | None |
| **Body** | `{ "text": string }` (max 500 chars sent) |
| **Response** | `{ data: { language: string } }` or `{ language: string }` |
| **Returns** | ISO language code (e.g., `"en"`, `"fr"`, `"hi"`) |

### POST `/translator/translate`

Translate text to a target language.

| Field | Detail |
|---|---|
| **Auth** | None |
| **Body** | `{ "text": string, "to": string }` |
| **Response** | `{ data: { translatedText: string } }` or `{ translatedText: string }` |

---

## 4. Transcription Service

**File:** `src/services/transcribeService.ts`

### POST `/speech/transcribe`

Transcribe an audio file (WAV or MP3) to text.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (optional) |
| **Content-Type** | `multipart/form-data` |
| **Form Fields** | `audio`: File (WAV/MP3), `language`: string |
| **Response** | `{ data: { text: string, segments?: TranscribeSegment[], words?: TranscribeWord[] } }` |
| **Notes** | Timestamps are returned when available; client-side formatting applies `[MM:SS]` prefixes |

#### TranscribeSegment / TranscribeWord Types

```typescript
TranscribeSegment = { startMs: number; endMs: number; text: string }
TranscribeWord    = { startMs: number; endMs: number; word: string }
```

---

## 5. Speech Translation Service

**File:** `src/services/speechTranslateService.ts`

### POST `/speech/translate-speech`

Translate speech audio into one or more target languages, returning translated audio files.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (optional) |
| **Content-Type** | `multipart/form-data` |
| **Form Fields** | `audio`: File (WAV/MP3), `to`: string[] (one per target lang), `outputFormat`?: `"mp3"` \| `"wav"`, `defaultVoice`?: string, `jobId`?: string, `inputFileId`?: string, `voicesJson`?: JSON string mapping target lang to voice name |
| **Response** | `{ data: { detectedLanguage?: string, text?: string, translations?: Record<string, string>, audio?: Record<string, SpeechTranslateAudioItem> } }` |

#### SpeechTranslateAudioItem Type

```typescript
{
  fileId?: string;
  voice?: string;
  contentType?: string;
  fileName?: string;
  expiresAt?: string;
  base64?: string;
  dataUrl?: string;
}
```

---

## 6. File Management Service

**File:** `src/services/filesApiService.ts`

### POST `/files/upload`

Upload a managed file (audio, transcript, etc.) to Azure storage.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Content-Type** | `multipart/form-data` (no explicit Content-Type header; browser sets boundary) |
| **Form Fields** | `file`: File, `feature`: string, `jobId`?: string, `durationMinutes`?: string, `isOutput`?: `"true"` \| `"false"` |
| **Response** | `{ success, data: StoredFileRecord }` |
| **Notes** | Supports upload progress tracking via XMLHttpRequest when `onProgress` callback is provided |

### GET `/files/{fileId}`

Download a managed file by ID.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Response** | Binary blob with `Content-Disposition` header for filename |

### DELETE `/files/{fileId}`

Delete a managed file by ID.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Response** | `{ success }` |

#### StoredFileRecord Type

```typescript
{
  fileId: string;
  fileName: string;
  contentType?: string;
  feature?: string;
  jobId?: string;
  durationMinutes?: number | null;
  isOutput?: boolean;
  uploadedAt?: string;
  expiresAt?: string;
  sizeBytes?: number | null;
}
```

---

## 7. Billing Service

**File:** `src/services/billingApiService.ts`

All billing endpoints support env variable overrides for the URL (e.g., `VITE_BILLING_SUMMARY_ENDPOINT`).

### GET `/billing/summary`

Fetch billing plan summary.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Env Override** | `VITE_BILLING_SUMMARY_ENDPOINT` |
| **Response** | `{ success, data: BillingSummary }` |

### GET `/billing/metrics`

Fetch billing metrics (spend, next billing amount).

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Env Override** | `VITE_BILLING_METRICS_ENDPOINT` |
| **Response** | `{ success, data: BillingMetrics }` |

### GET `/billing/payment-method`

Fetch the saved payment method.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Env Override** | `VITE_BILLING_PAYMENT_METHOD_ENDPOINT` |
| **Response** | `{ success, data: PaymentMethod }` |

### GET `/billing/invoices`

Fetch invoice history.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Env Override** | `VITE_INVOICES_ENDPOINT` |
| **Response** | `{ success, data: Invoice[] }` |

### POST `/billing/payment-method/update`

Initiate payment method update (returns a portal URL).

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Env Override** | `VITE_BILLING_UPDATE_PAYMENT_ENDPOINT` |
| **Body** | `{}` |
| **Response** | `{ success, data: { portalUrl: string } }` |

### POST `/billing/cancel`

Cancel the current subscription.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Env Override** | `VITE_BILLING_CANCEL_ENDPOINT` |
| **Body** | `{}` |
| **Response** | `{ success, data: { ok: true } }` |

#### Billing Types

```typescript
BillingSummary = {
  planName: string | null;
  planBadge: string | null;
  planPrice: number | null;
  planCurrency: string | null;
  planInterval: string | null;
  cycleStart: string | null;
  cycleEnd: string | null;
  nextBillingDate: string | null;
  daysRemaining: number | null;
}

BillingMetrics = {
  currentPlanPrice: number | null;
  currentCycleSpend: number | null;
  totalSpend: number | null;
  nextBillingAmount: number | null;
  currency: string | null;
}

PaymentMethod = {
  cardBrand: string | null;
  last4: string | null;
  expiryMonth: number | null;
  expiryYear: number | null;
  billingEmail: string | null;
}

Invoice = {
  id: string;
  date: string;
  number?: string;
  amount?: number | null;
  currency?: string;
  status?: string;
  downloadUrl?: string;
}
```

---

## 8. Payment Service (Razorpay)

**File:** `src/services/paymentApiService.ts`

### POST `/payment/create-order`

Create a Razorpay payment order.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Body** | `{ "planId": string }` |
| **Response** | `{ success, data: CreateOrderResponse }` |

### POST `/payment/verify-payment`

Verify a completed Razorpay payment.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Body** | `{ "razorpay_order_id": string, "razorpay_payment_id": string, "razorpay_signature": string }` |
| **Response** | `{ success, data: { verified: true, planId?: string, status?: string } }` |

#### CreateOrderResponse Type

```typescript
{
  orderId: string;
  amount: number;
  currency: string;
  keyId: string;
  plan?: {
    id: string;
    name: string;
    durationDays: number;
  };
}
```

---

## 9. Usage Service

**File:** `src/services/usageApiService.ts`

### GET `/usage/summary`

Fetch simple usage summary (totals without plan/quota details).

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Query** | `?startDate=<ISO>&endDate=<ISO>` (both optional) |
| **Response** | `{ success, data: SimpleUsageSummary }` |

### GET `/usage/detailed`

Fetch full usage data with all cards (totals, quotas, breakdown, plan details, alerts).

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Query** | `?filter=<daily|weekly|monthly|custom>&startDate=<ISO>&endDate=<ISO>` |
| **Response** | `{ success, data: DetailedUsageResponse }` |

### GET `/usage/breakdown`

Fetch paginated per-feature usage breakdown.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Query** | `?page=<n>&pageSize=<n>&sortBy=<field>&descending=<bool>&filter=<type>&startDate=<ISO>&endDate=<ISO>` |
| **Response** | `{ success, data: UsageBreakdown }` |

### GET `/usage/history`

Fetch usage history data points for charts.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (required) |
| **Query** | `?filter=<daily|weekly|monthly|custom>&days=<n>&feature=<string>` |
| **Response** | `{ success, data: UsageHistoryResponse }` |

#### Usage Types

```typescript
SimpleUsageSummary = {
  totalCharacters: number;
  totalMinutes: number;
  totalEnhancements: number;
  totalRequests: number;
  byFeature: FeatureUsageSummary[];
}

DetailedUsageResponse = {
  totalUsage: TotalUsageCard;
  remainingQuota: QuotaCard;
  breakdown: UsageBreakdown;
  planDetails: PlanDetails;
  alerts: UsageAlerts;
}

UsageHistoryResponse = {
  dataPoints: UsageHistoryPoint[];
  filter: string;
  feature: string | null;
  totalDays: number;
}

UsageHistoryPoint = {
  date: string;
  minutes: number;
  characters: number;
  requests: number;
  enhancements: number;
}
```

---

## 10. Script Studio Service

**File:** `src/services/scriptStudioService.ts`

### POST `/script-generation/{sku}`

Generate a full script for a given SKU type.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (optional) |
| **Path Params** | `sku`: `"youtube"` \| `"short"` \| `"podcast"` \| `"explainer"` \| `"custom"` |
| **Body** | `{ "inputs": Record<string, string>, "tone": string, "length"?: string }` |
| **Response** | `{ script: string, metadata?: { estimatedReadTime?: string, sections?: string[] } }` |

### POST `/script-generation/{sku}/generate-field`

Auto-generate a single form field value using AI.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (optional) |
| **Path Params** | `sku`: ScriptSKU |
| **Body** | `{ "fieldId": string, "context": Record<string, string> }` |
| **Response** | `{ content: string }` or `{ fieldValue: string }` |

### POST `/script-generation/{sku}/transform`

Transform an existing script (rewrite, shorten, expand, change tone).

| Field | Detail |
|---|---|
| **Auth** | Bearer token (optional) |
| **Path Params** | `sku`: ScriptSKU |
| **Body** | `{ "script": string, "transformation": "rewrite" | "shorten" | "expand" | "tone-change", "tone"?: string }` |
| **Response** | `{ script: string }` or `{ content: string }` |

---

## 11. Chat Service

**File:** `src/services/chatApiService.ts`

### POST `/chat`

Send a message to the AI chat assistant.

| Field | Detail |
|---|---|
| **Auth** | Bearer token (optional) |
| **Body** | `{ "message": string, "systemPrompt"?: string, "prompt": string, "system"?: string }` |
| **Response** | `{ success, reply: string }` or OpenAI-compatible `{ choices: [{ message: { content } }] }` |
| **Notes** | `prompt` and `system` are compatibility aliases for `message` and `systemPrompt` |

---

## 12. Serverless Azure Function (Chat Proxy)

**Files:** `api/chat/complete/index.js`, `api/chat/complete/function.json`

### POST `/api/chat/complete`

Proxies chat completion requests to Azure OpenAI or standard OpenAI endpoints. This is a server-side Azure Function, not called directly by the frontend service layer (the frontend calls `/chat` via `chatApiService.ts`, which the backend routes accordingly).

| Field | Detail |
|---|---|
| **Auth** | Anonymous (function-level) |
| **Body** | `{ "message": string, "history"?: ChatMessage[], "systemPrompt"?: string, "model"?: string, "temperature"?: number, "maxTokens"?: number }` |
| **Response** | `{ success, data: { message: string, model: string, usage: { promptTokens, completionTokens, totalTokens } } }` |

#### Environment Variables

| Variable | Required | Description |
|---|---|---|
| `OPENAI_ENDPOINT` | Yes | Azure OpenAI or standard OpenAI endpoint URL |
| `OPENAI_API_KEY` | Yes | API key for the endpoint |
| `OPENAI_MODEL` | Yes (or in request) | Model/deployment name |
| `OPENAI_API_VERSION` | No | Azure API version (default: `2024-02-15-preview`) |

---

## 13. Shared API Utilities

**File:** `src/services/apiUtils.ts`

Shared helper functions used by all service modules:

| Function | Signature | Description |
|---|---|---|
| `parseBody` | `(response: Response) => Promise<any>` | Parses response body as JSON if content-type is `application/json`, otherwise wraps text in `{ message }` |
| `getAuthHeaders` | `(token: string) => Record<string, string>` | Returns `Content-Type` + `Authorization` headers |
| `getHeaders` | `(token?: string \| null) => Record<string, string>` | Same as above but token is optional |

**File:** `src/services/apiBase.ts`

| Export | Description |
|---|---|
| `API_BASE` | Resolved API base URL (includes `/api` suffix) |
| `resolveApiBase()` | Resolution logic: env override > localhost detection > production URL |

---

## Endpoint Summary Table

| # | Method | Endpoint | Auth | Service File |
|---|---|---|---|---|
| 1 | POST | `/auth/signup` | No | `authApiService.ts` |
| 2 | POST | `/auth/login` | No | `authApiService.ts` |
| 3 | POST | `/auth/google` | No | `authApiService.ts` |
| 4 | GET | `/auth/verify-email` | No | `authApiService.ts` |
| 5 | POST | `/auth/resend-verification` | No | `authApiService.ts` |
| 6 | GET | `/auth/me` | Yes | `authApiService.ts` |
| 7 | DELETE | `/auth/delete-account` | Yes | `authApiService.ts` |
| 8 | POST | `/speech/tts` | Optional | `azureService.ts` |
| 9 | POST | `/translator/detect` | No | `langService.ts` |
| 10 | POST | `/translator/translate` | No | `langService.ts` |
| 11 | POST | `/speech/transcribe` | Optional | `transcribeService.ts` |
| 12 | POST | `/speech/translate-speech` | Optional | `speechTranslateService.ts` |
| 13 | POST | `/files/upload` | Yes | `filesApiService.ts` |
| 14 | GET | `/files/{fileId}` | Yes | `filesApiService.ts` |
| 15 | DELETE | `/files/{fileId}` | Yes | `filesApiService.ts` |
| 16 | GET | `/billing/summary` | Yes | `billingApiService.ts` |
| 17 | GET | `/billing/metrics` | Yes | `billingApiService.ts` |
| 18 | GET | `/billing/payment-method` | Yes | `billingApiService.ts` |
| 19 | GET | `/billing/invoices` | Yes | `billingApiService.ts` |
| 20 | POST | `/billing/payment-method/update` | Yes | `billingApiService.ts` |
| 21 | POST | `/billing/cancel` | Yes | `billingApiService.ts` |
| 22 | POST | `/payment/create-order` | Yes | `paymentApiService.ts` |
| 23 | POST | `/payment/verify-payment` | Yes | `paymentApiService.ts` |
| 24 | GET | `/usage/summary` | Yes | `usageApiService.ts` |
| 25 | GET | `/usage/detailed` | Yes | `usageApiService.ts` |
| 26 | GET | `/usage/breakdown` | Yes | `usageApiService.ts` |
| 27 | GET | `/usage/history` | Yes | `usageApiService.ts` |
| 28 | POST | `/script-generation/{sku}` | Optional | `scriptStudioService.ts` |
| 29 | POST | `/script-generation/{sku}/generate-field` | Optional | `scriptStudioService.ts` |
| 30 | POST | `/script-generation/{sku}/transform` | Optional | `scriptStudioService.ts` |
| 31 | POST | `/chat` | Optional | `chatApiService.ts` |

**Total: 31 API endpoints across 11 service modules.**
